#!/bin/bash
set -e

# =============================================================================
# SCRIPT RESTORE ÚLTIMO BACKUP POSTGRESQL - PLATAFORMA BI UCV
# =============================================================================
# Archivo sugerido:
#   scripts/restore_latest_databases.sh
#
# Objetivo:
# Restaurar automáticamente el último backup disponible de todas las bases
# PostgreSQL del proyecto:
#
#   1. bi_ucv
#      Data Warehouse principal.
#
#   2. n8n_app
#      Metadata interna de n8n.
#
#   3. metabase_app
#      Metadata interna de Metabase.
#
# Además:
#   - Restaura roles y usuarios globales desde el último globals_roles_*.sql.
#   - Detiene n8n y Metabase antes de restaurar sus bases.
#   - Usa pg_restore para backups en formato custom (.dump).
#   - Guarda logs de restauración.
#
# IMPORTANTE:
# Este script sobrescribe el estado actual de las bases con el último backup.
# Usarlo solo cuando se desea recuperar o migrar un ambiente completo.
# =============================================================================


# =============================================================================
# 1. UBICAR DIRECTORIO BASE DEL PROYECTO
# =============================================================================
# Permite ejecutar el script desde cualquier ubicación.
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

ENV_FILE="$PROJECT_DIR/.env"
BACKUP_DIR="$PROJECT_DIR/backups"
LOG_DIR="$BACKUP_DIR/logs"


# =============================================================================
# 2. CARGAR VARIABLES DE ENTORNO
# =============================================================================

if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
else
    echo "[ERROR] Archivo .env no encontrado en: $ENV_FILE"
    exit 1
fi


# =============================================================================
# 3. VALIDAR VARIABLES REQUERIDAS
# =============================================================================

: "${DB_NAME:?ERROR: DB_NAME no definido}"
: "${DB_USER:?ERROR: DB_USER no definido}"
: "${N8N_DB_NAME:?ERROR: N8N_DB_NAME no definido}"
: "${MB_DB_NAME:?ERROR: MB_DB_NAME no definido}"


# =============================================================================
# 4. CONFIGURACIÓN GENERAL
# =============================================================================

CONTAINER_NAME="ucv_bi_db"

DATE="$(date +"%Y%m%d_%H%M%S")"
LOG_FILE="$LOG_DIR/restore_${DATE}.log"

DATABASES=(
    "$DB_NAME"
    "$N8N_DB_NAME"
    "$MB_DB_NAME"
)


# =============================================================================
# 5. CREAR DIRECTORIO DE LOGS SI NO EXISTE
# =============================================================================

mkdir -p "$LOG_DIR"


# =============================================================================
# 6. FUNCIONES AUXILIARES
# =============================================================================

log() {
    echo "$1" | tee -a "$LOG_FILE"
}


buscar_ultimo_archivo() {
    local patron="$1"
    local archivo

    archivo="$(ls -1t $patron 2>/dev/null | head -n 1 || true)"

    if [ -z "$archivo" ]; then
        return 1
    fi

    echo "$archivo"
    return 0
}


validar_contenedor_activo() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        log "[ERROR] El contenedor $CONTAINER_NAME no está activo."
        log "[INFO] Levanta PostgreSQL primero con:"
        log "       docker compose up -d db"
        exit 1
    fi
}


validar_base_existe() {
    local database="$1"

    if ! docker exec "$CONTAINER_NAME" psql \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -tAc "SELECT 1 FROM pg_database WHERE datname='${database}'" | grep -q 1; then

        log "[ERROR] La base de datos $database no existe."
        log "[INFO] Verifica que init-db/00_create_app_databases.sh se haya ejecutado correctamente."
        exit 1
    fi
}


restaurar_base() {
    local database="$1"
    local backup_file="$2"
    local backup_filename

    backup_filename="$(basename "$backup_file")"

    log "------------------------------------------------------------"
    log "[INFO] Restaurando base: $database"
    log "[INFO] Archivo: $backup_filename"

    docker exec -i "$CONTAINER_NAME" pg_restore \
        -U "$DB_USER" \
        -d "$database" \
        --clean \
        --if-exists \
        "/backups/$backup_filename" >> "$LOG_FILE" 2>&1

    log "[OK] Base restaurada correctamente: $database"
}


# =============================================================================
# 7. INICIO DEL PROCESO
# =============================================================================

log "============================================================"
log "INICIO RESTAURACIÓN ÚLTIMO BACKUP: $(date)"
log "CONTENEDOR: $CONTAINER_NAME"
log "DIRECTORIO BACKUP: $BACKUP_DIR"
log "============================================================"


# =============================================================================
# 8. VALIDACIONES INICIALES
# =============================================================================

if [ ! -d "$BACKUP_DIR" ]; then
    log "[ERROR] Directorio de backups no existe: $BACKUP_DIR"
    exit 1
fi

validar_contenedor_activo


# =============================================================================
# 9. MOSTRAR BACKUPS QUE SERÁN RESTAURADOS
# =============================================================================

GLOBALS_FILE="$(buscar_ultimo_archivo "$BACKUP_DIR/globals_roles_*.sql" || true)"
BI_BACKUP="$(buscar_ultimo_archivo "$BACKUP_DIR/backup_${DB_NAME}_*.dump" || true)"
N8N_BACKUP="$(buscar_ultimo_archivo "$BACKUP_DIR/backup_${N8N_DB_NAME}_*.dump" || true)"
MB_BACKUP="$(buscar_ultimo_archivo "$BACKUP_DIR/backup_${MB_DB_NAME}_*.dump" || true)"

if [ -z "$GLOBALS_FILE" ]; then
    log "[ERROR] No se encontró backup de roles: globals_roles_*.sql"
    exit 1
fi

if [ -z "$BI_BACKUP" ]; then
    log "[ERROR] No se encontró backup de base: backup_${DB_NAME}_*.dump"
    exit 1
fi

if [ -z "$N8N_BACKUP" ]; then
    log "[ERROR] No se encontró backup de base: backup_${N8N_DB_NAME}_*.dump"
    exit 1
fi

if [ -z "$MB_BACKUP" ]; then
    log "[ERROR] No se encontró backup de base: backup_${MB_DB_NAME}_*.dump"
    exit 1
fi

log "[INFO] Últimos backups detectados:"
log "       Roles:     $(basename "$GLOBALS_FILE")"
log "       $DB_NAME:     $(basename "$BI_BACKUP")"
log "       $N8N_DB_NAME:    $(basename "$N8N_BACKUP")"
log "       $MB_DB_NAME:    $(basename "$MB_BACKUP")"


# =============================================================================
# 10. CONFIRMACIÓN DEL USUARIO
# =============================================================================
# Se solicita confirmación para evitar restauraciones accidentales.
# =============================================================================

echo ""
echo "ADVERTENCIA:"
echo "Este proceso restaurará las bases con el último backup encontrado."
echo "Se sobrescribirá el estado actual de:"
echo "  - $DB_NAME"
echo "  - $N8N_DB_NAME"
echo "  - $MB_DB_NAME"
echo ""
read -p "¿Deseas continuar? Escribe SI para continuar: " CONFIRMACION

if [ "$CONFIRMACION" != "SI" ]; then
    log "[INFO] Restauración cancelada por el usuario."
    exit 0
fi


# =============================================================================
# 11. DETENER SERVICIOS QUE USAN LAS BASES
# =============================================================================
# Se detienen n8n y Metabase para evitar conexiones activas durante el restore.
# PostgreSQL debe permanecer activo.
# =============================================================================

log "------------------------------------------------------------"
log "[INFO] Deteniendo n8n y Metabase antes de restaurar..."

docker compose -f "$PROJECT_DIR/docker-compose.yml" stop n8n metabase >> "$LOG_FILE" 2>&1 || true

log "[OK] Servicios detenidos o ya estaban detenidos."


# =============================================================================
# 12. VALIDAR EXISTENCIA DE BASES DE DATOS
# =============================================================================

for DATABASE in "${DATABASES[@]}"; do
    validar_base_existe "$DATABASE"
done


# =============================================================================
# 13. RESTAURAR ROLES Y USUARIOS GLOBALES
# =============================================================================
# Este paso es especialmente útil en restauraciones sobre servidores nuevos.
# Si los roles ya existen, PostgreSQL puede emitir avisos/errores de duplicidad.
# Por eso se ejecuta antes de restaurar las bases.
# =============================================================================

log "------------------------------------------------------------"
log "[INFO] Restaurando roles globales desde: $(basename "$GLOBALS_FILE")"

docker exec -i "$CONTAINER_NAME" psql \
    -U "$DB_USER" \
    -d "$DB_NAME" \
    < "$GLOBALS_FILE" >> "$LOG_FILE" 2>&1 || true

log "[OK] Proceso de roles globales finalizado."


# =============================================================================
# 14. RESTAURAR BASES DE DATOS
# =============================================================================

restaurar_base "$DB_NAME" "$BI_BACKUP"
restaurar_base "$N8N_DB_NAME" "$N8N_BACKUP"
restaurar_base "$MB_DB_NAME" "$MB_BACKUP"


# =============================================================================
# 15. LEVANTAR NUEVAMENTE SERVICIOS
# =============================================================================

log "------------------------------------------------------------"
log "[INFO] Levantando n8n y Metabase..."

docker compose -f "$PROJECT_DIR/docker-compose.yml" up -d n8n metabase >> "$LOG_FILE" 2>&1

log "[OK] Servicios levantados."


# =============================================================================
# 16. FIN DEL PROCESO
# =============================================================================

log "============================================================"
log "FIN RESTAURACIÓN ÚLTIMO BACKUP: $(date)"
log "ESTADO: EXITOSO"
log "============================================================"

exit 0