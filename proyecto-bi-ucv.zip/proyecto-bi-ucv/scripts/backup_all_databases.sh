#!/bin/bash
set -e

# =============================================================================
# SCRIPT BACKUP POSTGRESQL - PLATAFORMA BI UCV
# =============================================================================
# Archivo sugerido:
#   scripts/backup_all_databases.sh
#
# Objetivo:
# Respaldar todas las bases PostgreSQL del proyecto:
#
#   1. bi_ucv
#      Data Warehouse principal.
#
#   2. n8n_app
#      Metadata interna de n8n.
#
#   3. metabase_app
#      Metadata interna de Metabase.
#
# Además:
#   - Genera backup de roles y usuarios PostgreSQL.
#   - Guarda logs por ejecución.
#   - Elimina backups antiguos según política de retención.
#   - Es compatible con CRON.
#   - Documenta comandos de restauración por consola.
#   - Documenta configuración recomendada de crontab.
# =============================================================================


# =============================================================================
# 1. UBICAR DIRECTORIO BASE DEL PROYECTO
# =============================================================================
# Permite ejecutar el script desde cualquier ubicación, incluso desde CRON.
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

ENV_FILE="$PROJECT_DIR/.env"
BACKUP_DIR="$PROJECT_DIR/backups"
LOG_DIR="$BACKUP_DIR/logs"


# =============================================================================
# 2. CARGAR VARIABLES DE ENTORNO
# =============================================================================

if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
else
    echo "[ERROR] Archivo .env no encontrado en: $ENV_FILE"
    exit 1
fi


# =============================================================================
# 3. VALIDAR VARIABLES REQUERIDAS
# =============================================================================

: "${DB_NAME:?ERROR: DB_NAME no definido}"
: "${DB_USER:?ERROR: DB_USER no definido}"
: "${N8N_DB_NAME:?ERROR: N8N_DB_NAME no definido}"
: "${MB_DB_NAME:?ERROR: MB_DB_NAME no definido}"


# =============================================================================
# 4. CONFIGURACIÓN GENERAL
# =============================================================================

CONTAINER_NAME="ucv_bi_db"

DATE="$(date +"%Y%m%d_%H%M%S")"
LOG_FILE="$LOG_DIR/backup_${DATE}.log"

# Retención de backups en días.
RETENTION_DAYS=15

# Bases de datos a respaldar.
DATABASES=(
    "$DB_NAME"
    "$N8N_DB_NAME"
    "$MB_DB_NAME"
)


# =============================================================================
# 5. CREAR DIRECTORIOS SI NO EXISTEN
# =============================================================================

mkdir -p "$BACKUP_DIR"
mkdir -p "$LOG_DIR"


# =============================================================================
# 6. INICIO DEL LOG
# =============================================================================

{
    echo "============================================================"
    echo "INICIO BACKUP GENERAL: $(date)"
    echo "CONTENEDOR: $CONTAINER_NAME"
    echo "DIRECTORIO BACKUP: $BACKUP_DIR"
    echo "RETENCIÓN: $RETENTION_DAYS días"
    echo "============================================================"
} >> "$LOG_FILE"


# =============================================================================
# 7. VALIDAR QUE EL CONTENEDOR POSTGRESQL ESTÉ ACTIVO
# =============================================================================

if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "[ERROR] El contenedor $CONTAINER_NAME no está activo." >> "$LOG_FILE"
    exit 1
fi


# =============================================================================
# 8. BACKUP DE ROLES Y USUARIOS POSTGRESQL
# =============================================================================
# pg_dump no incluye roles/usuarios globales.
# Este respaldo permite reconstruir usuarios y permisos globales.
# =============================================================================

GLOBALS_FILE="globals_roles_${DATE}.sql"

echo "[INFO] Generando respaldo de roles globales: $GLOBALS_FILE" >> "$LOG_FILE"

if docker exec "$CONTAINER_NAME" pg_dumpall \
    -U "$DB_USER" \
    --globals-only \
    -f "/backups/$GLOBALS_FILE"; then

    echo "[OK] Respaldo de roles generado correctamente." >> "$LOG_FILE"

else

    echo "[ERROR] Falló respaldo de roles globales." >> "$LOG_FILE"
    exit 1

fi


# =============================================================================
# 9. BACKUP INDIVIDUAL DE CADA BASE DE DATOS
# =============================================================================
# Se usa formato custom (-F c), recomendado para recuperación con pg_restore.
# Ventajas:
#   - Más eficiente que SQL plano.
#   - Permite restauración selectiva.
#   - Mejor manejo de bases medianas/grandes.
# =============================================================================

for DATABASE in "${DATABASES[@]}"; do

    BACKUP_FILE="backup_${DATABASE}_${DATE}.dump"

    echo "------------------------------------------------------------" >> "$LOG_FILE"
    echo "[INFO] Iniciando backup de base: $DATABASE" >> "$LOG_FILE"
    echo "[INFO] Archivo: $BACKUP_FILE" >> "$LOG_FILE"

    if docker exec "$CONTAINER_NAME" pg_dump \
        -U "$DB_USER" \
        -d "$DATABASE" \
        -F c \
        -f "/backups/$BACKUP_FILE"; then

        echo "[OK] Backup generado correctamente para: $DATABASE" >> "$LOG_FILE"

    else

        echo "[ERROR] Falló backup de base: $DATABASE" >> "$LOG_FILE"
        exit 1

    fi

done


# =============================================================================
# 10. LIMPIEZA DE BACKUPS ANTIGUOS
# =============================================================================

echo "------------------------------------------------------------" >> "$LOG_FILE"
echo "[INFO] Eliminando backups con más de $RETENTION_DAYS días..." >> "$LOG_FILE"

find "$BACKUP_DIR" -name "*.dump" -type f -mtime +"$RETENTION_DAYS" -delete
find "$BACKUP_DIR" -name "globals_roles_*.sql" -type f -mtime +"$RETENTION_DAYS" -delete
find "$LOG_DIR" -name "backup_*.log" -type f -mtime +"$RETENTION_DAYS" -delete

echo "[OK] Limpieza de backups antiguos completada." >> "$LOG_FILE"


# =============================================================================
# 11. FIN DEL PROCESO
# =============================================================================

{
    echo "============================================================"
    echo "FIN BACKUP GENERAL: $(date)"
    echo "ESTADO: EXITOSO"
    echo "============================================================"
} >> "$LOG_FILE"

exit 0


# =============================================================================
# DOCUMENTACIÓN DE USO, CRONTAB Y RESTAURACIÓN
# =============================================================================
# Esta sección es solo documental.
# NO se ejecuta porque está después de "exit 0".
# =============================================================================


# =============================================================================
# A. UBICACIÓN RECOMENDADA DEL SCRIPT
# =============================================================================
# Estructura sugerida:
#
# proyecto-bi-ucv/
# ├── docker-compose.yml
# ├── .env
# ├── backups/
# │   └── logs/
# └── scripts/
#     └── backup_all_databases.sh
#
# Dar permisos de ejecución:
#
# chmod +x scripts/backup_all_databases.sh
#
# Ejecutar manualmente desde la raíz del proyecto:
#
# ./scripts/backup_all_databases.sh
#
# Verificar archivos generados:
#
# ls -lh backups/
# ls -lh backups/logs/
# =============================================================================


# =============================================================================
# B. CONFIGURACIÓN DE CRONTAB PARA BACKUP PERIÓDICO
# =============================================================================
# CRON permite programar la ejecución automática del respaldo.
#
# Abrir el editor de cron del usuario actual:
#
# crontab -e
#
# Formato general de una línea CRON:
#
# ┌───────────── minuto        0 - 59
# │ ┌─────────── hora          0 - 23
# │ │ ┌───────── día del mes   1 - 31
# │ │ │ ┌─────── mes           1 - 12
# │ │ │ │ ┌───── día semana    0 - 7  (0 y 7 = domingo)
# │ │ │ │ │
# * * * * * comando
#
# Ejemplo 1:
# Ejecutar backup todos los días a las 2:00 AM:
#
# 0 2 * * * /ruta/completa/proyecto-bi-ucv/scripts/backup_all_databases.sh
#
# Ejemplo real:
#
# 0 2 * * * /home/usuario/Documentos/proyecto-bi-ucv/scripts/backup_all_databases.sh
#
# Ejemplo 2:
# Ejecutar backup todos los días a las 2:00 AM y guardar salida CRON:
#
# 0 2 * * * /home/usuario/Documentos/proyecto-bi-ucv/scripts/backup_all_databases.sh >> /home/usuario/Documentos/proyecto-bi-ucv/backups/logs/cron_backup.log 2>&1
#
# Ejemplo 3:
# Ejecutar backup dos veces al día, a las 2:00 AM y 2:00 PM:
#
# 0 2,14 * * * /home/usuario/Documentos/proyecto-bi-ucv/scripts/backup_all_databases.sh
#
# Ejemplo 4:
# Ejecutar backup solo de lunes a viernes a las 11:30 PM:
#
# 30 23 * * 1-5 /home/usuario/Documentos/proyecto-bi-ucv/scripts/backup_all_databases.sh
#
# Ver tareas cron configuradas:
#
# crontab -l
#
# Ver logs del servicio cron en Ubuntu/Debian:
#
# grep CRON /var/log/syslog
#
# Verificar que el backup se ejecutó:
#
# ls -lh /home/usuario/Documentos/proyecto-bi-ucv/backups/
# ls -lh /home/usuario/Documentos/proyecto-bi-ucv/backups/logs/
#
# Recomendación:
# Usar rutas absolutas en CRON, no rutas relativas.
# =============================================================================


# =============================================================================
# C. RECOMENDACIÓN OPERATIVA PARA RESPALDOS
# =============================================================================
# Frecuencia sugerida:
#
# - Desarrollo local:
#   Backup manual antes de cambios importantes.
#
# - Producción pequeña:
#   Backup automático diario a las 2:00 AM.
#
# - Producción con alta actividad:
#   Backup automático dos veces al día.
#
# Retención sugerida:
#
# - 15 días para ambiente de pruebas.
# - 30 días para producción básica.
# - 90 días si la institución requiere mayor histórico.
#
# Recomendación adicional:
# Copiar periódicamente la carpeta backups/ a otro medio o servidor externo.
# Un backup guardado únicamente dentro del mismo VPS no protege ante pérdida
# completa del servidor.
# =============================================================================


# =============================================================================
# D. RESTAURAR ROLES Y USUARIOS GLOBALES
# =============================================================================
# Este paso se usa cuando se restaura en un PostgreSQL nuevo o vacío.
#
# Reemplazar la fecha por el archivo real existente en backups/.
#
# Comando:
#
# docker exec -i ucv_bi_db psql \
#   -U admin_ucv \
#   -d bi_ucv \
#   < backups/globals_roles_YYYYMMDD_HHMMSS.sql
#
# Ejemplo:
#
# docker exec -i ucv_bi_db psql \
#   -U admin_ucv \
#   -d bi_ucv \
#   < backups/globals_roles_20260528_020000.sql
# =============================================================================


# =============================================================================
# E. RESTAURAR BASE PRINCIPAL DATA WAREHOUSE: bi_ucv
# =============================================================================
# Esta base contiene:
#   - staging
#   - dw
#   - audit
#   - datamart
#
# Recomendado cuando se requiere recuperar el modelo BI completo.
#
# Comando:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d bi_ucv \
#   --clean \
#   --if-exists \
#   /backups/backup_bi_ucv_YYYYMMDD_HHMMSS.dump
#
# Ejemplo:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d bi_ucv \
#   --clean \
#   --if-exists \
#   /backups/backup_bi_ucv_20260528_020000.dump
# =============================================================================


# =============================================================================
# F. RESTAURAR BASE INTERNA DE N8N: n8n_app
# =============================================================================
# Esta base contiene:
#   - workflows
#   - credenciales cifradas
#   - historial de ejecuciones
#   - configuración interna de n8n
#
# Antes de restaurar se recomienda detener n8n:
#
# docker compose stop n8n
#
# Luego restaurar:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d n8n_app \
#   --clean \
#   --if-exists \
#   /backups/backup_n8n_app_YYYYMMDD_HHMMSS.dump
#
# Ejemplo:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d n8n_app \
#   --clean \
#   --if-exists \
#   /backups/backup_n8n_app_20260528_020000.dump
#
# Después:
#
# docker compose start n8n
# =============================================================================


# =============================================================================
# G. RESTAURAR BASE INTERNA DE METABASE: metabase_app
# =============================================================================
# Esta base contiene:
#   - usuarios
#   - dashboards
#   - preguntas
#   - permisos
#   - configuración interna de Metabase
#
# Antes de restaurar se recomienda detener Metabase:
#
# docker compose stop metabase
#
# Luego restaurar:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d metabase_app \
#   --clean \
#   --if-exists \
#   /backups/backup_metabase_app_YYYYMMDD_HHMMSS.dump
#
# Ejemplo:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d metabase_app \
#   --clean \
#   --if-exists \
#   /backups/backup_metabase_app_20260528_020000.dump
#
# Después:
#
# docker compose start metabase
# =============================================================================


# =============================================================================
# H. RESTAURACIÓN COMPLETA DEL AMBIENTE
# =============================================================================
# Escenario:
# Se necesita restaurar todo el ambiente PostgreSQL en un servidor nuevo.
#
# Pasos sugeridos:
#
# 1. Levantar solo PostgreSQL:
#
#    docker compose up -d db
#
# 2. Verificar que PostgreSQL esté activo:
#
#    docker ps
#
# 3. Restaurar roles globales:
#
#    docker exec -i ucv_bi_db psql \
#      -U admin_ucv \
#      -d bi_ucv \
#      < backups/globals_roles_YYYYMMDD_HHMMSS.sql
#
# 4. Restaurar bi_ucv:
#
#    docker exec -i ucv_bi_db pg_restore \
#      -U admin_ucv \
#      -d bi_ucv \
#      --clean \
#      --if-exists \
#      /backups/backup_bi_ucv_YYYYMMDD_HHMMSS.dump
#
# 5. Restaurar n8n_app:
#
#    docker exec -i ucv_bi_db pg_restore \
#      -U admin_ucv \
#      -d n8n_app \
#      --clean \
#      --if-exists \
#      /backups/backup_n8n_app_YYYYMMDD_HHMMSS.dump
#
# 6. Restaurar metabase_app:
#
#    docker exec -i ucv_bi_db pg_restore \
#      -U admin_ucv \
#      -d metabase_app \
#      --clean \
#      --if-exists \
#      /backups/backup_metabase_app_YYYYMMDD_HHMMSS.dump
#
# 7. Levantar todos los servicios:
#
#    docker compose up -d
#
# 8. Verificar logs:
#
#    docker logs ucv_bi_db
#    docker logs ucv_bi_n8n
#    docker logs ucv_bi_metabase
# =============================================================================


# =============================================================================
# I. VALIDAR ARCHIVO BACKUP ANTES DE RESTAURAR
# =============================================================================
# Se puede inspeccionar el contenido de un .dump antes de restaurar:
#
# docker exec -it ucv_bi_db pg_restore \
#   -l /backups/backup_bi_ucv_YYYYMMDD_HHMMSS.dump
#
# Ejemplo:
#
# docker exec -it ucv_bi_db pg_restore \
#   -l /backups/backup_bi_ucv_20260528_020000.dump
# =============================================================================


# =============================================================================
# J. RESTAURACIÓN SELECTIVA DE UNA TABLA
# =============================================================================
# Ejemplo para restaurar una tabla específica del Data Warehouse:
#
# docker exec -i ucv_bi_db pg_restore \
#   -U admin_ucv \
#   -d bi_ucv \
#   --clean \
#   --if-exists \
#   -t dw.dim_tiempo \
#   /backups/backup_bi_ucv_YYYYMMDD_HHMMSS.dump
#
# Nota:
# La restauración selectiva debe usarse con cuidado cuando existen relaciones
# de llaves foráneas.
# =============================================================================