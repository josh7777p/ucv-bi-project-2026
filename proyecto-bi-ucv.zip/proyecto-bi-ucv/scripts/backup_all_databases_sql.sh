#!/bin/bash
set -euo pipefail

# =============================================================================
# SCRIPT BACKUP POSTGRESQL EN FORMATO .SQL - PLATAFORMA BI UCV
# =============================================================================
# Archivo sugerido:
#   scripts/backup_all_databases_sql.sh
#
# Objetivo:
# Respaldar todas las bases PostgreSQL del proyecto en formato SQL plano:
#   - Estructura de la base de datos.
#   - Datos mediante comandos INSERT con columnas.
#   - Roles y usuarios globales en archivo separado.
#
# Diferencia frente al backup .dump:
#   - Este script genera .sql legible.
#   - Usa --column-inserts para que la data quede como INSERT INTO tabla (...)
#     VALUES (...).
#   - El archivo puede ser mucho más grande y más lento de restaurar que .dump.
# =============================================================================


# =============================================================================
# 1. UBICAR DIRECTORIO BASE DEL PROYECTO
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

ENV_FILE="$PROJECT_DIR/.env"
BACKUP_DIR="$PROJECT_DIR/backups"
LOG_DIR="$BACKUP_DIR/logs"


# =============================================================================
# 2. CARGAR VARIABLES DE ENTORNO
# =============================================================================

if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
else
    echo "[ERROR] Archivo .env no encontrado en: $ENV_FILE"
    exit 1
fi


# =============================================================================
# 3. VALIDAR VARIABLES REQUERIDAS
# =============================================================================

: "${DB_NAME:?ERROR: DB_NAME no definido}"
: "${DB_USER:?ERROR: DB_USER no definido}"
: "${N8N_DB_NAME:?ERROR: N8N_DB_NAME no definido}"
: "${MB_DB_NAME:?ERROR: MB_DB_NAME no definido}"


# =============================================================================
# 4. CONFIGURACIÓN GENERAL
# =============================================================================

CONTAINER_NAME="${DB_CONTAINER_NAME:-ucv_bi_db}"

DATE="$(date +"%Y%m%d_%H%M%S")"
LOG_FILE="$LOG_DIR/backup_sql_${DATE}.log"

# Puedes sobreescribir esto en el .env:
# BACKUP_RETENTION_DAYS=15
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-15}"

# Opcional en .env:
# BACKUP_SQL_COMPRESS=true
COMPRESS_SQL="${BACKUP_SQL_COMPRESS:-false}"

DATABASES=(
    "$DB_NAME"
    "$N8N_DB_NAME"
    "$MB_DB_NAME"
)


# =============================================================================
# 5. CREAR DIRECTORIOS SI NO EXISTEN
# =============================================================================

mkdir -p "$BACKUP_DIR"
mkdir -p "$LOG_DIR"


# =============================================================================
# 6. INICIO DEL LOG
# =============================================================================

{
    echo "============================================================"
    echo "INICIO BACKUP SQL GENERAL: $(date)"
    echo "CONTENEDOR: $CONTAINER_NAME"
    echo "DIRECTORIO BACKUP: $BACKUP_DIR"
    echo "RETENCIÓN: $RETENTION_DAYS días"
    echo "COMPRESIÓN SQL: $COMPRESS_SQL"
    echo "============================================================"
} >> "$LOG_FILE"


# =============================================================================
# 7. VALIDAR QUE EL CONTENEDOR POSTGRESQL ESTÉ ACTIVO
# =============================================================================

if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "[ERROR] El contenedor $CONTAINER_NAME no está activo." >> "$LOG_FILE"
    exit 1
fi


# =============================================================================
# 8. VALIDAR DIRECTORIO /backups EN EL CONTENEDOR
# =============================================================================
# Este script asume que el docker-compose monta:
#
#   ./backups:/backups
#
# Si no está montado así, los archivos podrían quedar dentro del contenedor y no
# en la carpeta backups del proyecto.
# =============================================================================

docker exec "$CONTAINER_NAME" mkdir -p /backups


# =============================================================================
# 9. BACKUP DE ROLES Y USUARIOS GLOBALES
# =============================================================================
# pg_dump no incluye roles/usuarios globales. Por eso se respaldan aparte.
# =============================================================================

GLOBALS_FILE="globals_roles_${DATE}.sql"

echo "[INFO] Generando respaldo de roles globales: $GLOBALS_FILE" >> "$LOG_FILE"

if docker exec "$CONTAINER_NAME" pg_dumpall     -U "$DB_USER"     --globals-only     --file="/backups/$GLOBALS_FILE"; then

    echo "[OK] Respaldo de roles generado correctamente." >> "$LOG_FILE"

else

    echo "[ERROR] Falló respaldo de roles globales." >> "$LOG_FILE"
    exit 1

fi


# =============================================================================
# 10. BACKUP INDIVIDUAL DE CADA BASE EN FORMATO SQL PLANO
# =============================================================================
# Opciones principales:
#
# --format=plain
#   Genera archivo .sql.
#
# --create
#   Incluye CREATE DATABASE y conexión a la base.
#
# --clean --if-exists
#   Agrega DROP antes de crear objetos, evitando errores si no existen.
#
# --column-inserts
#   Genera INSERT INTO tabla (col1, col2, ...) VALUES (...).
#
# --no-owner
#   Evita depender del propietario original exacto.
#
# --no-privileges
#   Evita incluir GRANT/REVOKE por objeto.
# =============================================================================

for DATABASE in "${DATABASES[@]}"; do

    BACKUP_FILE="backup_${DATABASE}_${DATE}.sql"

    echo "------------------------------------------------------------" >> "$LOG_FILE"
    echo "[INFO] Iniciando backup SQL de base: $DATABASE" >> "$LOG_FILE"
    echo "[INFO] Archivo: $BACKUP_FILE" >> "$LOG_FILE"

    if docker exec "$CONTAINER_NAME" pg_dump         -U "$DB_USER"         -d "$DATABASE"         --format=plain         --create         --clean         --if-exists         --column-inserts         --no-owner         --no-privileges         --encoding=UTF8         --file="/backups/$BACKUP_FILE"; then

        echo "[OK] Backup SQL generado correctamente para: $DATABASE" >> "$LOG_FILE"

    else

        echo "[ERROR] Falló backup SQL de base: $DATABASE" >> "$LOG_FILE"
        exit 1

    fi

done


# =============================================================================
# 11. COMPRESIÓN OPCIONAL
# =============================================================================

if [ "$COMPRESS_SQL" = "true" ]; then
    echo "------------------------------------------------------------" >> "$LOG_FILE"
    echo "[INFO] Comprimiendo archivos .sql..." >> "$LOG_FILE"

    for SQL_FILE in "$BACKUP_DIR"/backup_*_"$DATE".sql "$BACKUP_DIR"/globals_roles_"$DATE".sql; do
        if [ -f "$SQL_FILE" ]; then
            gzip -f "$SQL_FILE"
            echo "[OK] Comprimido: $(basename "$SQL_FILE").gz" >> "$LOG_FILE"
        fi
    done
fi


# =============================================================================
# 12. LIMPIEZA DE BACKUPS ANTIGUOS
# =============================================================================

echo "------------------------------------------------------------" >> "$LOG_FILE"
echo "[INFO] Eliminando backups con más de $RETENTION_DAYS días..." >> "$LOG_FILE"

find "$BACKUP_DIR" -name "*.sql" -type f -mtime +"$RETENTION_DAYS" -delete
find "$BACKUP_DIR" -name "*.sql.gz" -type f -mtime +"$RETENTION_DAYS" -delete
find "$BACKUP_DIR" -name "*.dump" -type f -mtime +"$RETENTION_DAYS" -delete
find "$BACKUP_DIR" -name "globals_roles_*.sql" -type f -mtime +"$RETENTION_DAYS" -delete
find "$BACKUP_DIR" -name "globals_roles_*.sql.gz" -type f -mtime +"$RETENTION_DAYS" -delete
find "$LOG_DIR" -name "backup_*.log" -type f -mtime +"$RETENTION_DAYS" -delete
find "$LOG_DIR" -name "backup_sql_*.log" -type f -mtime +"$RETENTION_DAYS" -delete

echo "[OK] Limpieza de backups antiguos completada." >> "$LOG_FILE"


# =============================================================================
# 13. FIN DEL PROCESO
# =============================================================================

{
    echo "============================================================"
    echo "FIN BACKUP SQL GENERAL: $(date)"
    echo "ESTADO: EXITOSO"
    echo "============================================================"
} >> "$LOG_FILE"

exit 0


# =============================================================================
# DOCUMENTACIÓN DE USO
# =============================================================================
# Ubicación recomendada:
#
# proyecto-bi-ucv/
# ├── docker-compose.yml
# ├── .env
# ├── backups/
# │   └── logs/
# └── scripts/
#     └── backup_all_databases_sql.sh
#
# Permisos:
#
# chmod +x scripts/backup_all_databases_sql.sh
#
# Ejecución manual:
#
# ./scripts/backup_all_databases_sql.sh
#
# Verificar archivos:
#
# ls -lh backups/
# ls -lh backups/logs/
#
# Validar que el archivo tiene INSERT:
#
# grep -n "INSERT INTO" backups/backup_bi_ucv_YYYYMMDD_HHMMSS.sql | head
#
# Restaurar roles:
#
# docker exec -i ucv_bi_db psql \
#   -U admin_ucv \
#   -d postgres \
#   < backups/globals_roles_YYYYMMDD_HHMMSS.sql
#
# Restaurar una base completa:
#
# docker exec -i ucv_bi_db psql \
#   -U admin_ucv \
#   -d postgres \
#   < backups/backup_bi_ucv_YYYYMMDD_HHMMSS.sql
#
# Para restaurar n8n o Metabase, detener primero el servicio:
#
# docker compose stop n8n
# docker exec -i ucv_bi_db psql -U admin_ucv -d postgres < backups/backup_n8n_app_YYYYMMDD_HHMMSS.sql
# docker compose start n8n
#
# docker compose stop metabase
# docker exec -i ucv_bi_db psql -U admin_ucv -d postgres < backups/backup_metabase_app_YYYYMMDD_HHMMSS.sql
# docker compose start metabase
#
# CRON diario a las 2:00 AM:
#
# 0 2 * * * /ruta/completa/proyecto-bi-ucv/scripts/backup_all_databases_sql.sh >> /ruta/completa/proyecto-bi-ucv/backups/logs/cron_backup_sql.log 2>&1
# =============================================================================
