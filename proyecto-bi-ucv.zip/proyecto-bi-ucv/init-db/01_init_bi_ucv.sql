-- =============================================================================
-- PROYECTO:
-- DATA WAREHOUSE PARA REDES SOCIALES Y PORTALES WEB UCV
--
-- ARQUITECTURA:
-- METODOLOGÍA RALPH KIMBALL + DATA MARTS + STAGING + AUDITORÍA ETL
--
-- OBJETIVO:
-- Implementar un modelo dimensional escalable para integrar publicaciones,
-- métricas de interacción y crecimiento de comunidad provenientes de múltiples
-- redes sociales, portales web y APIs públicas. El modelo conserva soporte
-- para RSS/scraping como mecanismos alternativos, pero para Noticiencias UCV
-- se prioriza WordPress REST API al estar públicamente disponible.
--
-- ESQUEMAS:
--   staging   = Zona de aterrizaje ETL / datos de origen y datos normalizados previos al DW
--   dw        = Data Warehouse dimensional basado en Ralph Kimball
--   audit     = Auditoría, trazabilidad, control de calidad y monitoreo ETL
--   datamart  = Vistas analíticas y materialized views para Metabase
--
-- TECNOLOGÍAS:
-- PostgreSQL + n8n + Metabase + Docker
--
-- CRITERIOS DE DISEÑO:
-- ✔ Modelo dimensional con llaves surrogate
-- ✔ Soporte multired social y multiperfil
-- ✔ Soporte para pieza comunicacional publicada en varias plataformas
-- ✔ Métricas acumuladas y variaciones frente a observaciones anteriores para análisis por rangos de fecha
-- ✔ Métricas flexibles mediante dimensión de tipo de métrica
-- ✔ Trazabilidad de ejecuciones ETL
-- ✔ Zona staging para reprocesamiento y auditoría técnica
-- ✔ Vistas optimizadas para tableros en Metabase
-- ✔ Documentación exhaustiva mediante comentarios en línea y COMMENT ON
-- ✔ Convención de nombres en español para facilitar mantenimiento académico y técnico
-- ✔ Términos descriptivos: origen, normalizada, variación, respuesta_json
-- =============================================================================


-- =============================================================================
-- 1. CREACIÓN DE ESQUEMAS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- SCHEMA: staging
-- FUNCIÓN:
-- Zona de aterrizaje y preparación ETL. Aquí se almacenan respuestas de origen
-- de APIs/scraping/RSS y registros normalizados antes de ser cargados al DW.
-- -----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS staging;

-- -----------------------------------------------------------------------------
-- SCHEMA: dw
-- FUNCIÓN:
-- Data Warehouse dimensional principal. Contiene dimensiones conformadas y
-- tablas de hechos alineadas con la metodología de Ralph Kimball.
-- -----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS dw;

-- -----------------------------------------------------------------------------
-- SCHEMA: audit
-- FUNCIÓN:
-- Esquema de auditoría para registrar ejecuciones ETL, errores, validaciones,
-- conteos de registros y controles de calidad.
-- -----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS audit;

-- -----------------------------------------------------------------------------
-- SCHEMA: datamart
-- FUNCIÓN:
-- Capa de consumo analítico. Contiene vistas y materialized views para Metabase,
-- evitando que los tableros consulten directamente estructuras operativas.
-- -----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS datamart;


-- =============================================================================
-- 2. TABLAS STAGING (DATOS DE ORIGEN Y NORMALIZADOS)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- TABLA: staging.stg_registro_origen
-- FUNCIÓN:
-- Tabla genérica de aterrizaje. Guarda la respuesta original completa recibida
-- desde cualquier fuente digital. Permite reprocesar datos sin consultar de nuevo
-- la API y conservar evidencia técnica ante fallos o cambios de estructura.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staging.stg_registro_origen (
    id_staging BIGSERIAL PRIMARY KEY, -- Identificador técnico interno del registro de origen.
    id_ejecucion_n8n TEXT, -- Identificador de ejecución o workflow en n8n que originó el registro.
    plataforma TEXT NOT NULL, -- Nombre de la plataforma de origen: Facebook, Instagram, YouTube, X, TikTok, Web, etc.
    fuente TEXT, -- Cuenta, página, canal, perfil, RSS o portal específico desde donde se obtuvo el dato.
    tipo_registro TEXT NOT NULL, -- Tipo de dato capturado: PUBLICACION, METRICA_PUBLICACION, COMUNIDAD, COMENTARIO, OTRO.
    identificador_origen TEXT, -- ID nativo del registro en la plataforma de origen, si existe.
    url_origen TEXT, -- URL pública o técnica asociada al registro extraído.
    endpoint_origen TEXT, -- Endpoint API, URL RSS o URL de scraping consultada.
    metodo_extraccion TEXT NOT NULL DEFAULT 'API', -- Método de extracción: API, RSS, SCRAPING, CSV, MANUAL u OTRO.
    respuesta_json JSONB NOT NULL, -- Respuesta original completa en formato JSONB para trazabilidad y reprocesamiento.
    hash_respuesta TEXT, -- Hash de la respuesta original para detectar duplicados o cambios entre extracciones.
    fecha_publicacion_origen TIMESTAMPTZ, -- Fecha/hora de publicación reportada por la fuente, cuando aplique.
    fecha_extraccion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora en que n8n o el ETL extrajo el dato.
    estado_procesamiento TEXT NOT NULL DEFAULT 'PENDIENTE', -- Estado ETL: PENDIENTE, PROCESADO, DESCARTADO, ERROR.
    mensaje_procesamiento TEXT, -- Mensaje técnico del procesamiento, error o justificación de descarte.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro en staging.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de última actualización del registro en staging.
);

-- -----------------------------------------------------------------------------
-- TABLA: staging.stg_publicacion_normalizada
-- FUNCIÓN:
-- Tabla de preparación con estructura común para publicaciones provenientes de
-- múltiples plataformas. Permite convertir datos heterogéneos en un contrato
-- estable antes de cargar dimensiones y hechos.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staging.stg_publicacion_normalizada (
    id_stg_publicacion BIGSERIAL PRIMARY KEY, -- Identificador técnico del registro normalizado de publicación.
    id_staging BIGINT REFERENCES staging.stg_registro_origen(id_staging), -- Referencia opcional al dato de origen que generó este registro.
    id_ejecucion_n8n TEXT, -- Identificador de ejecución n8n asociado a la transformación.
    plataforma TEXT NOT NULL, -- Plataforma donde fue detectada la publicación.
    fuente TEXT NOT NULL, -- Cuenta, perfil, canal o portal específico de publicación.
    identificador_publicacion_origen TEXT, -- ID nativo de la publicación en la plataforma.
    url_origen TEXT, -- URL pública de la publicación.
    titulo TEXT, -- Título, encabezado o descripción corta del contenido.
    cuerpo TEXT, -- Texto principal o cuerpo de la publicación.
    autor TEXT, -- Autor o responsable identificado, si aplica.
    tipo_contenido TEXT, -- Tipo de contenido: post, reel, story, video, short, nota web, carrusel, etc.
    categoria TEXT, -- Categoría temática del contenido, cuando se pueda clasificar.
    titulo_normalizado TEXT, -- Título común para agrupar una misma pieza comunicacional publicada en varias plataformas.
    slug_contenido TEXT, -- Código/slug común de la pieza comunicacional para análisis multicanal.
    fecha_publicacion TIMESTAMPTZ NOT NULL, -- Fecha/hora original de publicación.
    hash_contenido TEXT, -- Hash del contenido normalizado para apoyar detección de duplicados.
    metadata_json JSONB, -- Metadatos normalizados relevantes que no ameritan columna propia.
    procesado BOOLEAN NOT NULL DEFAULT FALSE, -- Indica si el registro ya fue cargado al DW.
    mensaje_procesamiento TEXT, -- Observación o error asociado al procesamiento hacia el DW.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de creación del registro normalizado.
);

-- -----------------------------------------------------------------------------
-- TABLA: staging.stg_metricas_publicacion_normalizada
-- FUNCIÓN:
-- Prepara métricas observadas por publicación antes de cargarlas a los hechos.
-- Incluye totales observados y variaciones calculadas cuando el proceso ETL dispone
-- de una observación anterior comparable.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staging.stg_metricas_publicacion_normalizada (
    id_stg_metrica BIGSERIAL PRIMARY KEY, -- Identificador técnico del registro normalizado de métricas.
    id_staging BIGINT REFERENCES staging.stg_registro_origen(id_staging), -- Referencia opcional al dato de origen que generó las métricas.
    id_ejecucion_n8n TEXT, -- Identificador de ejecución n8n asociado a la extracción de métricas.
    plataforma TEXT NOT NULL, -- Plataforma donde se observó la métrica.
    fuente TEXT NOT NULL, -- Cuenta, perfil, canal o portal donde se observó la métrica.
    identificador_publicacion_origen TEXT, -- ID nativo de la publicación a la que pertenecen las métricas.
    url_origen TEXT, -- URL de la publicación, útil cuando la API no suministra ID estable.
    fecha_observacion DATE NOT NULL, -- Día al que corresponde la observación de métricas.
    likes_total BIGINT DEFAULT 0 CHECK (likes_total >= 0), -- Total acumulado de likes observado en la fecha de extracción.
    likes_variacion BIGINT DEFAULT 0, -- Diferencia de likes frente a la observación anterior registrada.
    comentarios_total BIGINT DEFAULT 0 CHECK (comentarios_total >= 0), -- Total acumulado de comentarios observado.
    comentarios_variacion BIGINT DEFAULT 0, -- Diferencia de comentarios frente a la observación anterior.
    compartidos_total BIGINT DEFAULT 0 CHECK (compartidos_total >= 0), -- Total acumulado de compartidos/reposts observado.
    compartidos_variacion BIGINT DEFAULT 0, -- Diferencia de compartidos/reposts frente a la observación anterior.
    guardados_total BIGINT DEFAULT 0 CHECK (guardados_total >= 0), -- Total acumulado de guardados/bookmarks observado, si la plataforma lo permite.
    guardados_variacion BIGINT DEFAULT 0, -- Diferencia de guardados/bookmarks frente a la observación anterior.
    vistas_total BIGINT DEFAULT 0 CHECK (vistas_total >= 0), -- Total acumulado de vistas/reproducciones observado.
    vistas_variacion BIGINT DEFAULT 0, -- Diferencia de vistas/reproducciones frente a la observación anterior.
    alcance_total BIGINT DEFAULT 0 CHECK (alcance_total >= 0), -- Total acumulado o estimado de alcance observado, cuando exista.
    alcance_variacion BIGINT DEFAULT 0, -- Diferencia de alcance frente a la observación anterior.
    impresiones_total BIGINT DEFAULT 0 CHECK (impresiones_total >= 0), -- Total acumulado de impresiones observado, cuando exista.
    impresiones_variacion BIGINT DEFAULT 0, -- Diferencia de impresiones frente a la observación anterior.
    reacciones_positivas_total BIGINT DEFAULT 0 CHECK (reacciones_positivas_total >= 0), -- Total acumulado de reacciones clasificadas como positivas.
    reacciones_positivas_variacion BIGINT DEFAULT 0, -- Diferencia de reacciones positivas frente a la observación anterior.
    reacciones_negativas_total BIGINT DEFAULT 0 CHECK (reacciones_negativas_total >= 0), -- Total acumulado de reacciones clasificadas como negativas.
    reacciones_negativas_variacion BIGINT DEFAULT 0, -- Diferencia de reacciones negativas frente a la observación anterior.
    reacciones_neutrales_total BIGINT DEFAULT 0 CHECK (reacciones_neutrales_total >= 0), -- Total acumulado de reacciones clasificadas como neutrales.
    reacciones_neutrales_variacion BIGINT DEFAULT 0, -- Diferencia de reacciones neutrales frente a la observación anterior.
    metadata_json JSONB, -- Métricas adicionales o propias de cada plataforma aún no modeladas en columnas.
    procesado BOOLEAN NOT NULL DEFAULT FALSE, -- Indica si el registro fue cargado a las tablas de hechos.
    mensaje_procesamiento TEXT, -- Observación o error asociado al procesamiento hacia el DW.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de creación del registro normalizado de métricas.
);

-- -----------------------------------------------------------------------------
-- TABLA: staging.stg_comunidad_normalizada
-- FUNCIÓN:
-- Prepara snapshots diarios de comunidad/perfil. Permite medir crecimiento de
-- seguidores/suscriptores a partir de diferencias entre observaciones.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staging.stg_comunidad_normalizada (
    id_stg_comunidad BIGSERIAL PRIMARY KEY, -- Identificador técnico del snapshot normalizado de comunidad.
    id_staging BIGINT REFERENCES staging.stg_registro_origen(id_staging), -- Referencia opcional al dato de origen que generó el snapshot.
    id_ejecucion_n8n TEXT, -- Identificador de ejecución n8n asociado al snapshot.
    plataforma TEXT NOT NULL, -- Plataforma donde se observó la comunidad.
    fuente TEXT NOT NULL, -- Cuenta, perfil, canal o portal analizado.
    identificador_fuente_origen TEXT, -- ID nativo de la fuente/perfil/canal en la plataforma.
    fecha_observacion DATE NOT NULL, -- Día al que corresponde el snapshot de comunidad.
    total_seguidores BIGINT DEFAULT 0 CHECK (total_seguidores >= 0), -- Total acumulado de seguidores/suscriptores observado.
    seguidores_variacion BIGINT DEFAULT 0, -- Diferencia de seguidores frente a la observación anterior.
    total_publicaciones_perfil BIGINT DEFAULT 0 CHECK (total_publicaciones_perfil >= 0), -- Total acumulado de publicaciones reportado por el perfil/canal.
    publicaciones_perfil_variacion BIGINT DEFAULT 0, -- Diferencia de publicaciones del perfil frente a la observación anterior.
    vistas_totales_perfil BIGINT DEFAULT 0 CHECK (vistas_totales_perfil >= 0), -- Total acumulado de vistas del perfil/canal, si aplica.
    vistas_perfil_variacion BIGINT DEFAULT 0, -- Diferencia de vistas del perfil/canal frente a la observación anterior.
    metadata_json JSONB, -- Datos adicionales del perfil/canal no modelados en columnas específicas.
    procesado BOOLEAN NOT NULL DEFAULT FALSE, -- Indica si el snapshot fue cargado al DW.
    mensaje_procesamiento TEXT, -- Observación o error asociado al procesamiento hacia el DW.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de creación del snapshot normalizado.
);


-- =============================================================================
-- 3. DIMENSIONES CONFORMADAS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_tiempo
-- FUNCIÓN:
-- Calendario maestro con granularidad diaria. Permite analizar métricas por día,
-- semana, mes, trimestre, año y rangos personalizados en Metabase.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_tiempo (
    id_tiempo INT PRIMARY KEY, -- Llave inteligente en formato YYYYMMDD.
    fecha DATE NOT NULL UNIQUE, -- Fecha calendario estándar.
    dia INT NOT NULL CHECK (dia BETWEEN 1 AND 31), -- Número de día del mes.
    mes INT NOT NULL CHECK (mes BETWEEN 1 AND 12), -- Número de mes del año.
    nombre_mes TEXT NOT NULL, -- Nombre del mes para visualización.
    anho INT NOT NULL, -- Año calendario en formato YYYY.
    dia_semana INT NOT NULL CHECK (dia_semana BETWEEN 1 AND 7), -- Día ISO de semana: 1=Lunes, 7=Domingo.
    nombre_dia TEXT NOT NULL, -- Nombre del día de la semana.
    trimestre INT NOT NULL CHECK (trimestre BETWEEN 1 AND 4), -- Trimestre calendario.
    semana_anio INT NOT NULL CHECK (semana_anio BETWEEN 1 AND 53), -- Semana ISO del año.
    es_fin_de_semana BOOLEAN NOT NULL DEFAULT FALSE, -- Indica si la fecha corresponde a sábado o domingo.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de creación del registro calendario.
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_plataforma
-- FUNCIÓN:
-- Catálogo de plataformas digitales. Permite incorporar nuevas redes sociales,
-- portales web u otras fuentes sin alterar el modelo de hechos.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_plataforma (
    id_plataforma BIGSERIAL PRIMARY KEY, -- Llave surrogate de la plataforma.
    nombre_plataforma TEXT NOT NULL UNIQUE, -- Nombre de la plataforma: Facebook, Instagram, YouTube, X, TikTok, Web, etc.
    tipo_fuente TEXT NOT NULL, -- Clasificación: RED_SOCIAL, PORTAL_WEB, MENSAJERIA, BUSCADOR, OTRO.
    proveedor_api TEXT, -- Proveedor o familia tecnológica de la API, por ejemplo Meta, Google, X Corp.
    version_api TEXT, -- Versión de API o mecanismo de extracción utilizado.
    permite_historico BOOLEAN DEFAULT FALSE, -- Indica si la plataforma permite recuperar datos históricos de forma directa.
    requiere_token BOOLEAN DEFAULT TRUE, -- Indica si la plataforma requiere token/credenciales para extracción automatizada.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico de la plataforma: ACTIVO, INACTIVO, SUSPENDIDO.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de última actualización del registro.
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_fuente
-- FUNCIÓN:
-- Representa cuentas, páginas, perfiles, canales, portales o feeds concretos
-- dentro de cada plataforma. Ejemplo: @FacultadCienciasUCV en Instagram.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_fuente (
    id_fuente BIGSERIAL PRIMARY KEY, -- Llave surrogate de la fuente.
    id_plataforma BIGINT NOT NULL REFERENCES dw.dim_plataforma(id_plataforma), -- Plataforma a la que pertenece la fuente.
    nombre_fuente TEXT NOT NULL, -- Nombre público o descriptivo de la cuenta/perfil/canal.
    identificador_origen TEXT NOT NULL, -- Identificador nativo de la fuente en la plataforma: username, channel_id, page_id, URL, etc.
    url_perfil TEXT, -- URL pública del perfil, página, canal o portal.
    url_api TEXT, -- Endpoint base o referencia técnica usada para extracción.
    fecha_creacion_cuenta DATE, -- Fecha de creación de la cuenta/canal, si está disponible.
    responsable_interno TEXT, -- Unidad o persona responsable funcional de la fuente.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico de la fuente: ACTIVO, INACTIVO, SUSPENDIDO.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del registro.
    CONSTRAINT uq_fuente_plataforma_identificador UNIQUE(id_plataforma, identificador_origen)
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_tipo_contenido
-- FUNCIÓN:
-- Catálogo de tipos de contenido. Permite comparar rendimiento de videos, reels,
-- stories, notas web, posts, carruseles u otros formatos.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_tipo_contenido (
    id_tipo_contenido BIGSERIAL PRIMARY KEY, -- Llave surrogate del tipo de contenido.
    codigo_tipo_contenido TEXT NOT NULL UNIQUE, -- Código técnico: POST, REEL, STORY, VIDEO, SHORT, NOTA_WEB, CARRUSEL, OTRO.
    nombre_tipo_contenido TEXT NOT NULL, -- Nombre legible del tipo de contenido.
    descripcion TEXT, -- Descripción funcional del tipo de contenido.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico del tipo de contenido.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de última actualización del registro.
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_categoria_contenido
-- FUNCIÓN:
-- Catálogo de categorías temáticas institucionales. Permite clasificar contenidos
-- por docencia, investigación, extensión, eventos, noticias, cursos, etc.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_categoria_contenido (
    id_categoria_contenido BIGSERIAL PRIMARY KEY, -- Llave surrogate de la categoría.
    codigo_categoria TEXT NOT NULL UNIQUE, -- Código técnico de categoría.
    nombre_categoria TEXT NOT NULL, -- Nombre descriptivo de la categoría.
    descripcion TEXT, -- Descripción funcional de la categoría.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico de la categoría.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de última actualización del registro.
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_contenido_institucional
-- FUNCIÓN:
-- Agrupa una misma pieza comunicacional institucional publicada en varios canales.
-- Ejemplo: una noticia que aparece en la web, Facebook, Instagram y YouTube.
-- Esta dimensión permite responder qué contenido está en unas redes y no en otras.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_contenido_institucional (
    id_contenido BIGSERIAL PRIMARY KEY, -- Llave surrogate de la pieza comunicacional institucional.
    slug_contenido TEXT UNIQUE, -- Identificador común/slug para agrupar publicaciones equivalentes entre plataformas.
    titulo_normalizado TEXT NOT NULL, -- Título institucional común de la pieza comunicacional.
    descripcion_normalizada TEXT, -- Descripción consolidada o resumen de la pieza comunicacional.
    id_categoria_contenido BIGINT REFERENCES dw.dim_categoria_contenido(id_categoria_contenido), -- Categoría temática institucional.
    fecha_referencia DATE, -- Fecha de referencia del contenido, evento o noticia.
    hash_contenido_normalizado TEXT, -- Hash del contenido normalizado para apoyar detección de duplicados.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico del contenido: ACTIVO, INACTIVO, ARCHIVADO.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP -- Fecha/hora de última actualización del registro.
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_publicacion
-- FUNCIÓN:
-- Catálogo descriptivo de publicaciones concretas por plataforma. Cada fila es
-- una publicación específica en una fuente específica, asociable opcionalmente
-- a una pieza comunicacional institucional común.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_publicacion (
    id_publicacion BIGSERIAL PRIMARY KEY, -- Llave surrogate de la publicación.
    id_contenido BIGINT REFERENCES dw.dim_contenido_institucional(id_contenido), -- Pieza comunicacional común a la que pertenece esta publicación.
    id_fuente BIGINT NOT NULL REFERENCES dw.dim_fuente(id_fuente), -- Fuente/cuenta/canal donde se publicó el contenido.
    id_tipo_contenido BIGINT REFERENCES dw.dim_tipo_contenido(id_tipo_contenido), -- Tipo/formato de contenido publicado.
    id_categoria_contenido BIGINT REFERENCES dw.dim_categoria_contenido(id_categoria_contenido), -- Categoría temática de la publicación.
    identificador_publicacion_origen TEXT, -- ID nativo de la publicación en la plataforma.
    url_origen TEXT, -- URL pública de la publicación.
    titulo TEXT, -- Título, encabezado o descripción corta de la publicación.
    cuerpo TEXT, -- Texto completo o cuerpo principal de la publicación.
    autor TEXT, -- Autor o responsable identificado, si aplica.
    fecha_publicacion TIMESTAMPTZ NOT NULL, -- Fecha/hora original de publicación.
    estado_publicacion TEXT NOT NULL DEFAULT 'ACTIVA', -- Estado: ACTIVA, ELIMINADA, OCULTA, DESCONOCIDA.
    hash_contenido TEXT, -- Hash de contenido normalizado para control de duplicados.
    metadata_json JSONB, -- Atributos adicionales dependientes de plataforma.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del registro.
    CONSTRAINT ck_publicacion_identificador_o_url CHECK (identificador_publicacion_origen IS NOT NULL OR url_origen IS NOT NULL), -- Garantiza trazabilidad mínima por ID nativo o URL.
    CONSTRAINT uq_publicacion_fuente_idorigen UNIQUE(id_fuente, identificador_publicacion_origen),
    CONSTRAINT uq_publicacion_fuente_url UNIQUE(id_fuente, url_origen)
);

-- -----------------------------------------------------------------------------
-- DIMENSIÓN: dw.dim_tipo_metrica
-- FUNCIÓN:
-- Catálogo flexible de métricas digitales. Permite soportar métricas propias de
-- nuevas redes sociales sin modificar la estructura de hechos principales.
-- También clasifica la polaridad cuando la plataforma entrega reacciones explícitas.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.dim_tipo_metrica (
    id_tipo_metrica BIGSERIAL PRIMARY KEY, -- Llave surrogate del tipo de métrica.
    codigo_metrica TEXT NOT NULL UNIQUE, -- Código técnico: LIKE, LOVE, ANGRY, COMENTARIO, COMPARTIDO, VISTA, ALCANCE, etc.
    nombre_metrica TEXT NOT NULL, -- Nombre legible de la métrica.
    categoria_metrica TEXT NOT NULL, -- Categoría: REACCION, INTERACCION, DIFUSION, VISIBILIDAD, COMUNIDAD, OTRO.
    polaridad_metrica TEXT NOT NULL DEFAULT 'NO_APLICA', -- Polaridad: POSITIVA, NEGATIVA, NEUTRA, NO_APLICA.
    descripcion TEXT, -- Descripción funcional de la métrica.
    es_acumulada BOOLEAN NOT NULL DEFAULT TRUE, -- Indica si normalmente la API reporta esta métrica como total acumulado.
    estatus TEXT NOT NULL DEFAULT 'ACTIVO', -- Estado lógico del tipo de métrica.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del registro.
    CONSTRAINT ck_tipo_metrica_polaridad CHECK (polaridad_metrica IN ('POSITIVA','NEGATIVA','NEUTRA','NO_APLICA'))
);


-- =============================================================================
-- 4. TABLAS DE HECHOS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- HECHO SIN MEDIDAS: dw.fact_publicaciones
-- FUNCIÓN:
-- Registra la existencia de una publicación por fuente y fecha. Es una tabla
-- factless fact útil para contar publicaciones y analizar cobertura multicanal.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.fact_publicaciones (
    id_fact_publicacion BIGSERIAL PRIMARY KEY, -- Llave surrogate del hecho de publicación.
    id_publicacion BIGINT NOT NULL REFERENCES dw.dim_publicacion(id_publicacion), -- Publicación registrada.
    id_fuente BIGINT NOT NULL REFERENCES dw.dim_fuente(id_fuente), -- Fuente/cuenta/canal donde existe la publicación.
    id_tiempo INT NOT NULL REFERENCES dw.dim_tiempo(id_tiempo), -- Fecha calendario asociada a la publicación.
    id_ejecucion_n8n TEXT, -- Ejecución ETL que cargó el hecho.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de inserción del hecho.
    CONSTRAINT uq_fact_publicacion_fuente_dia UNIQUE(id_publicacion, id_fuente, id_tiempo)
);

-- -----------------------------------------------------------------------------
-- HECHO: dw.fact_metricas_publicacion_diaria
-- FUNCIÓN:
-- Almacena observaciones diarias de métricas por publicación. Incluye valores
-- acumulados observados por la API y valores de variación para analizar cambios
-- dentro de rangos de fecha.
--
-- DEFINICIÓN VARIACIÓN:
-- Variación = valor_total_observado_hoy - valor_total_observado_anterior.
-- Ejemplo: si ayer un post tenía 100 likes y hoy tiene 130, likes_total=130
-- y likes_variacion=30. Esto permite calcular interacción generada durante un período.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.fact_metricas_publicacion_diaria (
    id_metrica_publicacion BIGSERIAL PRIMARY KEY, -- Llave surrogate del hecho diario de métricas.
    id_publicacion BIGINT NOT NULL REFERENCES dw.dim_publicacion(id_publicacion), -- Publicación medida.
    id_fuente BIGINT NOT NULL REFERENCES dw.dim_fuente(id_fuente), -- Fuente/cuenta/canal donde se midió la publicación.
    id_tiempo INT NOT NULL REFERENCES dw.dim_tiempo(id_tiempo), -- Día de observación de las métricas.
    likes_total BIGINT NOT NULL DEFAULT 0 CHECK (likes_total >= 0), -- Total acumulado de likes observado en el día.
    likes_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de likes frente a la observación anterior.
    comentarios_total BIGINT NOT NULL DEFAULT 0 CHECK (comentarios_total >= 0), -- Total acumulado de comentarios observado en el día.
    comentarios_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de comentarios frente a la observación anterior.
    compartidos_total BIGINT NOT NULL DEFAULT 0 CHECK (compartidos_total >= 0), -- Total acumulado de compartidos/reposts observado.
    compartidos_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de compartidos/reposts frente a la observación anterior.
    guardados_total BIGINT NOT NULL DEFAULT 0 CHECK (guardados_total >= 0), -- Total acumulado de guardados/bookmarks observado.
    guardados_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de guardados/bookmarks frente a la observación anterior.
    vistas_total BIGINT NOT NULL DEFAULT 0 CHECK (vistas_total >= 0), -- Total acumulado de vistas/reproducciones observado.
    vistas_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de vistas/reproducciones frente a la observación anterior.
    alcance_total BIGINT NOT NULL DEFAULT 0 CHECK (alcance_total >= 0), -- Total acumulado/observado de alcance, cuando la plataforma lo permita.
    alcance_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de alcance frente a la observación anterior.
    impresiones_total BIGINT NOT NULL DEFAULT 0 CHECK (impresiones_total >= 0), -- Total acumulado/observado de impresiones, cuando exista.
    impresiones_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de impresiones frente a la observación anterior.
    reacciones_positivas_total BIGINT NOT NULL DEFAULT 0 CHECK (reacciones_positivas_total >= 0), -- Total acumulado de reacciones clasificadas como positivas.
    reacciones_positivas_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de reacciones positivas frente a la observación anterior.
    reacciones_negativas_total BIGINT NOT NULL DEFAULT 0 CHECK (reacciones_negativas_total >= 0), -- Total acumulado de reacciones clasificadas como negativas.
    reacciones_negativas_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de reacciones negativas frente a la observación anterior.
    reacciones_neutrales_total BIGINT NOT NULL DEFAULT 0 CHECK (reacciones_neutrales_total >= 0), -- Total acumulado de reacciones clasificadas como neutrales.
    reacciones_neutrales_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de reacciones neutrales frente a la observación anterior.
    total_interacciones_total BIGINT NOT NULL DEFAULT 0 CHECK (total_interacciones_total >= 0), -- Total acumulado calculado de interacciones principales.
    total_interacciones_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de interacciones calculadas para el período observado.
    indice_interaccion NUMERIC(12,4) DEFAULT 0, -- Indicador calculado de interacción según fórmula definida por el proyecto.
    id_ejecucion_n8n TEXT, -- Ejecución ETL que cargó o actualizó la observación.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del hecho.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del hecho.
    CONSTRAINT uq_metricas_publicacion_fuente_dia UNIQUE(id_publicacion, id_fuente, id_tiempo)
);

-- -----------------------------------------------------------------------------
-- HECHO DETALLE: dw.fact_metrica_publicacion_detalle
-- FUNCIÓN:
-- Tabla flexible tipo EAV controlado para almacenar métricas específicas por
-- plataforma. Complementa la tabla ancha anterior y permite agregar nuevas
-- métricas sin alterar el modelo físico.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.fact_metrica_publicacion_detalle (
    id_metrica_detalle BIGSERIAL PRIMARY KEY, -- Llave surrogate del detalle de métrica.
    id_publicacion BIGINT NOT NULL REFERENCES dw.dim_publicacion(id_publicacion), -- Publicación a la que pertenece la métrica.
    id_fuente BIGINT NOT NULL REFERENCES dw.dim_fuente(id_fuente), -- Fuente/cuenta/canal donde se observó la métrica.
    id_tiempo INT NOT NULL REFERENCES dw.dim_tiempo(id_tiempo), -- Día de observación de la métrica.
    id_tipo_metrica BIGINT NOT NULL REFERENCES dw.dim_tipo_metrica(id_tipo_metrica), -- Tipo de métrica observada.
    valor_total NUMERIC(18,4) NOT NULL DEFAULT 0 CHECK (valor_total >= 0), -- Valor acumulado/observado reportado por la fuente.
    valor_variacion NUMERIC(18,4) NOT NULL DEFAULT 0, -- Diferencia frente a la observación anterior para esa misma métrica.
    id_ejecucion_n8n TEXT, -- Ejecución ETL que cargó el detalle.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del detalle.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del detalle.
    CONSTRAINT uq_metrica_detalle_publicacion_dia_tipo UNIQUE(id_publicacion, id_fuente, id_tiempo, id_tipo_metrica)
);

-- -----------------------------------------------------------------------------
-- HECHO SNAPSHOT: dw.fact_comunidad_estado_diario
-- FUNCIÓN:
-- Snapshot diario del estado de comunidad por fuente/perfil/canal. Permite medir
-- crecimiento de seguidores, suscriptores y publicaciones acumuladas.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dw.fact_comunidad_estado_diario (
    id_estado_diario BIGSERIAL PRIMARY KEY, -- Llave surrogate del snapshot diario de comunidad.
    id_fuente BIGINT NOT NULL REFERENCES dw.dim_fuente(id_fuente), -- Fuente/cuenta/canal observado.
    id_tiempo INT NOT NULL REFERENCES dw.dim_tiempo(id_tiempo), -- Día de observación del snapshot.
    total_seguidores BIGINT NOT NULL DEFAULT 0 CHECK (total_seguidores >= 0), -- Total acumulado de seguidores/suscriptores observado.
    seguidores_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de seguidores/suscriptores frente a la observación anterior.
    total_publicaciones_perfil BIGINT NOT NULL DEFAULT 0 CHECK (total_publicaciones_perfil >= 0), -- Total acumulado de publicaciones del perfil/canal.
    publicaciones_perfil_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de publicaciones del perfil frente a la observación anterior.
    vistas_totales_perfil BIGINT NOT NULL DEFAULT 0 CHECK (vistas_totales_perfil >= 0), -- Total acumulado de vistas del perfil/canal, si aplica.
    vistas_perfil_variacion BIGINT NOT NULL DEFAULT 0, -- Diferencia de vistas del perfil/canal frente a la observación anterior.
    id_ejecucion_n8n TEXT, -- Ejecución ETL que cargó el snapshot.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del snapshot.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del snapshot.
    CONSTRAINT uq_comunidad_fuente_dia UNIQUE(id_fuente, id_tiempo)
);


-- =============================================================================
-- 5. TABLAS DE AUDITORÍA, LOGS Y CONTROL DE CALIDAD
-- =============================================================================

-- -----------------------------------------------------------------------------
-- TABLA: audit.log_proceso_maestro
-- FUNCIÓN:
-- Registra cada ejecución global de un flujo ETL. Debe insertarse al inicio del
-- proceso y actualizarse al finalizar con estado exitoso o fallido.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit.log_proceso_maestro (
    id_log_maestro BIGSERIAL PRIMARY KEY, -- Llave surrogate del log maestro.
    id_ejecucion_n8n TEXT UNIQUE NOT NULL, -- Identificador global de ejecución del workflow ETL.
    nombre_flujo TEXT NOT NULL, -- Nombre funcional del flujo, por ejemplo ETL_YOUTUBE_DIARIO.
    plataforma TEXT, -- Plataforma principal procesada por la ejecución, si aplica.
    fecha_inicio TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de inicio de la ejecución.
    fecha_fin TIMESTAMPTZ, -- Fecha/hora de finalización de la ejecución.
    estado_general TEXT NOT NULL DEFAULT 'INICIADO', -- Estado: INICIADO, FINALIZADO, FALLIDO, PARCIAL.
    registros_extraidos BIGINT DEFAULT 0, -- Cantidad de registros extraídos desde la fuente.
    registros_insertados BIGINT DEFAULT 0, -- Cantidad de registros insertados en staging/DW.
    registros_actualizados BIGINT DEFAULT 0, -- Cantidad de registros actualizados.
    registros_descartados BIGINT DEFAULT 0, -- Cantidad de registros descartados por reglas de negocio/calidad.
    registros_error BIGINT DEFAULT 0, -- Cantidad de registros con error.
    error_mensaje_global TEXT, -- Mensaje global de error en caso de falla.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del log maestro.
    actualizado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de última actualización del log maestro.
    CONSTRAINT ck_log_maestro_estado CHECK (estado_general IN ('INICIADO','FINALIZADO','FALLIDO','PARCIAL'))
);

-- -----------------------------------------------------------------------------
-- TABLA: audit.log_proceso_detalle
-- FUNCIÓN:
-- Registra pasos específicos dentro de una ejecución ETL: extracción, staging,
-- transformación, carga a DW, actualización de datamarts, etc.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit.log_proceso_detalle (
    id_log_detalle BIGSERIAL PRIMARY KEY, -- Llave surrogate del log de detalle.
    id_ejecucion_n8n TEXT NOT NULL REFERENCES audit.log_proceso_maestro(id_ejecucion_n8n) ON DELETE CASCADE, -- Ejecución global asociada.
    id_fuente BIGINT REFERENCES dw.dim_fuente(id_fuente), -- Fuente procesada, si ya existe en el DW.
    nombre_subproceso TEXT NOT NULL, -- Nombre del subproceso: EXTRACCION, STAGING, TRANSFORMACION, CARGA_DW, DATAMART.
    estado_subproceso TEXT NOT NULL DEFAULT 'INICIADO', -- Estado: INICIADO, FINALIZADO, FALLIDO, OMITIDO.
    intentos INT NOT NULL DEFAULT 0, -- Número de intentos realizados para el subproceso.
    registros_procesados BIGINT DEFAULT 0, -- Cantidad de registros procesados por el subproceso.
    registros_error BIGINT DEFAULT 0, -- Cantidad de registros con error en el subproceso.
    error_codigo TEXT, -- Código técnico o funcional del error, si aplica.
    error_mensaje TEXT, -- Descripción del error específico.
    fecha_inicio TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de inicio del subproceso.
    fecha_fin TIMESTAMPTZ, -- Fecha/hora de fin del subproceso.
    creado_el TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- Fecha/hora de creación del registro de detalle.
    CONSTRAINT ck_log_detalle_estado CHECK (estado_subproceso IN ('INICIADO','FINALIZADO','FALLIDO','OMITIDO'))
);




-- =============================================================================
-- 6. ÍNDICES OPTIMIZADOS
-- =============================================================================

-- Índices staging para acelerar procesamiento por lotes, control de pendientes y reprocesamiento.
CREATE INDEX IF NOT EXISTS idx_stg_origen_estado_fecha ON staging.stg_registro_origen(estado_procesamiento, fecha_extraccion DESC);
CREATE INDEX IF NOT EXISTS idx_stg_origen_plataforma_tipo ON staging.stg_registro_origen(plataforma, tipo_registro);
CREATE INDEX IF NOT EXISTS idx_stg_origen_respuesta_gin ON staging.stg_registro_origen USING GIN(respuesta_json);
CREATE UNIQUE INDEX IF NOT EXISTS uq_stg_publicacion_normalizada_id_staging ON staging.stg_publicacion_normalizada(id_staging);

-- Índice único parcial para evitar duplicar respuestas idénticas de una misma fuente durante cargas históricas o incrementales.
CREATE UNIQUE INDEX IF NOT EXISTS uq_stg_origen_hash_respuesta
ON staging.stg_registro_origen(plataforma, fuente, tipo_registro, identificador_origen, hash_respuesta)
WHERE hash_respuesta IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_stg_pub_procesado ON staging.stg_publicacion_normalizada(procesado, creado_el DESC);
CREATE INDEX IF NOT EXISTS idx_stg_metricas_procesado ON staging.stg_metricas_publicacion_normalizada(procesado, fecha_observacion DESC);
CREATE INDEX IF NOT EXISTS idx_stg_comunidad_procesado ON staging.stg_comunidad_normalizada(procesado, fecha_observacion DESC);

-- Índices dimensiones para búsquedas frecuentes.
CREATE INDEX IF NOT EXISTS idx_dim_fuente_plataforma ON dw.dim_fuente(id_plataforma);
CREATE INDEX IF NOT EXISTS idx_dim_publicacion_contenido ON dw.dim_publicacion(id_contenido);
CREATE INDEX IF NOT EXISTS idx_dim_publicacion_fuente_fecha ON dw.dim_publicacion(id_fuente, fecha_publicacion DESC);
CREATE INDEX IF NOT EXISTS idx_dim_publicacion_url ON dw.dim_publicacion(url_origen);
CREATE INDEX IF NOT EXISTS idx_dim_publicacion_hash ON dw.dim_publicacion(hash_contenido);

-- Índices hechos para Metabase y consultas temporales.
CREATE INDEX IF NOT EXISTS idx_fact_pub_tiempo ON dw.fact_publicaciones(id_tiempo);
CREATE INDEX IF NOT EXISTS idx_fact_pub_fuente ON dw.fact_publicaciones(id_fuente);
CREATE INDEX IF NOT EXISTS idx_fact_metricas_tiempo ON dw.fact_metricas_publicacion_diaria(id_tiempo);
CREATE INDEX IF NOT EXISTS idx_fact_metricas_fuente_tiempo ON dw.fact_metricas_publicacion_diaria(id_fuente, id_tiempo);
CREATE INDEX IF NOT EXISTS idx_fact_metricas_publicacion_tiempo ON dw.fact_metricas_publicacion_diaria(id_publicacion, id_tiempo DESC);
CREATE INDEX IF NOT EXISTS idx_fact_detalle_tipo_tiempo ON dw.fact_metrica_publicacion_detalle(id_tipo_metrica, id_tiempo);
CREATE INDEX IF NOT EXISTS idx_fact_detalle_fuente_tiempo ON dw.fact_metrica_publicacion_detalle(id_fuente, id_tiempo);
CREATE INDEX IF NOT EXISTS idx_fact_comunidad_fuente_tiempo ON dw.fact_comunidad_estado_diario(id_fuente, id_tiempo DESC);

-- Índices auditoría para monitoreo de ejecuciones.
CREATE INDEX IF NOT EXISTS idx_log_maestro_estado_fecha ON audit.log_proceso_maestro(estado_general, fecha_inicio DESC);
CREATE INDEX IF NOT EXISTS idx_log_detalle_ejecucion ON audit.log_proceso_detalle(id_ejecucion_n8n);
CREATE UNIQUE INDEX IF NOT EXISTS uq_log_detalle_ejecucion_subproceso ON audit.log_proceso_detalle (id_ejecucion_n8n, nombre_subproceso);



-- =============================================================================
-- 7. DATA MARTS (MATERIALIZED VIEWS PARA METABASE)
-- =============================================================================
-- FUNCIÓN GENERAL:
-- Capa de consumo analítico para Metabase. Esta sección mantiene únicamente
-- objetos que serán utilizados directamente en tableros estratégicos, tácticos,
-- operativos y de auditoría analítica.
--
-- DECISIÓN DE DISEÑO:
-- - Se eliminan las materialized views separadas por día/semana/mes/trimestre/año,
--   porque quedan consolidadas en vistas materializadas completas que permiten
--   agrupar por cualquier granularidad temporal desde Metabase.
-- - Se elimina datamart.vw_publicaciones_con_plataforma porque su función queda
--   cubierta por datamart.mv_detalle_publicaciones_categoria.
-- - Se materializan también las consultas de interacción, métricas flexibles,
--   comunidad y cobertura multicanal para dejar una capa analítica definitiva,
--   estable y optimizada para Metabase.
-- - Todas las materialized views se refrescan al final del ETL desde n8n.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- OBJETOS DATAMART
-- -----------------------------------------------------------------------------
-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_interacciones_por_publicacion
-- FUNCIÓN:
-- Vista materializada analítica para comparar interacción por publicación, red
-- social y fecha. Usa principalmente valores de variación para medir actividad
-- generada dentro de un período. Será alimentada por ETL de redes sociales como
-- Instagram, Facebook, YouTube, X u otras plataformas que entreguen métricas de
-- interacción.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_interacciones_por_publicacion AS
SELECT
    fmpd.id_metrica_publicacion,
    dt.fecha,
    dt.anho,
    dt.mes,
    dt.nombre_mes,
    dt.trimestre,
    dt.semana_anio,
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    dpla.tipo_fuente,
    df.id_fuente,
    df.nombre_fuente,
    dp.id_publicacion,
    dci.id_contenido,
    dci.slug_contenido,
    COALESCE(dci.titulo_normalizado, dp.titulo) AS titulo_normalizado,
    dp.titulo AS titulo_publicacion,
    dp.url_origen,
    dtc.codigo_tipo_contenido,
    dtc.nombre_tipo_contenido,
    COALESCE(dcc.codigo_categoria, 'OTRO') AS codigo_categoria,
    COALESCE(dcc.nombre_categoria, 'OTRO') AS nombre_categoria,
    COALESCE(fmpd.likes_total, 0) AS likes_total,
    COALESCE(fmpd.likes_variacion, 0) AS likes_variacion,
    COALESCE(fmpd.comentarios_total, 0) AS comentarios_total,
    COALESCE(fmpd.comentarios_variacion, 0) AS comentarios_variacion,
    COALESCE(fmpd.compartidos_total, 0) AS compartidos_total,
    COALESCE(fmpd.compartidos_variacion, 0) AS compartidos_variacion,
    COALESCE(fmpd.guardados_total, 0) AS guardados_total,
    COALESCE(fmpd.guardados_variacion, 0) AS guardados_variacion,
    COALESCE(fmpd.vistas_total, 0) AS vistas_total,
    COALESCE(fmpd.vistas_variacion, 0) AS vistas_variacion,
    COALESCE(fmpd.alcance_total, 0) AS alcance_total,
    COALESCE(fmpd.alcance_variacion, 0) AS alcance_variacion,
    COALESCE(fmpd.impresiones_total, 0) AS impresiones_total,
    COALESCE(fmpd.impresiones_variacion, 0) AS impresiones_variacion,
    COALESCE(fmpd.reacciones_positivas_total, 0) AS reacciones_positivas_total,
    COALESCE(fmpd.reacciones_positivas_variacion, 0) AS reacciones_positivas_variacion,
    COALESCE(fmpd.reacciones_negativas_total, 0) AS reacciones_negativas_total,
    COALESCE(fmpd.reacciones_negativas_variacion, 0) AS reacciones_negativas_variacion,
    COALESCE(fmpd.reacciones_neutrales_total, 0) AS reacciones_neutrales_total,
    COALESCE(fmpd.reacciones_neutrales_variacion, 0) AS reacciones_neutrales_variacion,
    COALESCE(fmpd.total_interacciones_total, 0) AS total_interacciones_total,
    COALESCE(fmpd.total_interacciones_variacion, 0) AS total_interacciones_variacion,
    COALESCE(fmpd.indice_interaccion, 0) AS indice_interaccion
FROM dw.fact_metricas_publicacion_diaria fmpd
JOIN dw.dim_publicacion dp
    ON dp.id_publicacion = fmpd.id_publicacion
JOIN dw.dim_fuente df
    ON df.id_fuente = fmpd.id_fuente
JOIN dw.dim_plataforma dpla
    ON dpla.id_plataforma = df.id_plataforma
JOIN dw.dim_tiempo dt
    ON dt.id_tiempo = fmpd.id_tiempo
LEFT JOIN dw.dim_contenido_institucional dci
    ON dci.id_contenido = dp.id_contenido
LEFT JOIN dw.dim_tipo_contenido dtc
    ON dtc.id_tipo_contenido = dp.id_tipo_contenido
LEFT JOIN dw.dim_categoria_contenido dcc
    ON dcc.id_categoria_contenido = COALESCE(dp.id_categoria_contenido, dci.id_categoria_contenido)
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_interacciones_por_publicacion IS
'Materialized view analítica para comparar interacciones por publicación, plataforma, fuente, categoría y fecha. Se alimenta desde hechos de métricas de redes sociales.';

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_interacciones_pub_id
ON datamart.mv_interacciones_por_publicacion (id_metrica_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_fecha
ON datamart.mv_interacciones_por_publicacion (fecha);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_plataforma_fecha
ON datamart.mv_interacciones_por_publicacion (id_plataforma, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_fuente_fecha
ON datamart.mv_interacciones_por_publicacion (id_fuente, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_publicacion
ON datamart.mv_interacciones_por_publicacion (id_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_categoria
ON datamart.mv_interacciones_por_publicacion (codigo_categoria);

CREATE INDEX IF NOT EXISTS idx_mv_interacciones_pub_periodo
ON datamart.mv_interacciones_por_publicacion (anho, mes, trimestre, semana_anio);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_metricas_flexibles_detalle
-- FUNCIÓN:
-- Vista materializada para analizar métricas específicas por tipo, incluyendo
-- categoría y polaridad. Permite incorporar nuevas métricas sin modificar la
-- estructura de tableros, apoyándose en dw.dim_tipo_metrica y el hecho flexible
-- EAV controlado.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_metricas_flexibles_detalle AS
SELECT
    dt.fecha,
    dt.anho,
    dt.mes,
    dt.nombre_mes,
    dt.trimestre,
    dt.semana_anio,
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    dpla.tipo_fuente,
    df.id_fuente,
    df.nombre_fuente,
    dp.id_publicacion,
    dci.id_contenido,
    dci.slug_contenido,
    COALESCE(dci.titulo_normalizado, dp.titulo) AS titulo_normalizado,
    dp.url_origen,
    dtm.id_tipo_metrica,
    dtm.codigo_metrica,
    dtm.nombre_metrica,
    dtm.categoria_metrica,
    dtm.polaridad_metrica,
    COALESCE(fmd.valor_total, 0) AS valor_total,
    COALESCE(fmd.valor_variacion, 0) AS valor_variacion
FROM dw.fact_metrica_publicacion_detalle fmd
JOIN dw.dim_tipo_metrica dtm
    ON dtm.id_tipo_metrica = fmd.id_tipo_metrica
JOIN dw.dim_publicacion dp
    ON dp.id_publicacion = fmd.id_publicacion
JOIN dw.dim_fuente df
    ON df.id_fuente = fmd.id_fuente
JOIN dw.dim_plataforma dpla
    ON dpla.id_plataforma = df.id_plataforma
JOIN dw.dim_tiempo dt
    ON dt.id_tiempo = fmd.id_tiempo
LEFT JOIN dw.dim_contenido_institucional dci
    ON dci.id_contenido = dp.id_contenido
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_metricas_flexibles_detalle IS
'Materialized view para analizar métricas flexibles por tipo, categoría y polaridad. Útil para reacciones positivas, negativas, neutrales y métricas futuras.';

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_fecha
ON datamart.mv_metricas_flexibles_detalle (fecha);

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_plataforma_fecha
ON datamart.mv_metricas_flexibles_detalle (id_plataforma, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_fuente_fecha
ON datamart.mv_metricas_flexibles_detalle (id_fuente, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_publicacion
ON datamart.mv_metricas_flexibles_detalle (id_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_tipo
ON datamart.mv_metricas_flexibles_detalle (id_tipo_metrica, codigo_metrica);

CREATE INDEX IF NOT EXISTS idx_mv_metricas_flex_periodo
ON datamart.mv_metricas_flexibles_detalle (anho, mes, trimestre, semana_anio);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_cobertura_contenido_plataforma
-- FUNCIÓN:
-- Permite analizar en qué plataformas se publicó cada pieza comunicacional.
-- Responde preguntas como: ¿qué contenido aparece en el portal web, pero no en
-- redes sociales?, o ¿qué publicaciones tienen mayor cobertura multicanal?
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_cobertura_contenido_plataforma AS
SELECT
    dci.id_contenido,
    dci.slug_contenido,
    dci.titulo_normalizado,
    COALESCE(dcc.codigo_categoria, 'OTRO') AS codigo_categoria,
    COALESCE(dcc.nombre_categoria, 'OTRO') AS nombre_categoria,
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    df.id_fuente,
    df.nombre_fuente,
    COUNT(DISTINCT dp.id_publicacion) AS cantidad_publicaciones,
    MIN(dp.fecha_publicacion) AS primera_fecha_publicacion,
    MAX(dp.fecha_publicacion) AS ultima_fecha_publicacion
FROM dw.dim_contenido_institucional dci
LEFT JOIN dw.dim_categoria_contenido dcc
    ON dcc.id_categoria_contenido = dci.id_categoria_contenido
LEFT JOIN dw.dim_publicacion dp
    ON dp.id_contenido = dci.id_contenido
LEFT JOIN dw.dim_fuente df
    ON df.id_fuente = dp.id_fuente
LEFT JOIN dw.dim_plataforma dpla
    ON dpla.id_plataforma = df.id_plataforma
GROUP BY
    dci.id_contenido,
    dci.slug_contenido,
    dci.titulo_normalizado,
    COALESCE(dcc.codigo_categoria, 'OTRO'),
    COALESCE(dcc.nombre_categoria, 'OTRO'),
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    df.id_fuente,
    df.nombre_fuente
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_cobertura_contenido_plataforma IS
'Materialized view para analizar cobertura multicanal de piezas comunicacionales por plataforma y fuente.';

CREATE INDEX IF NOT EXISTS idx_mv_cobertura_contenido
ON datamart.mv_cobertura_contenido_plataforma (id_contenido);

CREATE INDEX IF NOT EXISTS idx_mv_cobertura_plataforma
ON datamart.mv_cobertura_contenido_plataforma (id_plataforma);

CREATE INDEX IF NOT EXISTS idx_mv_cobertura_fuente
ON datamart.mv_cobertura_contenido_plataforma (id_fuente);

CREATE INDEX IF NOT EXISTS idx_mv_cobertura_categoria
ON datamart.mv_cobertura_contenido_plataforma (codigo_categoria);

CREATE INDEX IF NOT EXISTS idx_mv_cobertura_fecha
ON datamart.mv_cobertura_contenido_plataforma (ultima_fecha_publicacion);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_comunidad_diaria
-- FUNCIÓN:
-- Vista materializada para analizar crecimiento de comunidad por fuente y
-- plataforma. Será alimentada por ETL de redes sociales o canales que entreguen
-- seguidores, suscriptores, vistas de perfil o publicaciones acumuladas.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_comunidad_diaria AS
SELECT
    dt.fecha,
    dt.anho,
    dt.mes,
    dt.nombre_mes,
    dt.trimestre,
    dt.semana_anio,
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    dpla.tipo_fuente,
    df.id_fuente,
    df.nombre_fuente,
    COALESCE(fced.total_seguidores, 0) AS total_seguidores,
    COALESCE(fced.seguidores_variacion, 0) AS seguidores_variacion,
    COALESCE(fced.total_publicaciones_perfil, 0) AS total_publicaciones_perfil,
    COALESCE(fced.publicaciones_perfil_variacion, 0) AS publicaciones_perfil_variacion,
    COALESCE(fced.vistas_totales_perfil, 0) AS vistas_totales_perfil,
    COALESCE(fced.vistas_perfil_variacion, 0) AS vistas_perfil_variacion
FROM dw.fact_comunidad_estado_diario fced
JOIN dw.dim_fuente df
    ON df.id_fuente = fced.id_fuente
JOIN dw.dim_plataforma dpla
    ON dpla.id_plataforma = df.id_plataforma
JOIN dw.dim_tiempo dt
    ON dt.id_tiempo = fced.id_tiempo
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_comunidad_diaria IS
'Materialized view para analizar crecimiento diario de comunidad por fuente, plataforma y fecha.';

CREATE INDEX IF NOT EXISTS idx_mv_comunidad_fecha
ON datamart.mv_comunidad_diaria (fecha);

CREATE INDEX IF NOT EXISTS idx_mv_comunidad_plataforma_fecha
ON datamart.mv_comunidad_diaria (id_plataforma, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_comunidad_fuente_fecha
ON datamart.mv_comunidad_diaria (id_fuente, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_comunidad_periodo
ON datamart.mv_comunidad_diaria (anho, mes, trimestre, semana_anio);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_publicaciones_fuente_fecha_completa
-- FUNCIÓN:
-- Datamart principal de publicaciones por fecha, fuente y plataforma. Incluye
-- todas las fuentes activas aunque no tengan publicaciones en el período, usando
-- cero como valor. Es la base para gráficos comparativos por día, semana, mes,
-- trimestre y año en Metabase.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_publicaciones_fuente_fecha_completa AS
WITH fechas AS (
    SELECT
        dt.id_tiempo,
        dt.fecha,
        dt.anho,
        dt.mes,
        dt.nombre_mes,
        dt.trimestre,
        dt.semana_anio
    FROM dw.dim_tiempo dt
    WHERE dt.fecha BETWEEN DATE '2010-01-01' AND CURRENT_DATE
),
fuentes_activas AS (
    SELECT
        df.id_fuente,
        df.nombre_fuente,
        df.identificador_origen,
        df.url_perfil,
        dp.id_plataforma,
        dp.nombre_plataforma,
        dp.tipo_fuente
    FROM dw.dim_fuente df
    JOIN dw.dim_plataforma dp
        ON df.id_plataforma = dp.id_plataforma
    WHERE df.estatus = 'ACTIVO'
      AND dp.estatus = 'ACTIVO'
),
publicaciones AS (
    SELECT
        fp.id_tiempo,
        fp.id_fuente,
        COUNT(*) AS total_publicaciones
    FROM dw.fact_publicaciones fp
    GROUP BY
        fp.id_tiempo,
        fp.id_fuente
)
SELECT
    f.id_tiempo,
    f.fecha,
    f.anho,
    f.mes,
    f.nombre_mes,
    f.trimestre,
    f.semana_anio,
    fa.id_plataforma,
    fa.nombre_plataforma,
    fa.tipo_fuente,
    fa.id_fuente,
    fa.nombre_fuente,
    fa.identificador_origen,
    fa.url_perfil,
    COALESCE(p.total_publicaciones, 0) AS total_publicaciones
FROM fechas f
CROSS JOIN fuentes_activas fa
LEFT JOIN publicaciones p
    ON p.id_tiempo = f.id_tiempo
   AND p.id_fuente = fa.id_fuente
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_publicaciones_fuente_fecha_completa IS
'Materialized view de publicaciones por fecha, fuente y plataforma. Incluye fuentes activas sin publicaciones con valor 0 para comparaciones completas en Metabase.';

CREATE INDEX IF NOT EXISTS idx_mv_pub_ffc_fecha
ON datamart.mv_publicaciones_fuente_fecha_completa (fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_ffc_fuente_fecha
ON datamart.mv_publicaciones_fuente_fecha_completa (id_fuente, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_ffc_plataforma_fecha
ON datamart.mv_publicaciones_fuente_fecha_completa (id_plataforma, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_ffc_periodo
ON datamart.mv_publicaciones_fuente_fecha_completa (anho, mes, trimestre, semana_anio);

CREATE INDEX IF NOT EXISTS idx_mv_pub_ffc_nombres
ON datamart.mv_publicaciones_fuente_fecha_completa (nombre_plataforma, nombre_fuente);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_publicaciones_fuente_categoria_fecha_completa
-- FUNCIÓN:
-- Datamart de publicaciones por fecha, fuente, plataforma y categoría. Cruza
-- fechas, fuentes activas y categorías activas para mostrar valor 0 cuando una
-- categoría no tenga publicaciones en una fuente o período. Es la base para
-- matrices fuente-categoría y barras apiladas en Metabase.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_publicaciones_fuente_categoria_fecha_completa AS
WITH fechas AS (
    SELECT
        dt.id_tiempo,
        dt.fecha,
        dt.anho,
        dt.mes,
        dt.nombre_mes,
        dt.trimestre,
        dt.semana_anio
    FROM dw.dim_tiempo dt
    WHERE dt.fecha BETWEEN DATE '2010-01-01' AND CURRENT_DATE
),
fuentes_activas AS (
    SELECT
        df.id_fuente,
        df.nombre_fuente,
        df.identificador_origen,
        df.url_perfil,
        dp.id_plataforma,
        dp.nombre_plataforma,
        dp.tipo_fuente
    FROM dw.dim_fuente df
    JOIN dw.dim_plataforma dp
        ON df.id_plataforma = dp.id_plataforma
    WHERE df.estatus = 'ACTIVO'
      AND dp.estatus = 'ACTIVO'
),
categorias_activas AS (
    SELECT
        dcc.id_categoria_contenido,
        dcc.codigo_categoria,
        dcc.nombre_categoria
    FROM dw.dim_categoria_contenido dcc
    WHERE dcc.estatus = 'ACTIVO'
),
categoria_otro AS (
    SELECT id_categoria_contenido
    FROM dw.dim_categoria_contenido
    WHERE codigo_categoria = 'OTRO'
    LIMIT 1
),
publicaciones AS (
    SELECT
        fp.id_tiempo,
        fp.id_fuente,
        COALESCE(dpub.id_categoria_contenido, (SELECT id_categoria_contenido FROM categoria_otro)) AS id_categoria_contenido,
        COUNT(*) AS total_publicaciones
    FROM dw.fact_publicaciones fp
    JOIN dw.dim_publicacion dpub
        ON fp.id_publicacion = dpub.id_publicacion
    GROUP BY
        fp.id_tiempo,
        fp.id_fuente,
        COALESCE(dpub.id_categoria_contenido, (SELECT id_categoria_contenido FROM categoria_otro))
)
SELECT
    f.id_tiempo,
    f.fecha,
    f.anho,
    f.mes,
    f.nombre_mes,
    f.trimestre,
    f.semana_anio,
    fa.id_plataforma,
    fa.nombre_plataforma,
    fa.tipo_fuente,
    fa.id_fuente,
    fa.nombre_fuente,
    fa.identificador_origen,
    fa.url_perfil,
    ca.id_categoria_contenido,
    ca.codigo_categoria,
    ca.nombre_categoria,
    COALESCE(p.total_publicaciones, 0) AS total_publicaciones
FROM fechas f
CROSS JOIN fuentes_activas fa
CROSS JOIN categorias_activas ca
LEFT JOIN publicaciones p
    ON p.id_tiempo = f.id_tiempo
   AND p.id_fuente = fa.id_fuente
   AND p.id_categoria_contenido = ca.id_categoria_contenido
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_publicaciones_fuente_categoria_fecha_completa IS
'Materialized view de publicaciones por fecha, fuente, plataforma y categoría. Incluye combinaciones activas sin publicaciones con valor 0 para análisis comparativo en Metabase.';

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_fecha
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_fuente_fecha
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (id_fuente, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_categoria_fecha
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (id_categoria_contenido, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_plataforma_fecha
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (id_plataforma, fecha);

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_periodo
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (anho, mes, trimestre, semana_anio);

CREATE INDEX IF NOT EXISTS idx_mv_pub_fcfc_nombres
ON datamart.mv_publicaciones_fuente_categoria_fecha_completa (nombre_plataforma, nombre_fuente, nombre_categoria);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_detalle_publicaciones_categoria
-- FUNCIÓN:
-- Detalle operativo de publicaciones. Es la base para tablas en Metabase con
-- enlaces clicables, títulos, fechas, fuentes, plataformas, tipo de contenido y
-- categoría. Reemplaza a la antigua vista vw_publicaciones_con_plataforma.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_detalle_publicaciones_categoria AS
SELECT
    fp.id_fact_publicacion,
    fp.id_ejecucion_n8n,
    dp.id_publicacion,
    dp.identificador_publicacion_origen,
    dp.url_origen,
    dp.titulo,
    dp.cuerpo,
    dp.autor,
    dp.fecha_publicacion,
    dp.estado_publicacion,
    dp.hash_contenido,
    dp.metadata_json,
    dci.id_contenido,
    dci.slug_contenido,
    COALESCE(dci.titulo_normalizado, dp.titulo) AS titulo_normalizado,
    df.id_fuente,
    df.nombre_fuente,
    df.identificador_origen AS identificador_fuente,
    df.url_perfil,
    dpla.id_plataforma,
    dpla.nombre_plataforma,
    dpla.tipo_fuente,
    dtc.id_tipo_contenido,
    dtc.codigo_tipo_contenido,
    dtc.nombre_tipo_contenido,
    COALESCE(dcc.id_categoria_contenido, dcc_otro.id_categoria_contenido) AS id_categoria_contenido,
    COALESCE(dcc.codigo_categoria, 'OTRO') AS codigo_categoria,
    COALESCE(dcc.nombre_categoria, 'OTRO') AS nombre_categoria,
    dt.id_tiempo,
    dt.fecha,
    dt.dia,
    dt.dia_semana,
    dt.nombre_dia,
    dt.semana_anio,
    dt.mes,
    dt.nombre_mes,
    dt.trimestre,
    dt.anho,
    fp.creado_el AS fecha_carga_dw
FROM dw.fact_publicaciones fp
JOIN dw.dim_publicacion dp
    ON fp.id_publicacion = dp.id_publicacion
JOIN dw.dim_fuente df
    ON fp.id_fuente = df.id_fuente
JOIN dw.dim_plataforma dpla
    ON df.id_plataforma = dpla.id_plataforma
JOIN dw.dim_tiempo dt
    ON fp.id_tiempo = dt.id_tiempo
LEFT JOIN dw.dim_contenido_institucional dci
    ON dci.id_contenido = dp.id_contenido
LEFT JOIN dw.dim_tipo_contenido dtc
    ON dtc.id_tipo_contenido = dp.id_tipo_contenido
LEFT JOIN dw.dim_categoria_contenido dcc
    ON dcc.id_categoria_contenido = COALESCE(dp.id_categoria_contenido, dci.id_categoria_contenido)
LEFT JOIN dw.dim_categoria_contenido dcc_otro
    ON dcc_otro.codigo_categoria = 'OTRO'
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_detalle_publicaciones_categoria IS
'Materialized view operativa de publicaciones con fuente, plataforma, categoría, calendario y URL de origen. Base para tablas detalladas y reportes descargables en Metabase.';

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_detalle_pub_id_fact
ON datamart.mv_detalle_publicaciones_categoria (id_fact_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_detalle_pub_fecha
ON datamart.mv_detalle_publicaciones_categoria (fecha_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_detalle_pub_fuente_categoria
ON datamart.mv_detalle_publicaciones_categoria (nombre_fuente, nombre_categoria);

CREATE INDEX IF NOT EXISTS idx_mv_detalle_pub_plataforma_fecha
ON datamart.mv_detalle_publicaciones_categoria (nombre_plataforma, fecha_publicacion);

CREATE INDEX IF NOT EXISTS idx_mv_detalle_pub_url
ON datamart.mv_detalle_publicaciones_categoria (url_origen);

CREATE INDEX IF NOT EXISTS idx_mv_detalle_pub_titulo
ON datamart.mv_detalle_publicaciones_categoria (titulo);


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_resumen_publicaciones
-- FUNCIÓN:
-- Resumen ejecutivo de publicaciones. Produce una única fila con conteos globales,
-- rango de fechas y catálogos activos. Se usa para tarjetas KPI estratégicas.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_resumen_publicaciones AS
SELECT
    (SELECT COUNT(DISTINCT dp.id_publicacion) FROM dw.dim_publicacion dp) AS total_publicaciones,
    (SELECT COUNT(DISTINCT fp.id_fuente) FROM dw.fact_publicaciones fp) AS total_fuentes_con_publicaciones,
    (SELECT COUNT(*) FROM dw.dim_fuente df WHERE df.estatus = 'ACTIVO') AS total_fuentes_activas,
    (SELECT COUNT(DISTINCT df.id_plataforma)
     FROM dw.fact_publicaciones fp
     JOIN dw.dim_fuente df ON df.id_fuente = fp.id_fuente) AS total_plataformas_con_publicaciones,
    (SELECT COUNT(*) FROM dw.dim_plataforma dp WHERE dp.estatus = 'ACTIVO') AS total_plataformas_activas,
    (SELECT COUNT(DISTINCT dp.id_categoria_contenido) FROM dw.dim_publicacion dp WHERE dp.id_categoria_contenido IS NOT NULL) AS total_categorias_con_publicaciones,
    (SELECT COUNT(*) FROM dw.dim_categoria_contenido dcc WHERE dcc.estatus = 'ACTIVO') AS total_categorias_activas,
    (SELECT MIN(dp.fecha_publicacion::date) FROM dw.dim_publicacion dp) AS fecha_primera_publicacion,
    (SELECT MAX(dp.fecha_publicacion::date) FROM dw.dim_publicacion dp) AS fecha_ultima_publicacion,
    CURRENT_TIMESTAMP AS fecha_actualizacion_datamart
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_resumen_publicaciones IS
'Materialized view ejecutiva con conteos globales de publicaciones, fuentes, plataformas, categorías y rango de fechas. Base para KPIs estratégicos en Metabase.';

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_resumen_publicaciones_unica
ON datamart.mv_resumen_publicaciones ((1));


-- -----------------------------------------------------------------------------
-- MATERIALIZED VIEW: datamart.mv_kpis_redes
-- FUNCIÓN:
-- KPIs mensuales por plataforma para publicaciones e interacción. Incluye todas
-- las plataformas activas aunque no tengan métricas, usando 0 como valor. La parte
-- de interacción se alimentará con los ETL de redes sociales; WordPress aporta
-- publicaciones del portal web.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW datamart.mv_kpis_redes AS
WITH meses AS (
    SELECT DISTINCT
        dt.anho,
        dt.mes,
        dt.nombre_mes,
        DATE_TRUNC('month', dt.fecha)::date AS mes_inicio
    FROM dw.dim_tiempo dt
    WHERE dt.fecha BETWEEN DATE '2010-01-01' AND CURRENT_DATE
),
plataformas_activas AS (
    SELECT
        dp.id_plataforma,
        dp.nombre_plataforma,
        dp.tipo_fuente
    FROM dw.dim_plataforma dp
    WHERE dp.estatus = 'ACTIVO'
),
publicaciones AS (
    SELECT
        dpla.id_plataforma,
        dt.anho,
        dt.mes,
        COUNT(DISTINCT fp.id_publicacion) AS total_publicaciones
    FROM dw.fact_publicaciones fp
    JOIN dw.dim_fuente df
        ON df.id_fuente = fp.id_fuente
    JOIN dw.dim_plataforma dpla
        ON dpla.id_plataforma = df.id_plataforma
    JOIN dw.dim_tiempo dt
        ON dt.id_tiempo = fp.id_tiempo
    GROUP BY
        dpla.id_plataforma,
        dt.anho,
        dt.mes
),
metricas AS (
    SELECT
        dpla.id_plataforma,
        dt.anho,
        dt.mes,
        SUM(fmpd.likes_variacion) AS likes_periodo,
        SUM(fmpd.comentarios_variacion) AS comentarios_periodo,
        SUM(fmpd.compartidos_variacion) AS compartidos_periodo,
        SUM(fmpd.guardados_variacion) AS guardados_periodo,
        SUM(fmpd.vistas_variacion) AS vistas_periodo,
        SUM(fmpd.alcance_variacion) AS alcance_periodo,
        SUM(fmpd.impresiones_variacion) AS impresiones_periodo,
        SUM(fmpd.reacciones_positivas_variacion) AS reacciones_positivas_periodo,
        SUM(fmpd.reacciones_negativas_variacion) AS reacciones_negativas_periodo,
        SUM(fmpd.reacciones_neutrales_variacion) AS reacciones_neutrales_periodo,
        SUM(fmpd.total_interacciones_variacion) AS interacciones_periodo,
        AVG(fmpd.indice_interaccion) AS indice_interaccion_promedio
    FROM dw.fact_metricas_publicacion_diaria fmpd
    JOIN dw.dim_fuente df
        ON df.id_fuente = fmpd.id_fuente
    JOIN dw.dim_plataforma dpla
        ON dpla.id_plataforma = df.id_plataforma
    JOIN dw.dim_tiempo dt
        ON dt.id_tiempo = fmpd.id_tiempo
    GROUP BY
        dpla.id_plataforma,
        dt.anho,
        dt.mes
)
SELECT
    m.mes_inicio,
    m.anho,
    m.mes,
    m.nombre_mes,
    pa.id_plataforma,
    pa.nombre_plataforma,
    pa.tipo_fuente,
    COALESCE(p.total_publicaciones, 0) AS total_publicaciones,
    COALESCE(mt.likes_periodo, 0) AS likes_periodo,
    COALESCE(mt.comentarios_periodo, 0) AS comentarios_periodo,
    COALESCE(mt.compartidos_periodo, 0) AS compartidos_periodo,
    COALESCE(mt.guardados_periodo, 0) AS guardados_periodo,
    COALESCE(mt.vistas_periodo, 0) AS vistas_periodo,
    COALESCE(mt.alcance_periodo, 0) AS alcance_periodo,
    COALESCE(mt.impresiones_periodo, 0) AS impresiones_periodo,
    COALESCE(mt.reacciones_positivas_periodo, 0) AS reacciones_positivas_periodo,
    COALESCE(mt.reacciones_negativas_periodo, 0) AS reacciones_negativas_periodo,
    COALESCE(mt.reacciones_neutrales_periodo, 0) AS reacciones_neutrales_periodo,
    COALESCE(mt.interacciones_periodo, 0) AS interacciones_periodo,
    COALESCE(mt.indice_interaccion_promedio, 0) AS indice_interaccion_promedio
FROM meses m
CROSS JOIN plataformas_activas pa
LEFT JOIN publicaciones p
    ON p.id_plataforma = pa.id_plataforma
   AND p.anho = m.anho
   AND p.mes = m.mes
LEFT JOIN metricas mt
    ON mt.id_plataforma = pa.id_plataforma
   AND mt.anho = m.anho
   AND mt.mes = m.mes
WITH DATA;

COMMENT ON MATERIALIZED VIEW datamart.mv_kpis_redes IS
'Materialized view mensual de KPIs por plataforma. Integra publicaciones y métricas de interacción, mostrando 0 para plataformas activas sin datos en el período.';

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_kpis_redes_unique
ON datamart.mv_kpis_redes (id_plataforma, anho, mes);

CREATE INDEX IF NOT EXISTS idx_mv_kpis_redes_periodo
ON datamart.mv_kpis_redes (anho, mes);

CREATE INDEX IF NOT EXISTS idx_mv_kpis_redes_plataforma
ON datamart.mv_kpis_redes (nombre_plataforma);




-- =============================================================================
-- =============================================================================
-- 8. FUNCIONES Y TRIGGERS DE AUDITORÍA
-- =============================================================================

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_actualizar_timestamp
-- FUNCIÓN:
-- Actualiza automáticamente la columna actualizado_el en tablas con auditoría.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_actualizar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.actualizado_el = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_texto
-- FUNCIÓN:
-- Limpia cadenas de texto antes de guardarlas en tablas controladas del modelo.
-- Reglas aplicadas:
--   1. Elimina espacios en blanco al inicio y al final.
--   2. Convierte múltiples espacios internos en un solo espacio.
--   3. Convierte el texto a mayúsculas conservando acentos según collation.
--   4. Devuelve NULL si la cadena queda vacía.
-- NOTA:
-- No debe aplicarse a respuesta_json ni a campos donde se requiera preservar
-- exactamente el contenido original extraído desde la fuente.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_texto(p_texto TEXT)
RETURNS TEXT AS $$
BEGIN
    IF p_texto IS NULL THEN
        RETURN NULL;
    END IF;

    RETURN NULLIF(UPPER(REGEXP_REPLACE(BTRIM(p_texto), '\s+', ' ', 'g')), '');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_url
-- FUNCIÓN:
-- Limpia URLs y endpoints eliminando espacios iniciales/finales sin convertir
-- a mayúsculas, para preservar compatibilidad con rutas, parámetros y servicios.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_url(p_texto TEXT)
RETURNS TEXT AS $$
BEGIN
    IF p_texto IS NULL THEN
        RETURN NULL;
    END IF;

    RETURN NULLIF(BTRIM(p_texto), '');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_plataforma
-- FUNCIÓN:
-- Normaliza cadenas descriptivas de plataformas antes de INSERT/UPDATE.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_plataforma()
RETURNS TRIGGER AS $$
BEGIN
    NEW.nombre_plataforma := dw.fn_normalizar_texto(NEW.nombre_plataforma);
    NEW.tipo_fuente := dw.fn_normalizar_texto(NEW.tipo_fuente);
    NEW.proveedor_api := dw.fn_normalizar_texto(NEW.proveedor_api);
    NEW.version_api := dw.fn_normalizar_texto(NEW.version_api);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_fuente
-- FUNCIÓN:
-- Normaliza datos descriptivos de fuentes. URLs se limpian sin convertir a
-- mayúsculas para no alterar rutas ni parámetros técnicos.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_fuente()
RETURNS TRIGGER AS $$
BEGIN
    NEW.nombre_fuente := dw.fn_normalizar_texto(NEW.nombre_fuente);
    NEW.identificador_origen := dw.fn_normalizar_url(NEW.identificador_origen);
    NEW.url_perfil := dw.fn_normalizar_url(NEW.url_perfil);
    NEW.url_api := dw.fn_normalizar_url(NEW.url_api);
    NEW.responsable_interno := dw.fn_normalizar_texto(NEW.responsable_interno);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_tipo_contenido
-- FUNCIÓN:
-- Normaliza catálogo de tipos de contenido.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_tipo_contenido()
RETURNS TRIGGER AS $$
BEGIN
    NEW.codigo_tipo_contenido := dw.fn_normalizar_texto(NEW.codigo_tipo_contenido);
    NEW.nombre_tipo_contenido := dw.fn_normalizar_texto(NEW.nombre_tipo_contenido);
    NEW.descripcion := dw.fn_normalizar_texto(NEW.descripcion);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_categoria_contenido
-- FUNCIÓN:
-- Normaliza catálogo de categorías institucionales.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_categoria_contenido()
RETURNS TRIGGER AS $$
BEGIN
    NEW.codigo_categoria := dw.fn_normalizar_texto(NEW.codigo_categoria);
    NEW.nombre_categoria := dw.fn_normalizar_texto(NEW.nombre_categoria);
    NEW.descripcion := dw.fn_normalizar_texto(NEW.descripcion);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_contenido_institucional
-- FUNCIÓN:
-- Normaliza datos de piezas comunicacionales normalizadas.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_contenido_institucional()
RETURNS TRIGGER AS $$
BEGIN
    NEW.slug_contenido := dw.fn_normalizar_url(NEW.slug_contenido);
    NEW.titulo_normalizado := dw.fn_normalizar_texto(NEW.titulo_normalizado);
    NEW.descripcion_normalizada := dw.fn_normalizar_texto(NEW.descripcion_normalizada);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_publicacion
-- FUNCIÓN:
-- Normaliza publicaciones en el DW. URLs se limpian sin mayúsculas; hashes y
-- JSON se conservan sin alteración.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_publicacion()
RETURNS TRIGGER AS $$
BEGIN
    NEW.identificador_publicacion_origen := dw.fn_normalizar_url(NEW.identificador_publicacion_origen);
    NEW.url_origen := dw.fn_normalizar_url(NEW.url_origen);
    NEW.titulo := dw.fn_normalizar_texto(NEW.titulo);
    NEW.cuerpo := dw.fn_normalizar_texto(NEW.cuerpo);
    NEW.autor := dw.fn_normalizar_texto(NEW.autor);
    NEW.estado_publicacion := COALESCE(dw.fn_normalizar_texto(NEW.estado_publicacion), 'ACTIVA');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------
-- FUNCIÓN: dw.fn_normalizar_dim_tipo_metrica
-- FUNCIÓN:
-- Normaliza catálogo flexible de métricas digitales.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION dw.fn_normalizar_dim_tipo_metrica()
RETURNS TRIGGER AS $$
BEGIN
    NEW.codigo_metrica := dw.fn_normalizar_texto(NEW.codigo_metrica);
    NEW.nombre_metrica := dw.fn_normalizar_texto(NEW.nombre_metrica);
    NEW.categoria_metrica := dw.fn_normalizar_texto(NEW.categoria_metrica);
    NEW.polaridad_metrica := COALESCE(dw.fn_normalizar_texto(NEW.polaridad_metrica), 'NO_APLICA');
    NEW.descripcion := dw.fn_normalizar_texto(NEW.descripcion);
    NEW.estatus := COALESCE(dw.fn_normalizar_texto(NEW.estatus), 'ACTIVO');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers idempotentes de normalización de cadenas en tablas controladas.
DROP TRIGGER IF EXISTS tg_normalizar_dim_plataforma ON dw.dim_plataforma;
CREATE TRIGGER tg_normalizar_dim_plataforma
BEFORE INSERT OR UPDATE ON dw.dim_plataforma
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_plataforma();

DROP TRIGGER IF EXISTS tg_normalizar_dim_fuente ON dw.dim_fuente;
CREATE TRIGGER tg_normalizar_dim_fuente
BEFORE INSERT OR UPDATE ON dw.dim_fuente
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_fuente();

DROP TRIGGER IF EXISTS tg_normalizar_dim_tipo_contenido ON dw.dim_tipo_contenido;
CREATE TRIGGER tg_normalizar_dim_tipo_contenido
BEFORE INSERT OR UPDATE ON dw.dim_tipo_contenido
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_tipo_contenido();

DROP TRIGGER IF EXISTS tg_normalizar_dim_categoria_contenido ON dw.dim_categoria_contenido;
CREATE TRIGGER tg_normalizar_dim_categoria_contenido
BEFORE INSERT OR UPDATE ON dw.dim_categoria_contenido
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_categoria_contenido();

DROP TRIGGER IF EXISTS tg_normalizar_dim_contenido_institucional ON dw.dim_contenido_institucional;
CREATE TRIGGER tg_normalizar_dim_contenido_institucional
BEFORE INSERT OR UPDATE ON dw.dim_contenido_institucional
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_contenido_institucional();

DROP TRIGGER IF EXISTS tg_normalizar_dim_publicacion ON dw.dim_publicacion;
CREATE TRIGGER tg_normalizar_dim_publicacion
BEFORE INSERT OR UPDATE ON dw.dim_publicacion
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_publicacion();

DROP TRIGGER IF EXISTS tg_normalizar_dim_tipo_metrica ON dw.dim_tipo_metrica;
CREATE TRIGGER tg_normalizar_dim_tipo_metrica
BEFORE INSERT OR UPDATE ON dw.dim_tipo_metrica
FOR EACH ROW EXECUTE FUNCTION dw.fn_normalizar_dim_tipo_metrica();

-- Triggers idempotentes para columnas actualizado_el.
DROP TRIGGER IF EXISTS tg_update_timestamp_stg_origen ON staging.stg_registro_origen;
CREATE TRIGGER tg_update_timestamp_stg_origen
BEFORE UPDATE ON staging.stg_registro_origen
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_plataforma ON dw.dim_plataforma;
CREATE TRIGGER tg_update_timestamp_plataforma
BEFORE UPDATE ON dw.dim_plataforma
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_fuente ON dw.dim_fuente;
CREATE TRIGGER tg_update_timestamp_fuente
BEFORE UPDATE ON dw.dim_fuente
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_tipo_contenido ON dw.dim_tipo_contenido;
CREATE TRIGGER tg_update_timestamp_tipo_contenido
BEFORE UPDATE ON dw.dim_tipo_contenido
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_categoria_contenido ON dw.dim_categoria_contenido;
CREATE TRIGGER tg_update_timestamp_categoria_contenido
BEFORE UPDATE ON dw.dim_categoria_contenido
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_contenido ON dw.dim_contenido_institucional;
CREATE TRIGGER tg_update_timestamp_contenido
BEFORE UPDATE ON dw.dim_contenido_institucional
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_publicacion ON dw.dim_publicacion;
CREATE TRIGGER tg_update_timestamp_publicacion
BEFORE UPDATE ON dw.dim_publicacion
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_tipo_metrica ON dw.dim_tipo_metrica;
CREATE TRIGGER tg_update_timestamp_tipo_metrica
BEFORE UPDATE ON dw.dim_tipo_metrica
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_metricas_publicacion ON dw.fact_metricas_publicacion_diaria;
CREATE TRIGGER tg_update_timestamp_metricas_publicacion
BEFORE UPDATE ON dw.fact_metricas_publicacion_diaria
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_metrica_detalle ON dw.fact_metrica_publicacion_detalle;
CREATE TRIGGER tg_update_timestamp_metrica_detalle
BEFORE UPDATE ON dw.fact_metrica_publicacion_detalle
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_comunidad ON dw.fact_comunidad_estado_diario;
CREATE TRIGGER tg_update_timestamp_comunidad
BEFORE UPDATE ON dw.fact_comunidad_estado_diario
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();

DROP TRIGGER IF EXISTS tg_update_timestamp_log_maestro ON audit.log_proceso_maestro;
CREATE TRIGGER tg_update_timestamp_log_maestro
BEFORE UPDATE ON audit.log_proceso_maestro
FOR EACH ROW EXECUTE FUNCTION dw.fn_actualizar_timestamp();


-- =============================================================================
-- 9. DATOS SEMILLA OPCIONALES DE CATÁLOGOS
-- =============================================================================

-- -----------------------------------------------------------------------------
-- PRECARGA: DIMENSIÓN TIEMPO
-- FUNCIÓN:
-- Carga un calendario maestro desde 2010 hasta 2050. Esta precarga evita que el
-- ETL de n8n tenga que crear fechas dinámicamente y garantiza consistencia en
-- filtros temporales de Metabase. Se usa CASE explícito para no depender del
-- locale del sistema operativo o del contenedor PostgreSQL.
-- -----------------------------------------------------------------------------
INSERT INTO dw.dim_tiempo (
    id_tiempo,
    fecha,
    dia,
    mes,
    nombre_mes,
    anho,
    dia_semana,
    nombre_dia,
    trimestre,
    semana_anio,
    es_fin_de_semana
)
SELECT
    TO_CHAR(datum, 'YYYYMMDD')::INT AS id_tiempo, -- Llave inteligente YYYYMMDD.
    datum::DATE AS fecha, -- Fecha calendario estándar.
    EXTRACT(DAY FROM datum)::INT AS dia, -- Día del mes.
    EXTRACT(MONTH FROM datum)::INT AS mes, -- Mes numérico.
    CASE EXTRACT(MONTH FROM datum)::INT -- Nombre del mes sin depender de locale.
        WHEN 1 THEN 'ENERO'
        WHEN 2 THEN 'FEBRERO'
        WHEN 3 THEN 'MARZO'
        WHEN 4 THEN 'ABRIL'
        WHEN 5 THEN 'MAYO'
        WHEN 6 THEN 'JUNIO'
        WHEN 7 THEN 'JULIO'
        WHEN 8 THEN 'AGOSTO'
        WHEN 9 THEN 'SEPTIEMBRE'
        WHEN 10 THEN 'OCTUBRE'
        WHEN 11 THEN 'NOVIEMBRE'
        WHEN 12 THEN 'DICIEMBRE'
    END AS nombre_mes,
    EXTRACT(YEAR FROM datum)::INT AS anho, -- Año calendario.
    EXTRACT(ISODOW FROM datum)::INT AS dia_semana, -- Día ISO: 1 lunes, 7 domingo.
    CASE EXTRACT(ISODOW FROM datum)::INT -- Nombre del día sin depender de locale.
        WHEN 1 THEN 'LUNES'
        WHEN 2 THEN 'MARTES'
        WHEN 3 THEN 'MIERCOLES'
        WHEN 4 THEN 'JUEVES'
        WHEN 5 THEN 'VIERNES'
        WHEN 6 THEN 'SABADO'
        WHEN 7 THEN 'DOMINGO'
    END AS nombre_dia,
    EXTRACT(QUARTER FROM datum)::INT AS trimestre, -- Trimestre calendario.
    EXTRACT(WEEK FROM datum)::INT AS semana_anio, -- Semana ISO del año.
    CASE WHEN EXTRACT(ISODOW FROM datum)::INT IN (6,7) THEN TRUE ELSE FALSE END AS es_fin_de_semana -- Marca sábado/domingo.
FROM generate_series(
    '2010-01-01'::DATE,
    '2050-12-31'::DATE,
    '1 day'::INTERVAL
) AS datum
ON CONFLICT (id_tiempo) DO NOTHING;

-- -----------------------------------------------------------------------------
-- PRECARGA: PLATAFORMAS DIGITALES
-- FUNCIÓN:
-- Carga el catálogo base de plataformas actuales y futuras. Esto permite que el
-- modelo sea escalable para incorporar nuevas redes sociales sin modificar las
-- tablas de hechos. Las plataformas futuras quedan como catálogo disponible; solo
-- se utilizarán cuando se configuren fuentes y procesos ETL asociados.
-- -----------------------------------------------------------------------------
INSERT INTO dw.dim_plataforma (
    nombre_plataforma,
    tipo_fuente,
    proveedor_api,
    version_api,
    permite_historico,
    requiere_token,
    estatus
)
VALUES
('X', 'RED_SOCIAL', 'X Corp', 'API v2', FALSE, TRUE, 'ACTIVO'), -- Plataforma X/Twitter; API con restricciones de lectura.
('FACEBOOK', 'RED_SOCIAL', 'Meta', 'Graph API', TRUE, TRUE, 'ACTIVO'), -- Página/perfil Facebook mediante Meta Graph API.
('INSTAGRAM', 'RED_SOCIAL', 'Meta', 'Instagram Graph API', TRUE, TRUE, 'ACTIVO'), -- Instagram profesional/business mediante Graph API.
('YOUTUBE', 'RED_SOCIAL', 'Google', 'YouTube Data API v3', TRUE, TRUE, 'ACTIVO'), -- YouTube mediante API Key/OAuth según alcance.
('PORTAL WEB', 'PORTAL_WEB', 'WordPress', 'REST API', TRUE, FALSE, 'ACTIVO'), -- Portal institucional WordPress público consultado por REST API.
('WHATSAPP', 'MENSAJERIA', 'Meta', 'WhatsApp Business Cloud API', FALSE, TRUE, 'INACTIVO'), -- Plataforma futura; requiere cuenta/API empresarial.
('TIKTOK', 'RED_SOCIAL', 'TikTok', 'TikTok API', FALSE, TRUE, 'INACTIVO'), -- Plataforma futura; depende de permisos API.
('LINKEDIN', 'RED_SOCIAL', 'LinkedIn', 'LinkedIn API', FALSE, TRUE, 'INACTIVO'), -- Plataforma futura institucional/profesional.
('TELEGRAM', 'MENSAJERIA', 'Telegram', 'Bot API', TRUE, TRUE, 'INACTIVO'), -- Plataforma futura para canales/bots.
('THREADS', 'RED_SOCIAL', 'Meta', 'Threads API', FALSE, TRUE, 'INACTIVO'), -- Plataforma futura del ecosistema Meta.
('OTRO', 'OTRO', NULL, NULL, FALSE, FALSE, 'ACTIVO') -- Categoría genérica para fuentes no previstas.
ON CONFLICT (nombre_plataforma) DO UPDATE SET
    tipo_fuente = EXCLUDED.tipo_fuente,
    proveedor_api = EXCLUDED.proveedor_api,
    version_api = EXCLUDED.version_api,
    permite_historico = EXCLUDED.permite_historico,
    requiere_token = EXCLUDED.requiere_token,
    estatus = EXCLUDED.estatus,
    actualizado_el = CURRENT_TIMESTAMP;

-- -----------------------------------------------------------------------------
-- PRECARGA: FUENTES INSTITUCIONALES ACTUALES
-- FUNCIÓN:
-- Carga cuentas/canales/portales actualmente contemplados en el caso de estudio.
-- Se evita depender de IDs numéricos fijos de plataforma usando subconsultas.
-- Si en el futuro se agregan nuevas redes sociales, solo se insertan nuevas
-- fuentes asociadas a la plataforma correspondiente.
-- -----------------------------------------------------------------------------
INSERT INTO dw.dim_fuente (
    id_plataforma,
    nombre_fuente,
    identificador_origen,
    url_perfil,
    url_api,
    fecha_creacion_cuenta,
    responsable_interno,
    estatus
)
VALUES
((SELECT id_plataforma FROM dw.dim_plataforma WHERE nombre_plataforma = 'X'),
 'NOTICIAS UCV (X)',
 '@NOTICIENSUCV',
 'https://x.com/noticiensucv',
 NULL,
 '2024-01-01',
 'Departamento de Comunicaciones y Relaciones Públicas',
 'ACTIVO'), -- Cuenta X utilizada para difusión institucional.

((SELECT id_plataforma FROM dw.dim_plataforma WHERE nombre_plataforma = 'FACEBOOK'),
 'COORD. EXTENSION UCV',
 'COORD. EXTENSION UCV',
 'https://www.facebook.com/extensionucv',
 NULL,
 '2018-02-15',
 'Coordinación de Extensión',
 'ACTIVO'), -- Página Facebook institucional.

((SELECT id_plataforma FROM dw.dim_plataforma WHERE nombre_plataforma = 'INSTAGRAM'),
 'COORD. EXTENSION CIENCIAS UCV',
 '@NOTICIENCIASUCV',
 'https://www.instagram.com/noticienciasucv',
 NULL,
 '2015-07-01',
 'Coordinación de Extensión',
 'ACTIVO'), -- Perfil Instagram institucional.

((SELECT id_plataforma FROM dw.dim_plataforma WHERE nombre_plataforma = 'YOUTUBE'),
 'FACULTAD DE CIENCIAS UCV',
 '@FACULTADDECIENCIASUCV9050',
 'https://www.youtube.com/@facultaducv',
 'https://www.googleapis.com/youtube/v3',
 '2021-04-05',
 'Facultad de Ciencias UCV',
 'ACTIVO'), -- Canal YouTube institucional.

((SELECT id_plataforma FROM dw.dim_plataforma WHERE nombre_plataforma = 'PORTAL WEB'),
 'NOTICIENCIAS WEB',
 'NOTICIENCIAS.UCV.VE',
 'https://noticiencias.ucv.ve',
 'https://noticiencias.ucv.ve/wp-json/wp/v2/posts',
 '2017-01-01',
 'Departamento de Comunicaciones y Relaciones Públicas',
 'ACTIVO') -- Portal WordPress público consultado por REST API; no se modela RSS como fuente separada para evitar duplicidad del mismo sitio.
ON CONFLICT (id_plataforma, identificador_origen) DO UPDATE SET
    nombre_fuente = EXCLUDED.nombre_fuente,
    url_perfil = EXCLUDED.url_perfil,
    url_api = EXCLUDED.url_api,
    fecha_creacion_cuenta = EXCLUDED.fecha_creacion_cuenta,
    responsable_interno = EXCLUDED.responsable_interno,
    estatus = EXCLUDED.estatus,
    actualizado_el = CURRENT_TIMESTAMP;

-- -----------------------------------------------------------------------------
-- PRECARGA: TIPOS DE CONTENIDO
-- FUNCIÓN:
-- Carga formatos frecuentes de contenido digital. El catálogo puede ampliarse sin
-- modificar hechos ni dimensiones principales, lo cual favorece escalabilidad.
-- -----------------------------------------------------------------------------
-- Catálogo base de tipos de contenido. Puede ampliarse según necesidades del DBA.
INSERT INTO dw.dim_tipo_contenido (codigo_tipo_contenido, nombre_tipo_contenido, descripcion)
VALUES
('POST', 'Post', 'Publicación estándar en red social.'),
('REEL', 'Reel', 'Video corto vertical en Instagram/Facebook.'),
('STORY', 'Historia', 'Contenido efímero tipo historia.'),
('VIDEO', 'Video', 'Video estándar publicado en plataforma audiovisual o social.'),
('SHORT', 'Short', 'Video corto vertical en YouTube u otra plataforma.'),
('NOTA_WEB', 'Nota web', 'Publicación informativa del portal web institucional.'),
('CARRUSEL', 'Carrusel', 'Publicación compuesta por varias imágenes o piezas.'),
('OTRO', 'Otro', 'Tipo de contenido no clasificado.')
ON CONFLICT (codigo_tipo_contenido) DO NOTHING;

-- -----------------------------------------------------------------------------
-- PRECARGA: CATEGORÍAS DE CONTENIDO
-- FUNCIÓN:
-- Carga categorías temáticas institucionales iniciales para clasificar noticias,
-- publicaciones y piezas comunicacionales. Estas categorías pueden ajustarse con
-- usuarios funcionales durante el levantamiento de requerimientos.
-- -----------------------------------------------------------------------------
INSERT INTO dw.dim_categoria_contenido (codigo_categoria, nombre_categoria, descripcion)
VALUES
('ACADEMICO', 'Académico', 'Contenido relacionado con docencia, actividades académicas, clases, inscripciones y vida estudiantil.'),
('INVESTIGACION', 'Investigación', 'Contenido asociado a proyectos, publicaciones, laboratorios, ciencia y producción investigativa.'),
('EXTENSION', 'Extensión', 'Actividades de vinculación institucional, extensión universitaria, cursos y servicios a la comunidad.'),
('EVENTO', 'Evento', 'Convocatorias, charlas, foros, conferencias, jornadas, seminarios y encuentros institucionales.'),
('NOTICIA', 'Noticia institucional', 'Comunicaciones informativas generales de la Facultad o sus dependencias.'),
('CURSO', 'Curso / taller', 'Oferta de cursos, talleres, diplomados, formación continua o actividades de capacitación.'),
('CONVOCATORIA', 'Convocatoria', 'Llamados a participación, concursos, postulaciones, procesos internos o actividades abiertas.'),
('SERVICIO', 'Servicio', 'Información sobre servicios institucionales, trámites, atención al público o soporte a la comunidad.'),
('COMUNICADO', 'Comunicado', 'Avisos oficiales, pronunciamientos, alertas o información institucional relevante.'),
('SIN_CLASIFICAR', 'Sin Clasificar', 'Publicaciones sin categoría definida.'),
('OTRO', 'Otro', 'Categoría genérica para contenidos no clasificados inicialmente.')
ON CONFLICT (codigo_categoria) DO NOTHING;

-- Catálogo base de métricas frecuentes. Puede ampliarse para nuevas plataformas.
INSERT INTO dw.dim_tipo_metrica (codigo_metrica, nombre_metrica, categoria_metrica, polaridad_metrica, descripcion, es_acumulada)
VALUES
('LIKE', 'Me gusta', 'REACCION', 'POSITIVA', 'Reacción positiva básica en redes sociales.', TRUE),
('LOVE', 'Me encanta', 'REACCION', 'POSITIVA', 'Reacción positiva explícita, principalmente disponible en Meta/Facebook.', TRUE),
('HAHA', 'Me divierte', 'REACCION', 'NEUTRA', 'Reacción de humor; se clasifica como neutral por no ser necesariamente aprobación.', TRUE),
('WOW', 'Me asombra', 'REACCION', 'NEUTRA', 'Reacción de asombro; se clasifica como neutral por ambigüedad semántica.', TRUE),
('SAD', 'Me entristece', 'REACCION', 'NEGATIVA', 'Reacción asociada a tristeza o contenido sensible.', TRUE),
('ANGRY', 'Me enoja', 'REACCION', 'NEGATIVA', 'Reacción negativa explícita.', TRUE),
('COMENTARIO', 'Comentario', 'INTERACCION', 'NO_APLICA', 'Cantidad de comentarios o respuestas recibidas.', TRUE),
('COMPARTIDO', 'Compartido/Repost', 'DIFUSION', 'NO_APLICA', 'Cantidad de compartidos, reposts o shares.', TRUE),
('GUARDADO', 'Guardado/Bookmark', 'INTERACCION', 'NO_APLICA', 'Cantidad de guardados o bookmarks.', TRUE),
('VISTA', 'Vista/Reproducción', 'VISIBILIDAD', 'NO_APLICA', 'Cantidad de vistas o reproducciones.', TRUE),
('ALCANCE', 'Alcance', 'VISIBILIDAD', 'NO_APLICA', 'Cantidad de usuarios alcanzados, si la plataforma lo permite.', TRUE),
('IMPRESION', 'Impresión', 'VISIBILIDAD', 'NO_APLICA', 'Cantidad de impresiones generadas.', TRUE),
('SEGUIDOR', 'Seguidor/Suscriptor', 'COMUNIDAD', 'NO_APLICA', 'Cantidad de seguidores o suscriptores.', TRUE)
ON CONFLICT (codigo_metrica) DO NOTHING;


-- =============================================================================
-- 10. COMMENT ON (DOCUMENTACIÓN EXHAUSTIVA PARA DBA)
-- =============================================================================

COMMENT ON FUNCTION dw.fn_normalizar_texto(TEXT) IS 'Función de gobierno de datos que elimina espacios iniciales/finales, compacta espacios internos y convierte cadenas a mayúsculas conservando acentos según collation de PostgreSQL.';
COMMENT ON FUNCTION dw.fn_normalizar_url(TEXT) IS 'Función de limpieza para URLs y endpoints; elimina espacios iniciales/finales sin convertir a mayúsculas para preservar rutas y parámetros técnicos.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_plataforma() IS 'Trigger function que normaliza campos de texto de dw.dim_plataforma antes de insertar o actualizar.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_fuente() IS 'Trigger function que normaliza campos descriptivos de dw.dim_fuente y limpia URLs sin alterar su estructura.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_tipo_contenido() IS 'Trigger function que normaliza el catálogo de tipos de contenido.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_categoria_contenido() IS 'Trigger function que normaliza el catálogo de categorías institucionales.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_contenido_institucional() IS 'Trigger function que normaliza piezas comunicacionales normalizadas.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_publicacion() IS 'Trigger function que normaliza campos descriptivos de publicaciones sin alterar URLs, hashes ni JSON.';
COMMENT ON FUNCTION dw.fn_normalizar_dim_tipo_metrica() IS 'Trigger function que normaliza el catálogo flexible de métricas digitales.';

COMMENT ON SCHEMA staging IS 'Zona de aterrizaje y preparación ETL para datos de origen y normalizados provenientes de APIs públicas, WordPress REST API, archivos y procesos externos. RSS/scraping se conservan solo como mecanismos alternativos si una fuente futura no expone API.';
COMMENT ON SCHEMA dw IS 'Data Warehouse dimensional basado en Ralph Kimball; contiene dimensiones conformadas y tablas de hechos del sistema BI.';
COMMENT ON SCHEMA audit IS 'Esquema especializado para auditoría, monitoreo, trazabilidad ETL y control de calidad de datos.';
COMMENT ON SCHEMA datamart IS 'Capa analítica optimizada para dashboards, KPIs y consumo desde Metabase.';

COMMENT ON TABLE staging.stg_registro_origen IS 'Tabla genérica de aterrizaje que conserva la respuesta original de cualquier fuente digital para trazabilidad y reprocesamiento.';
COMMENT ON TABLE staging.stg_publicacion_normalizada IS 'Tabla staging con estructura común de publicaciones antes de cargar dimensiones y hechos del DW.';
COMMENT ON TABLE staging.stg_metricas_publicacion_normalizada IS 'Tabla staging con métricas observadas por publicación, incluyendo totales y variaciones previas a la carga al DW.';
COMMENT ON TABLE staging.stg_comunidad_normalizada IS 'Tabla staging con snapshots diarios de comunidad/perfil antes de cargar al hecho de comunidad.';

COMMENT ON TABLE dw.dim_tiempo IS 'Calendario maestro con granularidad diaria para análisis temporal de publicaciones, interacciones y comunidad.';
COMMENT ON TABLE dw.dim_plataforma IS 'Catálogo de plataformas digitales, redes sociales, portales web y fuentes similares.';
COMMENT ON TABLE dw.dim_fuente IS 'Catálogo de cuentas, perfiles, canales, páginas, portales o feeds específicos dentro de cada plataforma.';
COMMENT ON TABLE dw.dim_tipo_contenido IS 'Catálogo de formatos de contenido para comparar publicaciones por tipo: post, reel, video, nota web, etc.';
COMMENT ON TABLE dw.dim_categoria_contenido IS 'Catálogo de categorías temáticas institucionales para clasificar publicaciones y piezas comunicacionales.';
COMMENT ON TABLE dw.dim_contenido_institucional IS 'Dimensión que agrupa una misma pieza comunicacional publicada en varias plataformas para análisis multicanal.';
COMMENT ON TABLE dw.dim_publicacion IS 'Catálogo de publicaciones específicas por plataforma y fuente, asociables a una pieza comunicacional común.';
COMMENT ON TABLE dw.dim_tipo_metrica IS 'Catálogo flexible de métricas digitales, con clasificación por categoría y polaridad cuando aplique.';
COMMENT ON TABLE dw.fact_publicaciones IS 'Tabla de hechos sin medidas que registra existencia de publicaciones por fuente y fecha.';
COMMENT ON TABLE dw.fact_metricas_publicacion_diaria IS 'Hecho diario de métricas por publicación con valores acumulados observados y variaciones calculadas.';
COMMENT ON TABLE dw.fact_metrica_publicacion_detalle IS 'Hecho flexible de métricas específicas por publicación, fuente, día y tipo de métrica.';
COMMENT ON TABLE dw.fact_comunidad_estado_diario IS 'Snapshot diario de comunidad por fuente para analizar seguidores, publicaciones acumuladas y crecimiento.';

COMMENT ON TABLE audit.log_proceso_maestro IS 'Log maestro de ejecuciones ETL; registra inicio, fin, estado y conteos globales por workflow.';
COMMENT ON TABLE audit.log_proceso_detalle IS 'Log detallado de subprocesos ETL: extracción, staging, transformación, carga DW y datamarts.';

COMMENT ON MATERIALIZED VIEW datamart.mv_interacciones_por_publicacion IS 'Vista analítica para comparar interacciones por publicación, plataforma, fecha, tipo de contenido y categoría.';
COMMENT ON MATERIALIZED VIEW datamart.mv_metricas_flexibles_detalle IS 'Vista para analizar métricas flexibles por tipo y polaridad, incluyendo reacciones positivas, negativas y neutras.';
COMMENT ON MATERIALIZED VIEW datamart.mv_cobertura_contenido_plataforma IS 'Vista para determinar cobertura multicanal de contenidos institucionales por plataforma.';
COMMENT ON MATERIALIZED VIEW datamart.mv_comunidad_diaria IS 'Vista para analizar crecimiento diario de comunidad por fuente y plataforma.';
COMMENT ON MATERIALIZED VIEW datamart.mv_kpis_redes IS 'Materialized view mensual de KPIs por plataforma para Metabase; integra publicaciones e interacción y conserva plataformas activas con valor 0 cuando no existan datos.';

-- Comentarios de columnas generados explícitamente para documentación técnica.
COMMENT ON COLUMN staging.stg_registro_origen.id_staging IS 'Identificador técnico interno del registro de origen.';
COMMENT ON COLUMN staging.stg_registro_origen.id_ejecucion_n8n IS 'Identificador de ejecución o workflow en n8n que originó el registro.';
COMMENT ON COLUMN staging.stg_registro_origen.plataforma IS 'Nombre de la plataforma de origen: Facebook, Instagram, YouTube, X, TikTok, Web, etc.';
COMMENT ON COLUMN staging.stg_registro_origen.fuente IS 'Cuenta, página, canal, perfil, RSS o portal específico desde donde se obtuvo el dato.';
COMMENT ON COLUMN staging.stg_registro_origen.tipo_registro IS 'Tipo de dato capturado: PUBLICACION, METRICA_PUBLICACION, COMUNIDAD, COMENTARIO, OTRO.';
COMMENT ON COLUMN staging.stg_registro_origen.identificador_origen IS 'ID nativo del registro en la plataforma de origen, si existe.';
COMMENT ON COLUMN staging.stg_registro_origen.url_origen IS 'URL pública o técnica asociada al registro extraído.';
COMMENT ON COLUMN staging.stg_registro_origen.endpoint_origen IS 'Endpoint API, URL RSS o URL de scraping consultada.';
COMMENT ON COLUMN staging.stg_registro_origen.metodo_extraccion IS 'Método de extracción: API, RSS, SCRAPING, CSV, MANUAL u OTRO.';
COMMENT ON COLUMN staging.stg_registro_origen.respuesta_json IS 'Respuesta original completa en formato JSONB para trazabilidad y reprocesamiento.';
COMMENT ON COLUMN staging.stg_registro_origen.hash_respuesta IS 'Hash de la respuesta original para detectar duplicados o cambios entre extracciones.';
COMMENT ON COLUMN staging.stg_registro_origen.fecha_publicacion_origen IS 'Fecha/hora de publicación reportada por la fuente, cuando aplique.';
COMMENT ON COLUMN staging.stg_registro_origen.fecha_extraccion IS 'Fecha/hora en que n8n o el ETL extrajo el dato.';
COMMENT ON COLUMN staging.stg_registro_origen.estado_procesamiento IS 'Estado ETL: PENDIENTE, PROCESADO, DESCARTADO, ERROR.';
COMMENT ON COLUMN staging.stg_registro_origen.mensaje_procesamiento IS 'Mensaje técnico del procesamiento, error o justificación de descarte.';
COMMENT ON COLUMN staging.stg_registro_origen.creado_el IS 'Fecha/hora de creación del registro en staging.';
COMMENT ON COLUMN staging.stg_registro_origen.actualizado_el IS 'Fecha/hora de última actualización del registro en staging.';

COMMENT ON COLUMN staging.stg_publicacion_normalizada.id_stg_publicacion IS 'Identificador técnico del registro normalizado de publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.id_staging IS 'Referencia opcional al dato de origen que generó este registro.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.id_ejecucion_n8n IS 'Identificador de ejecución n8n asociado a la transformación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.plataforma IS 'Plataforma donde fue detectada la publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.fuente IS 'Cuenta, perfil, canal o portal específico de publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.identificador_publicacion_origen IS 'ID nativo de la publicación en la plataforma.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.url_origen IS 'URL pública de la publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.titulo IS 'Título, encabezado o descripción corta del contenido.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.cuerpo IS 'Texto principal o cuerpo de la publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.autor IS 'Autor o responsable identificado, si aplica.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.tipo_contenido IS 'Tipo de contenido: post, reel, story, video, short, nota web, carrusel, etc.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.categoria IS 'Categoría temática del contenido, cuando se pueda clasificar.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.titulo_normalizado IS 'Título común para agrupar una misma pieza comunicacional publicada en varias plataformas.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.slug_contenido IS 'Código/slug común de la pieza comunicacional para análisis multicanal.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.fecha_publicacion IS 'Fecha/hora original de publicación.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.hash_contenido IS 'Hash del contenido normalizado para apoyar detección de duplicados.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.metadata_json IS 'Metadatos normalizados relevantes que no ameritan columna propia.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.procesado IS 'Indica si el registro ya fue cargado al DW.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.mensaje_procesamiento IS 'Observación o error asociado al procesamiento hacia el DW.';
COMMENT ON COLUMN staging.stg_publicacion_normalizada.creado_el IS 'Fecha/hora de creación del registro normalizado.';

COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.id_stg_metrica IS 'Identificador técnico del registro normalizado de métricas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.id_staging IS 'Referencia opcional al dato de origen que generó las métricas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.id_ejecucion_n8n IS 'Identificador de ejecución n8n asociado a la extracción de métricas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.plataforma IS 'Plataforma donde se observó la métrica.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.fuente IS 'Cuenta, perfil, canal o portal donde se observó la métrica.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.identificador_publicacion_origen IS 'ID nativo de la publicación a la que pertenecen las métricas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.url_origen IS 'URL de la publicación, útil cuando la API no suministra ID estable.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.fecha_observacion IS 'Día al que corresponde la observación de métricas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.likes_total IS 'Total acumulado de likes observado en la fecha de extracción.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.likes_variacion IS 'Diferencia de likes frente a la observación anterior registrada.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.comentarios_total IS 'Total acumulado de comentarios observado.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.comentarios_variacion IS 'Diferencia de comentarios frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.compartidos_total IS 'Total acumulado de compartidos/reposts observado.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.compartidos_variacion IS 'Diferencia de compartidos/reposts frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.guardados_total IS 'Total acumulado de guardados/bookmarks observado, si la plataforma lo permite.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.guardados_variacion IS 'Diferencia de guardados/bookmarks frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.vistas_total IS 'Total acumulado de vistas/reproducciones observado.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.vistas_variacion IS 'Diferencia de vistas/reproducciones frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.alcance_total IS 'Total acumulado o estimado de alcance observado, cuando exista.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.alcance_variacion IS 'Diferencia de alcance frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.impresiones_total IS 'Total acumulado de impresiones observado, cuando exista.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.impresiones_variacion IS 'Diferencia de impresiones frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_positivas_total IS 'Total acumulado de reacciones clasificadas como positivas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_positivas_variacion IS 'Diferencia de reacciones positivas frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_negativas_total IS 'Total acumulado de reacciones clasificadas como negativas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_negativas_variacion IS 'Diferencia de reacciones negativas frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_neutrales_total IS 'Total acumulado de reacciones clasificadas como neutrales.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.reacciones_neutrales_variacion IS 'Diferencia de reacciones neutrales frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.metadata_json IS 'Métricas adicionales o propias de cada plataforma aún no modeladas en columnas.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.procesado IS 'Indica si el registro fue cargado a las tablas de hechos.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.mensaje_procesamiento IS 'Observación o error asociado al procesamiento hacia el DW.';
COMMENT ON COLUMN staging.stg_metricas_publicacion_normalizada.creado_el IS 'Fecha/hora de creación del registro normalizado de métricas.';

COMMENT ON COLUMN staging.stg_comunidad_normalizada.id_stg_comunidad IS 'Identificador técnico del snapshot normalizado de comunidad.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.id_staging IS 'Referencia opcional al dato de origen que generó el snapshot.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.id_ejecucion_n8n IS 'Identificador de ejecución n8n asociado al snapshot.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.plataforma IS 'Plataforma donde se observó la comunidad.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.fuente IS 'Cuenta, perfil, canal o portal analizado.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.identificador_fuente_origen IS 'ID nativo de la fuente/perfil/canal en la plataforma.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.fecha_observacion IS 'Día al que corresponde el snapshot de comunidad.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.total_seguidores IS 'Total acumulado de seguidores/suscriptores observado.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.seguidores_variacion IS 'Diferencia de seguidores frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.total_publicaciones_perfil IS 'Total acumulado de publicaciones reportado por el perfil/canal.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.publicaciones_perfil_variacion IS 'Diferencia de publicaciones del perfil frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.vistas_totales_perfil IS 'Total acumulado de vistas del perfil/canal, si aplica.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.vistas_perfil_variacion IS 'Diferencia de vistas del perfil/canal frente a la observación anterior.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.metadata_json IS 'Datos adicionales del perfil/canal no modelados en columnas específicas.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.procesado IS 'Indica si el snapshot fue cargado al DW.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.mensaje_procesamiento IS 'Observación o error asociado al procesamiento hacia el DW.';
COMMENT ON COLUMN staging.stg_comunidad_normalizada.creado_el IS 'Fecha/hora de creación del snapshot normalizado.';

COMMENT ON COLUMN dw.dim_tiempo.id_tiempo IS 'Llave inteligente en formato YYYYMMDD.';
COMMENT ON COLUMN dw.dim_tiempo.fecha IS 'Fecha calendario estándar.';
COMMENT ON COLUMN dw.dim_tiempo.dia IS 'Número de día del mes.';
COMMENT ON COLUMN dw.dim_tiempo.mes IS 'Número de mes del año.';
COMMENT ON COLUMN dw.dim_tiempo.nombre_mes IS 'Nombre del mes para visualización.';
COMMENT ON COLUMN dw.dim_tiempo.anho IS 'Año calendario en formato YYYY.';
COMMENT ON COLUMN dw.dim_tiempo.dia_semana IS 'Día ISO de semana: 1=Lunes, 7=Domingo.';
COMMENT ON COLUMN dw.dim_tiempo.nombre_dia IS 'Nombre del día de la semana.';
COMMENT ON COLUMN dw.dim_tiempo.trimestre IS 'Trimestre calendario.';
COMMENT ON COLUMN dw.dim_tiempo.semana_anio IS 'Semana ISO del año.';
COMMENT ON COLUMN dw.dim_tiempo.es_fin_de_semana IS 'Indica si la fecha corresponde a sábado o domingo.';
COMMENT ON COLUMN dw.dim_tiempo.creado_el IS 'Fecha/hora de creación del registro calendario.';

COMMENT ON COLUMN dw.dim_plataforma.id_plataforma IS 'Llave surrogate de la plataforma.';
COMMENT ON COLUMN dw.dim_plataforma.nombre_plataforma IS 'Nombre de la plataforma: Facebook, Instagram, YouTube, X, TikTok, Web, etc.';
COMMENT ON COLUMN dw.dim_plataforma.tipo_fuente IS 'Clasificación: RED_SOCIAL, PORTAL_WEB, MENSAJERIA, BUSCADOR, OTRO.';
COMMENT ON COLUMN dw.dim_plataforma.proveedor_api IS 'Proveedor o familia tecnológica de la API, por ejemplo Meta, Google, X Corp.';
COMMENT ON COLUMN dw.dim_plataforma.version_api IS 'Versión de API o mecanismo de extracción utilizado.';
COMMENT ON COLUMN dw.dim_plataforma.permite_historico IS 'Indica si la plataforma permite recuperar datos históricos de forma directa.';
COMMENT ON COLUMN dw.dim_plataforma.requiere_token IS 'Indica si la plataforma requiere token/credenciales para extracción automatizada.';
COMMENT ON COLUMN dw.dim_plataforma.estatus IS 'Estado lógico de la plataforma: ACTIVO, INACTIVO, SUSPENDIDO.';
COMMENT ON COLUMN dw.dim_plataforma.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_plataforma.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_fuente.id_fuente IS 'Llave surrogate de la fuente.';
COMMENT ON COLUMN dw.dim_fuente.id_plataforma IS 'Plataforma a la que pertenece la fuente.';
COMMENT ON COLUMN dw.dim_fuente.nombre_fuente IS 'Nombre público o descriptivo de la cuenta/perfil/canal.';
COMMENT ON COLUMN dw.dim_fuente.identificador_origen IS 'Identificador nativo de la fuente en la plataforma: username, channel_id, page_id, URL, etc.';
COMMENT ON COLUMN dw.dim_fuente.url_perfil IS 'URL pública del perfil, página, canal o portal.';
COMMENT ON COLUMN dw.dim_fuente.url_api IS 'Endpoint base o referencia técnica usada para extracción.';
COMMENT ON COLUMN dw.dim_fuente.fecha_creacion_cuenta IS 'Fecha de creación de la cuenta/canal, si está disponible.';
COMMENT ON COLUMN dw.dim_fuente.responsable_interno IS 'Unidad o persona responsable funcional de la fuente.';
COMMENT ON COLUMN dw.dim_fuente.estatus IS 'Estado lógico de la fuente: ACTIVO, INACTIVO, SUSPENDIDO.';
COMMENT ON COLUMN dw.dim_fuente.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_fuente.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_tipo_contenido.id_tipo_contenido IS 'Llave surrogate del tipo de contenido.';
COMMENT ON COLUMN dw.dim_tipo_contenido.codigo_tipo_contenido IS 'Código técnico: POST, REEL, STORY, VIDEO, SHORT, NOTA_WEB, CARRUSEL, OTRO.';
COMMENT ON COLUMN dw.dim_tipo_contenido.nombre_tipo_contenido IS 'Nombre legible del tipo de contenido.';
COMMENT ON COLUMN dw.dim_tipo_contenido.descripcion IS 'Descripción funcional del tipo de contenido.';
COMMENT ON COLUMN dw.dim_tipo_contenido.estatus IS 'Estado lógico del tipo de contenido.';
COMMENT ON COLUMN dw.dim_tipo_contenido.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_tipo_contenido.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_categoria_contenido.id_categoria_contenido IS 'Llave surrogate de la categoría.';
COMMENT ON COLUMN dw.dim_categoria_contenido.codigo_categoria IS 'Código técnico de categoría.';
COMMENT ON COLUMN dw.dim_categoria_contenido.nombre_categoria IS 'Nombre descriptivo de la categoría.';
COMMENT ON COLUMN dw.dim_categoria_contenido.descripcion IS 'Descripción funcional de la categoría.';
COMMENT ON COLUMN dw.dim_categoria_contenido.estatus IS 'Estado lógico de la categoría.';
COMMENT ON COLUMN dw.dim_categoria_contenido.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_categoria_contenido.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_contenido_institucional.id_contenido IS 'Llave surrogate de la pieza comunicacional institucional.';
COMMENT ON COLUMN dw.dim_contenido_institucional.slug_contenido IS 'Identificador común/slug para agrupar publicaciones equivalentes entre plataformas.';
COMMENT ON COLUMN dw.dim_contenido_institucional.titulo_normalizado IS 'Título institucional común de la pieza comunicacional.';
COMMENT ON COLUMN dw.dim_contenido_institucional.descripcion_normalizada IS 'Descripción consolidada o resumen de la pieza comunicacional.';
COMMENT ON COLUMN dw.dim_contenido_institucional.id_categoria_contenido IS 'Categoría temática institucional.';
COMMENT ON COLUMN dw.dim_contenido_institucional.fecha_referencia IS 'Fecha de referencia del contenido, evento o noticia.';
COMMENT ON COLUMN dw.dim_contenido_institucional.hash_contenido_normalizado IS 'Hash del contenido normalizado para apoyar detección de duplicados.';
COMMENT ON COLUMN dw.dim_contenido_institucional.estatus IS 'Estado lógico del contenido: ACTIVO, INACTIVO, ARCHIVADO.';
COMMENT ON COLUMN dw.dim_contenido_institucional.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_contenido_institucional.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_publicacion.id_publicacion IS 'Llave surrogate de la publicación.';
COMMENT ON COLUMN dw.dim_publicacion.id_contenido IS 'Pieza comunicacional común a la que pertenece esta publicación.';
COMMENT ON COLUMN dw.dim_publicacion.id_fuente IS 'Fuente/cuenta/canal donde se publicó el contenido.';
COMMENT ON COLUMN dw.dim_publicacion.id_tipo_contenido IS 'Tipo/formato de contenido publicado.';
COMMENT ON COLUMN dw.dim_publicacion.id_categoria_contenido IS 'Categoría temática de la publicación.';
COMMENT ON COLUMN dw.dim_publicacion.identificador_publicacion_origen IS 'ID nativo de la publicación en la plataforma.';
COMMENT ON COLUMN dw.dim_publicacion.url_origen IS 'URL pública de la publicación.';
COMMENT ON COLUMN dw.dim_publicacion.titulo IS 'Título, encabezado o descripción corta de la publicación.';
COMMENT ON COLUMN dw.dim_publicacion.cuerpo IS 'Texto completo o cuerpo principal de la publicación.';
COMMENT ON COLUMN dw.dim_publicacion.autor IS 'Autor o responsable identificado, si aplica.';
COMMENT ON COLUMN dw.dim_publicacion.fecha_publicacion IS 'Fecha/hora original de publicación.';
COMMENT ON COLUMN dw.dim_publicacion.estado_publicacion IS 'Estado: ACTIVA, ELIMINADA, OCULTA, DESCONOCIDA.';
COMMENT ON COLUMN dw.dim_publicacion.hash_contenido IS 'Hash de contenido normalizado para control de duplicados.';
COMMENT ON COLUMN dw.dim_publicacion.metadata_json IS 'Atributos adicionales dependientes de plataforma.';
COMMENT ON COLUMN dw.dim_publicacion.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_publicacion.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.dim_tipo_metrica.id_tipo_metrica IS 'Llave surrogate del tipo de métrica.';
COMMENT ON COLUMN dw.dim_tipo_metrica.codigo_metrica IS 'Código técnico: LIKE, LOVE, ANGRY, COMENTARIO, COMPARTIDO, VISTA, ALCANCE, etc.';
COMMENT ON COLUMN dw.dim_tipo_metrica.nombre_metrica IS 'Nombre legible de la métrica.';
COMMENT ON COLUMN dw.dim_tipo_metrica.categoria_metrica IS 'Categoría: REACCION, INTERACCION, DIFUSION, VISIBILIDAD, COMUNIDAD, OTRO.';
COMMENT ON COLUMN dw.dim_tipo_metrica.polaridad_metrica IS 'Polaridad: POSITIVA, NEGATIVA, NEUTRA, NO_APLICA.';
COMMENT ON COLUMN dw.dim_tipo_metrica.descripcion IS 'Descripción funcional de la métrica.';
COMMENT ON COLUMN dw.dim_tipo_metrica.es_acumulada IS 'Indica si normalmente la API reporta esta métrica como total acumulado.';
COMMENT ON COLUMN dw.dim_tipo_metrica.estatus IS 'Estado lógico del tipo de métrica.';
COMMENT ON COLUMN dw.dim_tipo_metrica.creado_el IS 'Fecha/hora de creación del registro.';
COMMENT ON COLUMN dw.dim_tipo_metrica.actualizado_el IS 'Fecha/hora de última actualización del registro.';

COMMENT ON COLUMN dw.fact_publicaciones.id_fact_publicacion IS 'Llave surrogate del hecho de publicación.';
COMMENT ON COLUMN dw.fact_publicaciones.id_publicacion IS 'Publicación registrada.';
COMMENT ON COLUMN dw.fact_publicaciones.id_fuente IS 'Fuente/cuenta/canal donde existe la publicación.';
COMMENT ON COLUMN dw.fact_publicaciones.id_tiempo IS 'Fecha calendario asociada a la publicación.';
COMMENT ON COLUMN dw.fact_publicaciones.id_ejecucion_n8n IS 'Ejecución ETL que cargó el hecho.';
COMMENT ON COLUMN dw.fact_publicaciones.creado_el IS 'Fecha/hora de inserción del hecho.';

COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.id_metrica_publicacion IS 'Llave surrogate del hecho diario de métricas.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.id_publicacion IS 'Publicación medida.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.id_fuente IS 'Fuente/cuenta/canal donde se midió la publicación.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.id_tiempo IS 'Día de observación de las métricas.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.likes_total IS 'Total acumulado de likes observado en el día.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.likes_variacion IS 'Diferencia de likes frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.comentarios_total IS 'Total acumulado de comentarios observado en el día.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.comentarios_variacion IS 'Diferencia de comentarios frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.compartidos_total IS 'Total acumulado de compartidos/reposts observado.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.compartidos_variacion IS 'Diferencia de compartidos/reposts frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.guardados_total IS 'Total acumulado de guardados/bookmarks observado.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.guardados_variacion IS 'Diferencia de guardados/bookmarks frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.vistas_total IS 'Total acumulado de vistas/reproducciones observado.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.vistas_variacion IS 'Diferencia de vistas/reproducciones frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.alcance_total IS 'Total acumulado/observado de alcance, cuando la plataforma lo permita.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.alcance_variacion IS 'Diferencia de alcance frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.impresiones_total IS 'Total acumulado/observado de impresiones, cuando exista.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.impresiones_variacion IS 'Diferencia de impresiones frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_positivas_total IS 'Total acumulado de reacciones clasificadas como positivas.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_positivas_variacion IS 'Diferencia de reacciones positivas frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_negativas_total IS 'Total acumulado de reacciones clasificadas como negativas.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_negativas_variacion IS 'Diferencia de reacciones negativas frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_neutrales_total IS 'Total acumulado de reacciones clasificadas como neutrales.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.reacciones_neutrales_variacion IS 'Diferencia de reacciones neutrales frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.total_interacciones_total IS 'Total acumulado calculado de interacciones principales.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.total_interacciones_variacion IS 'Diferencia de interacciones calculadas frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.indice_interaccion IS 'Indicador calculado de interacción según fórmula definida por el proyecto.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.id_ejecucion_n8n IS 'Ejecución ETL que cargó o actualizó la observación.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.creado_el IS 'Fecha/hora de creación del hecho.';
COMMENT ON COLUMN dw.fact_metricas_publicacion_diaria.actualizado_el IS 'Fecha/hora de última actualización del hecho.';

COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_metrica_detalle IS 'Llave surrogate del detalle de métrica.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_publicacion IS 'Publicación a la que pertenece la métrica.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_fuente IS 'Fuente/cuenta/canal donde se observó la métrica.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_tiempo IS 'Día de observación de la métrica.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_tipo_metrica IS 'Tipo de métrica observada.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.valor_total IS 'Valor acumulado/observado reportado por la fuente.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.valor_variacion IS 'Diferencia frente a la observación anterior para esa misma métrica.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.id_ejecucion_n8n IS 'Ejecución ETL que cargó el detalle.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.creado_el IS 'Fecha/hora de creación del detalle.';
COMMENT ON COLUMN dw.fact_metrica_publicacion_detalle.actualizado_el IS 'Fecha/hora de última actualización del detalle.';

COMMENT ON COLUMN dw.fact_comunidad_estado_diario.id_estado_diario IS 'Llave surrogate del snapshot diario de comunidad.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.id_fuente IS 'Fuente/cuenta/canal observado.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.id_tiempo IS 'Día de observación del snapshot.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.total_seguidores IS 'Total acumulado de seguidores/suscriptores observado.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.seguidores_variacion IS 'Diferencia de seguidores/suscriptores frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.total_publicaciones_perfil IS 'Total acumulado de publicaciones del perfil/canal.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.publicaciones_perfil_variacion IS 'Diferencia de publicaciones del perfil frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.vistas_totales_perfil IS 'Total acumulado de vistas del perfil/canal, si aplica.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.vistas_perfil_variacion IS 'Diferencia de vistas del perfil/canal frente a la observación anterior. Puede ser positiva, negativa o cero.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.id_ejecucion_n8n IS 'Ejecución ETL que cargó el snapshot.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.creado_el IS 'Fecha/hora de creación del snapshot.';
COMMENT ON COLUMN dw.fact_comunidad_estado_diario.actualizado_el IS 'Fecha/hora de última actualización del snapshot.';

COMMENT ON COLUMN audit.log_proceso_maestro.id_log_maestro IS 'Llave surrogate del log maestro.';
COMMENT ON COLUMN audit.log_proceso_maestro.id_ejecucion_n8n IS 'Identificador global de ejecución del workflow ETL.';
COMMENT ON COLUMN audit.log_proceso_maestro.nombre_flujo IS 'Nombre funcional del flujo, por ejemplo ETL_YOUTUBE_DIARIO.';
COMMENT ON COLUMN audit.log_proceso_maestro.plataforma IS 'Plataforma principal procesada por la ejecución, si aplica.';
COMMENT ON COLUMN audit.log_proceso_maestro.fecha_inicio IS 'Fecha/hora de inicio de la ejecución.';
COMMENT ON COLUMN audit.log_proceso_maestro.fecha_fin IS 'Fecha/hora de finalización de la ejecución.';
COMMENT ON COLUMN audit.log_proceso_maestro.estado_general IS 'Estado: INICIADO, FINALIZADO, FALLIDO, PARCIAL.';
COMMENT ON COLUMN audit.log_proceso_maestro.registros_extraidos IS 'Cantidad de registros extraídos desde la fuente.';
COMMENT ON COLUMN audit.log_proceso_maestro.registros_insertados IS 'Cantidad de registros insertados en staging/DW.';
COMMENT ON COLUMN audit.log_proceso_maestro.registros_actualizados IS 'Cantidad de registros actualizados.';
COMMENT ON COLUMN audit.log_proceso_maestro.registros_descartados IS 'Cantidad de registros descartados por reglas de negocio/calidad.';
COMMENT ON COLUMN audit.log_proceso_maestro.registros_error IS 'Cantidad de registros con error.';
COMMENT ON COLUMN audit.log_proceso_maestro.error_mensaje_global IS 'Mensaje global de error en caso de falla.';
COMMENT ON COLUMN audit.log_proceso_maestro.creado_el IS 'Fecha/hora de creación del log maestro.';
COMMENT ON COLUMN audit.log_proceso_maestro.actualizado_el IS 'Fecha/hora de última actualización del log maestro.';

COMMENT ON COLUMN audit.log_proceso_detalle.id_log_detalle IS 'Llave surrogate del log de detalle.';
COMMENT ON COLUMN audit.log_proceso_detalle.id_ejecucion_n8n IS 'Ejecución global asociada.';
COMMENT ON COLUMN audit.log_proceso_detalle.id_fuente IS 'Fuente procesada, si ya existe en el DW.';
COMMENT ON COLUMN audit.log_proceso_detalle.nombre_subproceso IS 'Nombre del subproceso: EXTRACCION, STAGING, TRANSFORMACION, CARGA_DW, DATAMART.';
COMMENT ON COLUMN audit.log_proceso_detalle.estado_subproceso IS 'Estado: INICIADO, FINALIZADO, FALLIDO, OMITIDO.';
COMMENT ON COLUMN audit.log_proceso_detalle.intentos IS 'Número de intentos realizados para el subproceso.';
COMMENT ON COLUMN audit.log_proceso_detalle.registros_procesados IS 'Cantidad de registros procesados por el subproceso.';
COMMENT ON COLUMN audit.log_proceso_detalle.registros_error IS 'Cantidad de registros con error en el subproceso.';
COMMENT ON COLUMN audit.log_proceso_detalle.error_codigo IS 'Código técnico o funcional del error, si aplica.';
COMMENT ON COLUMN audit.log_proceso_detalle.error_mensaje IS 'Descripción del error específico.';
COMMENT ON COLUMN audit.log_proceso_detalle.fecha_inicio IS 'Fecha/hora de inicio del subproceso.';
COMMENT ON COLUMN audit.log_proceso_detalle.fecha_fin IS 'Fecha/hora de fin del subproceso.';
COMMENT ON COLUMN audit.log_proceso_detalle.creado_el IS 'Fecha/hora de creación del registro de detalle.';



COMMENT ON INDEX staging.uq_stg_origen_hash_respuesta IS 'Índice único parcial que evita almacenar la misma respuesta exacta más de una vez para una misma fuente, tipo de registro e identificador de origen.';

COMMENT ON CONSTRAINT ck_publicacion_identificador_o_url ON dw.dim_publicacion IS 'Garantiza que toda publicación tenga trazabilidad mínima mediante identificador nativo o URL de origen.';

-- =============================================================================
-- FIN DEL SCRIPT DEFINITIVO ESCALABLE
-- =============================================================================
