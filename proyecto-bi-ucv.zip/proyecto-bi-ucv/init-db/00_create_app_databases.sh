#!/bin/bash
set -e

# =============================================================================
# ARCHIVO: 00_create_app_databases.sh
# PROYECTO BI UCV
# =============================================================================
# OBJETIVO:
# Crear las bases de datos y usuarios técnicos auxiliares usados por herramientas
# externas al Data Warehouse, leyendo los valores desde variables de entorno.
#
# BASE PRINCIPAL:
#   - bi_ucv
#     Se crea automáticamente por PostgreSQL mediante:
#       POSTGRES_DB=${DB_NAME}
#
# BASES AUXILIARES:
#   - n8n_app
#     Metadata interna de n8n: workflows, credenciales cifradas,
#     ejecuciones y configuración.
#
#   - metabase_app
#     Metadata interna de Metabase: usuarios, dashboards, preguntas,
#     permisos y configuración.
#
# IMPORTANTE:
# Este archivo debe ejecutarse antes del script principal del Data Warehouse:
#   01_init_bi_ucv.sql
#
# ESTRUCTURA RECOMENDADA:
#   init-db/
#   ├── 00_create_app_databases.sh
#   └── 01_init_bi_ucv.sql
# =============================================================================


echo "============================================================"
echo "INICIO: Creación de bases auxiliares para n8n y Metabase"
echo "============================================================"


# =============================================================================
# 1. VALIDACIÓN DE VARIABLES DE ENTORNO REQUERIDAS
# =============================================================================
# Si alguna variable no existe, el script se detiene inmediatamente.
# =============================================================================

: "${POSTGRES_USER:?ERROR: POSTGRES_USER no definido}"
: "${POSTGRES_DB:?ERROR: POSTGRES_DB no definido}"

: "${N8N_DB_NAME:?ERROR: N8N_DB_NAME no definido}"
: "${N8N_DB_USER:?ERROR: N8N_DB_USER no definido}"
: "${N8N_DB_PASS:?ERROR: N8N_DB_PASS no definido}"

: "${MB_DB_NAME:?ERROR: MB_DB_NAME no definido}"
: "${MB_DB_USER:?ERROR: MB_DB_USER no definido}"
: "${MB_DB_PASS:?ERROR: MB_DB_PASS no definido}"


# =============================================================================
# 2. CREACIÓN DE USUARIOS Y BASES AUXILIARES
# =============================================================================
# Nota:
# Se utiliza el usuario administrador principal de PostgreSQL definido en:
#   POSTGRES_USER
# =============================================================================

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL

    -- -------------------------------------------------------------------------
    -- BASE INTERNA DE N8N
    -- -------------------------------------------------------------------------
    -- Usuario técnico exclusivo para n8n.
    -- -------------------------------------------------------------------------
    CREATE USER ${N8N_DB_USER} WITH PASSWORD '${N8N_DB_PASS}';

    -- -------------------------------------------------------------------------
    -- Base de datos interna para n8n.
    -- -------------------------------------------------------------------------
    CREATE DATABASE ${N8N_DB_NAME} OWNER ${N8N_DB_USER};

    -- -------------------------------------------------------------------------
    -- Permisos completos del usuario n8n sobre su base.
    -- -------------------------------------------------------------------------
    GRANT ALL PRIVILEGES ON DATABASE ${N8N_DB_NAME} TO ${N8N_DB_USER};


    -- -------------------------------------------------------------------------
    -- BASE INTERNA DE METABASE
    -- -------------------------------------------------------------------------
    -- Usuario técnico exclusivo para Metabase.
    -- -------------------------------------------------------------------------
    CREATE USER ${MB_DB_USER} WITH PASSWORD '${MB_DB_PASS}';

    -- -------------------------------------------------------------------------
    -- Base de datos interna para Metabase.
    -- -------------------------------------------------------------------------
    CREATE DATABASE ${MB_DB_NAME} OWNER ${MB_DB_USER};

    -- -------------------------------------------------------------------------
    -- Permisos completos del usuario Metabase sobre su base.
    -- -------------------------------------------------------------------------
    GRANT ALL PRIVILEGES ON DATABASE ${MB_DB_NAME} TO ${MB_DB_USER};

EOSQL


# =============================================================================
# 3. PERMISOS SOBRE SCHEMA PUBLIC DE N8N
# =============================================================================
# n8n necesita crear y administrar sus propias tablas internas.
# Por eso se otorga control sobre el schema public dentro de n8n_app.
# =============================================================================

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$N8N_DB_NAME" <<-EOSQL

    -- Otorga permisos completos sobre el schema public al usuario técnico n8n.
    GRANT ALL ON SCHEMA public TO ${N8N_DB_USER};

    -- Transfiere propiedad del schema public al usuario técnico n8n.
    ALTER SCHEMA public OWNER TO ${N8N_DB_USER};

EOSQL


# =============================================================================
# 4. PERMISOS SOBRE SCHEMA PUBLIC DE METABASE
# =============================================================================
# Metabase necesita crear sus tablas internas en su propia base.
# Por eso se otorga control sobre el schema public dentro de metabase_app.
# =============================================================================

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$MB_DB_NAME" <<-EOSQL

    -- Otorga permisos completos sobre el schema public al usuario técnico Metabase.
    GRANT ALL ON SCHEMA public TO ${MB_DB_USER};

    -- Transfiere propiedad del schema public al usuario técnico Metabase.
    ALTER SCHEMA public OWNER TO ${MB_DB_USER};

EOSQL


echo "============================================================"
echo "FIN: Bases auxiliares creadas correctamente"
echo "============================================================"