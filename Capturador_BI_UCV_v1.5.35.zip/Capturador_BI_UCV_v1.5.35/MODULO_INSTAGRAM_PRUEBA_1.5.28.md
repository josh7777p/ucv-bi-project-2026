# Módulo de Instagram — prueba 1.5.28

## Objetivo

Validar la captura asistida de las diez primeras publicaciones de un perfil público de Instagram antes de habilitar capturas extensas.

## Estrategia

- Inicio desde la cuadrícula del perfil.
- Apertura automática de la primera publicación.
- Lectura del detalle visible dentro del modal.
- Navegación mediante el botón exterior `Next`, sin confundirlo con el control interno de un carrusel.
- Persistencia inmediata en IndexedDB por `shortcode`.
- Observación pasiva de las respuestas estructuradas solicitadas por la propia página.
- Fusión de observaciones mediante el valor máximo, nunca mediante suma.

## Datos previstos

- Shortcode e ID multimedia cuando esté disponible.
- Permalink directo.
- Autor, fecha y hora exactas.
- Descripción, hashtags, menciones y ubicación cuando aparezca.
- Tipo de contenido y referencias multimedia.
- Me gusta, comentarios, visualizaciones, reproducciones, compartidos y guardados únicamente cuando exista un valor explícito.
- Alcance e impresiones permanecen en `null` en la interfaz pública.

## Períodos disponibles

- Primeras 10 publicaciones.
- Último mes.
- Últimos 3 meses.
- Último año.
- Completo.

Los períodos se calculan desde la publicación cronológicamente más reciente recuperada e incluyen completo el día límite. Las publicaciones anteriores usadas para confirmar la detención se excluyen del archivo final.

## Alcance de la validación interna

Los dos HTML suministrados permitieron confirmar la extracción de shortcode, permalink, fecha ISO, descripción y Me gusta, además de la detección separada del botón exterior `Next`. La navegación real entre diez publicaciones debe confirmarse en Instagram mediante una ejecución del usuario.
