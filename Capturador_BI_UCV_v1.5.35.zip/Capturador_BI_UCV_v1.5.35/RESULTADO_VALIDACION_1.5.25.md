# Resultado de validación — v1.5.25

## Alcance

La validación se realizó con pruebas internas, datos sintéticos y el HTML guardado de Facebook. No sustituye una ejecución nueva en la página dinámica.

## Resultados

- Todos los archivos JavaScript superaron `node --check`.
- Todos los archivos JSON internos se interpretaron correctamente.
- Prueba secuencial controlada: 5 tarjetas, 5 fechas, 5 zonas de métricas y 5 identificadores únicos.
- Diagnóstico de fecha: 5 enlaces por icono de privacidad, 5 intentos de tooltip y 5 fechas exactas resueltas.
- Fusión métrica: el máximo numérico permanece sin cambios y su raw corresponde a la misma observación.
- Una lectura posterior inferior se conserva por separado como última observación sin reemplazar el máximo.
- Cuando la observación máxima no tiene desglose, no se toma el desglose de una lectura distinta.
- Exportación sintética: la métrica operativa, el raw del máximo y el raw de la última lectura se mantuvieron separados.
- Las fuentes principales del módulo X conservaron exactamente sus hashes de la v1.5.24.

## Regla para el DW

Solo los valores numéricos de `metricas` se destinan a cálculos. Los objetos `metricas_raw`, `metricas_raw_primera_observacion`, `metricas_raw_ultima_observacion` y los campos raw de `metricas_observacion` son evidencia de auditoría.
