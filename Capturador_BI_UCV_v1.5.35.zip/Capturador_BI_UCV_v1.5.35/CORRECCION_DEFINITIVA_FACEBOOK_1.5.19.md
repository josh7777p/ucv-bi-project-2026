# Capturador BI UCV v1.5.19 — Facebook

## Propósito

Combinar la cobertura de fechas alcanzada por la v1.5.17 con la reducción de observaciones repetidas de la v1.5.18.

## Estrategia de fecha

1. Localiza el botón `Acciones en esta publicación`.
2. Asciende hasta el contenedor mínimo que conserva un único menú de publicación.
3. Resuelve el control `aria-labelledby` mediante `document.getElementById()`.
4. Conserva la fecha únicamente cuando existe una evidencia semántica única.
5. No usa fechas del cuerpo, comentarios, posición del feed ni publicaciones vecinas.

## Recuperación adaptativa

- Se realizan varios intentos breves mientras la tarjeta sigue en el DOM.
- Si el encabezado continúa pendiente, el menú se centra temporalmente y se reintenta solo esa tarjeta.
- Cuando `MutationObserver` detecta la aparición del nodo accesible, la fecha se persiste de inmediato.
- Las tarjetas sin cambios no vuelven a guardarse.
- Para períodos finitos existe un barrido final rápido de respaldo; `Ejecutar todo` no recorre nuevamente todo el perfil.

## Datos conservados

- Fecha normalizada `YYYY-MM-DD` y `DD/MM/YYYY`.
- Texto original de fecha en `fecha_raw`.
- Identificador nativo, multimedia o firma derivada.
- Reacciones, comentarios, compartidos y demás métricas visibles.
- Descripción sin `Ver más` ni `Ver menos` al final.

## Alcance modular

Los archivos principales de X/Twitter no fueron modificados. Los cambios corresponden al flujo de Facebook y a sus parámetros de ejecución.
