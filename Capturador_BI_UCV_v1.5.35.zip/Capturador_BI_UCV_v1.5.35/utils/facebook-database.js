// Capturador BI UCV — almacenamiento local independiente para Facebook.
// v1.5.25: consolida observaciones repetidas por ID nativo o firma derivada,
// promueve registros DERIVADOS a NATIVOS y conserva la evidencia raw asociada
// al valor máximo, además de la primera y última observación.
(function () {
    'use strict';

    const DB_NAME = 'biucv_facebook_stats';
    const DB_VERSION = 4;
    const STORE_POSTS = 'posts';
    const MAX_POSTS = 30000;
    const QUALITY_RANK = Object.freeze({ PROVISIONAL: 1, DERIVADO: 2, NATIVO: 3 });
    const SCOPE_RANK = Object.freeze({ PROVISIONAL: 0, CONTENIDO_DERIVADO: 1, MULTIMEDIA: 2, PUBLICACION: 3 });
    const TRUSTED_DATE_PRECISIONS = new Set(['EXACTA', 'APROXIMADA_CALENDARIO']);
    const TRUSTED_DATE_SOURCES = new Set(['DATA_UTIME', 'TIME_DATETIME', 'ABBR_TITLE', 'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT', 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT', 'AUTHOR_DATE_HOVER_TOOLTIP', 'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY', 'AUTHOR_DATE_ARIA_LABEL', 'AUTHOR_DATE_TITLE', 'AUTHOR_DATE_DIRECT_TEXT', 'PERMALINK_ARIA_LABEL', 'PERMALINK_TITLE', 'PERMALINK_LABEL']);
    const DIRECT_DATE_SOURCES = new Set(['DATA_UTIME', 'TIME_DATETIME', 'ABBR_TITLE', 'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT', 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT', 'AUTHOR_DATE_HOVER_TOOLTIP', 'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY', 'AUTHOR_DATE_ARIA_LABEL', 'AUTHOR_DATE_TITLE', 'AUTHOR_DATE_DIRECT_TEXT', 'PERMALINK_ARIA_LABEL', 'PERMALINK_TITLE', 'PERMALINK_LABEL']);

    function cleanText(value, maxLength = 25000) {
        return typeof value === 'string' ? value.slice(0, maxLength) : '';
    }

    function finiteCount(value) {
        if (value === null || value === undefined || value === '') return null;
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
    }

    function cleanRaw(value, maxLength = 160) {
        if (value === null || value === undefined || value === '') return null;
        return cleanText(String(value), maxLength) || null;
    }

    function requestResult(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function transactionDone(transaction) {
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            transaction.onabort = () => reject(transaction.error || new Error('IndexedDB transaction aborted'));
        });
    }

    function ensureIndex(store, name, keyPath, options = {}) {
        if (!store.indexNames.contains(name)) store.createIndex(name, keyPath, options);
    }

    function openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = () => {
                const database = request.result;
                let store;
                if (!database.objectStoreNames.contains(STORE_POSTS)) {
                    store = database.createObjectStore(STORE_POSTS, { keyPath: 'id' });
                } else {
                    store = request.transaction.objectStore(STORE_POSTS);
                }
                ensureIndex(store, 'last_seen_at', 'last_seen_at');
                ensureIndex(store, 'created_at_ms', 'created_at_ms');
                ensureIndex(store, 'author_slug', 'author_slug');
                ensureIndex(store, 'native_id', 'native_id');
                ensureIndex(store, 'content_signature', 'content_signature');
                ensureIndex(store, 'identifier_quality', 'identifier_quality');
                ensureIndex(store, 'feed_order', 'feed_order');
                ensureIndex(store, 'media_asset_ids', 'media_asset_ids', { multiEntry: true });
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function normalizeQuality(value, nativeId, contentSignature) {
        const quality = cleanText(String(value || ''), 20).toUpperCase();
        if (quality === 'NATIVO' || quality === 'DERIVADO' || quality === 'PROVISIONAL') return quality;
        if (nativeId) return 'NATIVO';
        return contentSignature ? 'DERIVADO' : 'PROVISIONAL';
    }

    function evaluateRecordQuality(record) {
        const issues = [];
        const scope = String(record?.identifier_scope || '').toUpperCase();
        const precision = String(record?.date_precision || '').toUpperCase();
        const source = String(record?.date_source || '').toUpperCase();
        const ms = Number(record?.created_at_ms || 0);
        const postUrl = scope === 'PUBLICACION' ? (record?.permalink || '') : '';
        const nativeMediaUrl = scope === 'MULTIMEDIA' ? (record?.permalink || '') : '';
        const contentUrl = nativeMediaUrl || record?.media_urls?.[0] || '';
        const stableId = record?.native_id || record?.content_signature || record?.id || '';
        const hasStableLocator = Boolean(stableId);
        const hasDate = TRUSTED_DATE_PRECISIONS.has(precision) && TRUSTED_DATE_SOURCES.has(source) && ms > 0 && ms <= Date.now() + 10 * 60e3;
        const hasAuthor = Boolean(cleanText(record?.author_name || '', 300)) && Boolean(cleanText(record?.author_slug || '', 220));
        const hasContent = Boolean(cleanText(record?.text || '', 50000)) || Number(record?.media_count || 0) > 0;
        if (!hasStableLocator) issues.push('SIN_IDENTIFICADOR_ESTABLE');
        if (!hasDate) issues.push('SIN_FECHA_CONFIABLE');
        if (!hasAuthor) issues.push('SIN_AUTOR_CONFIABLE');
        if (!hasContent) issues.push('SIN_CONTENIDO');
        record.dw_eligible = issues.length === 0;
        record.dw_ineligible_reason = issues.join('|');
        record.record_quality_status = record.dw_eligible
            ? 'LISTO_DW'
            : (hasContent ? 'PENDIENTE_FECHA_O_IDENTIFICADOR' : 'SOLO_STAGING');
        record.quality_issues = issues;
        record.post_url = postUrl;
        record.content_url = contentUrl;
        record.reference_url = postUrl || contentUrl;
        record.reference_type = postUrl ? 'URL_PUBLICACION' : (contentUrl ? (/\/(?:reel|videos|watch)\b/i.test(contentUrl) || String(record?.media_type || '').toUpperCase() === 'VIDEO' ? 'URL_VIDEO' : 'URL_IMAGEN') : 'IDENTIFICADOR_DERIVADO');
        record.reference_quality = postUrl ? 'NATIVA_PUBLICACION' : (contentUrl ? (nativeMediaUrl ? 'NATIVA_MULTIMEDIA' : 'TEMPORAL_MULTIMEDIA') : 'DERIVADA_ESTABLE');
        record.source_locator_id = stableId;
        return record;
    }

    function normalizePost(post, context, seenAt) {
        const nativeId = cleanText(post?.native_id || '', 220);
        const contentSignature = cleanText(post?.content_signature || '', 220);
        const identifierQuality = normalizeQuality(post?.identifier_quality, nativeId, contentSignature);
        const id = cleanText(String(post?.id || post?.identificador_publicacion_origen || ''), 260);
        if (!id) return null;

        const parsedDate = Date.parse(post?.created_at || post?.fecha_publicacion || '');
        const explicitDateMs = Number(post?.created_at_ms || 0);
        const createdAtMs = Number.isFinite(explicitDateMs) && explicitDateMs > 0
            ? explicitDateMs
            : (Number.isFinite(parsedDate) ? parsedDate : 0);

        const normalized = {
            id,
            native_id: nativeId,
            content_signature: contentSignature,
            identifier_quality: identifierQuality,
            identifier_source: cleanText(post?.identifier_source || '', 80),
            identifier_scope: cleanText(post?.identifier_scope || (identifierQuality === 'NATIVO' ? 'PUBLICACION' : (identifierQuality === 'DERIVADO' ? 'CONTENIDO_DERIVADO' : 'PROVISIONAL')), 60).toUpperCase(),
            provisional_id: identifierQuality === 'PROVISIONAL',
            dw_eligible: false,
            dw_ineligible_reason: '',
            record_quality_status: cleanText(post?.record_quality_status || '', 60),
            quality_issues: Array.isArray(post?.quality_issues) ? post.quality_issues.map(item => cleanText(String(item), 100)).filter(Boolean) : [],
            permalink: cleanText(post?.permalink || post?.url_origen || '', 1200),
            permalink_source: cleanText(post?.permalink_source || '', 1800),
            permalink_quality: cleanText(post?.permalink_quality || (nativeId ? 'NATIVA' : 'NO_DISPONIBLE'), 40).toUpperCase(),
            post_type: cleanText(post?.post_type || post?.tipo_contenido || 'PUBLICACION', 80).toUpperCase(),
            text: cleanText(post?.text || post?.cuerpo || '', 50000),
            author_name: cleanText(post?.author_name || post?.autor_nombre || '', 300),
            author_slug: cleanText(post?.author_slug || post?.autor_usuario || '', 220),
            author_url: cleanText(post?.author_url || post?.autor_url || '', 1200),
            target_profile_slug: cleanText(post?.target_profile_slug || '', 220),
            target_profile_name: cleanText(post?.target_profile_name || '', 300),
            created_at: createdAtMs > 0 ? new Date(createdAtMs).toISOString() : '',
            created_at_ms: createdAtMs > 0 ? createdAtMs : 0,
            date_raw: cleanRaw(post?.date_raw || post?.fecha_raw, 400),
            date_visible_raw: cleanRaw(post?.date_visible_raw || post?.fecha_visible_raw, 200),
            date_tooltip_raw: cleanRaw(post?.date_tooltip_raw || post?.fecha_tooltip_raw, 400),
            date_privacy_title: cleanRaw(post?.date_privacy_title || post?.fecha_icono_privacidad, 200),
            date_precision: cleanText(post?.date_precision || post?.fecha_precision || 'NO_DETECTADA', 50).toUpperCase(),
            date_reference_at: cleanText(post?.date_reference_at || '', 100),
            date_source: cleanText(post?.date_source || '', 100),
            date_aria_labelledby_id: cleanText(post?.date_aria_labelledby_id || '', 180),
            date_action_scope_level: Math.max(0, Number(post?.date_action_scope_level || 0)),
            date_action_menu_label: cleanText(post?.date_action_menu_label || '', 400),
            date_has_explicit_time: post?.date_has_explicit_time === true,
            date_timezone: cleanText(post?.date_timezone || '', 100),
            date_is_estimated: post?.date_is_estimated === true,
            date_locked: post?.date_locked === true || (createdAtMs > 0 && DIRECT_DATE_SOURCES.has(String(post?.date_source || '').toUpperCase())),
            metrics_review_only: post?.metrics_review_only === true,
            date_confidence: cleanText(post?.date_confidence || (createdAtMs > 0 ? 'ALTA' : 'NO_DISPONIBLE'), 40).toUpperCase(),
            date_interval_from: cleanText(post?.date_interval_from || '', 100),
            date_interval_to: cleanText(post?.date_interval_to || '', 100),
            feed_order: Math.max(0, Number(post?.feed_order || 0)),
            first_seen_scroll_y: Math.max(0, Number(post?.first_seen_scroll_y || 0)),
            first_seen_cycle: Math.max(0, Number(post?.first_seen_cycle || 0)),
            is_pinned: post?.is_pinned === true,
            is_own_publication: post?.is_own_publication !== false,
            is_shared_content: post?.is_shared_content === true,
            metrics_attributable_to_account: post?.metrics_attributable_to_account !== false,
            reactions_count: finiteCount(post?.reactions_count ?? post?.reacciones_total),
            comments_count: finiteCount(post?.comments_count ?? post?.comentarios_total),
            shares_count: finiteCount(post?.shares_count ?? post?.compartidos_total),
            views_count: finiteCount(post?.views_count ?? post?.vistas_total),
            // Los campos *_raw representan la evidencia de la observación que
            // aporta el valor máximo operativo. Los campos first/last raw se
            // conservan aparte para no mezclar instantes distintos.
            reactions_raw: cleanRaw(post?.reactions_raw, 220),
            comments_raw: cleanRaw(post?.comments_raw, 220),
            shares_raw: cleanRaw(post?.shares_raw, 220),
            views_raw: cleanRaw(post?.views_raw, 220),
            reaction_breakdown_raw: cleanRaw(post?.reaction_breakdown_raw, 1400),
            reactions_first_raw: cleanRaw(post?.reactions_first_raw ?? post?.reactions_raw, 220),
            comments_first_raw: cleanRaw(post?.comments_first_raw ?? post?.comments_raw, 220),
            shares_first_raw: cleanRaw(post?.shares_first_raw ?? post?.shares_raw, 220),
            views_first_raw: cleanRaw(post?.views_first_raw ?? post?.views_raw, 220),
            reactions_last_raw: cleanRaw(post?.reactions_last_raw ?? post?.reactions_raw, 220),
            comments_last_raw: cleanRaw(post?.comments_last_raw ?? post?.comments_raw, 220),
            shares_last_raw: cleanRaw(post?.shares_last_raw ?? post?.shares_raw, 220),
            views_last_raw: cleanRaw(post?.views_last_raw ?? post?.views_raw, 220),
            reaction_breakdown_first_raw: cleanRaw(post?.reaction_breakdown_first_raw ?? post?.reaction_breakdown_raw, 1400),
            reaction_breakdown_last_raw: cleanRaw(post?.reaction_breakdown_last_raw ?? post?.reaction_breakdown_raw, 1400),
            audience: cleanText(post?.audience || '', 80),
            media_type: cleanText(post?.media_type || '', 80).toUpperCase(),
            media_count: finiteCount(post?.media_count) || 0,
            media_urls: Array.isArray(post?.media_urls)
                ? post.media_urls.map(item => cleanText(String(item), 1500)).filter(Boolean).slice(0, 30)
                : [],
            media_asset_ids: Array.isArray(post?.media_asset_ids)
                ? post.media_asset_ids.map(item => cleanText(String(item), 400)).filter(Boolean).slice(0, 30)
                : [],
            external_links: Array.isArray(post?.external_links)
                ? post.external_links.map(item => cleanText(String(item), 1200)).filter(Boolean).slice(0, 30)
                : [],
            source_method: cleanText(post?.source_method || context?.operationName || 'FACEBOOK_DOM_VISIBLE_V9', 120),
            author_source: cleanText(post?.author_source || '', 80),
            reactions_source: cleanText(post?.reactions_source || '', 100),
            comments_source: cleanText(post?.comments_source || '', 100),
            shares_source: cleanText(post?.shares_source || '', 100),
            views_source: cleanText(post?.views_source || '', 100),
            reactions_confidence: cleanText(post?.reactions_confidence || '', 40),
            comments_confidence: cleanText(post?.comments_confidence || '', 40),
            shares_confidence: cleanText(post?.shares_confidence || '', 40),
            views_confidence: cleanText(post?.views_confidence || '', 40),
            permalink_enrichment_source: cleanText(post?.permalink_enrichment_source || '', 100),
            permalink_enrichment_success: post?.permalink_enrichment_success === true,
            permalink_enrichment_attempted: post?.permalink_enrichment_attempted === true,
            permalink_enrichment_attempt_count: Math.max(0, Number(post?.permalink_enrichment_attempt_count || 0)),
            permalink_enrichment_error: cleanText(post?.permalink_enrichment_error || '', 180),
            metrics_zone_observed: post?.metrics_zone_observed === true,
            metrics_zone_visible: post?.metrics_zone_visible === true,
            engagement_controls_present: post?.engagement_controls_present === true,
            card_lower_edge_observed: post?.card_lower_edge_observed === true,
            reactions_observed_count: Math.max(0, Number(post?.reactions_observed_count || (finiteCount(post?.reactions_count) !== null ? 1 : 0))),
            comments_observed_count: Math.max(0, Number(post?.comments_observed_count || (finiteCount(post?.comments_count) !== null ? 1 : 0))),
            shares_observed_count: Math.max(0, Number(post?.shares_observed_count || (finiteCount(post?.shares_count) !== null ? 1 : 0))),
            views_observed_count: Math.max(0, Number(post?.views_observed_count || (finiteCount(post?.views_count) !== null ? 1 : 0))),
            reactions_first_value: finiteCount(post?.reactions_first_value ?? post?.reactions_count),
            comments_first_value: finiteCount(post?.comments_first_value ?? post?.comments_count),
            shares_first_value: finiteCount(post?.shares_first_value ?? post?.shares_count),
            views_first_value: finiteCount(post?.views_first_value ?? post?.views_count),
            reactions_last_value: finiteCount(post?.reactions_last_value ?? post?.reactions_count),
            comments_last_value: finiteCount(post?.comments_last_value ?? post?.comments_count),
            shares_last_value: finiteCount(post?.shares_last_value ?? post?.shares_count),
            views_last_value: finiteCount(post?.views_last_value ?? post?.views_count),
            first_seen_at: seenAt,
            last_seen_at: seenAt,
            seen_count: 1
        };
        return evaluateRecordQuality(normalized);
    }

    function qualityRank(value) {
        return QUALITY_RANK[String(value || '').toUpperCase()] || 0;
    }

    function identityRank(post) {
        const quality = String(post?.identifier_quality || '').toUpperCase();
        const scope = String(post?.identifier_scope || '').toUpperCase();
        return qualityRank(quality) * 10 + (SCOPE_RANK[scope] || 0);
    }

    function preferText(existing, incoming) {
        if (!incoming) return existing || '';
        if (!existing) return incoming;
        return incoming.length >= existing.length ? incoming : existing;
    }

    function preferMetric(existing, incoming) {
        if (incoming === null || incoming === undefined) return existing ?? null;
        if (existing === null || existing === undefined) return incoming;
        return Math.max(existing, incoming);
    }

    function preferRaw(existing, incoming) {
        if (!incoming) return existing ?? null;
        if (!existing) return incoming;
        const incomingHasLabel = /[^0-9.,+\-\s]/u.test(incoming);
        const existingHasLabel = /[^0-9.,+\-\s]/u.test(existing);
        if (incomingHasLabel && !existingHasLabel) return incoming;
        return incoming.length >= existing.length ? incoming : existing;
    }

    function metricEvidence(existing, incoming, metric) {
        const valueField = `${metric}_count`;
        const rawField = `${metric}_raw`;
        const existingValue = finiteCount(existing?.[valueField]);
        const incomingValue = finiteCount(incoming?.[valueField]);
        const existingRaw = cleanRaw(existing?.[rawField], 220);
        const incomingRaw = cleanRaw(incoming?.[rawField], 220);

        if (existingValue === null && incomingValue === null) {
            return { value: null, raw: preferRaw(existingRaw, incomingRaw), winner: null };
        }
        if (existingValue === null) return { value: incomingValue, raw: incomingRaw, winner: 'incoming' };
        if (incomingValue === null) return { value: existingValue, raw: existingRaw, winner: 'existing' };
        if (incomingValue > existingValue) return { value: incomingValue, raw: incomingRaw, winner: 'incoming' };
        if (existingValue > incomingValue) return { value: existingValue, raw: existingRaw, winner: 'existing' };

        // En empate no cambia el valor máximo; se conserva la evidencia raw
        // más informativa sin alterar la métrica operativa.
        const preferred = preferRaw(existingRaw, incomingRaw);
        return {
            value: existingValue,
            raw: preferred,
            winner: preferred === incomingRaw && incomingRaw !== existingRaw ? 'incoming' : 'existing'
        };
    }

    function breakdownForMetricWinner(existing, incoming, selection) {
        const existingRaw = cleanRaw(existing?.reaction_breakdown_raw, 1400);
        const incomingRaw = cleanRaw(incoming?.reaction_breakdown_raw, 1400);
        if (selection?.winner === 'incoming') return incomingRaw;
        if (selection?.winner === 'existing') return existingRaw;
        return preferRaw(existingRaw, incomingRaw);
    }

    function preferDate(existing, incoming) {
        const precisionRank = {
            EXACTA: 60,
            APROXIMADA_CALENDARIO: 50,
            RELATIVA_CONFIABLE: 40,
            NO_DETECTADA: 0,
            NO_DISPONIBLE: 0,
            NO_INTERPRETADA: 0
        };
        const sourceRank = {
            DATA_UTIME: 900,
            TIME_DATETIME: 900,
            ABBR_TITLE: 850,
            AUTHOR_DATE_HOVER_TOOLTIP: 895,
            AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT: 880,
            AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT: 840,
            AUTHOR_DATE_ARIA_LABELLEDBY: 820,
            AUTHOR_DATE_ARIA_LABEL: 780,
            AUTHOR_DATE_TITLE: 760,
            AUTHOR_DATE_DIRECT_TEXT: 740,
            PERMALINK_ARIA_LABEL: 740,
            PERMALINK_TITLE: 730,
            PERMALINK_LABEL: 720
        };
        const valid = value => Number(value?.created_at_ms || 0) > 0
            && TRUSTED_DATE_PRECISIONS.has(String(value?.date_precision || '').toUpperCase())
            && TRUSTED_DATE_SOURCES.has(String(value?.date_source || '').toUpperCase());
        const score = value => {
            if (!valid(value)) return 0;
            return (sourceRank[String(value?.date_source || '').toUpperCase()] || 0)
                + (precisionRank[String(value?.date_precision || '').toUpperCase()] || 0);
        };
        const existingValid = valid(existing);
        const incomingValid = valid(incoming);
        if (incoming?.metrics_review_only === true) return existingValid ? existing : incoming;
        if (!existingValid && incomingValid) return incoming;
        if (existingValid && !incomingValid) return existing;
        if (!existingValid && !incomingValid) return existing || incoming;
        const existingScore = score(existing);
        const incomingScore = score(incoming);
        if (incomingScore > existingScore) return incoming;
        if (incomingScore < existingScore) return existing;
        // Con igual calidad se conserva la primera fecha para evitar que una
        // observación posterior de otra zona de la tarjeta la sustituya.
        return existing;
    }

    function comparableText(value) {
        return String(value || '')
            .normalize('NFKC')
            .toLowerCase()
            .replace(/\b(?:ver más|ver menos|see more|see less)\b/gi, ' ')
            .replace(/https?:\/\/\S+/gi, ' ')
            .replace(/[^\p{L}\p{N}\s]+/gu, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function textsLikelySame(a, b) {
        const x = comparableText(a);
        const y = comparableText(b);
        if (!x || !y) return true;
        const shorter = x.length <= y.length ? x : y;
        const longer = x.length > y.length ? x : y;
        if (shorter.length >= 40 && longer.startsWith(shorter.slice(0, Math.min(shorter.length, 220)))) return true;
        const words = new Set(shorter.split(' ').filter(word => word.length > 3));
        if (!words.size) return shorter === longer;
        const common = longer.split(' ').filter(word => words.has(word)).length;
        return common / words.size >= 0.72;
    }

    function mergePost(existing, incoming, context, seenAt) {
        const preferredIdentity = identityRank(incoming) > identityRank(existing) ? incoming : existing;
        const preferredDate = preferDate(existing, incoming);
        const next = { ...existing, ...incoming };

        next.id = preferredIdentity.id;
        next.native_id = preferredIdentity.native_id || existing?.native_id || incoming?.native_id || '';
        next.identifier_quality = preferredIdentity.identifier_quality;
        next.identifier_source = preferredIdentity.identifier_source || existing?.identifier_source || incoming?.identifier_source || '';
        next.identifier_scope = preferredIdentity.identifier_scope || existing?.identifier_scope || incoming?.identifier_scope || (next.identifier_quality === 'NATIVO' ? 'PUBLICACION' : (next.identifier_quality === 'DERIVADO' ? 'CONTENIDO_DERIVADO' : 'PROVISIONAL'));
        next.provisional_id = next.identifier_quality === 'PROVISIONAL';
        next.dw_eligible = false;
        next.dw_ineligible_reason = '';
        next.permalink_quality = preferredIdentity.permalink_quality || existing?.permalink_quality || incoming?.permalink_quality || 'NO_DISPONIBLE';
        next.permalink = preferredIdentity.permalink || existing?.permalink || incoming?.permalink || '';
        next.permalink_source = preferredIdentity.permalink_source || existing?.permalink_source || incoming?.permalink_source || '';

        for (const field of ['text', 'target_profile_name', 'audience']) {
            next[field] = preferText(existing?.[field], incoming?.[field]);
        }
        const incomingIsTarget = incoming?.author_slug && incoming.author_slug === incoming?.target_profile_slug;
        const existingIsTarget = existing?.author_slug && existing.author_slug === existing?.target_profile_slug;
        const preferredAuthor = incomingIsTarget && !existingIsTarget ? incoming : (existingIsTarget && !incomingIsTarget ? existing : incoming);
        next.author_name = preferredAuthor?.author_name || existing?.author_name || incoming?.author_name || '';
        next.author_slug = preferredAuthor?.author_slug || existing?.author_slug || incoming?.author_slug || '';
        next.author_url = preferredAuthor?.author_url || existing?.author_url || incoming?.author_url || '';
        const metricSelections = {};
        for (const metric of ['reactions', 'comments', 'shares', 'views']) {
            const selection = metricEvidence(existing, incoming, metric);
            metricSelections[metric] = selection;
            next[`${metric}_count`] = selection.value;
            next[`${metric}_raw`] = selection.raw;
        }
        // El desglose de reacciones debe pertenecer a la misma observación que
        // suministró el máximo. Si esa observación no expuso desglose, se deja
        // nulo en vez de asociar evidencia de otro instante.
        next.reaction_breakdown_raw = breakdownForMetricWinner(
            existing,
            incoming,
            metricSelections.reactions
        );

        next.created_at = preferredDate?.created_at || '';
        next.created_at_ms = Number(preferredDate?.created_at_ms || 0);
        next.date_raw = preferredDate?.date_raw || null;
        next.date_visible_raw = preferredDate?.date_visible_raw || null;
        next.date_tooltip_raw = preferredDate?.date_tooltip_raw || null;
        next.date_privacy_title = preferredDate?.date_privacy_title || null;
        next.date_precision = preferredDate?.date_precision || 'NO_DETECTADA';
        next.date_reference_at = preferredDate?.date_reference_at || '';
        next.date_source = preferredDate?.date_source || existing?.date_source || incoming?.date_source || '';
        next.date_aria_labelledby_id = preferredDate?.date_aria_labelledby_id || '';
        next.date_action_scope_level = Math.max(0, Number(preferredDate?.date_action_scope_level || 0));
        next.date_action_menu_label = preferredDate?.date_action_menu_label || '';
        next.date_has_explicit_time = preferredDate?.date_has_explicit_time === true;
        next.date_timezone = preferredDate?.date_timezone || existing?.date_timezone || incoming?.date_timezone || '';
        next.date_is_estimated = preferredDate?.date_is_estimated === true;
        next.date_locked = preferredDate?.date_locked === true;
        next.metrics_review_only = existing?.metrics_review_only === true && incoming?.metrics_review_only === true;
        next.date_confidence = preferredDate?.date_confidence || existing?.date_confidence || incoming?.date_confidence || 'NO_DISPONIBLE';
        next.date_interval_from = preferredDate?.date_interval_from || existing?.date_interval_from || incoming?.date_interval_from || '';
        next.date_interval_to = preferredDate?.date_interval_to || existing?.date_interval_to || incoming?.date_interval_to || '';
        const existingOrder = Number(existing?.feed_order || 0);
        const incomingOrder = Number(incoming?.feed_order || 0);
        next.feed_order = existingOrder && incomingOrder ? Math.min(existingOrder, incomingOrder) : (existingOrder || incomingOrder || 0);
        next.first_seen_scroll_y = Math.min(
            Number(existing?.first_seen_scroll_y || Number.MAX_SAFE_INTEGER),
            Number(incoming?.first_seen_scroll_y || Number.MAX_SAFE_INTEGER)
        );
        if (!Number.isFinite(next.first_seen_scroll_y) || next.first_seen_scroll_y === Number.MAX_SAFE_INTEGER) next.first_seen_scroll_y = 0;
        next.first_seen_cycle = Math.min(
            Number(existing?.first_seen_cycle || Number.MAX_SAFE_INTEGER),
            Number(incoming?.first_seen_cycle || Number.MAX_SAFE_INTEGER)
        );
        if (!Number.isFinite(next.first_seen_cycle) || next.first_seen_cycle === Number.MAX_SAFE_INTEGER) next.first_seen_cycle = 0;

        for (const field of ['author_source', 'reactions_source', 'comments_source', 'shares_source', 'views_source', 'reactions_confidence', 'comments_confidence', 'shares_confidence', 'views_confidence', 'permalink_enrichment_source']) {
            next[field] = preferText(existing?.[field], incoming?.[field]);
        }
        next.permalink_enrichment_success = existing?.permalink_enrichment_success === true || incoming?.permalink_enrichment_success === true;
        next.permalink_enrichment_attempted = existing?.permalink_enrichment_attempted === true || incoming?.permalink_enrichment_attempted === true;
        next.permalink_enrichment_attempt_count = Math.max(
            Number(existing?.permalink_enrichment_attempt_count || 0),
            Number(incoming?.permalink_enrichment_attempt_count || 0)
        );
        next.permalink_enrichment_error = next.permalink_enrichment_success
            ? ''
            : (incoming?.permalink_enrichment_error || existing?.permalink_enrichment_error || '');
        next.metrics_zone_observed = existing?.metrics_zone_observed === true || incoming?.metrics_zone_observed === true;
        next.metrics_zone_visible = existing?.metrics_zone_visible === true || incoming?.metrics_zone_visible === true;
        next.engagement_controls_present = existing?.engagement_controls_present === true || incoming?.engagement_controls_present === true;
        next.card_lower_edge_observed = existing?.card_lower_edge_observed === true || incoming?.card_lower_edge_observed === true;
        for (const metric of ['reactions', 'comments', 'shares', 'views']) {
            const existingObserved = Number(existing?.[`${metric}_observed_count`] || 0);
            const incomingObserved = Number(incoming?.[`${metric}_observed_count`] || 0);
            next[`${metric}_observed_count`] = existingObserved + incomingObserved;
            next[`${metric}_first_value`] = existing?.[`${metric}_first_value`] ?? incoming?.[`${metric}_first_value`] ?? null;
            next[`${metric}_first_raw`] = existing?.[`${metric}_first_raw`]
                ?? existing?.[`${metric}_raw`]
                ?? incoming?.[`${metric}_first_raw`]
                ?? incoming?.[`${metric}_raw`]
                ?? null;
            next[`${metric}_last_value`] = incomingObserved > 0
                ? (incoming?.[`${metric}_last_value`] ?? incoming?.[`${metric}_count`] ?? null)
                : (existing?.[`${metric}_last_value`] ?? existing?.[`${metric}_count`] ?? null);
            next[`${metric}_last_raw`] = incomingObserved > 0
                ? (incoming?.[`${metric}_last_raw`] ?? incoming?.[`${metric}_raw`] ?? null)
                : (existing?.[`${metric}_last_raw`] ?? existing?.[`${metric}_raw`] ?? null);
        }
        next.reaction_breakdown_first_raw = existing?.reaction_breakdown_first_raw
            ?? existing?.reaction_breakdown_raw
            ?? incoming?.reaction_breakdown_first_raw
            ?? incoming?.reaction_breakdown_raw
            ?? null;
        next.reaction_breakdown_last_raw = Number(incoming?.reactions_observed_count || 0) > 0
            ? (incoming?.reaction_breakdown_last_raw ?? incoming?.reaction_breakdown_raw ?? null)
            : (existing?.reaction_breakdown_last_raw ?? existing?.reaction_breakdown_raw ?? null);

        const preferredContentRecord = String(incoming?.text || '').length > String(existing?.text || '').length ? incoming : existing;
        next.content_signature = preferredContentRecord?.content_signature || existing?.content_signature || incoming?.content_signature || '';
        next.media_urls = Array.from(new Set([...(existing?.media_urls || []), ...(incoming?.media_urls || [])])).slice(0, 30);
        next.media_asset_ids = Array.from(new Set([...(existing?.media_asset_ids || []), ...(incoming?.media_asset_ids || [])])).slice(0, 30);
        next.external_links = Array.from(new Set([...(existing?.external_links || []), ...(incoming?.external_links || [])])).slice(0, 30);
        next.media_count = Math.max(Number(existing?.media_count || 0), Number(incoming?.media_count || 0), next.media_urls.length);
        next.first_seen_at = Math.min(Number(existing?.first_seen_at || seenAt), Number(incoming?.first_seen_at || seenAt));
        next.last_seen_at = seenAt;
        next.seen_count = Number(existing?.seen_count || 0) + Number(incoming?.seen_count || 1);
        next.source_method = cleanText(context?.operationName || incoming?.source_method || existing?.source_method || 'FACEBOOK_DOM_VISIBLE_V9', 120);
        return evaluateRecordQuality(next);
    }

    async function findBySignature(store, signature) {
        if (!signature || !store.indexNames.contains('content_signature')) return null;
        return requestResult(store.index('content_signature').get(signature));
    }

    async function findByMediaAssets(store, incoming) {
        if (!store.indexNames.contains('media_asset_ids')) return null;
        const assets = Array.isArray(incoming?.media_asset_ids) ? incoming.media_asset_ids : [];
        for (const asset of assets) {
            if (!asset) continue;
            const matches = await requestResult(store.index('media_asset_ids').getAll(asset, 8));
            for (const candidate of matches || []) {
                if (candidate?.id === incoming?.id) return candidate;
                if (textsLikelySame(candidate?.text, incoming?.text)) return candidate;
            }
        }
        return null;
    }

    async function pruneIfNeeded(database) {
        const transaction = database.transaction(STORE_POSTS, 'readonly');
        const store = transaction.objectStore(STORE_POSTS);
        const count = await requestResult(store.count());
        await transactionDone(transaction);
        if (count <= MAX_POSTS) return;

        const excess = count - MAX_POSTS;
        const writeTx = database.transaction(STORE_POSTS, 'readwrite');
        const index = writeTx.objectStore(STORE_POSTS).index('last_seen_at');
        let removed = 0;
        await new Promise((resolve, reject) => {
            const cursorRequest = index.openCursor();
            cursorRequest.onerror = () => reject(cursorRequest.error);
            cursorRequest.onsuccess = () => {
                const cursor = cursorRequest.result;
                if (!cursor || removed >= excess) return resolve();
                cursor.delete();
                removed += 1;
                cursor.continue();
            };
        });
        await transactionDone(writeTx);
    }

    async function upsertPosts(posts, context = {}) {
        const database = await openDatabase();
        const seenAt = Date.now();
        let inserted = 0;
        let updated = 0;
        let promoted = 0;
        try {
            const transaction = database.transaction(STORE_POSTS, 'readwrite');
            const store = transaction.objectStore(STORE_POSTS);
            for (const post of posts || []) {
                const incoming = normalizePost(post, context, seenAt);
                if (!incoming) continue;

                const exact = await requestResult(store.get(incoming.id));
                let mediaMatch = null;
                if (!exact && incoming.media_asset_ids?.length) mediaMatch = await findByMediaAssets(store, incoming);
                let signatureMatch = null;
                if (!exact && !mediaMatch && incoming.content_signature) signatureMatch = await findBySignature(store, incoming.content_signature);

                let target = exact || mediaMatch || signatureMatch;
                if (target && target.id !== incoming.id) {
                    const incomingNative = incoming.identifier_quality === 'NATIVO';
                    const targetNative = target.identifier_quality === 'NATIVO';
                    const incomingScope = String(incoming.identifier_scope || '').toUpperCase();
                    const targetScope = String(target.identifier_scope || '').toUpperCase();
                    // Dos permalinks de publicación distintos no se fusionan solo por texto.
                    // Sí se permite promover un ID de fotografía a un permalink exterior
                    // o fusionar varias fotos de la misma tarjeta mediante la firma estable.
                    if (incomingNative && targetNative
                        && incomingScope === 'PUBLICACION'
                        && targetScope === 'PUBLICACION') target = null;
                }

                if (!target) {
                    await requestResult(store.put(incoming));
                    inserted += 1;
                    continue;
                }

                let merged = mergePost(target, incoming, context, seenAt);
                if (target.id !== incoming.id && identityRank(incoming) > identityRank(target)) {
                    merged.id = incoming.id;
                    merged.native_id = incoming.native_id || merged.native_id;
                    merged.identifier_quality = incoming.identifier_quality;
                    merged.identifier_scope = incoming.identifier_scope || merged.identifier_scope;
                    merged.provisional_id = merged.identifier_quality === 'PROVISIONAL';
                    await requestResult(store.delete(target.id));
                    promoted += 1;
                } else {
                    merged.id = target.id;
                }
                merged = evaluateRecordQuality(merged);
                await requestResult(store.put(merged));
                updated += 1;
            }
            await transactionDone(transaction);
            await pruneIfNeeded(database);
            return { success: true, inserted, updated, promoted };
        } finally {
            database.close();
        }
    }

    async function getAllPosts() {
        const database = await openDatabase();
        try {
            const transaction = database.transaction(STORE_POSTS, 'readonly');
            const rows = await requestResult(transaction.objectStore(STORE_POSTS).getAll());
            await transactionDone(transaction);
            return rows || [];
        } finally {
            database.close();
        }
    }

    async function getSummary() {
        const rows = await getAllPosts();
        const quality = { NATIVO: 0, DERIVADO: 0, PROVISIONAL: 0 };
        let observations = 0;
        for (const row of rows) {
            const key = String(row?.identifier_quality || 'PROVISIONAL').toUpperCase();
            if (Object.prototype.hasOwnProperty.call(quality, key)) quality[key] += 1;
            observations += Math.max(1, Number(row?.seen_count || 1));
        }
        return {
            count: rows.length,
            observations,
            duplicatesMerged: Math.max(0, observations - rows.length),
            quality
        };
    }

    async function clear() {
        const database = await openDatabase();
        try {
            const transaction = database.transaction(STORE_POSTS, 'readwrite');
            await requestResult(transaction.objectStore(STORE_POSTS).clear());
            await transactionDone(transaction);
            return true;
        } finally {
            database.close();
        }
    }

    globalThis.FacebookPostDB = { upsertPosts, getAllPosts, getSummary, clear };
})();
