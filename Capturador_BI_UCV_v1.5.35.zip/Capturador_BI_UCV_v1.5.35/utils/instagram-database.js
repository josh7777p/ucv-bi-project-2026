// Capturador BI UCV — almacenamiento local independiente para Instagram.
// Conserva una fila por shortcode y fusiona observaciones repetidas mediante
// máximos visibles, nunca mediante sumas.
(function () {
    'use strict';

    const DB_NAME = 'biucv_instagram_stats';
    const DB_VERSION = 1;
    const STORE_POSTS = 'posts';
    const MAX_POSTS = 30000;

    function cleanText(value, maxLength = 50000) {
        return typeof value === 'string' ? value.slice(0, maxLength) : '';
    }

    function finiteCount(value) {
        if (value === null || value === undefined || value === '') return null;
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
    }

    function cleanRaw(value, maxLength = 500) {
        if (value === null || value === undefined || value === '') return null;
        return cleanText(String(value), maxLength) || null;
    }

    function normalizeUsername(value) {
        return cleanText(String(value || '').replace(/^@/, ''), 220).toLowerCase();
    }

    function extractHashtags(text) {
        return [...new Set((String(text || '').match(/#[\p{L}\p{N}_]+/gu) || [])
            .map(value => value.slice(1))
            .filter(Boolean))];
    }

    function extractMentions(text) {
        const source = String(text || '');
        const values = [];
        const seen = new Set();
        const regex = /@([A-Za-z0-9._]{1,30})/g;
        let match;
        while ((match = regex.exec(source)) !== null) {
            const previous = match.index > 0 ? source[match.index - 1] : '';
            if (previous && /[A-Za-z0-9._%+-]/.test(previous)) continue;
            const username = match[1].replace(/\.+$/, '');
            if (!username || username.length > 30 || username.includes('..')) continue;
            const key = username.toLowerCase();
            if (!seen.has(key)) {
                seen.add(key);
                values.push(username);
            }
        }
        return values;
    }

    function mediaUrlStableKey(value) {
        try {
            const url = new URL(String(value || ''), 'https://www.instagram.com/');
            const cacheKey = url.searchParams.get('ig_cache_key');
            if (cacheKey) return `ig_cache:${cacheKey.replace(/=+$/g, '')}`;
            const filename = decodeURIComponent(url.pathname.split('/').pop() || '');
            const mediaId = filename.match(/^(\d+_\d+_\d+)_n(?:\.|$)/i)?.[1]
                || filename.match(/^(\d{8,})/i)?.[1];
            if (mediaId) return `media:${mediaId}`;
            return `path:${url.pathname.replace(/\.(?:jpe?g|webp|heic|png|mp4)$/i, '')}`;
        } catch (_) {
            return `raw:${String(value || '').split('?')[0]}`;
        }
    }

    function mediaUrlQualityScore(value) {
        const raw = String(value || '');
        let score = 0;
        if (/\.mp4(?:\?|$)/i.test(raw)) score += 100000;
        if (!/[?&]stp=/i.test(raw)) score += 10000;
        for (const match of raw.matchAll(/(?:^|[_?&])(?:s|p|cstp=mx|ctp=s)(\d{2,5})(?:x(\d{2,5}))?/gi)) {
            score = Math.max(score, Number(match[1] || 0) * Number(match[2] || match[1] || 0));
        }
        return score;
    }

    function dedupeMediaUrls(values) {
        const selected = new Map();
        for (const value of values || []) {
            const url = cleanText(String(value || ''), 1800);
            if (!url || /^blob:/i.test(url)) continue;
            const key = mediaUrlStableKey(url);
            const previous = selected.get(key);
            if (!previous || mediaUrlQualityScore(url) > mediaUrlQualityScore(previous)) selected.set(key, url);
        }
        return [...selected.values()];
    }

    function classifyPost(post) {
        const target = normalizeUsername(post?.target_username || '');
        const author = normalizeUsername(post?.author_username || '');
        const collaborators = [...new Set((post?.collaborator_usernames || []).map(normalizeUsername).filter(Boolean))];
        const targetIsAuthor = Boolean(target && author === target);
        const targetIsCollaborator = Boolean(target && collaborators.includes(target));
        const hasOtherCollaborators = collaborators.some(username => username !== author);
        const appearsInTargetGrid = post?.from_target_profile_grid !== false;
        const collaborative = Boolean(post?.is_collaboration)
            || hasOtherCollaborators
            || (!targetIsAuthor && appearsInTargetGrid);
        const targetParticipates = targetIsAuthor
            || targetIsCollaborator
            || (!targetIsAuthor && appearsInTargetGrid);
        let classification = 'AJENA_NO_CLASIFICADA';
        if (targetIsAuthor && collaborative) classification = 'PROPIA_COLABORATIVA';
        else if (targetIsAuthor) classification = 'PROPIA_EXCLUSIVA';
        else if (targetParticipates && collaborative) classification = 'COLABORACION_PUBLICADA_POR_TERCERO';
        return {
            ...post,
            target_username: target || null,
            collaborator_usernames: collaborators,
            is_own_post: targetIsAuthor,
            is_collaboration: collaborative,
            target_account_participates: targetParticipates,
            metrics_attributable_to_target: targetParticipates,
            exclusive_target_production: targetIsAuthor && !collaborative,
            account_link_classification: classification,
            account_link_classification_source: post?.account_link_classification_source
                || (targetIsCollaborator || hasOtherCollaborators || post?.is_collaboration
                    ? 'DATOS_ESTRUCTURADOS_COLABORADORES'
                    : (!targetIsAuthor && appearsInTargetGrid
                        ? 'AUTOR_DISTINTO_EN_GRID_PRINCIPAL_CUENTA_OBJETIVO'
                        : 'COMPARACION_AUTOR_CUENTA_OBJETIVO'))
        };
    }

    function requestResult(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function transactionDone(transaction) {
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            transaction.onabort = () => reject(transaction.error || new Error('IndexedDB transaction aborted'));
        });
    }

    function ensureIndex(store, name, keyPath, options = {}) {
        if (!store.indexNames.contains(name)) store.createIndex(name, keyPath, options);
    }

    function openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = () => {
                const database = request.result;
                let store;
                if (!database.objectStoreNames.contains(STORE_POSTS)) {
                    store = database.createObjectStore(STORE_POSTS, { keyPath: 'shortcode' });
                } else {
                    store = request.transaction.objectStore(STORE_POSTS);
                }
                ensureIndex(store, 'created_at_ms', 'created_at_ms');
                ensureIndex(store, 'last_seen_at', 'last_seen_at');
                ensureIndex(store, 'author_username', 'author_username');
                ensureIndex(store, 'media_id', 'media_id');
                ensureIndex(store, 'feed_order', 'feed_order');
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function normalizeMetric(post, name) {
        const metrics = post?.metrics || post?.metricas || {};
        const raws = post?.metrics_raw || post?.metricas_raw || {};
        const value = finiteCount(metrics[name] ?? post?.[name]);
        const raw = cleanRaw(raws[name] ?? post?.[`${name}_raw`]);
        return { value, raw };
    }

    function normalizePost(post, seenAt) {
        const shortcode = cleanText(post?.shortcode || post?.code || post?.identificador_publicacion_origen || '', 120);
        if (!shortcode || !/^[A-Za-z0-9_-]{5,120}$/.test(shortcode)) return null;
        const parsedDate = Date.parse(post?.created_at || post?.fecha_publicacion || '');
        const explicitMs = Number(post?.created_at_ms || 0);
        const createdAtMs = Number.isFinite(explicitMs) && explicitMs > 0
            ? explicitMs
            : (Number.isFinite(parsedDate) ? parsedDate : 0);
        const likes = normalizeMetric(post, 'like_count');
        const comments = normalizeMetric(post, 'comment_count');
        const views = normalizeMetric(post, 'view_count');
        const plays = normalizeMetric(post, 'play_count');
        const shares = normalizeMetric(post, 'share_count');
        const saves = normalizeMetric(post, 'save_count');
        const mediaUrls = Array.isArray(post?.media_urls)
            ? dedupeMediaUrls(post.media_urls)
            : [];
        const altTexts = Array.isArray(post?.media_alt_texts)
            ? post.media_alt_texts.map(value => cleanText(String(value || ''), 2000)).filter(Boolean)
            : [];
        const normalized = {
            shortcode,
            id: shortcode,
            media_id: cleanText(String(post?.media_id || post?.pk || ''), 160) || null,
            permalink: cleanText(post?.permalink || post?.url_publicacion || '', 1200),
            post_type: cleanText(post?.post_type || post?.tipo_contenido || 'PUBLICACION', 40).toUpperCase(),
            author_username: cleanText(post?.author_username || post?.autor_usuario || '', 220),
            author_name: cleanText(post?.author_name || post?.autor_nombre || '', 300),
            author_url: cleanText(post?.author_url || post?.autor_url || '', 1200),
            caption: cleanText(post?.caption || post?.text || post?.cuerpo || '', 50000),
            created_at: createdAtMs > 0 ? new Date(createdAtMs).toISOString() : '',
            created_at_ms: createdAtMs > 0 ? createdAtMs : 0,
            date_raw: cleanRaw(post?.date_raw || post?.fecha_raw, 300),
            timezone: cleanText(post?.timezone || post?.zona_horaria || 'UTC', 80),
            location_name: cleanText(post?.location_name || '', 500) || null,
            hashtags: extractHashtags(post?.caption || post?.text || post?.cuerpo || ''),
            mentions: extractMentions(post?.caption || post?.text || post?.cuerpo || ''),
            target_username: normalizeUsername(post?.target_username || ''),
            from_target_profile_grid: post?.from_target_profile_grid !== false,
            is_pinned: post?.is_pinned === true,
            collaborator_usernames: Array.isArray(post?.collaborator_usernames)
                ? [...new Set(post.collaborator_usernames.map(normalizeUsername).filter(Boolean))]
                : [],
            is_collaboration: post?.is_collaboration === true,
            account_link_classification_source: cleanText(post?.account_link_classification_source || '', 160) || null,
            media_count: Math.max(0, Number(post?.media_count || mediaUrls.length || 0)),
            media_urls: mediaUrls,
            media_alt_texts: altTexts,
            like_count: likes.value,
            comment_count: comments.value,
            view_count: views.value,
            play_count: plays.value,
            share_count: shares.value,
            save_count: saves.value,
            metrics_raw: {
                like_count: likes.raw,
                comment_count: comments.raw,
                view_count: views.raw,
                play_count: plays.raw,
                share_count: shares.raw,
                save_count: saves.raw
            },
            metric_sources: post?.metric_sources && typeof post.metric_sources === 'object'
                ? { ...post.metric_sources }
                : {},
            structured_data_found: post?.structured_data_found === true,
            capture_surface: cleanText(post?.capture_surface || 'INSTAGRAM_MODAL_DOM', 100),
            feed_order: Math.max(0, Number(post?.feed_order || 0)),
            first_seen_at: seenAt,
            last_seen_at: seenAt,
            seen_count: 1
        };
        return classifyPost(normalized);
    }

    function mergeMetric(existing, incoming, name) {
        const oldValue = finiteCount(existing?.[name]);
        const newValue = finiteCount(incoming?.[name]);
        const oldRaw = cleanRaw(existing?.metrics_raw?.[name]);
        const newRaw = cleanRaw(incoming?.metrics_raw?.[name]);
        const oldSource = cleanRaw(existing?.metric_sources?.[name], 160);
        const newSource = cleanRaw(incoming?.metric_sources?.[name], 160);
        if (oldValue === null && newValue === null) {
            return oldRaw
                ? { value: null, raw: oldRaw, source: oldSource }
                : { value: null, raw: newRaw, source: newSource };
        }
        if (oldValue === null) return { value: newValue, raw: newRaw, source: newSource };
        if (newValue === null) return { value: oldValue, raw: oldRaw, source: oldSource };
        if (newValue > oldValue) return { value: newValue, raw: newRaw, source: newSource };
        if (newValue === oldValue && !oldRaw && newRaw) return { value: oldValue, raw: newRaw, source: newSource || oldSource };
        return { value: oldValue, raw: oldRaw, source: oldSource };
    }

    function mergePosts(existing, incoming) {
        const metrics = {};
        for (const name of ['like_count', 'comment_count', 'view_count', 'play_count', 'share_count', 'save_count']) {
            metrics[name] = mergeMetric(existing, incoming, name);
        }
        const preferIncomingText = (incoming.caption || '').length > (existing.caption || '').length;
        const createdAtMs = existing.created_at_ms > 0 && incoming.created_at_ms > 0
            ? Math.min(existing.created_at_ms, incoming.created_at_ms)
            : (existing.created_at_ms || incoming.created_at_ms || 0);
        const merged = {
            ...existing,
            media_id: existing.media_id || incoming.media_id || null,
            permalink: existing.permalink || incoming.permalink,
            post_type: existing.post_type !== 'PUBLICACION' ? existing.post_type : incoming.post_type,
            author_username: existing.author_username || incoming.author_username,
            author_name: existing.author_name || incoming.author_name,
            author_url: existing.author_url || incoming.author_url,
            caption: preferIncomingText ? incoming.caption : existing.caption,
            created_at_ms: createdAtMs,
            created_at: createdAtMs > 0 ? new Date(createdAtMs).toISOString() : '',
            date_raw: existing.date_raw || incoming.date_raw,
            timezone: existing.timezone || incoming.timezone,
            location_name: existing.location_name || incoming.location_name,
            hashtags: extractHashtags(preferIncomingText ? incoming.caption : existing.caption),
            mentions: extractMentions(preferIncomingText ? incoming.caption : existing.caption),
            target_username: existing.target_username || incoming.target_username || null,
            from_target_profile_grid: existing.from_target_profile_grid || incoming.from_target_profile_grid,
            is_pinned: Boolean(existing.is_pinned || incoming.is_pinned),
            collaborator_usernames: [...new Set([...(existing.collaborator_usernames || []), ...(incoming.collaborator_usernames || [])])],
            is_collaboration: Boolean(existing.is_collaboration || incoming.is_collaboration),
            account_link_classification_source: incoming.account_link_classification_source || existing.account_link_classification_source || null,
            media_count: Math.max(existing.media_count || 0, incoming.media_count || 0),
            media_urls: dedupeMediaUrls([...(existing.media_urls || []), ...(incoming.media_urls || [])]),
            media_alt_texts: [...new Set([...(existing.media_alt_texts || []), ...(incoming.media_alt_texts || [])])],
            like_count: metrics.like_count.value,
            comment_count: metrics.comment_count.value,
            view_count: metrics.view_count.value,
            play_count: metrics.play_count.value,
            share_count: metrics.share_count.value,
            save_count: metrics.save_count.value,
            metrics_raw: Object.fromEntries(Object.entries(metrics).map(([key, value]) => [key, value.raw])),
            metric_sources: Object.fromEntries(Object.entries(metrics).map(([key, value]) => [key, value.source || null])),
            structured_data_found: existing.structured_data_found || incoming.structured_data_found,
            capture_surface: incoming.capture_surface || existing.capture_surface,
            feed_order: Math.min(existing.feed_order || Number.MAX_SAFE_INTEGER, incoming.feed_order || Number.MAX_SAFE_INTEGER),
            first_seen_at: Math.min(existing.first_seen_at || incoming.first_seen_at, incoming.first_seen_at),
            last_seen_at: Math.max(existing.last_seen_at || 0, incoming.last_seen_at || 0),
            seen_count: Math.max(1, Number(existing.seen_count || 1)) + 1
        };
        return classifyPost(merged);
    }

    async function upsertPosts(posts, context = {}) {
        const list = Array.isArray(posts) ? posts.slice(0, 120) : [];
        if (!list.length) return { inserted: 0, updated: 0, ignored: 0 };
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readwrite');
        const store = transaction.objectStore(STORE_POSTS);
        const seenAt = Date.now();
        let inserted = 0;
        let updated = 0;
        let ignored = 0;
        for (const post of list) {
            const normalized = normalizePost({ ...post, capture_surface: post?.capture_surface || context.operationName }, seenAt);
            if (!normalized) {
                ignored++;
                continue;
            }
            const existing = await requestResult(store.get(normalized.shortcode));
            if (existing) {
                store.put(mergePosts(existing, normalized));
                updated++;
            } else {
                store.put(normalized);
                inserted++;
            }
        }
        await transactionDone(transaction);
        database.close();
        return { inserted, updated, ignored };
    }

    async function getAllPosts() {
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readonly');
        const rows = await requestResult(transaction.objectStore(STORE_POSTS).getAll());
        await transactionDone(transaction);
        database.close();
        return (rows || []).sort((a, b) => {
            const orderA = Number(a.feed_order || Number.MAX_SAFE_INTEGER);
            const orderB = Number(b.feed_order || Number.MAX_SAFE_INTEGER);
            if (orderA !== orderB) return orderA - orderB;
            return Number(b.created_at_ms || 0) - Number(a.created_at_ms || 0);
        });
    }

    async function getSummary() {
        const rows = await getAllPosts();
        const withDate = rows.filter(row => Number(row.created_at_ms || 0) > 0).length;
        const firstDateMs = rows.reduce((min, row) => row.created_at_ms > 0 ? Math.min(min, row.created_at_ms) : min, Infinity);
        return {
            count: rows.length,
            withDate,
            withoutDate: rows.length - withDate,
            withLikes: rows.filter(row => row.like_count !== null).length,
            withComments: rows.filter(row => row.comment_count !== null).length,
            withViews: rows.filter(row => row.view_count !== null || row.play_count !== null).length,
            firstDateMs: Number.isFinite(firstDateMs) ? firstDateMs : null,
            lastDateMs: rows.reduce((max, row) => Math.max(max, row.created_at_ms || 0), 0) || null,
            lastSeenAt: rows.reduce((max, row) => Math.max(max, row.last_seen_at || 0), 0) || null,
            maxPosts: MAX_POSTS
        };
    }

    async function clear() {
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readwrite');
        transaction.objectStore(STORE_POSTS).clear();
        await transactionDone(transaction);
        database.close();
        return true;
    }

    globalThis.InstagramPostDB = {
        upsertPosts,
        getAllPosts,
        getSummary,
        clear
    };
})();
