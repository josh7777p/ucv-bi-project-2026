// XPorter — local database for posts passively seen in X timelines.
// One IndexedDB row per post ID; repeat sightings update the existing row.
(function () {
    const DB_NAME = 'xporter_feed_stats';
    const DB_VERSION = 1;
    const STORE_POSTS = 'posts';
    const MAX_POSTS = 50000;
    const METRICS = [
        'view_count',
        'bookmark_count',
        'favorite_count',
        'retweet_count',
        'reply_count',
        'quote_count'
    ];

    function emptyMetrics() {
        return Object.fromEntries(METRICS.map(name => [name, null]));
    }

    function normalizeUsername(value) {
        return String(value || '').replace(/^@/, '').trim().toLowerCase();
    }

    function normalizeType(post) {
        const raw = String(post?.type || '').toUpperCase();
        if (raw === 'RETWEET' || post?.is_retweet === true) return 'RETWEET';
        if (raw === 'THREAD_REPLY') return 'THREAD_REPLY';
        if (raw === 'REPLY' || post?.in_reply_to_status_id) {
            const replyTarget = normalizeUsername(post?.in_reply_to_username);
            const author = normalizeUsername(post?.author_username);
            return replyTarget && author && replyTarget === author ? 'THREAD_REPLY' : 'REPLY';
        }
        return 'TWEET';
    }

    function cleanMetricObject(value, raw = false) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const result = {};
        for (const name of METRICS) {
            if (raw) {
                const item = source[name];
                result[name] = item === null || item === undefined ? null : cleanText(String(item), 120);
            } else {
                result[name] = finiteCount(source[name]);
            }
        }
        return result;
    }

    function cleanStringMap(value, maxLength = 160) {
        if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
        const result = {};
        for (const [key, item] of Object.entries(value)) {
            if (!/^[A-Za-z0-9_]{1,80}$/.test(key)) continue;
            result[key] = item === null || item === undefined ? null : cleanText(String(item), maxLength);
        }
        return result;
    }

    function rawEvidenceScore(value) {
        if (value === null || value === undefined || value === '') return 0;
        const text = String(value).trim();
        if (!text) return 0;
        // Labels such as "1.2K likes", "64,1 mil seguidores" or
        // "203 mil vistas" are stronger audit evidence than plain API digits.
        if (/[^0-9.,+-]/u.test(text)) return 2;
        return 1;
    }

    function preferRawEvidence(existingValue, incomingValue) {
        const existingScore = rawEvidenceScore(existingValue);
        const incomingScore = rawEvidenceScore(incomingValue);
        if (incomingScore === 0) return existingValue ?? null;
        if (existingScore > incomingScore) return existingValue;
        return incomingValue;
    }

    function requestResult(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function transactionDone(transaction) {
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            transaction.onabort = () => reject(transaction.error || new Error('IndexedDB transaction aborted'));
        });
    }

    function openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = () => {
                const database = request.result;
                const store = database.createObjectStore(STORE_POSTS, { keyPath: 'id' });
                store.createIndex('last_seen_at', 'last_seen_at');
                store.createIndex('created_at_ms', 'created_at_ms');
                store.createIndex('author_username', 'author_username');
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    function finiteCount(value) {
        if (value === null || value === undefined || value === '') return null;
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
    }

    function cleanText(value, maxLength) {
        return typeof value === 'string' ? value.slice(0, maxLength) : '';
    }

    function normalizePost(post, context, seenAt) {
        const createdAtRaw = cleanText(post.created_at, 80);
        const createdAtMs = Date.parse(createdAtRaw);
        const createdAtIso = Number.isFinite(createdAtMs)
            ? new Date(createdAtMs).toISOString()
            : createdAtRaw;
        const type = normalizeType(post);
        const targetUsername = cleanText(post.target_account_username, 40);
        const authorUsername = cleanText(post.author_username, 40);
        const reposterUsername = cleanText(post.reposter_username || post.cuenta_que_republica, 40);
        const isExternalRetweet = type === 'RETWEET' && (
            post.es_repost_externo === true
            || (normalizeUsername(authorUsername)
                && normalizeUsername(reposterUsername || targetUsername)
                && normalizeUsername(authorUsername) !== normalizeUsername(reposterUsername || targetUsername))
        );
        const isOwnPublication = !isExternalRetweet && (
            post.es_publicacion_propia === true
            || !targetUsername
            || normalizeUsername(authorUsername) === normalizeUsername(targetUsername)
        );
        const originalMetrics = post.metricas_contenido_original
            ? cleanMetricObject(post.metricas_contenido_original)
            : Object.fromEntries(METRICS.map(name => [name, finiteCount(post[name])]));
        const originalRawMetrics = post.metricas_raw_contenido_original
            ? cleanMetricObject(post.metricas_raw_contenido_original, true)
            : cleanMetricObject(post.metricas_raw, true);
        const operationalMetrics = isExternalRetweet ? emptyMetrics() : originalMetrics;
        const operationalRawMetrics = isExternalRetweet ? emptyMetrics() : cleanMetricObject(post.metricas_raw, true);

        const normalized = {
            id: String(post.id),
            feed_order: finiteCount(post.feed_order) || 0,
            text: cleanText(post.text, 25000),
            tweet_url: cleanText(post.tweet_url, 300),
            language: cleanText(post.language, 16),
            created_at: createdAtIso,
            created_at_ms: Number.isFinite(createdAtMs) ? createdAtMs : 0,
            author_id: cleanText(post.author_id, 32),
            author_name: cleanText(post.author_name, 200),
            author_username: authorUsername,
            author_followers_count: finiteCount(post.author_followers_count),
            first_author_followers_count: finiteCount(post.author_followers_count),
            author_verified: Boolean(post.author_verified),
            type,
            in_reply_to_status_id: cleanText(post.in_reply_to_status_id, 32),
            in_reply_to_user_id: cleanText(post.in_reply_to_user_id, 32),
            in_reply_to_username: cleanText(post.in_reply_to_username, 40),
            conversation_id: cleanText(post.conversation_id, 32),
            target_account_username: targetUsername,
            reposter_username: reposterUsername,
            original_author_username: cleanText(post.original_author_username || (type === 'RETWEET' ? authorUsername : ''), 40),
            cuenta_que_republica: cleanText(post.cuenta_que_republica || reposterUsername, 40),
            autor_original: cleanText(post.autor_original || (type === 'RETWEET' ? authorUsername : ''), 40),
            es_publicacion_propia: Boolean(isOwnPublication),
            es_repost_externo: Boolean(isExternalRetweet),
            metricas_atribuibles_cuenta: Boolean(isOwnPublication && !isExternalRetweet),
            metricas_raw: operationalRawMetrics,
            metricas_contenido_original: isExternalRetweet ? originalMetrics : null,
            metricas_raw_contenido_original: isExternalRetweet ? originalRawMetrics : null,
            metricas_origen: cleanText(post.metricas_origen, 80),
            metricas_fuente_detalle: cleanStringMap(post.metricas_fuente_detalle),
            is_quote: Boolean(post.is_quote),
            is_retweet: type === 'RETWEET',
            is_article: Boolean(post.is_article || post.article_title),
            is_pinned: Boolean(post.is_pinned),
            media_count: finiteCount(post.media_count) || 0,
            media_types: cleanText(post.media_types, 80),
            media_type: cleanText(post.media_type, 80),
            media_urls: cleanText(post.media_urls, 20000),
            media_alt_texts: cleanText(post.media_alt_texts, 12000),
            source: cleanText(post.source, 300),
            hashtags: cleanText(post.hashtags, 5000),
            urls: cleanText(post.urls, 12000),
            article_title: cleanText(post.article_title, 2000),
            article_url: cleanText(post.article_url, 1000),
            article_text: cleanText(post.article_text, 25000),
            first_seen_at: seenAt,
            last_seen_at: seenAt,
            seen_count: 1,
            last_surface: cleanText(context?.operationName, 80)
        };

        for (const metric of METRICS) {
            const value = operationalMetrics[metric];
            normalized[metric] = value;
            normalized[`first_${metric}`] = value;
        }
        return normalized;
    }

    function mergePost(existing, incoming, context, seenAt) {
        const next = { ...existing, ...incoming };
        for (const field of [
            'text', 'tweet_url', 'language', 'created_at',
            'author_id', 'author_name', 'author_username', 'media_types', 'media_type',
            'media_urls', 'media_alt_texts', 'source', 'hashtags', 'urls',
            'article_title', 'article_url', 'article_text',
            'type', 'in_reply_to_status_id', 'in_reply_to_user_id', 'in_reply_to_username',
            'conversation_id', 'target_account_username', 'reposter_username',
            'original_author_username', 'cuenta_que_republica', 'autor_original',
            'metricas_origen'
        ]) {
            if (!incoming[field]) next[field] = existing[field] || incoming[field];
        }
        if (!incoming.created_at_ms) next.created_at_ms = existing.created_at_ms || 0;
        const feedOrders = [existing.feed_order, incoming.feed_order]
            .map(value => finiteCount(value))
            .filter(value => value > 0);
        next.feed_order = feedOrders.length ? Math.min(...feedOrders) : 0;
        next.first_seen_at = existing.first_seen_at || seenAt;
        next.last_seen_at = seenAt;
        next.seen_count = (Number(existing.seen_count) || 1) + 1;
        next.last_surface = cleanText(context?.operationName, 80) || existing.last_surface || '';
        next.author_verified = Boolean(existing.author_verified || incoming.author_verified);
        next.is_quote = Boolean(existing.is_quote || incoming.is_quote);
        next.is_article = Boolean(existing.is_article || incoming.is_article);
        next.is_pinned = Boolean(existing.is_pinned || incoming.is_pinned);
        next.is_retweet = next.type === 'RETWEET';
        next.es_repost_externo = Boolean(existing.es_repost_externo || incoming.es_repost_externo);
        next.es_publicacion_propia = next.es_repost_externo
            ? false
            : Boolean(existing.es_publicacion_propia || incoming.es_publicacion_propia);
        next.metricas_atribuibles_cuenta = Boolean(next.es_publicacion_propia && !next.es_repost_externo);
        const existingRaw = cleanMetricObject(existing.metricas_raw, true);
        const incomingRaw = cleanMetricObject(incoming.metricas_raw, true);
        next.metricas_raw = {};
        for (const metric of METRICS) {
            next.metricas_raw[metric] = preferRawEvidence(existingRaw[metric], incomingRaw[metric]);
        }
        next.metricas_fuente_detalle = {
            ...(existing.metricas_fuente_detalle || {}),
            ...(incoming.metricas_fuente_detalle || {})
        };

        if (next.es_repost_externo) {
            const existingOriginal = cleanMetricObject(existing.metricas_contenido_original || existing);
            const incomingOriginal = cleanMetricObject(incoming.metricas_contenido_original || incoming);
            next.metricas_contenido_original = {};
            const existingOriginalRaw = cleanMetricObject(
                existing.metricas_raw_contenido_original || existing.metricas_raw,
                true
            );
            const incomingOriginalRaw = cleanMetricObject(
                incoming.metricas_raw_contenido_original || incoming.metricas_raw,
                true
            );
            next.metricas_raw_contenido_original = {};
            for (const metric of METRICS) {
                next.metricas_raw_contenido_original[metric] = preferRawEvidence(
                    existingOriginalRaw[metric],
                    incomingOriginalRaw[metric]
                );
            }
            for (const metric of METRICS) {
                next.metricas_contenido_original[metric] = incomingOriginal[metric] ?? existingOriginal[metric] ?? null;
                next[metric] = null;
                next[`first_${metric}`] = null;
                next.metricas_raw[metric] = null;
            }
        } else {
            next.metricas_contenido_original = null;
            next.metricas_raw_contenido_original = null;
            for (const metric of METRICS) {
                next[`first_${metric}`] = existing[`first_${metric}`] ?? existing[metric] ?? incoming[metric];
                if (incoming[metric] === null) next[metric] = existing[metric] ?? null;
            }
        }

        if (incoming.author_followers_count === null) {
            next.author_followers_count = existing.author_followers_count ?? null;
        }
        next.first_author_followers_count = existing.first_author_followers_count
            ?? existing.author_followers_count
            ?? incoming.author_followers_count;
        next.type = normalizeType(next);
        return next;
    }

    async function upsertPosts(posts, context = {}) {
        if (!Array.isArray(posts) || posts.length === 0) return { inserted: 0, updated: 0 };

        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readwrite');
        const done = transactionDone(transaction);
        const store = transaction.objectStore(STORE_POSTS);
        const seenAt = Date.now();
        let inserted = 0;
        let updated = 0;

        for (const post of posts) {
            if (!post?.id || !/^\d{5,30}$/.test(String(post.id))) continue;
            const normalized = normalizePost(post, context, seenAt);
            const existing = await requestResult(store.get(normalized.id));
            if (existing) {
                store.put(mergePost(existing, normalized, context, seenAt));
                updated += 1;
            } else {
                store.add(normalized);
                inserted += 1;
            }
        }

        await done;
        database.close();

        if (inserted > 0) await trimToLimit();
        return { inserted, updated };
    }

    async function trimToLimit() {
        const database = await openDatabase();
        const countTransaction = database.transaction(STORE_POSTS, 'readonly');
        const countDone = transactionDone(countTransaction);
        const count = await requestResult(countTransaction.objectStore(STORE_POSTS).count());
        await countDone;
        if (count <= MAX_POSTS) {
            database.close();
            return 0;
        }

        const removeCount = count - MAX_POSTS;
        const transaction = database.transaction(STORE_POSTS, 'readwrite');
        const done = transactionDone(transaction);
        const index = transaction.objectStore(STORE_POSTS).index('last_seen_at');
        let removed = 0;
        await new Promise((resolve, reject) => {
            const request = index.openCursor();
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                const cursor = request.result;
                if (!cursor || removed >= removeCount) {
                    resolve();
                    return;
                }
                cursor.delete();
                removed += 1;
                cursor.continue();
            };
        });
        await done;
        database.close();
        return removed;
    }

    async function getSummary() {
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readonly');
        const done = transactionDone(transaction);
        const store = transaction.objectStore(STORE_POSTS);
        const count = await requestResult(store.count());
        let lastSeenAt = 0;

        if (count > 0) {
            lastSeenAt = await new Promise((resolve, reject) => {
                const request = store.index('last_seen_at').openCursor(null, 'prev');
                request.onsuccess = () => resolve(request.result?.value?.last_seen_at || 0);
                request.onerror = () => reject(request.error);
            });
        }
        await done;
        database.close();
        return { count, lastSeenAt, maxPosts: MAX_POSTS };
    }

    async function getAllPosts() {
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readonly');
        const done = transactionDone(transaction);
        const posts = await requestResult(transaction.objectStore(STORE_POSTS).getAll());
        await done;
        database.close();
        posts.sort((a, b) => (b.last_seen_at || 0) - (a.last_seen_at || 0));
        return posts;
    }

    async function clear() {
        const database = await openDatabase();
        const transaction = database.transaction(STORE_POSTS, 'readwrite');
        const done = transactionDone(transaction);
        transaction.objectStore(STORE_POSTS).clear();
        await done;
        database.close();
    }

    globalThis.XPorterPostDB = {
        upsertPosts,
        getSummary,
        getAllPosts,
        clear,
        mergePost,
        MAX_POSTS,
        METRICS
    };
})();
