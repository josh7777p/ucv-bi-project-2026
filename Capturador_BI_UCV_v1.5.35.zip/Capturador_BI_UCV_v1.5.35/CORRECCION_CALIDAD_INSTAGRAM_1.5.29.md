# Corrección de calidad de Instagram — 1.5.29

Esta versión incorpora cuatro ajustes localizados en el módulo de Instagram:

1. Detección de publicaciones fijadas mediante señales semánticas del grid, el modal y los datos estructurados.
2. Cola inicial del grid para recorrer en orden las publicaciones visibles y no depender exclusivamente de `Next`.
3. Clasificación explícita de publicaciones propias y colaborativas, conservando el autor original.
4. Extracción de menciones que excluye direcciones de correo electrónico.
5. Deduplicación de variantes de URLs multimedia por `ig_cache_key` o identificador estable.

Las métricas numéricas, fechas, shortcodes y enlaces permanentes mantienen las reglas aprobadas en la versión 1.5.28.
