# Corrección del recorrido de Instagram — 1.5.30

La navegación vuelve a usar el botón exterior `Next` como ruta principal, sin cerrar el modal entre publicaciones. La cola del grid se conserva como respaldo.

## Estado de captura

- `FIRST_10_REACHED`: diez publicaciones recuperadas.
- `DATE_WINDOW_REACHED`: límite temporal confirmado.
- `END_REACHED`: final confirmado en captura completa.
- `NAVIGATION_INTERRUPTED`: no fue posible avanzar antes de alcanzar la meta; el JSON parcial se marca como incompleto.
