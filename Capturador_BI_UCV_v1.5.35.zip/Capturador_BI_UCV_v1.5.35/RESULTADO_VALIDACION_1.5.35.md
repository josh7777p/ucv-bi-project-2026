# Resultado de validación — 1.5.35

## Alcance

La corrección se concentra en `content/facebook-content.js` y en la versión del manifiesto. Los módulos funcionales de X, Instagram, el service worker, las descargas y las bases locales permanecen idénticos a la versión 1.5.34.

## Pruebas superadas

- Un control moderno `See more` con `role="button"` continúa recibiendo un único clic.
- Un `span` moderno dentro del cuerpo textual continúa expandiéndose.
- Un `Ver más` contenido en un enlace `/notes/...` no recibe clic.
- Un texto `Ver más` fuera del cuerpo y sin semántica de botón no recibe clic.
- Las rutas `/notes/...` y `/perfil/posts/...` son rechazadas durante una captura activa.
- La ruta del perfil original continúa siendo aceptada.
- Todos los archivos JavaScript superan la validación de sintaxis con Node.js.
- Todos los archivos JSON incluidos son válidos.
- El ZIP supera la prueba de integridad después del empaquetado.

## Prueba real pendiente

La validación definitiva requiere ejecutar el histórico en Facebook desde diciembre de 2019 y confirmar que el barrido continúa hacia publicaciones anteriores sin abandonar el perfil.
