# Validación interna 1.5.15

- Sintaxis JavaScript validada con Node.js.
- Manifest V3 y archivos JSON validados.
- Resolución de `aria-labelledby` comprobada contra un nodo externo al contenedor de la tarjeta.
- Se conserva el control dentro de la tarjeta como evidencia de asociación.
- Protección contra enlaces de comentarios y fechas del cuerpo.
- Detención temporal reforzada.
- Archivos centrales de X comparados byte por byte con 1.5.13.
