# Resultado de validación — v1.5.21

- Sintaxis JavaScript: aprobada.
- Archivos JSON: válidos.
- HTML guardado `9999.html`: 34 menús de publicación, 34 fechas asociadas, 0 ambiguas y 0 faltantes; nivel estructural 3 en los 34 casos.
- Fuente `AUTHOR_DATE_HOVER_TOOLTIP`: aceptada por contenido y service worker.
- Módulos principales de X: sin cambios binarios frente a v1.5.20.
- El recorrido dinámico real de Facebook debe confirmarse con una nueva ejecución.
- La extensión se detiene con `DATE_CAPTURE_QUALITY_LOW` si la cobertura inicial de fechas es insuficiente, evitando que “Último mes” continúe indefinidamente.
