# Validación aria-labelledby 1.5.15

La ruta principal se probó en un DOM sintético equivalente al observado en Facebook:

- control temporal dentro de la tarjeta;
- `aria-labelledby="_r_8o_"`;
- nodo accesible externo con texto `15 min`;
- fecha futura escrita en el cuerpo;
- fecha de comentario con `comment_id`.

Resultado:

```json
{
  "raw": "15 min",
  "source": "AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT",
  "precision": "RELATIVA_CONFIABLE"
}
```

También se validó una fecha de calendario completa:

```json
{
  "raw": "18 de julio a las 3:32 a. m.",
  "source": "AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT",
  "precision": "APROXIMADA_CALENDARIO"
}
```

La fecha del cuerpo y la fecha del comentario fueron rechazadas.
