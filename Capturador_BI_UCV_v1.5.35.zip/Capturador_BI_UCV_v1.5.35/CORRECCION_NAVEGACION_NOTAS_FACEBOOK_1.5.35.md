# Corrección de navegación en notas antiguas de Facebook — 1.5.35

- La expansión automática acepta únicamente controles internos con texto exacto `Ver más`, `See more` o `Mostrar más`.
- Se omiten controles contenidos en enlaces, elementos `role="link"`, encabezados, navegación o zonas multimedia.
- `Learn More` no se considera expansor de una descripción porque puede ser una llamada a la acción o un enlace heredado.
- Antes de cada tarjeta y después de una expansión se verifica que la pestaña continúe en el perfil original.
- No se modifica la lógica funcional de X ni de Instagram.
