# Capturador BI UCV v1.5.25 — trazabilidad final

Esta versión conserva los valores numéricos aprobados en v1.5.24 y corrige dos aspectos auxiliares:

1. Los contadores de la ruta de fecha por icono de privacidad ahora se incluyen en el resultado final.
2. La evidencia raw de cada métrica queda vinculada a la observación que produjo el máximo visible.

Los campos destinados al DW siguen siendo los contenidos en `metricas`. Los nuevos campos raw son evidencia de auditoría y no deben utilizarse para cálculos.
