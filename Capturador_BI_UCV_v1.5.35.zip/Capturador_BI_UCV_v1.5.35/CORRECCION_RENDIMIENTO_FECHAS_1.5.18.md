# Capturador BI UCV v1.5.18 — Facebook

## Objetivo

Reducir el tiempo de captura sin perder la asociación estructural de la fecha con cada publicación.

## Cambios exclusivos de Facebook

- Mantiene la ruta validada: botón **Acciones en esta publicación** → contenedor mínimo → `aria-labelledby` → `document.getElementById()`.
- Conserva `fecha_raw` y normaliza el día para fechas relativas y de calendario.
- Usa un `MutationObserver` para reintentar únicamente menús cuya fecha todavía no fue hidratada.
- Omite la persistencia cuando una publicación no cambió en fecha, contenido, URL, multimedia o métricas.
- Persiste de nuevo si aumenta una métrica o aparece una fecha/permalink que faltaba.
- Sustituye el recorrido completo hacia atrás por revisiones dirigidas a las posiciones donde quedó una fecha pendiente.
- Reduce el solapamiento y las pausas del scroll de forma conservadora.
- Reduce la revisión final de métricas a las dos pantallas previas.
- Elimina `Ver menos`/`See less` al final del cuerpo exportado.

## Integridad

- No se infieren fechas por posición, cuerpo o publicaciones vecinas.
- Una fecha ambigua continúa sin asignarse.
- El módulo de X/Twitter no fue modificado.
