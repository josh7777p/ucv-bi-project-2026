# Captura de las primeras 10 publicaciones — v1.5.33

La opción `first_10` se amplió a X y Facebook sin sustituir sus recorridos validados.

- X: utiliza la captura pasiva de `/with_replies`, asigna un orden estable al primer avistamiento y se detiene al alcanzar diez IDs únicos.
- Facebook: conserva la captura secuencial mediante menú de acciones y termina después de diez tarjetas únicas procesadas.
- Instagram: permanece sin cambios funcionales respecto de la v1.5.32.

La finalización esperada para las tres plataformas es `FIRST_10_REACHED`.
