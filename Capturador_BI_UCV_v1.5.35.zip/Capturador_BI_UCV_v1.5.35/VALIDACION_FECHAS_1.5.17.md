# Validación recomendada de fechas — v1.5.17

En el JSON exportado debe verificarse:

- `metadata_captura.version_extension`: `1.5.17`.
- `calidad_captura.fechas.no_detectadas`: idealmente `0`.
- `calidad_captura.fechas.porcentaje_cobertura`: idealmente `100`.
- `fecha_origen_deteccion`: `AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT`.
- `fecha_nivel_contenedor_acciones`: normalmente `3` para la estructura validada.
- `fecha_raw`: debe coincidir con el texto visible de Facebook, por ejemplo `4 h`, `1 día` o `14 de julio a las 4:08 pm`.
- `fecha_publicacion_visual`: debe estar normalizada como `DD/MM/YYYY`.

Las publicaciones sin fecha no se completan mediante el texto del cuerpo, comentarios, orden del feed ni límite temporal.
