// XPorter UCV — institutional local build.
// External uninstall telemetry is disabled. Keep a compatible no-op API so the
// original service worker can call it without transmitting anything.
(function () {
  async function refresh() {}
  function maybeRefresh() {}
  globalThis.XPorterFeedback = { refresh, maybeRefresh };
})();
