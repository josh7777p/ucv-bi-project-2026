// XPorter — download module
// Owns export serialization and chrome.downloads handoff. The service worker
// only chooses which saved dataset to download.

(function () {
    let activeDownload = null;

    function keepWorkerAliveDuringDownload() {
        if (typeof chrome === 'undefined' || !chrome.runtime?.getPlatformInfo) {
            return () => {};
        }
        // startCurrentDownload acknowledges the popup immediately, so the
        // generation promise is no longer tied to the runtime-message event.
        // Touch a Chrome API before MV3's idle deadline while large parts are
        // being serialized or handed to chrome.downloads.
        const timer = setInterval(() => {
            try {
                chrome.runtime.getPlatformInfo(() => {});
            } catch (_) { /* keepalive is best-effort */ }
        }, 20000);
        return () => clearInterval(timer);
    }

    function getPartLimit(format, mode) {
        const group = mode === 'posts' ? 'posts' : 'users';
        const configured = XPORTER_CONFIG?.DOWNLOAD_PART_LIMITS?.[group]?.[format];
        if (Number.isFinite(configured) && configured > 0) return configured;
        return group === 'posts' ? 10000 : 50000;
    }

    function buildPlan(state, requestedFormat) {
        const format = requestedFormat || state?.outputFormat || 'csv';
        const count = Math.max(0, Number(state?.tweetCount) || 0);
        const partSize = getPartLimit(format, state?.exportMode || 'posts');
        const partCount = Math.max(1, Math.ceil(count / partSize));
        return {
            count,
            format,
            partSize,
            partCount,
            multipart: partCount > 1,
            active: !!activeDownload
        };
    }

    async function getCurrentPlan(format) {
        const state = await XPorterStorage.loadExportState();
        return buildPlan(state, format);
    }

    async function* loadCurrentParts(state, partSize) {
        const readSize = Math.max(1, Number(XPORTER_CONFIG?.STORAGE_BATCH_READ_SIZE) || 100);
        let part = [];

        for (let start = 0; start < (state.totalBatches || 0); start += readSize) {
            const count = Math.min(readSize, state.totalBatches - start);
            const batches = await XPorterStorage.loadTweetBatches(start, count);
            for (const batch of batches) {
                for (const item of batch) {
                    part.push(item);
                    if (part.length === partSize) {
                        yield part;
                        part = [];
                    }
                }
            }
        }

        if (part.length > 0) yield part;
    }

    function reportDownload(message) {
        try {
            const result = chrome.runtime?.sendMessage?.(message);
            result?.catch?.(() => {});
        } catch (_) { /* popup may be closed */ }
    }

    async function recordSuccessfulDownload() {
        await XPorterStorage.recordDownload()
            .then(() => globalThis.XPorterFeedback?.refresh?.())
            .catch(() => {});
    }

    async function downloadCurrent(format) {
        const state = await XPorterStorage.loadExportState();
        const plan = buildPlan(state, format);
        if (!state || plan.count === 0 || !state.totalBatches) return { error: 'NO_DATA' };

        let partNumber = 0;
        let downloadedCount = 0;
        let lastResult = null;
        const filenames = [];
        const exportedAt = new Date();
        for await (const items of loadCurrentParts(state, plan.partSize)) {
            partNumber++;
            reportDownload({
                type: 'DOWNLOAD_PROGRESS',
                partNumber,
                partCount: plan.partCount,
                count: plan.count,
                format: plan.format
            });
            lastResult = await downloadItems(items, {
                username: state.username || 'unknown',
                socialPlatform: state.socialPlatform || 'x',
                mode: state.exportMode || 'posts',
                format: plan.format,
                profile: state.userInfo || null,
                timelineMode: state.settings?.timelineMode || 'user_tweets_and_replies',
                totalExportCount: plan.count,
                captureMethod: state.captureMethod || null,
                captureResult: state.scrollCaptureResult || null,
                capturePeriod: state.settings?.capturePeriod || state.scrollCaptureResult?.capturePeriod || 'unlimited',
                startedAt: state.startedAt || null,
                completedAt: state.completedAt || null,
                dateFrom: state.dateFrom,
                dateTo: state.dateTo,
                exportedAt,
                partNumber,
                partCount: plan.partCount,
                saveAs: !plan.multipart
            });
            if (lastResult?.success !== true) return lastResult;
            downloadedCount += items.length;
            filenames.push(lastResult.filename);
        }

        if (partNumber === 0) return { error: 'NO_DATA' };
        if (downloadedCount !== plan.count) {
            XLog.error(`Download row count mismatch: expected ${plan.count}, read ${downloadedCount}`);
            return { error: 'DOWNLOAD_FAILED' };
        }
        await recordSuccessfulDownload();
        reportDownload({
            type: 'DOWNLOAD_COMPLETE',
            partCount: partNumber,
            count: plan.count,
            format: plan.format
        });
        if (!plan.multipart) return lastResult;
        return { success: true, count: plan.count, partCount: partNumber, filenames };
    }

    async function startCurrentDownload(format) {
        if (activeDownload) return { error: 'DOWNLOAD_IN_PROGRESS' };
        const plan = await getCurrentPlan(format);
        if (plan.count === 0) return { error: 'NO_DATA' };

        const stopKeepAlive = keepWorkerAliveDuringDownload();
        activeDownload = downloadCurrent(plan.format)
            .then(result => {
                if (result?.success !== true) {
                    reportDownload({ type: 'DOWNLOAD_ERROR', error: result?.error || 'DOWNLOAD_FAILED' });
                }
                return result;
            })
            .catch(error => {
                XLog.error('Download failed:', error.message);
                reportDownload({ type: 'DOWNLOAD_ERROR', error: error.message || 'DOWNLOAD_FAILED' });
                return { error: error.message || 'DOWNLOAD_FAILED' };
            })
            .finally(() => {
                stopKeepAlive();
                activeDownload = null;
            });

        return { success: true, started: true, ...plan, active: true };
    }

    async function getCurrentPostsText() {
        const state = await XPorterStorage.loadExportState();
        if (state?.exportMode !== 'posts') return { error: 'NO_DATA' };
        const plan = buildPlan(state, 'txt');
        if (plan.multipart) return { error: 'COPY_TOO_LARGE' };
        for await (const items of loadCurrentParts(state, plan.partSize)) {
            return {
                success: true,
                text: XPorterCSV.generatePostsText(items, state.userInfo || {}),
                count: items.length
            };
        }
        return { error: 'NO_DATA' };
    }

    async function downloadHistory(id, format) {
        const entry = await XPorterStorage.loadExportHistoryEntry(id);
        if (!entry) return { error: 'HISTORY_NOT_FOUND' };
        if (!Array.isArray(entry.items) || entry.items.length === 0) {
            return { error: 'HISTORY_DATA_GONE' };
        }

        const result = await downloadItems(entry.items, {
            username: entry.username || 'unknown',
            socialPlatform: entry.socialPlatform || 'x',
            mode: entry.exportMode || 'posts',
            format: format || entry.outputFormat || 'csv',
            profile: entry.userInfo || {
                name: entry.displayName || '',
                screenName: entry.username || ''
            },
            timelineMode: entry.timelineMode || 'user_tweets_and_replies',
            totalExportCount: entry.itemCount || entry.items.length,
            capturePeriod: entry.capturePeriod || entry.settings?.capturePeriod || 'unlimited',
            startedAt: entry.startedAt || null,
            completedAt: entry.completedAt || null,
            dateFrom: entry.dateFrom,
            dateTo: entry.dateTo,
            exportedAt: entry.completedAt || new Date()
        });
        if (result.success) await recordSuccessfulDownload();
        return result;
    }

    function toIsoOrNull(value) {
        if (value === undefined || value === null || value === '') return null;
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? null : date.toISOString();
    }

    function numberOrNull(value) {
        if (value === undefined || value === null || value === '') return null;
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : null;
    }

    const UCV_METRIC_NAMES = [
        'view_count',
        'bookmark_count',
        'favorite_count',
        'retweet_count',
        'reply_count',
        'quote_count'
    ];

    function normalizeUsername(value) {
        return String(value || '').replace(/^@/, '').trim().toLowerCase();
    }

    function normalizeUcvType(item = {}) {
        const raw = String(item.type || '').toUpperCase();
        if (raw === 'RETWEET' || item.is_retweet === true) return 'RETWEET';
        if (raw === 'THREAD_REPLY') return 'THREAD_REPLY';
        if (raw === 'REPLY' || item.in_reply_to_status_id) {
            const replyTarget = normalizeUsername(item.in_reply_to_username);
            const author = normalizeUsername(item.author_username);
            return replyTarget && author && replyTarget === author ? 'THREAD_REPLY' : 'REPLY';
        }
        return 'TWEET';
    }

    function emptyUcvMetrics() {
        return Object.fromEntries(UCV_METRIC_NAMES.map(name => [name, null]));
    }

    function normalizeMetricObject(value, raw = false) {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const result = {};
        for (const name of UCV_METRIC_NAMES) {
            const item = source[name];
            result[name] = raw
                ? (item === undefined || item === null || item === '' ? null : String(item))
                : numberOrNull(item);
        }
        return result;
    }

    function normalizeUcvPostForExport(item = {}, targetUsername = '') {
        const type = normalizeUcvType(item);
        const authorUsername = String(item.author_username || '');
        const reposterUsername = String(item.reposter_username || item.cuenta_que_republica || targetUsername || '');
        const normalizedTarget = normalizeUsername(item.target_account_username || targetUsername);
        const normalizedAuthor = normalizeUsername(authorUsername);
        const normalizedReposter = normalizeUsername(reposterUsername || targetUsername);
        const isExternalRetweet = type === 'RETWEET' && (
            item.es_repost_externo === true
            || (normalizedAuthor && normalizedReposter && normalizedAuthor !== normalizedReposter)
        );
        const isOwnPublication = !isExternalRetweet && (
            item.es_publicacion_propia === true
            || !normalizedTarget
            || normalizedAuthor === normalizedTarget
        );

        const currentMetrics = Object.fromEntries(
            UCV_METRIC_NAMES.map(name => [name, numberOrNull(item[name])])
        );
        const currentRawMetrics = normalizeMetricObject(item.metricas_raw, true);
        const originalMetrics = normalizeMetricObject(
            item.metricas_contenido_original || currentMetrics
        );
        const originalRawMetrics = normalizeMetricObject(
            item.metricas_raw_contenido_original || currentRawMetrics,
            true
        );
        const operationalMetrics = isExternalRetweet ? emptyUcvMetrics() : currentMetrics;
        const operationalRawMetrics = isExternalRetweet ? emptyUcvMetrics() : currentRawMetrics;

        return {
            ...item,
            type,
            ...operationalMetrics,
            metricas_raw: operationalRawMetrics,
            metricas_contenido_original: isExternalRetweet ? originalMetrics : null,
            metricas_raw_contenido_original: isExternalRetweet ? originalRawMetrics : null,
            target_account_username: item.target_account_username || targetUsername || null,
            reposter_username: type === 'RETWEET' ? (reposterUsername || targetUsername || null) : null,
            original_author_username: type === 'RETWEET'
                ? (item.original_author_username || authorUsername || null)
                : null,
            cuenta_que_republica: type === 'RETWEET'
                ? (item.cuenta_que_republica || reposterUsername || targetUsername || null)
                : null,
            autor_original: type === 'RETWEET'
                ? (item.autor_original || authorUsername || null)
                : null,
            es_publicacion_propia: Boolean(isOwnPublication),
            es_repost_externo: Boolean(isExternalRetweet),
            metricas_atribuibles_cuenta: Boolean(isOwnPublication && !isExternalRetweet),
            is_retweet: type === 'RETWEET',
            is_article: Boolean(item.is_article || item.article_title)
        };
    }

    function buildUcvProfile(profile = {}, exportedAt = new Date()) {
        const username = profile.screenName || profile.username || '';
        const captureIso = toIsoOrNull(exportedAt) || new Date().toISOString();
        const totalFollowers = numberOrNull(profile.followersCount ?? profile.followers_count);
        const totalFollowing = numberOrNull(profile.followingCount ?? profile.following_count);
        const totalPosts = numberOrNull(profile.tweetCount ?? profile.tweet_count);

        return {
            perfil: {
                identificador_origen: profile.id || null,
                nombre_cuenta: profile.name || null,
                usuario: username || null,
                url_perfil: username ? `https://x.com/${String(username).replace(/^@/, '')}` : null,
                biografia: profile.bio || null,
                ubicacion: profile.location || null,
                sitio_web: profile.url || null,
                fecha_creacion: toIsoOrNull(profile.createdAt || profile.created_at),
                imagen_perfil_url: profile.profileImageUrl || profile.profile_image_url || null,
                cuenta_protegida: Boolean(profile.isProtected ?? profile.protected),
                cuenta_verificada: Boolean(profile.isVerified ?? profile.verified),
                categoria_profesional: profile.professionalCategory || profile.professional_category || null,
                total_listas: numberOrNull(profile.listedCount ?? profile.listed_count),
                total_likes_realizados: numberOrNull(profile.likesCount ?? profile.likes_count),
                total_multimedia: numberOrNull(profile.mediaCount ?? profile.media_count),
                total_suscripciones: numberOrNull(profile.subscriptionsCount ?? profile.subscriptions_count)
            },
            comunidad: {
                tipo_comunidad: 'SEGUIDORES',
                fecha_medicion: captureIso,
                total_seguidores: totalFollowers,
                total_seguidores_raw: profile.followersCountRaw ?? profile.followers_count_raw ?? null,
                total_seguidos: totalFollowing,
                total_seguidos_raw: profile.followingCountRaw ?? profile.following_count_raw ?? null,
                total_publicaciones_perfil: totalPosts,
                total_publicaciones_perfil_raw: profile.tweetCountRaw ?? profile.tweet_count_raw ?? null,
                origen_medicion: profile.profileSource || profile.source || 'PERFIL_X_SESION_AUTENTICADA'
            }
        };
    }

    function buildUcvCaptureSummary(items, options = {}) {
        const typeCounts = {};
        const authors = new Set();
        const ids = new Set();
        let firstDate = null;
        let lastDate = null;
        let ownPosts = 0;
        let externalRetweets = 0;
        let attributablePosts = 0;

        for (const item of items || []) {
            const type = normalizeUcvType(item);
            typeCounts[type] = (typeCounts[type] || 0) + 1;
            if (item?.author_username) authors.add(String(item.author_username).toLowerCase());
            if (item?.id) ids.add(String(item.id));
            if (item?.es_publicacion_propia === true) ownPosts += 1;
            if (item?.es_repost_externo === true) externalRetweets += 1;
            if (item?.metricas_atribuibles_cuenta === true) attributablePosts += 1;
            const date = toIsoOrNull(item?.created_at);
            if (date && (!firstDate || date < firstDate)) firstDate = date;
            if (date && (!lastDate || date > lastDate)) lastDate = date;
        }

        const reason = options.captureResult?.reason || null;
        const requestedPeriod = options.captureResult?.capturePeriod || options.capturePeriod || 'unlimited';
        const reachedEnd = reason === 'END_REACHED';
        const reachedFirstTen = requestedPeriod === 'first_10'
            && reason === 'FIRST_10_REACHED'
            && items.length >= 10;
        const reachedDateWindow = reason === 'DATE_WINDOW_REACHED';
        const reachedRequestedPeriod = reachedFirstTen || reachedDateWindow;
        const captureComplete = reachedEnd || reachedRequestedPeriod;
        const finalPosition = options.captureResult?.finalPosition || {};

        return {
            total_registros_exportacion: numberOrNull(options.totalExportCount) ?? items.length,
            registros_en_archivo: items.length,
            identificadores_unicos_en_archivo: ids.size,
            autores_distintos_en_archivo: authors.size,
            publicaciones_propias_en_archivo: ownPosts,
            retweets_externos_en_archivo: externalRetweets,
            publicaciones_con_metricas_atribuibles: attributablePosts,
            primera_fecha_recuperada: firstDate,
            ultima_fecha_recuperada: lastDate,
            distribucion_tipos: typeCounts,
            parte_numero: numberOrNull(options.partNumber) || 1,
            total_partes: numberOrNull(options.partCount) || 1,
            captura_llego_al_final: reachedEnd,
            captura_llego_al_periodo_solicitado: reachedRequestedPeriod,
            captura_completa: captureComplete,
            estado_captura: captureComplete ? 'COMPLETA' : 'INCOMPLETA',
            motivo_finalizacion_captura: reason,
            periodo_extraccion: options.captureResult?.capturePeriod || 'unlimited',
            fecha_referencia_periodo: options.captureResult?.periodReferenceDate || null,
            fecha_limite_periodo: options.captureResult?.periodCutoffDate || null,
            registros_excluidos_anteriores_al_periodo: numberOrNull(options.captureResult?.excludedBeforePeriod),
            registros_sin_fecha_excluidos: numberOrNull(options.captureResult?.excludedWithoutDate),
            ciclos_desplazamiento: numberOrNull(options.captureResult?.cycles),
            ciclos_sin_nuevas_publicaciones: numberOrNull(options.captureResult?.stagnantCycles),
            confirmaciones_de_final: numberOrNull(options.captureResult?.endConfirmations),
            registros_unicos_detectados_antes_de_filtros: numberOrNull(options.captureResult?.rawUniquePosts),
            posicion_final_scroll: numberOrNull(finalPosition.scrollTop),
            altura_final_pagina: numberOrNull(finalPosition.pageHeight),
            altura_ventana: numberOrNull(finalPosition.viewportHeight),
            distancia_final_al_fondo: numberOrNull(finalPosition.distanceToBottom)
        };
    }

    function buildUcvJsonPayload(allItems, options = {}) {
        const exportedAt = options.exportedAt ? new Date(options.exportedAt) : new Date();
        const username = options.username || options.profile?.screenName || 'unknown';
        const targetUsername = String(username).replace(/^@/, '');
        const normalizedItems = (allItems || []).map(item => normalizeUcvPostForExport(item, targetUsername));
        const profileBlocks = buildUcvProfile(options.profile || {}, exportedAt);
        return {
            metadata_captura: {
                plataforma: 'X',
                cuenta_objetivo: targetUsername,
                metodo_extraccion: options.captureMethod === 'BROWSER_SCROLL_PASSIVE'
                    ? 'CAPTURA_ASISTIDA_SCROLL_NAVEGADOR'
                    : 'CAPTURA_ASISTIDA_EXTENSION_LOCAL',
                herramienta: 'CAPTURADOR_BI_UCV',
                version_extension: chrome.runtime?.getManifest?.().version || '1.4.19',
                modo_cronologia: options.timelineMode === 'user_tweets'
                    ? 'SOLO_POSTS'
                    : 'POSTS_Y_RESPUESTAS',
                fecha_inicio_captura: toIsoOrNull(options.startedAt),
                fecha_fin_captura: toIsoOrNull(options.completedAt) || exportedAt.toISOString(),
                fecha_exportacion: exportedAt.toISOString(),
                procesamiento: 'LOCAL_EN_NAVEGADOR',
                metricas_operativas: 'VALORES_NUMERICOS',
                metricas_raw: 'EVIDENCIA_AUXILIAR_NO_DESTINADA_A_CALCULOS',
                periodo_extraccion: options.captureResult?.capturePeriod || options.capturePeriod || 'unlimited',
                periodo_calculado_desde: (options.captureResult?.capturePeriod || options.capturePeriod) === 'first_10'
                    ? 'ORDEN_VISIBLE_INICIAL'
                    : 'PUBLICACION_MAS_RECIENTE_RECUPERADA'
            },
            ...profileBlocks,
            resumen_captura: buildUcvCaptureSummary(normalizedItems, options),
            publicaciones: normalizedItems
        };
    }


    function facebookQualityRank(value) {
        return ({ PROVISIONAL: 1, DERIVADO: 2, NATIVO: 3 })[String(value || '').toUpperCase()] || 0;
    }

    function facebookIdentityRank(item) {
        const quality = facebookQualityRank(item?.identifier_quality);
        const scope = ({ PROVISIONAL: 0, CONTENIDO_DERIVADO: 1, MULTIMEDIA: 2, PUBLICACION: 3 })[String(item?.identifier_scope || '').toUpperCase()] || 0;
        return quality * 10 + scope;
    }

    function mergeFacebookExportRows(existing, incoming) {
        const preferred = facebookIdentityRank(incoming) > facebookIdentityRank(existing)
            ? incoming
            : existing;
        const merged = { ...existing, ...incoming, id: preferred.id };
        const longer = (a, b) => String(b || '').length >= String(a || '').length ? (b || a || '') : (a || b || '');
        const maxMetric = (a, b) => {
            const x = numberOrNull(a);
            const y = numberOrNull(b);
            if (x === null) return y;
            if (y === null) return x;
            return Math.max(x, y);
        };
        merged.native_id = preferred.native_id || existing?.native_id || incoming?.native_id || '';
        merged.identifier_quality = preferred.identifier_quality || existing?.identifier_quality || incoming?.identifier_quality || 'PROVISIONAL';
        merged.identifier_source = preferred.identifier_source || existing?.identifier_source || incoming?.identifier_source || '';
        merged.identifier_scope = preferred.identifier_scope || existing?.identifier_scope || incoming?.identifier_scope || '';
        merged.permalink = preferred?.permalink || existing?.permalink || incoming?.permalink || '';
        merged.permalink_source = preferred?.permalink_source || existing?.permalink_source || incoming?.permalink_source || '';

        const dateRank = { EXACTA: 6, APROXIMADA_CALENDARIO: 5, RELATIVA_CONFIABLE: 4, RELATIVA_APROXIMADA: 3, INFERIDA_POR_ORDEN: 2, INFERIDA_POR_LIMITE: 1, FECHA_CAPTURA_REFERENCIAL: 1, NO_DETECTADA: 0 };
        const existingDateRank = dateRank[String(existing?.date_precision || '').toUpperCase()] || 0;
        const incomingDateRank = dateRank[String(incoming?.date_precision || '').toUpperCase()] || 0;
        const existingLocked = existing?.date_locked === true && Number(existing?.created_at_ms || 0) > 0;
        const incomingLocked = incoming?.date_locked === true && Number(incoming?.created_at_ms || 0) > 0;
        const preferredDate = existingLocked
            ? existing
            : (incomingLocked
                ? incoming
                : (incomingDateRank > existingDateRank
                    ? incoming
                    : (incomingDateRank < existingDateRank ? existing : (Number(existing?.created_at_ms || 0) > 0 ? existing : incoming))));
        merged.created_at = preferredDate?.created_at || '';
        merged.created_at_ms = Number(preferredDate?.created_at_ms || 0);
        merged.date_raw = preferredDate?.date_raw || null;
        merged.date_visible_raw = preferredDate?.date_visible_raw || null;
        merged.date_tooltip_raw = preferredDate?.date_tooltip_raw || null;
        merged.date_privacy_title = preferredDate?.date_privacy_title || null;
        merged.date_precision = preferredDate?.date_precision || 'NO_DETECTADA';
        merged.date_reference_at = preferredDate?.date_reference_at || '';
        merged.date_source = preferredDate?.date_source || '';
        merged.date_aria_labelledby_id = preferredDate?.date_aria_labelledby_id || '';
        merged.date_action_scope_level = Math.max(0, Number(preferredDate?.date_action_scope_level || 0));
        merged.date_action_menu_label = preferredDate?.date_action_menu_label || '';
        merged.date_has_explicit_time = preferredDate?.date_has_explicit_time === true;
        merged.date_timezone = preferredDate?.date_timezone || existing?.date_timezone || incoming?.date_timezone || '';
        merged.date_is_estimated = preferredDate?.date_is_estimated === true;
        merged.date_locked = preferredDate?.date_locked === true;
        merged.date_confidence = preferredDate?.date_confidence || existing?.date_confidence || incoming?.date_confidence || 'NO_DISPONIBLE';
        merged.date_interval_from = preferredDate?.date_interval_from || existing?.date_interval_from || incoming?.date_interval_from || '';
        merged.date_interval_to = preferredDate?.date_interval_to || existing?.date_interval_to || incoming?.date_interval_to || '';
        const existingOrder = Number(existing?.feed_order || 0);
        const incomingOrder = Number(incoming?.feed_order || 0);
        merged.feed_order = existingOrder && incomingOrder ? Math.min(existingOrder, incomingOrder) : (existingOrder || incomingOrder || 0);
        merged.first_seen_scroll_y = Math.min(
            Number(existing?.first_seen_scroll_y || Number.MAX_SAFE_INTEGER),
            Number(incoming?.first_seen_scroll_y || Number.MAX_SAFE_INTEGER)
        );
        if (!Number.isFinite(merged.first_seen_scroll_y) || merged.first_seen_scroll_y === Number.MAX_SAFE_INTEGER) merged.first_seen_scroll_y = 0;
        merged.first_seen_cycle = Math.min(
            Number(existing?.first_seen_cycle || Number.MAX_SAFE_INTEGER),
            Number(incoming?.first_seen_cycle || Number.MAX_SAFE_INTEGER)
        );
        if (!Number.isFinite(merged.first_seen_cycle) || merged.first_seen_cycle === Number.MAX_SAFE_INTEGER) merged.first_seen_cycle = 0;

        merged.text = longer(existing?.text, incoming?.text);
        const incomingIsTarget = incoming?.author_slug && incoming.author_slug === incoming?.target_profile_slug;
        const existingIsTarget = existing?.author_slug && existing.author_slug === existing?.target_profile_slug;
        const preferredAuthor = incomingIsTarget && !existingIsTarget ? incoming : (existingIsTarget && !incomingIsTarget ? existing : incoming);
        merged.author_name = preferredAuthor?.author_name || existing?.author_name || incoming?.author_name || '';
        merged.author_slug = preferredAuthor?.author_slug || existing?.author_slug || incoming?.author_slug || '';
        merged.author_url = preferredAuthor?.author_url || existing?.author_url || incoming?.author_url || '';
        merged.author_source = preferredAuthor?.author_source || existing?.author_source || incoming?.author_source || '';
        merged.reactions_count = maxMetric(existing?.reactions_count, incoming?.reactions_count);
        merged.comments_count = maxMetric(existing?.comments_count, incoming?.comments_count);
        merged.shares_count = maxMetric(existing?.shares_count, incoming?.shares_count);
        merged.views_count = maxMetric(existing?.views_count, incoming?.views_count);
        merged.reactions_raw = longer(existing?.reactions_raw, incoming?.reactions_raw) || null;
        merged.comments_raw = longer(existing?.comments_raw, incoming?.comments_raw) || null;
        merged.shares_raw = longer(existing?.shares_raw, incoming?.shares_raw) || null;
        merged.views_raw = longer(existing?.views_raw, incoming?.views_raw) || null;
        merged.reaction_breakdown_raw = longer(existing?.reaction_breakdown_raw, incoming?.reaction_breakdown_raw) || null;
        merged.media_urls = Array.from(new Set([...(existing?.media_urls || []), ...(incoming?.media_urls || [])])).slice(0, 30);
        merged.media_asset_ids = Array.from(new Set([...(existing?.media_asset_ids || []), ...(incoming?.media_asset_ids || [])])).slice(0, 30);
        merged.external_links = Array.from(new Set([...(existing?.external_links || []), ...(incoming?.external_links || [])])).slice(0, 30);
        for (const field of ['date_timezone', 'reactions_source', 'comments_source', 'shares_source', 'views_source', 'reactions_confidence', 'comments_confidence', 'shares_confidence', 'views_confidence', 'permalink_enrichment_source']) {
            merged[field] = longer(existing?.[field], incoming?.[field]);
        }
        merged.date_has_explicit_time = existing?.date_has_explicit_time === true || incoming?.date_has_explicit_time === true;
        merged.permalink_enrichment_success = existing?.permalink_enrichment_success === true || incoming?.permalink_enrichment_success === true;
        merged.permalink_enrichment_attempted = existing?.permalink_enrichment_attempted === true || incoming?.permalink_enrichment_attempted === true;
        merged.permalink_enrichment_attempt_count = Math.max(
            Number(existing?.permalink_enrichment_attempt_count || 0),
            Number(incoming?.permalink_enrichment_attempt_count || 0)
        );
        merged.permalink_enrichment_error = merged.permalink_enrichment_success
            ? null
            : (incoming?.permalink_enrichment_error || existing?.permalink_enrichment_error || null);
        merged.metrics_zone_observed = existing?.metrics_zone_observed === true || incoming?.metrics_zone_observed === true;
        merged.metrics_zone_visible = existing?.metrics_zone_visible === true || incoming?.metrics_zone_visible === true;
        merged.engagement_controls_present = existing?.engagement_controls_present === true || incoming?.engagement_controls_present === true;
        merged.card_lower_edge_observed = existing?.card_lower_edge_observed === true || incoming?.card_lower_edge_observed === true;
        for (const metric of ['reactions', 'comments', 'shares', 'views']) {
            merged[`${metric}_observed_count`] = Number(existing?.[`${metric}_observed_count`] || 0)
                + Number(incoming?.[`${metric}_observed_count`] || 0);
            merged[`${metric}_first_value`] = existing?.[`${metric}_first_value`] ?? incoming?.[`${metric}_first_value`] ?? null;
            merged[`${metric}_last_value`] = incoming?.[`${metric}_last_value`] ?? existing?.[`${metric}_last_value`] ?? null;
        }
        merged.observation_count = Number(existing?.observation_count || 1) + Number(incoming?.observation_count || 1);
        return merged;
    }

    function comparableFacebookExportText(value) {
        return String(value || '')
            .normalize('NFKC')
            .toLowerCase()
            .replace(/\b(?:ver más|ver menos|see more|see less)\b/gi, ' ')
            .replace(/https?:\/\/\S+/gi, ' ')
            .replace(/[^\p{L}\p{N}\s]+/gu, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function facebookExportRowsLikelySame(a, b) {
        const x = comparableFacebookExportText(a?.text);
        const y = comparableFacebookExportText(b?.text);
        if (!x || !y) return true;
        const shorter = x.length <= y.length ? x : y;
        const longer = x.length > y.length ? x : y;
        if (shorter.length >= 40 && longer.startsWith(shorter.slice(0, Math.min(shorter.length, 220)))) return true;
        const words = new Set(shorter.split(' ').filter(word => word.length > 3));
        if (!words.size) return shorter === longer;
        const common = longer.split(' ').filter(word => words.has(word)).length;
        return common / words.size >= 0.72;
    }

    function consolidateFacebookItems(items = []) {
        const byId = new Map();
        const signatureToKey = new Map();
        const mediaToKey = new Map();
        for (const item of items || []) {
            const quality = String(item?.identifier_quality || (item?.native_id ? 'NATIVO' : 'PROVISIONAL')).toUpperCase();
            const signature = item?.content_signature || '';
            const nativeKey = quality === 'NATIVO' && item?.native_id ? `N:${item.native_id}` : '';
            let key = nativeKey || (signature ? `S:${signature}` : `P:${item?.id || Math.random()}`);

            if (byId.has(key)) {
                byId.set(key, mergeFacebookExportRows(byId.get(key), item));
            } else {
                let mediaKey = '';
                for (const asset of item?.media_asset_ids || []) {
                    const candidateKey = mediaToKey.get(asset);
                    const candidate = candidateKey ? byId.get(candidateKey) : null;
                    if (candidate && facebookExportRowsLikelySame(candidate, item)) { mediaKey = candidateKey; break; }
                }
                if (mediaKey) key = mediaKey;
                else if (signature && signatureToKey.has(signature)) {
                    const previousKey = signatureToKey.get(signature);
                    const previous = byId.get(previousKey);
                    const incomingScope = String(item?.identifier_scope || '').toUpperCase();
                    const previousScope = String(previous?.identifier_scope || '').toUpperCase();
                    const distinctPostPermalinks = quality === 'NATIVO'
                        && previous?.identifier_quality === 'NATIVO'
                        && incomingScope === 'PUBLICACION'
                        && previousScope === 'PUBLICACION'
                        && previous?.native_id !== item?.native_id;
                    if (!distinctPostPermalinks) key = previousKey;
                }
                const existing = byId.get(key);
                byId.set(key, existing ? mergeFacebookExportRows(existing, item) : { ...item });
            }
            const saved = byId.get(key);
            if (saved?.content_signature) signatureToKey.set(saved.content_signature, key);
            for (const asset of saved?.media_asset_ids || []) mediaToKey.set(asset, key);
        }
        return Array.from(byId.values());
    }

    function facebookLocalDateParts(value, hasExplicitTime = false) {
        const date = new Date(value || 0);
        if (!Number.isFinite(date.getTime()) || date.getTime() <= 0) {
            return { date: null, time: null };
        }
        const pad = (number) => String(number).padStart(2, '0');
        return {
            date: `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`,
            time: hasExplicitTime ? `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}` : null
        };
    }

    function facebookVisualDate(isoValue) {
        const date = new Date(isoValue || 0);
        if (!Number.isFinite(date.getTime()) || date.getTime() <= 0) return null;
        const pad = value => String(value).padStart(2, '0');
        return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()}`;
    }

    function reactionBreakdownVisibleTotal(rawValue) {
        const raw = String(rawValue || '');
        if (!raw) return null;
        let total = 0;
        let found = false;
        const pattern = /:\s*(\d[\d.,\s]*)\s*(?:persona(?:s)?|people|person|usuarios?|users?)/gi;
        for (const match of raw.matchAll(pattern)) {
            const value = numberOrNull(String(match[1] || '').replace(/[.,\s]/g, ''));
            if (value === null) continue;
            total += value;
            found = true;
        }
        return found ? total : null;
    }

    function isTrustedFacebookExportDate(item = {}) {
        const precisions = new Set(['EXACTA', 'APROXIMADA_CALENDARIO', 'RELATIVA_CONFIABLE']);
        const sources = new Set(['DATA_UTIME', 'TIME_DATETIME', 'ABBR_TITLE', 'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT', 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT', 'AUTHOR_DATE_HOVER_TOOLTIP', 'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY', 'AUTHOR_DATE_ARIA_LABEL', 'AUTHOR_DATE_TITLE', 'AUTHOR_DATE_DIRECT_TEXT', 'PERMALINK_ARIA_LABEL', 'PERMALINK_TITLE', 'PERMALINK_LABEL']);
        const precision = String(item.date_precision || 'NO_DETECTADA').toUpperCase();
        const source = String(item.date_source || '').toUpperCase();
        const ms = Date.parse(item.created_at || '');
        return precisions.has(precision) && sources.has(source) && Number.isFinite(ms) && ms <= Date.now() + 10 * 60e3;
    }

    function normalizeFacebookPostForExport(item = {}) {
        const quality = String(item.identifier_quality || (item.native_id ? 'NATIVO' : 'PROVISIONAL')).toUpperCase();
        const scope = String(item.identifier_scope || (quality === 'NATIVO' ? 'PUBLICACION' : (quality === 'DERIVADO' ? 'CONTENIDO_DERIVADO' : 'PROVISIONAL'))).toUpperCase();
        const datePrecision = String(item.date_precision || 'NO_DETECTADA').toUpperCase();
        const trustedDate = isTrustedFacebookExportDate(item);
        const publicationUrl = scope === 'PUBLICACION' ? (item.permalink || item.post_url || null) : null;
        const nativeContentUrl = scope === 'MULTIMEDIA' ? (item.permalink || item.content_url || null) : (item.content_url || null);
        const mediaUrls = Array.isArray(item.media_urls) ? item.media_urls.filter(Boolean) : [];
        const contentUrl = nativeContentUrl || mediaUrls[0] || null;
        const originUrl = publicationUrl || contentUrl || null;
        const publicationId = scope === 'PUBLICACION' ? (item.native_id || null) : null;
        const mediaId = scope === 'MULTIMEDIA' ? (item.native_id || null) : null;
        const stableDerivedId = item.content_signature || (quality === 'DERIVADO' ? item.id : null);
        const sourceIdentifier = publicationId
            || mediaId
            || stableDerivedId
            || item.source_locator_id
            || item.id
            || null;
        const hasStableIdentifier = Boolean(sourceIdentifier);
        const hasAuthor = Boolean(item.author_name && item.author_slug);
        const hasContent = Boolean(item.text) || Number(item.media_count || 0) > 0;
        const qualityIssues = [];
        if (!hasStableIdentifier) qualityIssues.push('SIN_IDENTIFICADOR_ESTABLE');
        if (!trustedDate || !item.created_at) qualityIssues.push('SIN_FECHA_CONFIABLE');
        if (!hasAuthor) qualityIssues.push('SIN_AUTOR_CONFIABLE');
        if (!hasContent) qualityIssues.push('SIN_CONTENIDO');
        const dwEligible = qualityIssues.length === 0;
        const status = dwEligible ? 'LISTO_DW' : (hasContent ? 'PENDIENTE_FECHA_O_IDENTIFICADOR' : 'SOLO_STAGING');
        const dateParts = trustedDate ? facebookLocalDateParts(item.created_at, item.date_has_explicit_time === true) : { date: null, time: null };
        const isNativeContentUrl = Boolean(nativeContentUrl);
        let referenceType = 'IDENTIFICADOR_DERIVADO';
        let referenceQuality = 'DERIVADA_ESTABLE';
        if (publicationUrl) {
            referenceType = 'URL_PUBLICACION';
            referenceQuality = 'NATIVA_PUBLICACION';
        } else if (contentUrl) {
            referenceType = /\/(?:reel|videos|watch)\b/i.test(contentUrl) || String(item.media_type || '').toUpperCase() === 'VIDEO'
                ? 'URL_VIDEO'
                : 'URL_IMAGEN';
            referenceQuality = isNativeContentUrl ? 'NATIVA_MULTIMEDIA' : 'TEMPORAL_MULTIMEDIA';
        }

        const metricQuality = (value, source, confidence) => ({
            disponible: numberOrNull(value) !== null,
            origen: source || (numberOrNull(value) !== null ? 'INTERFAZ_VISIBLE' : 'NO_DISPONIBLE'),
            confianza: confidence || (numberOrNull(value) !== null ? 'MEDIA' : 'NO_DISPONIBLE')
        });

        return {
            identificador_publicacion_origen: sourceIdentifier,
            id_publicacion_facebook: publicationId,
            id_multimedia_facebook: mediaId,
            identificador_derivado: stableDerivedId,
            identificador_interno_captura: item.id || null,
            firma_contenido: item.content_signature || null,
            identificador_provisional: quality === 'PROVISIONAL',
            calidad_identificador: quality,
            origen_identificador: item.identifier_source || null,
            alcance_identificador: scope,
            nivel_vinculacion_origen: publicationUrl
                ? 'PUBLICACION_DIRECTA'
                : (contentUrl ? 'MULTIMEDIA_REPRESENTATIVA' : 'IDENTIFICADOR_DERIVADO'),
            estado_calidad_registro: status,
            problemas_calidad: qualityIssues,
            apto_para_dw: dwEligible,
            motivo_no_apto_dw: dwEligible ? null : qualityIssues.join('|'),
            url_origen: originUrl,
            url_publicacion: publicationUrl,
            url_contenido: contentUrl,
            url_contenidos_adicionales: mediaUrls.filter(url => url !== contentUrl),
            tipo_url_origen: referenceType,
            calidad_url: referenceQuality,
            es_url_publicacion_directa: Boolean(publicationUrl),
            nota_url_origen: publicationUrl
                ? 'Permalink directo de la publicación.'
                : (contentUrl
                    ? 'Facebook no expuso el permalink exterior; se conserva una URL representativa del contenido multimedia.'
                    : 'La interfaz no expuso una URL; el registro se vincula mediante un identificador derivado estable.'),
            tipo_contenido: item.post_type || 'PUBLICACION',
            autor_nombre: item.author_name || null,
            autor_usuario: item.author_slug || null,
            autor_url: item.author_url || null,
            autor_origen_deteccion: item.author_source || null,
            fecha_publicacion: trustedDate ? toIsoOrNull(item.created_at) : null,
            fecha_publicacion_fecha: dateParts.date,
            fecha_analitica: dateParts.date,
            fecha_publicacion_visual: trustedDate ? facebookVisualDate(item.created_at) : null,
            hora_publicacion: item.date_has_explicit_time === true ? dateParts.time : null,
            zona_horaria: item.date_timezone || null,
            fecha_precision: datePrecision,
            fecha_es_estimada: item.date_is_estimated === true,
            fecha_confianza: item.date_confidence || (trustedDate ? 'ALTA' : 'NO_DISPONIBLE'),
            fecha_intervalo_desde: toIsoOrNull(item.date_interval_from),
            fecha_intervalo_hasta: toIsoOrNull(item.date_interval_to),
            metodo_calculo_fecha: datePrecision === 'RELATIVA_CONFIABLE'
                ? 'CALCULADA_DESDE_FECHA_HORA_OBSERVACION'
                : (datePrecision === 'INFERIDA_POR_ORDEN'
                    ? 'INTERPOLADA_ENTRE_PUBLICACIONES_VECINAS'
                    : (datePrecision === 'INFERIDA_POR_LIMITE'
                        ? 'CALCULADA_CON_ORDEN_Y_LIMITE_DEL_PERIODO'
                        : (datePrecision === 'FECHA_CAPTURA_REFERENCIAL'
                            ? 'FECHA_DE_CAPTURA_COMO_REFERENCIA'
                            : (trustedDate ? 'LEIDA_DESDE_ENCABEZADO_FACEBOOK' : 'NO_DISPONIBLE')))),
            fecha_raw: item.date_raw || null,
            fecha_visible_raw: item.date_visible_raw || null,
            fecha_tooltip_raw: item.date_tooltip_raw || null,
            fecha_icono_privacidad: item.date_privacy_title || null,
            fecha_referencia_calculo: item.date_reference_at || null,
            fecha_origen_deteccion: item.date_source || null,
            fecha_id_aria: item.date_aria_labelledby_id || null,
            fecha_nivel_contenedor_acciones: numberOrNull(item.date_action_scope_level),
            fecha_etiqueta_menu_acciones: item.date_action_menu_label || null,
            orden_feed: numberOrNull(item.feed_order),
            evaluacion_periodo: trustedDate ? 'DENTRO_PERIODO_SOLICITADO' : 'NO_DETERMINABLE_SIN_FECHA',
            cuerpo: item.text || '',
            es_publicacion_propia: item.is_own_publication !== false,
            es_contenido_compartido: item.is_shared_content === true,
            metricas_atribuibles_cuenta: item.metrics_attributable_to_account !== false,
            es_publicacion_fijada: item.is_pinned === true,
            audiencia: item.audience || null,
            metricas: {
                reacciones_total: numberOrNull(item.reactions_count),
                comentarios_total: numberOrNull(item.comments_count),
                compartidos_total: numberOrNull(item.shares_count),
                vistas_total: Number(item.views_observed_count || 0) > 0 ? numberOrNull(item.views_count) : null,
                alcance_total: null,
                impresiones_total: null,
                guardados_total: null
            },
            // Evidencia correspondiente al valor máximo guardado en metricas.
            // No se utiliza para cálculos del DW.
            metricas_raw: {
                reacciones_total: item.reactions_raw || null,
                comentarios_total: item.comments_raw || null,
                compartidos_total: item.shares_raw || null,
                vistas_total: item.views_raw || null,
                desglose_reacciones: item.reaction_breakdown_raw || null
            },
            metricas_raw_primera_observacion: {
                reacciones_total: item.reactions_first_raw || null,
                comentarios_total: item.comments_first_raw || null,
                compartidos_total: item.shares_first_raw || null,
                vistas_total: item.views_first_raw || null,
                desglose_reacciones: item.reaction_breakdown_first_raw || null
            },
            metricas_raw_ultima_observacion: {
                reacciones_total: item.reactions_last_raw || null,
                comentarios_total: item.comments_last_raw || null,
                compartidos_total: item.shares_last_raw || null,
                vistas_total: item.views_last_raw || null,
                desglose_reacciones: item.reaction_breakdown_last_raw || null
            },
            validacion_desglose_reacciones: (() => {
                const totalReportado = numberOrNull(item.reactions_count);
                const sumaVisible = reactionBreakdownVisibleTotal(item.reaction_breakdown_raw);
                return {
                    total_reportado: totalReportado,
                    suma_desglose_visible: sumaVisible,
                    coincide: totalReportado !== null && sumaVisible !== null ? totalReportado === sumaVisible : null,
                    desglose_completo: totalReportado !== null && sumaVisible !== null ? totalReportado === sumaVisible : false
                };
            })(),
            metricas_calidad: {
                reacciones: metricQuality(item.reactions_count, item.reactions_source, item.reactions_confidence),
                comentarios: metricQuality(item.comments_count, item.comments_source, item.comments_confidence),
                compartidos: metricQuality(item.shares_count, item.shares_source, item.shares_confidence),
                vistas: Number(item.views_observed_count || 0) > 0 ? metricQuality(item.views_count, item.views_source, item.views_confidence) : metricQuality(null, 'NO_DISPONIBLE', 'NO_DISPONIBLE'),
                alcance: { disponible: false, origen: 'NO_VISIBLE_EN_INTERFAZ_PUBLICA', confianza: 'NO_DISPONIBLE' },
                impresiones: { disponible: false, origen: 'NO_VISIBLE_EN_INTERFAZ_PUBLICA', confianza: 'NO_DISPONIBLE' },
                guardados: { disponible: false, origen: 'NO_VISIBLE_EN_INTERFAZ_PUBLICA', confianza: 'NO_DISPONIBLE' }
            },
            estado_observacion_dom: item.metrics_zone_observed === true ? 'COMPLETA' : 'PARCIAL',
            encabezado_observado: true,
            contenido_observado: Boolean(item.text) || Number(item.media_count || 0) > 0,
            zona_metricas_observada: item.metrics_zone_observed === true,
            zona_metricas_visible_en_alguna_observacion: item.metrics_zone_visible === true,
            metricas_observacion: {
                reacciones: {
                    primer_valor: numberOrNull(item.reactions_first_value),
                    raw_primer_valor: item.reactions_first_raw || null,
                    valor_maximo: numberOrNull(item.reactions_count),
                    raw_valor_maximo: item.reactions_raw || null,
                    ultimo_valor_observado: numberOrNull(item.reactions_last_value),
                    raw_ultimo_valor_observado: item.reactions_last_raw || null,
                    observaciones_con_valor: Math.max(0, Number(item.reactions_observed_count || 0))
                },
                comentarios: {
                    primer_valor: numberOrNull(item.comments_first_value),
                    raw_primer_valor: item.comments_first_raw || null,
                    valor_maximo: numberOrNull(item.comments_count),
                    raw_valor_maximo: item.comments_raw || null,
                    ultimo_valor_observado: numberOrNull(item.comments_last_value),
                    raw_ultimo_valor_observado: item.comments_last_raw || null,
                    observaciones_con_valor: Math.max(0, Number(item.comments_observed_count || 0))
                },
                compartidos: {
                    primer_valor: numberOrNull(item.shares_first_value),
                    raw_primer_valor: item.shares_first_raw || null,
                    valor_maximo: numberOrNull(item.shares_count),
                    raw_valor_maximo: item.shares_raw || null,
                    ultimo_valor_observado: numberOrNull(item.shares_last_value),
                    raw_ultimo_valor_observado: item.shares_last_raw || null,
                    observaciones_con_valor: Math.max(0, Number(item.shares_observed_count || 0))
                },
                vistas: {
                    primer_valor: numberOrNull(item.views_first_value),
                    raw_primer_valor: item.views_first_raw || null,
                    valor_maximo: Number(item.views_observed_count || 0) > 0 ? numberOrNull(item.views_count) : null,
                    raw_valor_maximo: item.views_raw || null,
                    ultimo_valor_observado: numberOrNull(item.views_last_value),
                    raw_ultimo_valor_observado: item.views_last_raw || null,
                    observaciones_con_valor: Math.max(0, Number(item.views_observed_count || 0))
                }
            },
            multimedia: {
                tipo: item.media_type || 'NINGUNO',
                cantidad: numberOrNull(item.media_count) || 0,
                url_representativa: contentUrl,
                urls: mediaUrls,
                identificadores_estables: Array.isArray(item.media_asset_ids) ? item.media_asset_ids : []
            },
            enlaces_externos: Array.isArray(item.external_links) ? item.external_links : [],
            observaciones_fusionadas: Math.max(1, Number(item.observation_count || 1)),
            origen_metricas: item.source_method || 'FACEBOOK_DOM_VISIBLE_V9',
            fecha_observacion: toIsoOrNull(item.scraped_at) || new Date().toISOString()
        };
    }

    function buildFacebookCaptureSummary(items, options = {}) {
        const reason = options.captureResult?.reason || null;
        const requestedPeriod = options.captureResult?.capturePeriod || options.capturePeriod || 'unlimited';
        const reachedEnd = reason === 'END_REACHED';
        const reachedFirstTen = requestedPeriod === 'first_10'
            && reason === 'FIRST_10_REACHED'
            && (items || []).length >= 10;
        const reachedDateWindow = reason === 'DATE_WINDOW_REACHED';
        const reachedPeriod = reachedFirstTen || reachedDateWindow;
        const coverageReached = reachedEnd || reachedPeriod;
        const readyCount = (items || []).filter(item => item.estado_calidad_registro === 'LISTO_DW').length;
        const pendingCount = Math.max(0, (items || []).length - readyCount);
        const complete = coverageReached && pendingCount === 0;
        const typeCounts = {};
        const ids = new Set();
        let firstDate = null;
        let lastDate = null;
        let own = 0;
        let shared = 0;
        let attributable = 0;
        for (const item of items || []) {
            const type = item.tipo_contenido || 'PUBLICACION';
            typeCounts[type] = (typeCounts[type] || 0) + 1;
            if (item.identificador_publicacion_origen) ids.add(String(item.identificador_publicacion_origen));
            if (item.es_publicacion_propia) own++;
            if (item.es_contenido_compartido) shared++;
            if (item.metricas_atribuibles_cuenta) attributable++;
            const date = item.fecha_publicacion;
            if (date && (!firstDate || date < firstDate)) firstDate = date;
            if (date && (!lastDate || date > lastDate)) lastDate = date;
        }
        const finalPosition = options.captureResult?.finalPosition || {};
        return {
            total_registros_capturados: items.length,
            total_registros_exportacion: readyCount,
            publicaciones_en_arreglo_principal: readyCount,
            publicaciones_pendientes_calidad: pendingCount,
            registros_en_archivo: items.length,
            identificadores_unicos_en_archivo: ids.size,
            publicaciones_propias_en_archivo: own,
            contenidos_compartidos_en_archivo: shared,
            publicaciones_con_metricas_atribuibles: attributable,
            primera_fecha_recuperada: firstDate,
            ultima_fecha_recuperada: lastDate,
            distribucion_tipos: typeCounts,
            parte_numero: numberOrNull(options.partNumber) || 1,
            total_partes: numberOrNull(options.partCount) || 1,
            captura_llego_al_final: reachedEnd,
            captura_llego_al_periodo_solicitado: reachedPeriod,
            cobertura_solicitada_alcanzada: coverageReached,
            captura_completa: complete,
            estado_captura: complete
                ? (reachedDateWindow ? 'COMPLETA_PARA_EL_PERIODO' : 'COMPLETA')
                : (coverageReached
                    ? ((numberOrNull(options.captureResult?.includedWithoutTrustedDate) || 0) > 0
                        ? 'PARCIAL_POR_FECHAS_NO_RECUPERADAS'
                        : 'PARCIAL_POR_CALIDAD')
                    : 'INCOMPLETA'),
            motivo_finalizacion_captura: reason,
            periodo_extraccion: options.captureResult?.capturePeriod || 'unlimited',
            fecha_referencia_periodo: options.captureResult?.periodReferenceDate || null,
            fecha_limite_periodo: options.captureResult?.periodCutoffDate || null,
            registros_excluidos_anteriores_al_periodo: numberOrNull(options.captureResult?.excludedBeforePeriod) || 0,
            registros_sin_fecha_excluidos: numberOrNull(options.captureResult?.excludedWithoutDate) || 0,
            registros_sin_fecha_confiable_incluidos: numberOrNull(options.captureResult?.includedWithoutTrustedDate) || 0,
            fechas_inferidas_por_orden: numberOrNull(options.captureResult?.inferredByOrder) || 0,
            fechas_inferidas_por_limite: numberOrNull(options.captureResult?.inferredByLimit) || 0,
            fechas_asignadas_desde_captura: numberOrNull(options.captureResult?.captureDateFallback) || 0,
            registros_originalmente_sin_fecha: numberOrNull(options.captureResult?.originalMissingDates) || 0,
            registros_excluidos_posteriores_a_referencia: numberOrNull(options.captureResult?.excludedAfterReference) || 0,
            ciclos_desplazamiento: numberOrNull(options.captureResult?.cycles),
            ciclos_sin_nuevas_publicaciones: numberOrNull(options.captureResult?.stagnantCycles),
            confirmaciones_de_final: numberOrNull(options.captureResult?.endConfirmations),
            registros_consolidados_detectados_antes_de_filtros: numberOrNull(options.captureResult?.rawUniquePosts),
            registros_fusionados_en_consolidacion_final: Math.max(
                0,
                (numberOrNull(options.captureResult?.rawUniquePosts) || items.length)
                - (numberOrNull(options.captureResult?.excludedBeforePeriod) || 0)
                - (numberOrNull(options.captureResult?.excludedAfterReference) || 0)
                - items.length
            ),
            observaciones_dom: numberOrNull(options.captureResult?.rawObservations),
            duplicados_fusionados_durante_captura: numberOrNull(options.captureResult?.duplicatesMerged),
            modo_recorrido: options.captureResult?.traversalMode || null,
            zoom_original: numberOrNull(options.captureResult?.originalZoom),
            zoom_captura: numberOrNull(options.captureResult?.captureZoom),
            zoom_restaurado: options.captureResult?.zoomRestored === true,
            tarjetas_procesadas_una_pasada: numberOrNull(options.captureResult?.cardsProcessed),
            menus_acciones_procesados: numberOrNull(options.captureResult?.actionMenusProcessed),
            tarjetas_con_fecha_en_recorrido: numberOrNull(options.captureResult?.cardsWithDate),
            tarjetas_sin_fecha_en_recorrido: numberOrNull(options.captureResult?.cardsWithoutDate),
            tarjetas_con_zona_metricas: numberOrNull(options.captureResult?.cardsWithMetricZone),
            tarjetas_con_encabezado_visible: numberOrNull(options.captureResult?.cardsWithHeaderVisible),
            tarjetas_sin_encabezado_visible: numberOrNull(options.captureResult?.cardsWithoutHeaderVisible),
            tarjetas_completas_en_ventana: numberOrNull(options.captureResult?.cardsFullyVisible),
            tarjetas_con_reintento_local_fecha: numberOrNull(options.captureResult?.cardsWithLocalDateRetry),
            desplazamientos_locales_hasta_metricas: numberOrNull(options.captureResult?.localMetricFallbacks),
            intentos_tooltip_fecha_relativa: numberOrNull(options.captureResult?.relativeDateTooltipAttempts),
            fechas_relativas_resueltas_por_tooltip: numberOrNull(options.captureResult?.relativeDateTooltipResolved),
            enlaces_fecha_por_icono_privacidad: numberOrNull(options.captureResult?.privacyDateLinksFound),
            intentos_tooltip_privacidad: numberOrNull(options.captureResult?.privacyTooltipAttempts),
            fechas_exactas_resueltas_por_tooltip_privacidad: numberOrNull(options.captureResult?.privacyTooltipResolved),
            publicaciones_expandidas: numberOrNull(options.captureResult?.expandedCards),
            sondeos_carga_siguiente_tarjeta: numberOrNull(options.captureResult?.loadProbes),
            posicion_final_scroll: numberOrNull(finalPosition.scrollTop),
            altura_final_pagina: numberOrNull(finalPosition.pageHeight),
            altura_ventana: numberOrNull(finalPosition.viewportHeight),
            distancia_final_al_fondo: numberOrNull(finalPosition.distanceToBottom)
        };
    }

    function buildFacebookQualitySummary(items, options = {}) {
        const quality = { NATIVO: 0, DERIVADO: 0, PROVISIONAL: 0 };
        const dates = { EXACTA: 0, APROXIMADA_CALENDARIO: 0, RELATIVA_CONFIABLE: 0, INFERIDA_POR_ORDEN: 0, INFERIDA_POR_LIMITE: 0, FECHA_CAPTURA_REFERENCIAL: 0, NO_DETECTADA: 0 };
        const nativeScope = { PUBLICACION: 0, MULTIMEDIA: 0 };
        const metrics = { reacciones: 0, comentarios: 0, compartidos: 0, vistas: 0, alcance: 0, impresiones: 0 };
        const statuses = { LISTO_DW: 0, PENDIENTE_FECHA_O_IDENTIFICADOR: 0, SOLO_STAGING: 0 };
        let observations = 0;
        let withPostUrl = 0;
        let withContentUrlOnly = 0;
        let withoutAnyUrl = 0;
        let withPostUrlAndTrustedDate = 0;
        let targetAuthor = 0;
        let invalidAuthor = 0;
        let metricsZoneObserved = 0;
        let metricsZoneNotObserved = 0;

        for (const item of items || []) {
            const q = String(item.calidad_identificador || 'PROVISIONAL').toUpperCase();
            if (Object.prototype.hasOwnProperty.call(quality, q)) quality[q] += 1;
            const scope = String(item.alcance_identificador || 'PROVISIONAL').toUpperCase();
            if (q === 'NATIVO' && Object.prototype.hasOwnProperty.call(nativeScope, scope)) nativeScope[scope] += 1;
            const d = String(item.fecha_precision || 'NO_DETECTADA').toUpperCase();
            if (Object.prototype.hasOwnProperty.call(dates, d)) dates[d] += 1;
            else dates.NO_DETECTADA += 1;
            const status = String(item.estado_calidad_registro || (item.apto_para_dw ? 'LISTO_DW' : 'PENDIENTE_FECHA_O_IDENTIFICADOR')).toUpperCase();
            if (Object.prototype.hasOwnProperty.call(statuses, status)) statuses[status] += 1;
            observations += Math.max(1, Number(item.observaciones_fusionadas || 1));

            if (item.url_publicacion) withPostUrl += 1;
            else if (item.url_contenido) withContentUrlOnly += 1;
            else withoutAnyUrl += 1;
            if (item.url_publicacion && item.fecha_publicacion) withPostUrlAndTrustedDate += 1;

            const authorName = String(item.autor_nombre || '');
            const authorSlug = String(item.autor_usuario || '');
            if (authorSlug && authorSlug === String(options.username || '').replace(/^@/, '')) targetAuthor += 1;
            if (!authorName || !authorSlug || /^(?:\d+\s*(?:días?|sem|semanas?|h|horas?)|photo|reel)$/i.test(authorName)) invalidAuthor += 1;


            if (item.metricas?.reacciones_total !== null) metrics.reacciones += 1;
            if (item.metricas?.comentarios_total !== null) metrics.comentarios += 1;
            if (item.metricas?.compartidos_total !== null) metrics.compartidos += 1;
            if (item.metricas?.vistas_total !== null) metrics.vistas += 1;
            if (item.metricas?.alcance_total !== null) metrics.alcance += 1;
            if (item.metricas?.impresiones_total !== null) metrics.impresiones += 1;
            if (item.zona_metricas_observada === true) metricsZoneObserved += 1;
            else metricsZoneNotObserved += 1;
        }
        const totalCaptureObservations = numberOrNull(options.captureResult?.rawObservations) || observations;
        return {
            observaciones_dom_en_archivo: observations,
            observaciones_dom_totales_captura: totalCaptureObservations,
            publicaciones_consolidadas: items.length,
            registros_descartados_por_duplicado: Math.max(0, observations - items.length),
            identificadores: {
                nativos: quality.NATIVO,
                derivados: quality.DERIVADO,
                provisionales: quality.PROVISIONAL,
                nativos_de_publicacion: nativeScope.PUBLICACION,
                nativos_de_multimedia: nativeScope.MULTIMEDIA
            },
            urls: {
                con_url_publicacion: withPostUrl,
                solo_url_multimedia: withContentUrlOnly,
                sin_url: withoutAnyUrl,
                con_url_publicacion_y_fecha_confiable: withPostUrlAndTrustedDate
            },
            fechas: {
                exactas: dates.EXACTA,
                aproximadas_calendario: dates.APROXIMADA_CALENDARIO,
                relativas_confiables: dates.RELATIVA_CONFIABLE,
                inferidas_por_orden: dates.INFERIDA_POR_ORDEN,
                inferidas_por_limite: dates.INFERIDA_POR_LIMITE,
                fecha_captura_referencial: dates.FECHA_CAPTURA_REFERENCIAL,
                no_detectadas: dates.NO_DETECTADA,
                cobertura_fecha: items.length - dates.NO_DETECTADA,
                porcentaje_cobertura: items.length ? Number((((items.length - dates.NO_DETECTADA) / items.length) * 100).toFixed(2)) : 0
            },
            autores: {
                asociados_cuenta_objetivo: targetAuthor,
                invalidos_o_no_detectados: invalidAuthor
            },
            vinculacion_origen: {
                con_permalink_publicacion: withPostUrl,
                con_url_multimedia_representativa: withContentUrlOnly,
                solo_identificador_derivado: withoutAnyUrl,
                sin_procesamiento_asistido: true
            },
            cobertura_metricas: {
                con_reacciones: metrics.reacciones,
                con_comentarios: metrics.comentarios,
                con_compartidos: metrics.compartidos,
                con_vistas: metrics.vistas,
                con_alcance: metrics.alcance,
                con_impresiones: metrics.impresiones,
                zona_metricas_observada: metricsZoneObserved,
                zona_metricas_no_observada: metricsZoneNotObserved
            },
            aptitud_carga: {
                aptas_dw: statuses.LISTO_DW,
                pendientes_fecha_o_identificador: statuses.PENDIENTE_FECHA_O_IDENTIFICADOR,
                solo_staging: statuses.SOLO_STAGING
            },
            calidad_integral_completa: statuses.LISTO_DW === items.length,
            advertencias: [
                'LISTO_DW requiere fecha confiable, autor, contenido e identificador estable; la referencia puede ser un permalink, una URL multimedia o una firma derivada.',
                'Cuando Facebook no expone el permalink exterior, url_origen utiliza una referencia multimedia representativa y conserva el tipo y la calidad de esa URL.',
                'Facebook no muestra alcance ni impresiones en la interfaz pública de este perfil.',
                'No se infieren fechas por posición ni por límite. Los registros sin fecha directa se conservan en publicaciones_pendientes_fecha.',
                'Cada tarjeta se procesa en una sola pasada con una lectura de confirmación local; se conserva el valor máximo visible sin regresar a publicaciones anteriores.',
                'Comentarios y compartidos solo se guardan cuando existe un contador explícito.',
                'Las fechas mencionadas dentro del cuerpo y las fechas de comentarios no se aceptan como fecha de publicación.',
            ]
        };
    }

    function buildFacebookJsonPayload(allItems, options = {}) {
        const exportedAt = options.exportedAt ? new Date(options.exportedAt) : new Date();
        const profile = options.profile || {};
        const account = String(options.username || profile.screenName || 'unknown').replace(/^@/, '');
        const consolidated = consolidateFacebookItems(allItems || []);
        const posts = consolidated.map(normalizeFacebookPostForExport);
        const readyPosts = posts.filter(item => item.estado_calidad_registro === 'LISTO_DW');
        const pendingPosts = posts.filter(item => item.estado_calidad_registro !== 'LISTO_DW');
        const friends = numberOrNull(profile.friendsCount);
        const followers = numberOrNull(profile.followersCount);
        const primaryCommunity = friends !== null ? 'AMIGOS' : (followers !== null ? 'SEGUIDORES' : 'NO_DISPONIBLE');
        return {
            metadata_captura: {
                plataforma: 'FACEBOOK',
                cuenta_objetivo: account,
                metodo_extraccion: 'CAPTURA_ASISTIDA_SCROLL_NAVEGADOR',
                herramienta: 'CAPTURADOR_BI_UCV',
                version_extension: chrome.runtime?.getManifest?.().version || '1.5.26',
                fecha_inicio_captura: toIsoOrNull(options.startedAt),
                fecha_fin_captura: toIsoOrNull(options.completedAt) || exportedAt.toISOString(),
                fecha_exportacion: exportedAt.toISOString(),
                procesamiento: 'LOCAL_EN_NAVEGADOR',
                metricas_operativas: 'VALORES_NUMERICOS',
                metricas_raw: 'EVIDENCIA_AUXILIAR_NO_DESTINADA_A_CALCULOS',
                periodo_extraccion: options.captureResult?.capturePeriod || options.capturePeriod || 'unlimited',
                periodo_calculado_desde: (options.captureResult?.capturePeriod || options.capturePeriod) === 'first_10'
                    ? 'ORDEN_VISIBLE_INICIAL'
                    : 'PUBLICACION_MAS_RECIENTE_RECUPERADA',
                modo_recorrido: options.captureResult?.traversalMode || 'ONE_PASS_PRIVACY_TOOLTIP_V26',
                zoom_temporal_captura: numberOrNull(options.captureResult?.captureZoom)
            },
            perfil: {
                identificador_origen: profile.id || null,
                nombre: profile.name || account,
                usuario: account,
                url_perfil: profile.url || `https://www.facebook.com/${account}`,
                tipo_cuenta_detectado: profile.accountType || 'PERFIL',
                imagen_perfil_url: profile.profileImageUrl || null,
                origen_datos: profile.source || 'PERFIL_FACEBOOK_INTERFAZ_VISIBLE'
            },
            comunidad: {
                tipo_comunidad_principal: primaryCommunity,
                fecha_medicion: exportedAt.toISOString(),
                total_amigos: friends,
                total_amigos_raw: profile.friendsCountRaw || null,
                total_seguidores: followers,
                total_seguidores_raw: profile.followersCountRaw || null,
                origen_medicion: profile.source || 'PERFIL_FACEBOOK_INTERFAZ_VISIBLE',
                nota: 'Amigos y seguidores se conservan por separado y no se suman automáticamente.'
            },
            resumen_captura: buildFacebookCaptureSummary(posts, options),
            calidad_captura: buildFacebookQualitySummary(posts, options),
            nota_estructura: 'El arreglo publicaciones contiene solo registros con fecha leída de la línea temporal situada debajo del autor. Los registros sin fecha se conservan en publicaciones_pendientes_fecha y no se infieren.',
            publicaciones: readyPosts,
            publicaciones_pendientes_fecha: pendingPosts
        };
    }

    function instagramCaracasDateParts(value) {
        const date = new Date(value || 0);
        if (!Number.isFinite(date.getTime())) return { date: null, time: null };
        try {
            const parts = new Intl.DateTimeFormat('en-CA', {
                timeZone: 'America/Caracas',
                year: 'numeric', month: '2-digit', day: '2-digit',
                hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
            }).formatToParts(date);
            const map = Object.fromEntries(parts.map(part => [part.type, part.value]));
            return {
                date: `${map.year}-${map.month}-${map.day}`,
                time: `${map.hour}:${map.minute}:${map.second}`
            };
        } catch (_) {
            return { date: date.toISOString().slice(0, 10), time: date.toISOString().slice(11, 19) };
        }
    }

    function instagramDayKeyToDate(value) {
        const token = String(Math.trunc(Number(value || 0)));
        return /^\d{8}$/.test(token)
            ? `${token.slice(0, 4)}-${token.slice(4, 6)}-${token.slice(6, 8)}`
            : null;
    }

    function normalizeInstagramUsernameForExport(value) {
        return String(value || '').trim().replace(/^@/, '').toLowerCase();
    }

    function normalizeInstagramMentionsForExport(value, caption = '') {
        const source = String(caption || '');
        const result = [];
        const seen = new Set();
        const regex = /@([A-Za-z0-9._]{1,30})/g;
        let match;
        while ((match = regex.exec(source)) !== null) {
            const previous = match.index > 0 ? source[match.index - 1] : '';
            if (previous && /[A-Za-z0-9._%+-]/.test(previous)) continue;
            const username = match[1].replace(/\.+$/, '');
            if (!username || username.length > 30 || username.includes('..')) continue;
            const key = username.toLowerCase();
            if (!seen.has(key)) {
                seen.add(key);
                result.push(username);
            }
        }
        return result;
    }

    function instagramMediaUrlStableKey(value) {
        try {
            const url = new URL(String(value || ''), 'https://www.instagram.com/');
            const cacheKey = url.searchParams.get('ig_cache_key');
            if (cacheKey) return `ig_cache:${cacheKey.replace(/=+$/g, '')}`;
            const filename = decodeURIComponent(url.pathname.split('/').pop() || '');
            const mediaId = filename.match(/^(\d+_\d+_\d+)_n(?:\.|$)/i)?.[1]
                || filename.match(/^(\d{8,})/i)?.[1];
            if (mediaId) return `media:${mediaId}`;
            return `path:${url.pathname.replace(/\.(?:jpe?g|webp|heic|png|mp4)$/i, '')}`;
        } catch (_) {
            return `raw:${String(value || '').split('?')[0]}`;
        }
    }

    function instagramMediaUrlQualityScore(value) {
        const raw = String(value || '');
        let score = 0;
        if (/\.mp4(?:\?|$)/i.test(raw)) score += 100000;
        if (!/[?&]stp=/i.test(raw)) score += 10000;
        for (const match of raw.matchAll(/(?:^|[_?&])(?:s|p|cstp=mx|ctp=s)(\d{2,5})(?:x(\d{2,5}))?/gi)) {
            score = Math.max(score, Number(match[1] || 0) * Number(match[2] || match[1] || 0));
        }
        return score;
    }

    function dedupeInstagramMediaUrls(values) {
        const selected = new Map();
        for (const value of values || []) {
            const url = String(value || '').trim();
            if (!url || /^blob:/i.test(url)) continue;
            const key = instagramMediaUrlStableKey(url);
            const previous = selected.get(key);
            if (!previous || instagramMediaUrlQualityScore(url) > instagramMediaUrlQualityScore(previous)) selected.set(key, url);
        }
        return [...selected.values()];
    }

    function normalizeInstagramPostForExport(item = {}, targetUsername = '') {
        const shortcode = String(item.shortcode || item.id || '').trim();
        const createdAt = toIsoOrNull(item.created_at);
        const dateParts = instagramCaracasDateParts(createdAt);
        const authorUsername = String(item.author_username || targetUsername || '').replace(/^@/, '');
        const target = normalizeInstagramUsernameForExport(item.target_username || targetUsername);
        const author = normalizeInstagramUsernameForExport(authorUsername);
        const collaborators = [...new Set((Array.isArray(item.collaborator_usernames) ? item.collaborator_usernames : [])
            .map(normalizeInstagramUsernameForExport)
            .filter(Boolean))];
        const targetIsAuthor = Boolean(target && author === target);
        const targetIsCollaborator = Boolean(target && collaborators.includes(target));
        const appearsInTargetGrid = item.from_target_profile_grid !== false;
        const collaborative = item.is_collaboration === true
            || collaborators.some(username => username !== author)
            || (!targetIsAuthor && appearsInTargetGrid);
        const targetParticipates = item.target_account_participates === true
            || targetIsAuthor
            || targetIsCollaborator
            || (!targetIsAuthor && appearsInTargetGrid);
        const linkClassification = item.account_link_classification
            || (targetIsAuthor
                ? (collaborative ? 'PROPIA_COLABORATIVA' : 'PROPIA_EXCLUSIVA')
                : (targetParticipates && collaborative ? 'COLABORACION_PUBLICADA_POR_TERCERO' : 'AJENA_NO_CLASIFICADA'));
        const mediaUrls = dedupeInstagramMediaUrls(Array.isArray(item.media_urls) ? item.media_urls : []);
        const contentExists = Boolean(item.caption) || Number(item.media_count || 0) > 0;
        const issues = [];
        if (!shortcode) issues.push('SIN_SHORTCODE');
        if (!createdAt) issues.push('SIN_FECHA_CONFIABLE');
        if (!authorUsername) issues.push('SIN_AUTOR_CONFIABLE');
        if (!contentExists) issues.push('SIN_CONTENIDO');
        const eligible = issues.length === 0;
        const fallbackSegment = String(item.post_type || '').toUpperCase() === 'REEL' ? 'reel' : 'p';
        const fallbackPermalink = shortcode ? `https://www.instagram.com/${fallbackSegment}/${shortcode}/` : null;
        const metrics = {
            me_gusta_total: numberOrNull(item.like_count),
            comentarios_total: numberOrNull(item.comment_count),
            visualizaciones_total: numberOrNull(item.view_count),
            reproducciones_total: numberOrNull(item.play_count),
            compartidos_total: numberOrNull(item.share_count),
            guardados_total: numberOrNull(item.save_count),
            alcance_total: null,
            impresiones_total: null
        };
        return {
            identificador_publicacion_origen: shortcode || null,
            id_multimedia_instagram: item.media_id || null,
            shortcode: shortcode || null,
            identificador_interno_captura: shortcode ? `instagram:${shortcode}` : null,
            estado_calidad_registro: eligible ? 'LISTO_DW' : (contentExists ? 'PENDIENTE_FECHA_O_IDENTIFICADOR' : 'SOLO_STAGING'),
            problemas_calidad: issues,
            apto_para_dw: eligible,
            motivo_no_apto_dw: eligible ? null : issues.join('|'),
            url_origen: item.permalink || fallbackPermalink,
            url_publicacion: item.permalink || fallbackPermalink,
            tipo_contenido: item.post_type || 'PUBLICACION',
            autor_nombre: item.author_name || authorUsername || null,
            autor_usuario: authorUsername || null,
            autor_url: item.author_url || (authorUsername ? `https://www.instagram.com/${authorUsername}/` : null),
            fecha_publicacion: createdAt,
            fecha_publicacion_fecha: dateParts.date,
            fecha_analitica: dateParts.date,
            fecha_publicacion_visual: dateParts.date ? dateParts.date.split('-').reverse().join('/') : null,
            hora_publicacion: dateParts.time,
            zona_horaria: 'America/Caracas',
            fecha_precision: createdAt ? 'EXACTA' : 'NO_DETECTADA',
            fecha_confianza: createdAt ? 'ALTA' : 'NO_DISPONIBLE',
            fecha_raw: item.date_raw || null,
            orden_feed: numberOrNull(item.feed_order),
            es_publicacion_fijada: item.is_pinned === true,
            es_publicacion_propia: targetIsAuthor,
            es_publicacion_colaborativa: collaborative,
            cuenta_objetivo_participa: targetParticipates,
            metricas_atribuibles_cuenta: targetParticipates,
            produccion_exclusiva_cuenta: targetIsAuthor && !collaborative,
            clasificacion_vinculacion_cuenta: linkClassification,
            origen_clasificacion_vinculacion: item.account_link_classification_source || null,
            colaboradores_usuarios: collaborators,
            cuerpo: item.caption || '',
            hashtags: Array.isArray(item.hashtags) ? [...new Set(item.hashtags.filter(Boolean))] : [],
            menciones: normalizeInstagramMentionsForExport(item.mentions, item.caption),
            ubicacion: item.location_name || null,
            multimedia: {
                cantidad: numberOrNull(item.media_count) || mediaUrls.length || 0,
                urls: mediaUrls,
                textos_alternativos: Array.isArray(item.media_alt_texts) ? item.media_alt_texts : []
            },
            metricas: metrics,
            metricas_raw: {
                me_gusta_total: item.metrics_raw?.like_count || null,
                comentarios_total: item.metrics_raw?.comment_count || null,
                visualizaciones_total: item.metrics_raw?.view_count || null,
                reproducciones_total: item.metrics_raw?.play_count || null,
                compartidos_total: item.metrics_raw?.share_count || null,
                guardados_total: item.metrics_raw?.save_count || null
            },
            metricas_fuente_detalle: item.metric_sources || {},
            datos_estructurados_encontrados: item.structured_data_found === true,
            superficie_captura: item.capture_surface || 'INSTAGRAM_MODAL_DOM',
            observaciones_fusionadas: Math.max(1, Number(item.observation_count || 1)),
            fecha_observacion: toIsoOrNull(item.scraped_at)
        };
    }

    function buildInstagramJsonPayload(allItems, options = {}) {
        const exportedAt = options.exportedAt ? new Date(options.exportedAt) : new Date();
        const profile = options.profile || {};
        const account = String(options.username || profile.screenName || 'unknown').replace(/^@/, '');
        const posts = (allItems || []).map(item => normalizeInstagramPostForExport(item, account));
        const ready = posts.filter(item => item.apto_para_dw);
        const pending = posts.filter(item => !item.apto_para_dw);
        const firstDate = posts.map(item => item.fecha_publicacion).filter(Boolean).sort()[0] || null;
        const lastDate = posts.map(item => item.fecha_publicacion).filter(Boolean).sort().at(-1) || null;
        const typeCounts = {};
        for (const post of posts) typeCounts[post.tipo_contenido] = (typeCounts[post.tipo_contenido] || 0) + 1;
        const reason = options.captureResult?.reason || null;
        const requestedPeriod = options.captureResult?.capturePeriod || options.capturePeriod || 'first_10';
        const firstTenComplete = requestedPeriod === 'first_10'
            && reason === 'FIRST_10_REACHED'
            && posts.length >= 10;
        const dateWindowComplete = ['last_month', 'last_3_months', 'last_year'].includes(requestedPeriod)
            && reason === 'DATE_WINDOW_REACHED';
        const fullHistoryComplete = requestedPeriod === 'unlimited' && reason === 'END_REACHED';
        const captureComplete = firstTenComplete || dateWindowComplete || fullHistoryComplete;
        return {
            metadata_captura: {
                plataforma: 'INSTAGRAM',
                cuenta_objetivo: account,
                metodo_extraccion: 'CAPTURA_ASISTIDA_NAVEGACION_MODAL',
                herramienta: 'CAPTURADOR_BI_UCV',
                version_extension: chrome.runtime?.getManifest?.().version || '1.5.32',
                fecha_inicio_captura: toIsoOrNull(options.startedAt),
                fecha_fin_captura: toIsoOrNull(options.completedAt) || exportedAt.toISOString(),
                fecha_exportacion: exportedAt.toISOString(),
                procesamiento: 'LOCAL_EN_NAVEGADOR',
                metricas_operativas: 'VALORES_NUMERICOS',
                metricas_raw: 'EVIDENCIA_AUXILIAR_NO_DESTINADA_A_CALCULOS',
                periodo_extraccion: options.captureResult?.capturePeriod || options.capturePeriod || 'first_10',
                periodo_calculado_desde: 'PUBLICACION_MAS_RECIENTE_RECUPERADA',
                modo_recorrido: 'COLA_GRID_VERIFICADA_CON_NEXT_Y_RESPALDO_DOM'
            },
            perfil: {
                identificador_origen: profile.id || `instagram:${account}`,
                nombre: profile.name || account,
                usuario: account,
                url_perfil: profile.url || `https://www.instagram.com/${account}/`,
                biografia: profile.biography || null,
                imagen_perfil_url: profile.profileImageUrl || null,
                cuenta_privada: Boolean(profile.isProtected),
                cuenta_verificada: Boolean(profile.isVerified),
                origen_datos: profile.source || 'PERFIL_INSTAGRAM_INTERFAZ_VISIBLE'
            },
            comunidad: {
                tipo_comunidad: 'SEGUIDORES',
                fecha_medicion: exportedAt.toISOString(),
                total_seguidores: numberOrNull(profile.followersCount),
                total_seguidores_raw: profile.followersCountRaw || null,
                total_seguidos: numberOrNull(profile.followingCount),
                total_seguidos_raw: profile.followingCountRaw || null,
                total_publicaciones_perfil: numberOrNull(profile.postsCount ?? profile.tweetCount),
                total_publicaciones_perfil_raw: profile.postsCountRaw || null,
                origen_medicion: profile.source || 'PERFIL_INSTAGRAM_INTERFAZ_VISIBLE'
            },
            resumen_captura: {
                total_registros_exportacion: posts.length,
                registros_en_archivo: posts.length,
                identificadores_unicos_en_archivo: new Set(posts.map(item => item.shortcode).filter(Boolean)).size,
                publicaciones_propias_en_archivo: posts.filter(item => item.es_publicacion_propia).length,
                publicaciones_colaborativas_en_archivo: posts.filter(item => item.es_publicacion_colaborativa).length,
                publicaciones_atribuibles_cuenta_en_archivo: posts.filter(item => item.metricas_atribuibles_cuenta).length,
                publicaciones_ajenas_no_clasificadas_en_archivo: posts.filter(item => !item.cuenta_objetivo_participa).length,
                publicaciones_fijadas_en_archivo: posts.filter(item => item.es_publicacion_fijada).length,
                primera_fecha_recuperada: firstDate,
                ultima_fecha_recuperada: lastDate,
                distribucion_tipos: typeCounts,
                captura_llego_al_final: requestedPeriod === 'unlimited' && reason === 'END_REACHED',
                captura_llego_al_periodo_solicitado: firstTenComplete || dateWindowComplete,
                captura_completa: captureComplete,
                estado_captura: captureComplete ? 'COMPLETA' : 'INCOMPLETA',
                motivo_finalizacion_captura: reason,
                periodo_extraccion: requestedPeriod,
                fecha_referencia_periodo: options.captureResult?.periodReferenceDate || null,
                fecha_limite_periodo: instagramDayKeyToDate(options.captureResult?.periodCutoffDayKey),
                dia_limite_periodo_clave: numberOrNull(options.captureResult?.periodCutoffDayKey),
                registros_detectados_antes_de_filtros: numberOrNull(options.captureResult?.rawUniquePosts),
                registros_excluidos_anteriores_al_periodo: numberOrNull(options.captureResult?.excludedBeforePeriod) || 0,
                registros_excluidos_posteriores_a_referencia: numberOrNull(options.captureResult?.excludedAfterReference) || 0,
                registros_sin_fecha_confiable_incluidos: numberOrNull(options.captureResult?.undatedIncludedForQualityReview) || 0,
                publicaciones_procesadas: numberOrNull(options.captureResult?.processed),
                duplicados_fusionados: numberOrNull(options.captureResult?.duplicatesMerged),
                respuestas_estructuradas_indexadas: numberOrNull(options.captureResult?.structuredPayloadsIndexed)
            },
            calidad_captura: {
                fechas: {
                    exactas: posts.filter(item => Boolean(item.fecha_publicacion)).length,
                    no_detectadas: posts.filter(item => !item.fecha_publicacion).length,
                    porcentaje_cobertura: posts.length ? Number((posts.filter(item => Boolean(item.fecha_publicacion)).length / posts.length * 100).toFixed(2)) : 0
                },
                clasificacion_vinculacion: {
                    propias_exclusivas: posts.filter(item => item.clasificacion_vinculacion_cuenta === 'PROPIA_EXCLUSIVA').length,
                    propias_colaborativas: posts.filter(item => item.clasificacion_vinculacion_cuenta === 'PROPIA_COLABORATIVA').length,
                    colaboraciones_publicadas_por_terceros: posts.filter(item => item.clasificacion_vinculacion_cuenta === 'COLABORACION_PUBLICADA_POR_TERCERO').length,
                    ajenas_no_clasificadas: posts.filter(item => item.clasificacion_vinculacion_cuenta === 'AJENA_NO_CLASIFICADA').length,
                    fijadas: posts.filter(item => item.es_publicacion_fijada).length
                },
                cobertura_metricas: {
                    con_me_gusta: posts.filter(item => item.metricas.me_gusta_total !== null).length,
                    con_comentarios: posts.filter(item => item.metricas.comentarios_total !== null).length,
                    con_visualizaciones: posts.filter(item => item.metricas.visualizaciones_total !== null).length,
                    con_reproducciones: posts.filter(item => item.metricas.reproducciones_total !== null).length,
                    con_compartidos: posts.filter(item => item.metricas.compartidos_total !== null).length,
                    con_guardados: posts.filter(item => item.metricas.guardados_total !== null).length
                },
                aptitud_carga: {
                    aptas_dw: ready.length,
                    pendientes_fecha_o_identificador: pending.filter(item => item.estado_calidad_registro === 'PENDIENTE_FECHA_O_IDENTIFICADOR').length,
                    solo_staging: pending.filter(item => item.estado_calidad_registro === 'SOLO_STAGING').length
                },
                advertencias: [
                    'Los totales se guardan solo cuando Instagram los expone en el detalle visible o en una respuesta estructurada observada pasivamente.',
                    'Los iconos de compartir y guardar no implican que exista un contador público; esos campos permanecen en null cuando no hay valor explícito.',
                    'Las publicaciones colaborativas se identifican por coautores estructurados o por un autor distinto dentro del grid principal de la cuenta objetivo; no se confunden con producción exclusiva.',
                    'Las variantes de una misma URL multimedia se deduplican mediante ig_cache_key o identificador estable del archivo.',
                    'Alcance e impresiones no están disponibles en la interfaz pública y permanecen en null.'
                ]
            },
            publicaciones: ready,
            publicaciones_pendientes_calidad: pending
        };
    }

    function ucvReportPeriodToken(options = {}) {
        const raw = String(
            options.captureResult?.capturePeriod
            || options.capturePeriod
            || ''
        ).toLowerCase();
        const map = {
            first_10: 'PRIMERAS_10',
            unlimited: 'COMPLETO',
            last_month: 'ULTIMO_MES',
            last_3_months: 'ULTIMOS_3_MESES',
            last_year: 'ULTIMO_ANO'
        };
        if (map[raw]) return map[raw];
        if (options.dateFrom || options.dateTo) return 'RANGO_FECHAS';
        return 'COMPLETO';
    }

    function ucvFilenameTimestamp(value) {
        const date = value instanceof Date ? value : new Date(value || Date.now());
        const safeDate = Number.isFinite(date.getTime()) ? date : new Date();
        const pad = number => String(number).padStart(2, '0');
        return `${safeDate.getFullYear()}-${pad(safeDate.getMonth() + 1)}-${pad(safeDate.getDate())}_${pad(safeDate.getHours())}${pad(safeDate.getMinutes())}`;
    }

    function buildUcvExportFilename(options, extension) {
        const platformValue = String(options.socialPlatform || 'x').toLowerCase();
        const platform = platformValue === 'facebook' ? 'FACEBOOK' : (platformValue === 'instagram' ? 'INSTAGRAM' : 'X');
        const period = ucvReportPeriodToken(options);
        const timestamp = ucvFilenameTimestamp(options.exportedAt || new Date());
        const part = Number(options.partCount || 1) > 1
            ? `_PARTE_${Number(options.partNumber || 1)}_DE_${Number(options.partCount || 1)}`
            : '';
        return `${platform}_${period}_${timestamp}${part}.${extension}`;
    }

    async function downloadItems(allItems, options) {
        const username = options.username || 'unknown';
        const mode = options.mode || 'posts';
        const format = options.format || 'csv';
        const isUsers = mode !== 'posts';
        let content;
        let mimeType;
        let extension;

        const settings = await XPorterStorage.loadSettings();
        const headerOpts = {
            localize: settings.localizeExportHeaders === true,
            lang: settings.language || 'en'
        };

        if (format === 'txt' && mode === 'posts') {
            content = XPorterCSV.generatePostsText(allItems, options.profile || {});
            mimeType = 'text/plain;charset=utf-8;';
            extension = 'txt';
        } else if (format === 'json') {
            const payload = mode === 'posts'
                ? (options.socialPlatform === 'facebook'
                    ? buildFacebookJsonPayload(allItems, options)
                    : (options.socialPlatform === 'instagram'
                        ? buildInstagramJsonPayload(allItems, options)
                        : buildUcvJsonPayload(allItems, options)))
                : allItems;
            content = JSON.stringify(payload, null, 2);
            mimeType = 'application/json;charset=utf-8;';
            extension = 'json';
        } else if (format === 'xlsx') {
            content = XPorterCSV.generateXLSX(allItems, isUsers, headerOpts);
            mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            extension = 'xlsx';
        } else {
            content = XPorterCSV.generateCSV(allItems, isUsers, headerOpts);
            mimeType = 'text/csv;charset=utf-8;';
            extension = 'csv';
        }

        const filename = buildUcvExportFilename(options, extension);
        const result = await startDownload(content, mimeType, filename, options.saveAs !== false);
        if (result.success) return { ...result, count: allItems.length, filename };
        return result;
    }

    const FEED_EXPORT_HEADERS = [
        'id', 'text', 'tweet_url', 'language', 'created_at',
        'author_id', 'author_name', 'author_username',
        'author_followers_count', 'first_author_followers_count', 'author_verified',
        'view_count', 'bookmark_count', 'favorite_count', 'retweet_count', 'reply_count', 'quote_count',
        'first_view_count', 'first_bookmark_count', 'first_favorite_count',
        'first_retweet_count', 'first_reply_count', 'first_quote_count',
        'first_seen_at', 'last_seen_at', 'seen_count', 'last_surface',
        'type', 'in_reply_to_status_id', 'in_reply_to_user_id', 'in_reply_to_username', 'conversation_id',
        'target_account_username', 'reposter_username', 'original_author_username',
        'es_publicacion_propia', 'es_repost_externo', 'metricas_atribuibles_cuenta',
        'is_quote', 'is_retweet', 'is_article', 'is_pinned', 'media_count', 'media_types'
    ];

    async function downloadSeenPosts(outputFormat) {
        const posts = await XPorterPostDB.getAllPosts();
        if (posts.length === 0) return { error: 'NO_DATA' };

        const rows = posts.map(post => ({
            ...post,
            first_seen_at: post.first_seen_at ? new Date(post.first_seen_at).toISOString() : '',
            last_seen_at: post.last_seen_at ? new Date(post.last_seen_at).toISOString() : ''
        }));
        const format = outputFormat === 'json' ? 'json' : 'csv';
        let content;
        let mimeType;

        if (format === 'json') {
            content = JSON.stringify(rows.map(({ created_at_ms, ...post }) => post), null, 2);
            mimeType = 'application/json;charset=utf-8;';
        } else {
            const lines = [FEED_EXPORT_HEADERS.map(XPorterCSV.escapeCSVValue).join(',')];
            for (const row of rows) {
                lines.push(FEED_EXPORT_HEADERS.map(header => XPorterCSV.escapeCSVValue(row[header])).join(','));
            }
            content = '\uFEFF' + lines.join('\n') + '\n';
            mimeType = 'text/csv;charset=utf-8;';
        }

        const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
        const filename = `XPorter_seen_posts_${stamp}.${format}`;
        const result = await startDownload(content, mimeType, filename);
        return result.success ? { ...result, count: rows.length, filename } : result;
    }

    function startDownload(content, mimeType, filename, saveAs = true) {
        const blob = new Blob([content], { type: mimeType });
        const reader = new FileReader();
        return new Promise((resolve) => {
            reader.onerror = () => resolve({ error: 'DOWNLOAD_FAILED' });
            reader.onload = () => {
                chrome.downloads.download({
                    url: reader.result,
                    filename,
                    saveAs
                }, (downloadId) => {
                    if (chrome.runtime.lastError || downloadId === undefined) {
                        XLog.error('Download failed:', chrome.runtime.lastError?.message);
                        resolve({ error: 'DOWNLOAD_FAILED' });
                        return;
                    }
                    resolve({ success: true, downloadId });
                });
            };
            reader.readAsDataURL(blob);
        });
    }

    globalThis.XPorterDownloads = {
        getCurrentPlan,
        startCurrentDownload,
        downloadCurrent,
        getCurrentPostsText,
        downloadHistory,
        downloadSeenPosts,
        buildUcvJsonPayload,
        buildFacebookJsonPayload,
        buildInstagramJsonPayload
    };
})();
