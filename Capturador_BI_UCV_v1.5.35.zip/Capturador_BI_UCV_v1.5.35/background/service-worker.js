// XPorter — Background Service Worker
// Orchestrates the export process and handles popup/content-script messages

// Import utility scripts (paths relative to this service worker's location)
importScripts(
    '../utils/config.js',
    '../utils/api-features.js',
    '../utils/api-parsers.js',
    '../utils/api.js',
    '../utils/rateLimit.js',
    '../utils/columns-i18n.js',
    '../utils/csv.js',
    '../utils/storage.js',
    '../utils/post-database.js',
    '../utils/facebook-database.js',
    '../utils/instagram-database.js',
    '../popup/i18n.js', // loadTranslations() — used to localize the in-page capture overlay
    './uninstall-feedback.js',
    './downloads.js'
);

// Export batches, history, settings, and usage counters are worker/UI data.
// Content scripts do not need direct storage access; keep X page contexts from
// reading them and route their legitimate operations through runtime messages.
if (chrome.storage?.local?.setAccessLevel) {
    chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
}

// Current export state
let currentExport = null;
let rateLimiter = null;
let searchCapture = null;
let profileScrollCapture = null;
let facebookScrollCapture = null;
let instagramScrollCapture = null;
let exportLoopPromise = null;
let lastTransientStatus = null;
let manualWaitUntil = null;

function normalizeCapturedType(value) {
    const type = String(value || '').toUpperCase();
    if (type === 'RETWEET') return 'RETWEET';
    if (type === 'THREAD_REPLY') return 'THREAD_REPLY';
    if (type === 'REPLY') return 'REPLY';
    return 'TWEET';
}

function shouldIncludeCapturedPost(post, settings = {}) {
    const type = normalizeCapturedType(post?.type);
    if (settings.includeRetweets === false && type === 'RETWEET') return false;
    if (settings.includeReplies === false && (type === 'REPLY' || type === 'THREAD_REPLY')) return false;
    if (settings.includeArticles === false && Boolean(post?.is_article || post?.article_title)) return false;
    return true;
}

const RATE_LIMIT_KEYS_BY_MODE = {
    posts: 'UserTweets',
    followers: 'Followers',
    following: 'Following',
    verified_followers: 'BlueVerifiedFollowers'
};

// Operations whose live-captured queryIds we accept from the content script.
const VALID_LIVE_OPERATIONS = new Set([
    'UserByScreenName',
    'UserTweets',
    'UserTweetsAndReplies',
    'Followers',
    'Following',
    'BlueVerifiedFollowers',
    'SearchTimeline'
]);

// Synchronous latch closing the async window between the `running` check and
// `currentExport` assignment in start/resume (two rapid START_EXPORT messages
// could otherwise both pass the guard and spawn two competing loops).
let exportStarting = false;

// Clamp a user-typed custom-speed value to its [min, max, default] range.
function clampCustomSpeed(value, range) {
    const [min, max, def] = range || [];
    let v = Number(value);
    if (!Number.isFinite(v)) v = def;
    if (Number.isFinite(min)) v = Math.max(min, v);
    if (Number.isFinite(max)) v = Math.min(max, v);
    return v;
}

// Build the effective pacing preset for the given settings. Named presets come
// from XPORTER_CONFIG.SPEED_PRESETS; 'custom' is assembled from the user's own
// numbers and honors the batch rhythm unconditionally (alwaysBatchCooldown).
function resolveSpeedPreset(settings) {
    const presets = XPORTER_CONFIG.SPEED_PRESETS || {};
    if (settings.exportSpeed === 'custom') {
        const L = XPORTER_CONFIG.CUSTOM_SPEED_LIMITS || {};
        const delayMs = clampCustomSpeed(settings.customDelaySec, L.delaySec) * 1000;
        return {
            adaptiveFloor: delayMs,
            adaptivePad: 1000,
            budgetFraction: 1,
            // The user picked an explicit pace — hold it while X's budget
            // lasts, then wait out the window reset (racing preset).
            raceReserve: 2,
            batchSize: clampCustomSpeed(settings.customBatchSize, L.batch),
            cooldownDuration: clampCustomSpeed(settings.customCooldownMin, L.cooldownMin) * 60000,
            alwaysBatchCooldown: true,
            // Headerless fallback also runs at the user's chosen pace.
            customFallbackDelays: [delayMs, delayMs + 2000]
        };
    }
    return presets[settings.exportSpeed] || presets.standard || {};
}

function createRateLimiter(settings, mode) {
    const adaptivePacing = settings.adaptivePacing !== false;
    // Export Speed preset — the one user-facing pacing knob. Everything else
    // (floors, pads, fallback delays, batch rhythm) is derived from it.
    const preset = resolveSpeedPreset(settings);
    const configuredFallback = adaptivePacing
        ? (preset.customFallbackDelays || XPORTER_CONFIG.FALLBACK_REQUEST_DELAYS?.[mode])
        : null;
    const scale = preset.fallbackScale || 1;
    const fallbackMinDelay = Math.round((configuredFallback?.[0] || settings.requestDelay) * scale);
    const fallbackMaxDelay = Math.round((configuredFallback?.[1] || fallbackMinDelay / scale) * scale);
    const endpointKey = (mode === 'posts' && settings.timelineMode === 'user_tweets_and_replies')
        ? 'UserTweetsAndReplies'
        : RATE_LIMIT_KEYS_BY_MODE[mode];

    return new RateLimitManager({
        requestDelay: settings.requestDelay,
        batchSize: preset.batchSize || settings.batchSize,
        cooldownDuration: preset.cooldownDuration || settings.cooldownDuration,
        adaptiveFloor: preset.adaptiveFloor,
        adaptivePad: preset.adaptivePad,
        budgetFraction: preset.budgetFraction,
        raceReserve: preset.raceReserve,
        alwaysBatchCooldown: preset.alwaysBatchCooldown,
        adaptivePacing,
        fallbackMinDelay,
        fallbackMaxDelay,
        rateLimitProvider: () => (
            endpointKey && typeof XPorterAPI?.getRateLimit === 'function'
                ? XPorterAPI.getRateLimit(endpointKey)
                : null
        )
    });
}

// ==================== Overlay i18n (date-range capture overlay) ====================
// The in-page overlay shown on x.com during a date-range export lives in the page
// context and can't load the popup locale files itself. The worker loads the user's
// language here and ships ready-to-render strings to the content script.
let _overlayI18n = null;

async function getOverlayI18n() {
    if (_overlayI18n) return _overlayI18n;
    let lang = 'en';
    try {
        const settings = await XPorterStorage.loadSettings();
        lang = settings.language || (typeof detectBrowserLanguage === 'function' ? detectBrowserLanguage() : 'en');
    } catch (_) { /* default en */ }
    let tr = {};
    try {
        if (typeof loadTranslations === 'function') tr = await loadTranslations(lang);
    } catch (_) { /* default en fallbacks below */ }
    const g = (k, fallback) => (tr[k] !== undefined ? tr[k] : fallback);
    const dir = ['ar', 'fa', 'he', 'ur'].includes(lang) ? 'rtl' : 'ltr';
    const strings = {
        lang,
        dir,
        title: g('ovTitle', 'XPorter date range export'),
        note: g('ovNote', 'Keep this tab open. XPorter is scrolling it to collect posts.'),
        collapse: g('ovCollapse', 'Collapse XPorter status'),
        expand: g('ovExpand', 'Expand XPorter status'),
        noLimit: g('ovNoLimit', 'No post limit'),
        limitLabel: g('ovLimit', 'Limit:'),
        postsCollected: g('postsCollected', 'posts collected'),
        posts: g('posts', 'posts'),
        preparingFor: g('ovPreparing', 'Preparing search for'),
        preparingPage: g('ovPreparingPage', 'Preparing search page...'),
        exportingFor: g('ovExportingFor', 'Exporting'),
        scrollingFor: g('ovScrolling', 'Scrolling X search for'),
        stop: g('ovStop', 'Stop export'),
        stopping: g('ovStopping', 'Stopping…'),
        rateLimited: g('ovRateLimited', 'X rate limit — retrying in'),
        almostDone: g('ovAlmostDone', "Looks like that's all the posts in this range — you can stop the export")
    };
    // Cache only when the locale really loaded. Caching the silent English
    // fallback pinned the overlay to English for the SW's whole lifetime
    // even though the popup UI was localized (seen in the field: RU popup,
    // English overlay).
    if (tr && Object.keys(tr).length > 0) {
        _overlayI18n = strings;
    }
    return strings;
}

// Build a localized overlay subtitle for a given phase key.
function overlayPhase(i18n, phaseKey, username) {
    const u = username || 'profile';
    switch (phaseKey) {
        case 'preparing': return `${i18n.preparingFor} @${u}...`;
        case 'scrolling': return `${i18n.scrollingFor} @${u}...`;
        case 'exporting':
        default: return `${i18n.exportingFor} @${u}...`;
    }
}

// ==================== Message Handling ====================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch(err => {
        sendResponse({ error: err.message });
    });
    return true; // async response
});

async function handleMessage(message, sender) {
    switch (message.type) {
        case 'SET_USERNAME':
            await XPorterStorage.saveDetectedUsername(message.username);
            return { success: true };

        case 'SET_SOCIAL_ACCOUNT':
            if (!['x', 'facebook', 'instagram'].includes(String(message.platform || '').toLowerCase())) {
                return { error: 'INVALID_PLATFORM' };
            }
            await XPorterStorage.saveDetectedSocialAccount(
                String(message.platform).toLowerCase(),
                String(message.account || ''),
                String(message.url || '')
            );
            return { success: true };

        case 'GET_SOCIAL_ACCOUNT':
            return await XPorterStorage.loadDetectedSocialAccount(String(message.platform || '').toLowerCase());

        case 'GET_USERNAME':
            const username = await XPorterStorage.loadDetectedUsername();
            return { username };

        case 'START_EXPORT':
            return await startExport(message);

        case 'STOP_EXPORT':
            return stopExport();

        case 'GET_STATUS': {
            const exportStatus = await getExportStatus();
            // A UI is now showing this state — a lingering terminal badge
            // (✓ / ! / II) has done its job and would only go stale.
            if (!exportStatus?.running) setBadge('');
            return exportStatus;
        }

        case 'DOWNLOAD_CSV':
        case 'DOWNLOAD_EXPORT':
            return await XPorterDownloads.startCurrentDownload(message.outputFormat);

        case 'GET_DOWNLOAD_PLAN':
            return await XPorterDownloads.getCurrentPlan(message.outputFormat);

        case 'GET_EXPORT_TEXT':
            return await XPorterDownloads.getCurrentPostsText();

        case 'DOWNLOAD_HISTORY_ENTRY':
            await applyAutoExpiration();
            return await XPorterDownloads.downloadHistory(message.id, message.outputFormat);

        case 'RESUME_EXPORT':
            return await resumeExport(message.extraItems);

        case 'SAVE_SETTINGS':
            if (!await XPorterStorage.saveSettings(message.settings)) {
                return { error: 'STORAGE_FULL' };
            }
            _overlayI18n = null; // language may have changed — reload overlay strings lazily
            await applyAutoExpiration();
            XPorterFeedback.refresh(); // keep language/theme/settings snapshot fresh
            return { success: true };

        case 'GET_SETTINGS':
            const settings = await XPorterStorage.loadSettings();
            return { settings };

        case 'CLEAR_EXPORT':
            if (exportLoopPromise) {
                return { error: 'ALREADY_RUNNING' };
            }
            if (!await XPorterStorage.clearExportState()) {
                return { error: 'STORAGE_FULL' };
            }
            currentExport = null;
            setBadge('');
            return { success: true };

        case 'DISCOVERED_QUERYID':
            // Live queryId captured from X.com's own network traffic. The relay
            // channel is spoofable by any page script, so validate strictly here
            // (content.js validates too — defense in depth): known operation,
            // plausible queryId shape. Anything else is dropped silently.
            if (VALID_LIVE_OPERATIONS.has(message.operationName) &&
                typeof message.queryId === 'string' &&
                /^[A-Za-z0-9_-]{10,40}$/.test(message.queryId)) {
                XPorterAPI.setLiveQueryId(message.operationName, message.queryId, message.requestTemplate || null);
            }
            return { success: true };

        case 'PAGE_GRAPHQL_RESPONSE':
            return handlePageGraphqlResponse(message, sender);

        case 'CAPTURE_FEED_POSTS': {
            if (!isXPageSender(sender)) return { error: 'INVALID_SENDER' };
            if (typeof message.operationName !== 'string' ||
                !/(Timeline|Tweets|TweetDetail|Bookmarks|Likes|Community|ListLatest|UserMedia|RepliesDOM)/i.test(message.operationName) ||
                !Array.isArray(message.posts) || message.posts.length === 0 || message.posts.length > 250) {
                return { error: 'INVALID_POSTS' };
            }
            const result = await XPorterPostDB.upsertPosts(message.posts, {
                operationName: message.operationName
            });
            const summary = await XPorterPostDB.getSummary();
            return { ...result, total: summary.count };
        }

        case 'GET_FEED_DB_SUMMARY':
            return XPorterPostDB.getSummary();

        case 'UCV_SCROLL_CAPTURE_PROGRESS': {
            if (!isXPageSender(sender) || !profileScrollCapture || sender.tab?.id !== profileScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await XPorterPostDB.getSummary();
            profileScrollCapture.progressEvents = (profileScrollCapture.progressEvents || 0) + 1;
            profileScrollCapture.lastProgressAt = Date.now();
            profileScrollCapture.lastTotal = summary.count;
            profileScrollCapture.cycles = Number(message.cycles || 0);
            profileScrollCapture.stagnantCycles = Number(message.stagnantCycles || 0);
            profileScrollCapture.endConfirmations = Number(message.endConfirmations || 0);
            profileScrollCapture.endConfirmationLimit = Number(message.endConfirmationLimit || 0) || null;
            profileScrollCapture.autoWaiting = message.autoWaiting === true;
            profileScrollCapture.pauseReason = message.pauseReason || null;
            profileScrollCapture.pauseUntil = Number(message.pauseUntil || 0) || null;
            profileScrollCapture.loading = message.loading === true;
            profileScrollCapture.atBottom = message.atBottom === true;
            profileScrollCapture.idleMs = Number(message.idleMs || 0);
            profileScrollCapture.bottomStableMs = Number(message.bottomStableMs || 0);
            profileScrollCapture.capturePeriod = message.capturePeriod || profileScrollCapture.capturePeriod || 'unlimited';
            profileScrollCapture.periodReferenceDateMs = Number(message.periodReferenceDateMs || 0) || null;
            profileScrollCapture.periodCutoffDateMs = Number(message.periodCutoffDateMs || 0) || null;
            profileScrollCapture.periodFrontierDateMs = Number(message.periodFrontierDateMs || 0) || null;

            if (currentExport?.running) {
                currentExport.tweetCount = summary.count;
                currentExport.status = 'scrolling';
                currentExport.scrollCaptureStats = {
                    cycles: profileScrollCapture.cycles,
                    stagnantCycles: profileScrollCapture.stagnantCycles,
                    lastProgressAt: profileScrollCapture.lastProgressAt,
                    capturePeriod: profileScrollCapture.capturePeriod || 'unlimited',
                    periodReferenceDateMs: profileScrollCapture.periodReferenceDateMs || null,
                    periodCutoffDateMs: profileScrollCapture.periodCutoffDateMs || null,
                    periodFrontierDateMs: profileScrollCapture.periodFrontierDateMs || null
                };
                if (profileScrollCapture.progressEvents % 5 === 0) {
                    await saveCurrentState({ bestEffort: true });
                }
                broadcastStatus({
                    running: true,
                    status: 'scrolling',
                    username: currentExport.username,
                    tweetCount: summary.count,
                    expectedTweets: getExpectedItemCount(),
                    quantityLimit: currentExport.settings?.quantityLimit || 0,
                    batch: Math.floor(summary.count / 50) + 1,
                    stagnantCycles: profileScrollCapture.stagnantCycles,
                    endConfirmations: profileScrollCapture.endConfirmations,
                    autoWaiting: profileScrollCapture.autoWaiting,
                    pauseReason: profileScrollCapture.pauseReason,
                    pauseUntil: profileScrollCapture.pauseUntil,
                    endConfirmationLimit: profileScrollCapture.endConfirmationLimit,
                    loading: profileScrollCapture.loading,
                    atBottom: profileScrollCapture.atBottom,
                    idleMs: profileScrollCapture.idleMs,
                    bottomStableMs: profileScrollCapture.bottomStableMs,
                    exportMode: currentExport.exportMode
                });
            }
            return { success: true, total: summary.count };
        }

        case 'UCV_SCROLL_CAPTURE_DONE': {
            if (!isXPageSender(sender) || !profileScrollCapture || sender.tab?.id !== profileScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await XPorterPostDB.getSummary();
            const capture = profileScrollCapture;
            profileScrollCapture = null;
            capture.resolve?.({
                success: message.reason !== 'ERROR',
                reason: message.reason || 'END_REACHED',
                error: message.error || null,
                total: summary.count,
                cycles: Number(message.cycles || 0),
                stagnantCycles: Number(message.stagnantCycles || 0),
                endConfirmations: Number(message.endConfirmations || 0),
                finalPosition: message.finalPosition || null,
                periodReached: message.periodReached === true,
                capturePeriod: message.capturePeriod || 'unlimited',
                periodReferenceDateMs: Number(message.periodReferenceDateMs || 0) || null,
                periodCutoffDateMs: Number(message.periodCutoffDateMs || 0) || null,
                periodFrontierDateMs: Number(message.periodFrontierDateMs || 0) || null
            });
            return { success: true, total: summary.count };
        }

        case 'IG_CAPTURE_POSTS': {
            if (!isInstagramPageSender(sender) || !Array.isArray(message.posts) || message.posts.length === 0 || message.posts.length > 120) {
                return { error: 'INVALID_INSTAGRAM_POSTS' };
            }
            const result = await InstagramPostDB.upsertPosts(message.posts, {
                operationName: message.operationName || 'InstagramModalDOM'
            });
            const summary = await InstagramPostDB.getSummary();
            return { ...result, total: summary.count };
        }

        case 'GET_INSTAGRAM_DB_SUMMARY':
            return InstagramPostDB.getSummary();

        case 'IG_SCROLL_CAPTURE_PROGRESS': {
            if (!isInstagramPageSender(sender) || !instagramScrollCapture || sender.tab?.id !== instagramScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await InstagramPostDB.getSummary();
            instagramScrollCapture.lastProgressAt = Date.now();
            instagramScrollCapture.lastTotal = summary.count;
            instagramScrollCapture.processed = Number(message.processed || 0);
            instagramScrollCapture.duplicates = Number(message.duplicates || 0);
            instagramScrollCapture.capturePeriod = message.capturePeriod || instagramScrollCapture.capturePeriod || 'first_10';
            instagramScrollCapture.periodReferenceDateMs = Number(message.periodReferenceDateMs || 0) || null;
            instagramScrollCapture.periodCutoffDayKey = Number(message.periodCutoffDayKey || 0) || null;
            instagramScrollCapture.currentShortcode = message.currentShortcode || null;
            if (currentExport?.running && currentExport.socialPlatform === 'instagram') {
                currentExport.tweetCount = summary.count;
                currentExport.status = 'scrolling';
                currentExport.scrollCaptureStats = {
                    processed: instagramScrollCapture.processed,
                    duplicates: instagramScrollCapture.duplicates,
                    capturePeriod: instagramScrollCapture.capturePeriod,
                    periodReferenceDateMs: instagramScrollCapture.periodReferenceDateMs,
                    periodCutoffDayKey: instagramScrollCapture.periodCutoffDayKey,
                    currentShortcode: instagramScrollCapture.currentShortcode,
                    lastProgressAt: instagramScrollCapture.lastProgressAt
                };
                await saveCurrentState({ bestEffort: true });
                broadcastStatus({
                    running: true,
                    status: 'scrolling',
                    username: currentExport.username,
                    socialPlatform: 'instagram',
                    tweetCount: summary.count,
                    batch: Math.floor(summary.count / 10) + 1,
                    exportMode: currentExport.exportMode
                });
            }
            return { success: true, total: summary.count };
        }

        case 'IG_SCROLL_CAPTURE_DONE': {
            if (!isInstagramPageSender(sender) || !instagramScrollCapture || sender.tab?.id !== instagramScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await InstagramPostDB.getSummary();
            const capture = instagramScrollCapture;
            instagramScrollCapture = null;
            capture.resolve?.({
                success: message.reason !== 'ERROR',
                reason: message.reason || 'END_REACHED',
                error: message.error || null,
                total: summary.count,
                processed: Number(message.processed || 0),
                duplicates: Number(message.duplicates || 0),
                capturePeriod: message.capturePeriod || 'first_10',
                periodReached: message.periodReached === true,
                periodReferenceDateMs: Number(message.periodReferenceDateMs || 0) || null,
                periodCutoffDayKey: Number(message.periodCutoffDayKey || 0) || null,
                currentShortcode: message.currentShortcode || null,
                structuredPayloadsIndexed: Number(message.structuredPayloadsIndexed || 0)
            });
            return { success: true, total: summary.count };
        }

        case 'FB_CAPTURE_POSTS': {
            if (!isFacebookPageSender(sender) || !Array.isArray(message.posts) || message.posts.length === 0 || message.posts.length > 120) {
                return { error: 'INVALID_FACEBOOK_POSTS' };
            }
            const result = await FacebookPostDB.upsertPosts(message.posts, {
                operationName: message.operationName || 'FacebookDOMVisible'
            });
            const summary = await FacebookPostDB.getSummary();
            return { ...result, total: summary.count };
        }

        case 'GET_FACEBOOK_DB_SUMMARY':
            return FacebookPostDB.getSummary();

        case 'FB_SCROLL_CAPTURE_PROGRESS': {
            if (!isFacebookPageSender(sender) || !facebookScrollCapture || sender.tab?.id !== facebookScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await FacebookPostDB.getSummary();
            facebookScrollCapture.progressEvents = (facebookScrollCapture.progressEvents || 0) + 1;
            facebookScrollCapture.lastProgressAt = Date.now();
            facebookScrollCapture.lastTotal = summary.count;
            facebookScrollCapture.cycles = Number(message.cycles || 0);
            facebookScrollCapture.stagnantCycles = Number(message.stagnantCycles || 0);
            facebookScrollCapture.endConfirmations = Number(message.endConfirmations || 0);
            facebookScrollCapture.endConfirmationLimit = Number(message.endConfirmationLimit || 0) || null;
            facebookScrollCapture.capturePeriod = message.capturePeriod || 'unlimited';
            facebookScrollCapture.periodReferenceDateMs = Number(message.periodReferenceDateMs || 0) || null;
            facebookScrollCapture.periodCutoffDateMs = Number(message.periodCutoffDateMs || 0) || null;
            facebookScrollCapture.periodFrontierDateMs = Number(message.periodFrontierDateMs || 0) || null;
            if (currentExport?.running && currentExport.socialPlatform === 'facebook') {
                currentExport.tweetCount = summary.count;
                currentExport.status = 'scrolling';
                currentExport.scrollCaptureStats = {
                    cycles: facebookScrollCapture.cycles,
                    stagnantCycles: facebookScrollCapture.stagnantCycles,
                    capturePeriod: facebookScrollCapture.capturePeriod,
                    periodReferenceDateMs: facebookScrollCapture.periodReferenceDateMs,
                    periodCutoffDateMs: facebookScrollCapture.periodCutoffDateMs,
                    periodFrontierDateMs: facebookScrollCapture.periodFrontierDateMs,
                    lastProgressAt: facebookScrollCapture.lastProgressAt
                };
                if (facebookScrollCapture.progressEvents % 5 === 0) await saveCurrentState({ bestEffort: true });
                broadcastStatus({
                    running: true,
                    status: 'scrolling',
                    username: currentExport.username,
                    socialPlatform: 'facebook',
                    tweetCount: summary.count,
                    batch: Math.floor(summary.count / 50) + 1,
                    stagnantCycles: facebookScrollCapture.stagnantCycles,
                    endConfirmations: facebookScrollCapture.endConfirmations,
                    endConfirmationLimit: facebookScrollCapture.endConfirmationLimit,
                    autoWaiting: message.autoWaiting === true,
                    pauseReason: message.pauseReason || null,
                    pauseUntil: Number(message.pauseUntil || 0) || null,
                    loading: message.loading === true,
                    atBottom: message.atBottom === true,
                    exportMode: currentExport.exportMode
                });
            }
            return { success: true, total: summary.count };
        }

        case 'FB_SCROLL_CAPTURE_DONE': {
            if (!isFacebookPageSender(sender) || !facebookScrollCapture || sender.tab?.id !== facebookScrollCapture.tabId) {
                return { error: 'INVALID_SENDER' };
            }
            const summary = await FacebookPostDB.getSummary();
            const capture = facebookScrollCapture;
            facebookScrollCapture = null;
            capture.resolve?.({
                success: message.reason !== 'ERROR',
                reason: message.reason || 'END_REACHED',
                error: message.error || null,
                total: summary.count,
                cycles: Number(message.cycles || 0),
                stagnantCycles: Number(message.stagnantCycles || 0),
                endConfirmations: Number(message.endConfirmations || 0),
                finalPosition: message.finalPosition || null,
                periodReached: message.periodReached === true,
                capturePeriod: message.capturePeriod || 'unlimited',
                periodReferenceDateMs: Number(message.periodReferenceDateMs || 0) || null,
                periodCutoffDateMs: Number(message.periodCutoffDateMs || 0) || null,
                periodFrontierDateMs: Number(message.periodFrontierDateMs || 0) || null,
                traversalMode: message.traversalMode || null,
                captureZoom: Number(message.captureZoom || 0) || null,
                cardsProcessed: Number(message.cardsProcessed || 0),
                actionMenusProcessed: Number(message.actionMenusProcessed || 0),
                cardsWithDate: Number(message.cardsWithDate || 0),
                cardsWithoutDate: Number(message.cardsWithoutDate || 0),
                cardsWithMetricZone: Number(message.cardsWithMetricZone || 0),
                cardsWithHeaderVisible: Number(message.cardsWithHeaderVisible || 0),
                cardsWithoutHeaderVisible: Number(message.cardsWithoutHeaderVisible || 0),
                cardsFullyVisible: Number(message.cardsFullyVisible || 0),
                cardsWithLocalDateRetry: Number(message.cardsWithLocalDateRetry || 0),
                localMetricFallbacks: Number(message.localMetricFallbacks || 0),
                relativeDateTooltipAttempts: Number(message.relativeDateTooltipAttempts || 0),
                relativeDateTooltipResolved: Number(message.relativeDateTooltipResolved || 0),
                privacyDateLinksFound: Number(message.privacyDateLinksFound || 0),
                privacyTooltipAttempts: Number(message.privacyTooltipAttempts || 0),
                privacyTooltipResolved: Number(message.privacyTooltipResolved || 0),
                expandedCards: Number(message.expandedCards || 0),
                loadProbes: Number(message.loadProbes || 0)
            });
            return { success: true, total: summary.count };
        }

        case 'DOWNLOAD_FEED_DB':
            return XPorterDownloads.downloadSeenPosts(message.outputFormat);

        case 'CLEAR_FEED_DB':
            await XPorterPostDB.clear();
            return { success: true };

        case 'GET_EXPORT_HISTORY':
            await applyAutoExpiration();
            const history = await XPorterStorage.loadExportHistory();
            return { history: history.map(({ items, ...entry }) => entry) };

        case 'DELETE_HISTORY_ENTRY':
            return await XPorterStorage.deleteExportHistoryEntry(message.id)
                ? { success: true }
                : { error: 'STORAGE_FULL' };

        case 'CLEAR_HISTORY':
            return await XPorterStorage.clearExportHistory()
                ? { success: true }
                : { error: 'STORAGE_FULL' };

        case 'XP_SESSION_OPEN':
            // Popup was opened — count it and refresh the snapshot.
            await XPorterStorage.recordOpen();
            XPorterFeedback.refresh();
            return { success: true };

        case 'XP_ACTIVE_TICK':
            // Accumulated active (visible) time in the UI. Refresh is throttled
            // unless the page is unloading (flush) so we don't churn on every tick.
            await XPorterStorage.addActiveMs(message.ms);
            XPorterFeedback.maybeRefresh(message.flush);
            return { success: true };

        default:
            return { error: 'Unknown message type' };
    }
}

function isXPageSender(sender) {
    try {
        const url = new URL(sender?.tab?.url || '');
        return url.protocol === 'https:' && (url.hostname === 'x.com' || url.hostname === 'twitter.com');
    } catch (_) {
        return false;
    }
}

function isFacebookPageSender(sender) {
    try {
        const url = new URL(sender?.tab?.url || '');
        return url.protocol === 'https:' && /(^|\.)facebook\.com$/i.test(url.hostname);
    } catch (_) {
        return false;
    }
}

function isInstagramPageSender(sender) {
    try {
        const url = new URL(sender?.tab?.url || '');
        return url.protocol === 'https:' && /(^|\.)instagram\.com$/i.test(url.hostname);
    } catch (_) {
        return false;
    }
}

// ==================== Export Engine ====================

// A stopped export's loop unwinds asynchronously (final flush + persist +
// tab close). Start/Resume gate on exportLoopPromise, so a fast Stop → Resume
// raced that unwind and returned ALREADY_RUNNING for an export the UI already
// showed as stopped. Wait (bounded) for the loop to actually exit first.
async function waitForLoopUnwind(ms = 8000) {
    if (!exportLoopPromise || currentExport?.running) return;
    await Promise.race([
        exportLoopPromise,
        new Promise(resolve => setTimeout(resolve, ms))
    ]);
}

async function startExport({ username, dateFrom, dateTo, exportMode, outputFormat, socialPlatform, capturePeriod }) {
    await waitForLoopUnwind();
    if (exportStarting || exportLoopPromise || (currentExport && currentExport.running)) {
        return { error: 'ALREADY_RUNNING' };
    }
    exportStarting = true;

    try {
        return await _startExportInner({ username, dateFrom, dateTo, exportMode, outputFormat, socialPlatform, capturePeriod });
    } finally {
        exportStarting = false;
    }
}

async function _startExportInner({ username, dateFrom, dateTo, exportMode, outputFormat, socialPlatform, capturePeriod }) {
    const settings = await XPorterStorage.loadSettings();
    const mode = exportMode || 'posts';
    const requestedPlatform = String(socialPlatform || settings.socialPlatform || 'x').toLowerCase();
    const platform = ['facebook', 'instagram'].includes(requestedPlatform) ? requestedPlatform : 'x';
    const requestedCapturePeriod = String(capturePeriod || settings.capturePeriod || 'unlimited').toLowerCase();
    const allowedCapturePeriods = new Set(['first_10', 'unlimited', 'last_month', 'last_3_months', 'last_year']);
    settings.capturePeriod = allowedCapturePeriods.has(requestedCapturePeriod) ? requestedCapturePeriod : 'unlimited';
    // first_10 es compatible con X, Facebook e Instagram. Para X se
    // reutiliza el límite interno ya probado, sin alterar la preferencia global.
    if (platform === 'x' && settings.capturePeriod === 'first_10') settings.quantityLimit = 10;
    const normalizedDateFrom = (mode === 'posts') ? normalizeDateBoundary(dateFrom, 'start') : null;
    const normalizedDateTo = (mode === 'posts') ? normalizeDateBoundary(dateTo, 'end') : null;

    if (normalizedDateFrom && normalizedDateTo && normalizedDateFrom > normalizedDateTo) {
        return { error: 'INVALID_DATE_RANGE' };
    }

    // Initialize rate limiter with current settings. The provider lets it pace
    // adaptively from X's live x-rate-limit-* budget (fixed delay is fallback).
    rateLimiter = platform === 'x' ? createRateLimiter(settings, mode) : null;
    lastTransientStatus = null;
    _overlayI18n = null; // re-read the UI language for this export's overlay

    if (rateLimiter) {
        rateLimiter.onStatusChange((event) => {
            lastTransientStatus = event;
            broadcastStatus({ ...event, exportMode: mode });
        });
    }

    // Clear previous export data
    if (!await XPorterStorage.clearExportState()) {
        return { error: 'STORAGE_FULL' };
    }

    currentExport = {
        running: true,
        username: username,
        socialPlatform: platform,
        exportMode: mode,
        outputFormat: outputFormat || 'json',
        dateFrom: normalizedDateFrom,
        dateTo: normalizedDateTo,
        settings: settings,
        tweetCount: 0, // used for both tweets and users (item count)
        itemsRecordedBase: 0,
        totalBatches: 0,
        tweetBuffer: [], // used for both tweets and users
        userId: null,
        cursor: null,
        startedAt: Date.now(),
        status: 'resolving_user'
    };

    // Save initial state before acknowledging the start. A failed write must
    // not leave an in-memory export marked running with no loop behind it.
    try {
        await saveCurrentState();
    } catch (error) {
        currentExport = null;
        rateLimiter = null;
        return { error: error.message };
    }

    // Anonymous usage counter (for uninstall feedback) — fire and forget
    XPorterStorage.recordExportStart(mode, outputFormat, {
        dateRange: !!(normalizedDateFrom || normalizedDateTo)
    }).then(XPorterFeedback.refresh).catch(() => {});
    _lastRecordedUsagePhase = 'resolving_user';

    // Start the export process (non-blocking)
    launchExportLoop('Export loop error:');

    return { success: true, status: 'started' };
}

async function runExportLoop() {
    try {
        // Step 1: Resolve user ID
        broadcastStatus({ running: true, status: 'resolving_user', username: currentExport.username, exportMode: currentExport.exportMode });

        const isFacebookCapture = currentExport.socialPlatform === 'facebook';
        const isInstagramCapture = currentExport.socialPlatform === 'instagram';
        const useProfileScrollCapture = !isFacebookCapture && !isInstagramCapture && isProfileScrollCaptureMode();
        let userInfo;
        if (isFacebookCapture) {
            userInfo = await readProfileFromOpenFacebookTab(currentExport.username);
        } else if (isInstagramCapture) {
            userInfo = await readProfileFromOpenInstagramTab(currentExport.username);
        } else if (useProfileScrollCapture) {
            userInfo = await readProfileFromOpenRepliesTab(currentExport.username);
        } else {
            try {
                // Resolve through the rate limiter: a NETWORK_TIMEOUT or 429 here
                // gets the same visible retries as any page fetch, and Stop aborts
                // the retry wait instead of racing the in-flight request. Terminal
                // errors (NOT_LOGGED_IN etc.) pass through non-retried as before.
                userInfo = await rateLimiter.executeWithRateLimit(() =>
                    XPorterAPI.getUserByScreenName(currentExport.username));
                // The resolve hits a separate, generous endpoint budget — don't
                // let it count as request #1, or the first real page would sit
                // out a pacing delay before any result appears.
                rateLimiter.requestCount = 0;
                rateLimiter.totalRequests = 0;
                rateLimiter.lastRequestAt = null;
            } catch (err) {
                if (err.message === 'NOT_LOGGED_IN') throw new Error('NOT_LOGGED_IN');
                if (err.message === 'USER_NOT_FOUND') throw new Error('USER_NOT_FOUND');
                if (err.message === 'USER_SUSPENDED') throw new Error('USER_SUSPENDED');
                if (err.message.startsWith('ENDPOINT_DISCOVERY_FAILED')) throw new Error('ENDPOINT_DISCOVERY_FAILED');
                throw err;
            }
        }

        if (userInfo.isProtected) {
            throw new Error('ACCOUNT_PRIVATE');
        }

        currentExport.userId = userInfo.id;
        currentExport.userInfo = userInfo;
        currentExport.status = 'fetching';
        recordUsagePhase('fetching');
        await saveCurrentState();

        // Determine expected count based on mode
        const expectedCount = getExpectedItemCount();

        broadcastStatus({
            running: true,
            status: 'fetching',
            username: currentExport.username,
            expectedTweets: expectedCount,
            tweetCount: 0,
            exportMode: currentExport.exportMode
        });

        // Step 2: Run the appropriate fetch loop based on mode
        if (currentExport.exportMode === 'posts') {
            if (isFacebookCapture) {
                await _fetchFacebookByProfileScrollLoop();
            } else if (isInstagramCapture) {
                await _fetchInstagramByModalLoop();
            } else if (useProfileScrollCapture) {
                await _fetchPostsByProfileScrollLoop();
            } else {
                await _fetchPostsLoop();
            }
        } else {
            await _fetchUsersLoop();
        }

        if (!currentExport.running) {
            await flushExportBuffer();
            currentExport.status = 'stopped';
            await saveCurrentState();
            recordExportStoppedOnce();
            broadcastStopped();
            return;
        }

        // Save remaining buffer
        await flushExportBuffer();

        // Export complete
        currentExport.running = false;
        currentExport.status = 'complete';
        currentExport.completedAt = Date.now();
        await saveCurrentState();

        await saveCompletedExportHistory();

        // Anonymous usage counter (for uninstall feedback) — fire and forget
        const itemsDelta = Math.max(0, currentExport.tweetCount - (currentExport.itemsRecordedBase || 0));
        XPorterStorage.recordExportComplete(itemsDelta).then(XPorterFeedback.refresh).catch(() => {});

        broadcastStatus({
            running: false,
            status: 'complete',
            tweetCount: currentExport.tweetCount,
            username: currentExport.username,
            socialPlatform: currentExport.socialPlatform || 'x',
            exportMode: currentExport.exportMode,
            captureMethod: currentExport.captureMethod || null,
            timelineMode: currentExport.settings?.timelineMode || null,
            scrollCaptureResult: currentExport.scrollCaptureResult || null,
            startedAt: currentExport.startedAt,
            completedAt: currentExport.completedAt
        });

    } catch (error) {
        if (error.message === 'ABORTED') {
            // Flush remaining buffer
            await flushExportBuffer();
            currentExport.running = false;
            currentExport.status = 'stopped';
            await saveCurrentState();
            recordExportStoppedOnce();
            broadcastStopped();
        } else {
            throw error;
        }
    }
}

async function saveCompletedExportHistory() {
    const ui = currentExport.userInfo || {};
    const historyLimit = Number(XPORTER_CONFIG.EXPORT_HISTORY_DATA_LIMIT) || 5000;
    const keepPayload = currentExport.tweetCount <= historyLimit;
    const historyItems = keepPayload ? await XPorterStorage.loadAllTweets() : null;
    await XPorterStorage.saveExportHistory({
        username: ui.screenName || currentExport.username,
        socialPlatform: currentExport.socialPlatform || 'x',
        displayName: ui.name || currentExport.username,
        profileImageUrl: ui.profileImageUrl || '',
        userInfo: { ...ui },
        exportMode: currentExport.exportMode,
        itemCount: currentExport.tweetCount,
        outputFormat: currentExport.outputFormat || 'json',
        timelineMode: currentExport.settings?.timelineMode || 'user_tweets_and_replies',
        startedAt: currentExport.startedAt || null,
        dateFrom: currentExport.dateFrom?.toISOString() || null,
        dateTo: currentExport.dateTo?.toISOString() || null,
        completedAt: currentExport.completedAt || Date.now(),
        ...(historyItems ? { items: historyItems } : {})
    });
}


// ==================== BI UCV: browser-driven Replies capture ====================

function isProfileScrollCaptureMode(exportState = currentExport) {
    return exportState?.exportMode === 'posts'
        && exportState?.settings?.timelineMode === 'user_tweets_and_replies';
}

const UCV_CAPTURE_PERIOD_MONTHS = Object.freeze({
    last_month: 1,
    last_3_months: 3,
    last_year: 12
});

function normalizeCapturePeriod(value) {
    if (value === 'first_10') return 'first_10';
    return Object.prototype.hasOwnProperty.call(UCV_CAPTURE_PERIOD_MONTHS, value)
        ? value
        : 'unlimited';
}

function subtractUtcCalendarMonths(timestamp, months) {
    const source = new Date(Number(timestamp));
    if (!Number.isFinite(source.getTime())) return null;
    const day = source.getUTCDate();
    const target = new Date(source.getTime());
    target.setUTCDate(1);
    target.setUTCMonth(target.getUTCMonth() - months);
    const lastDay = new Date(Date.UTC(
        target.getUTCFullYear(),
        target.getUTCMonth() + 1,
        0,
        source.getUTCHours(),
        source.getUTCMinutes(),
        source.getUTCSeconds(),
        source.getUTCMilliseconds()
    )).getUTCDate();
    target.setUTCDate(Math.min(day, lastDay));
    target.setUTCHours(
        source.getUTCHours(),
        source.getUTCMinutes(),
        source.getUTCSeconds(),
        source.getUTCMilliseconds()
    );
    return target.getTime();
}

function utcDayStart(timestamp) {
    if (timestamp === null || timestamp === undefined || timestamp === '') return null;
    const date = new Date(Number(timestamp));
    if (!Number.isFinite(date.getTime())) return null;
    return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
}

function filterRowsByCapturePeriod(rows, requestedPeriod) {
    const period = normalizeCapturePeriod(requestedPeriod);
    if (period === 'first_10') {
        const orderedRows = rows.slice().sort((a, b) => {
            const ao = Number(a?.feed_order || 0);
            const bo = Number(b?.feed_order || 0);
            if (ao > 0 && bo > 0 && ao !== bo) return ao - bo;
            if (ao > 0 && bo <= 0) return -1;
            if (ao <= 0 && bo > 0) return 1;
            const af = Number(a?.first_seen_at || 0);
            const bf = Number(b?.first_seen_at || 0);
            if (af !== bf) return af - bf;
            return Number(b?.created_at_ms || 0) - Number(a?.created_at_ms || 0);
        });
        const selected = orderedRows.slice(0, 10);
        const referenceDateMs = selected.reduce(
            (max, row) => Math.max(max, Number(row?.created_at_ms || 0)),
            0
        );
        return {
            rows: selected,
            period,
            referenceDateMs: referenceDateMs || null,
            cutoffDateMs: null,
            excludedBeforeCutoff: 0,
            excludedWithoutDate: 0
        };
    }
    if (period === 'unlimited') {
        return {
            rows,
            period,
            referenceDateMs: null,
            cutoffDateMs: null,
            excludedBeforeCutoff: 0,
            excludedWithoutDate: 0
        };
    }

    const validRows = rows.filter(row => Number(row?.created_at_ms) > 0);
    const ownNonPinned = validRows.filter(row =>
        row?.es_publicacion_propia === true
        && row?.es_repost_externo !== true
        && row?.is_pinned !== true
    );
    const referencePool = ownNonPinned.length > 0 ? ownNonPinned : validRows;
    const referenceDateMs = referencePool.reduce(
        (max, row) => Math.max(max, Number(row.created_at_ms) || 0),
        0
    );
    const cutoffDateMs = utcDayStart(subtractUtcCalendarMonths(
        referenceDateMs,
        UCV_CAPTURE_PERIOD_MONTHS[period]
    ));

    if (!referenceDateMs || !cutoffDateMs) {
        return {
            rows,
            period,
            referenceDateMs: referenceDateMs || null,
            cutoffDateMs: cutoffDateMs || null,
            excludedBeforeCutoff: 0,
            excludedWithoutDate: 0
        };
    }

    let excludedBeforeCutoff = 0;
    let excludedWithoutDate = 0;
    const filteredRows = rows.filter(row => {
        const createdAtMs = Number(row?.created_at_ms) || 0;
        if (!createdAtMs) {
            excludedWithoutDate += 1;
            return false;
        }
        const createdDayStart = utcDayStart(createdAtMs);
        const referenceDayStart = utcDayStart(referenceDateMs);
        if (createdDayStart === null
            || createdDayStart < cutoffDateMs
            || createdDayStart > referenceDayStart) {
            excludedBeforeCutoff += 1;
            return false;
        }
        return true;
    });

    return {
        rows: filteredRows,
        period,
        referenceDateMs,
        cutoffDateMs,
        excludedBeforeCutoff,
        excludedWithoutDate
    };
}

async function findOpenRepliesTab(username) {
    const wanted = String(username || '').replace(/^@/, '').toLowerCase();
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const matching = tabs.filter(tab => {
        try {
            const url = new URL(tab.url || '');
            if (url.protocol !== 'https:' || !['x.com', 'twitter.com'].includes(url.hostname)) return false;
            const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/with_replies\/?$/);
            return !!match && (!wanted || match[1].toLowerCase() === wanted);
        } catch (_) {
            return false;
        }
    });
    return matching.find(tab => tab.active) || matching[0] || null;
}

async function readProfileFromOpenRepliesTab(username) {
    const tab = await findOpenRepliesTab(username);
    if (!tab?.id) throw new Error('OPEN_REPLIES_PAGE');

    let response;
    try {
        response = await chrome.tabs.sendMessage(tab.id, { type: 'UCV_READ_X_PROFILE' });
    } catch (_) {
        throw new Error('RELOAD_X_PAGE');
    }
    if (!response?.success || !response.profile) {
        throw new Error(response?.error || 'PROFILE_READ_FAILED');
    }

    const profile = response.profile;
    const screenName = profile.screenName || String(username || '').replace(/^@/, '');
    return {
        id: profile.id || null,
        name: profile.name || screenName,
        screenName,
        bio: profile.bio || null,
        location: profile.location || null,
        url: profile.url || null,
        createdAt: profile.createdAt || null,
        profileImageUrl: profile.profileImageUrl || null,
        isProtected: profile.isProtected === true,
        isVerified: profile.isVerified === true,
        followersCount: profile.followersCount !== null && profile.followersCount !== undefined && Number.isFinite(Number(profile.followersCount))
            ? Number(profile.followersCount) : null,
        followersCountRaw: profile.followersCountRaw || null,
        followingCount: profile.followingCount !== null && profile.followingCount !== undefined && Number.isFinite(Number(profile.followingCount))
            ? Number(profile.followingCount) : null,
        followingCountRaw: profile.followingCountRaw || null,
        tweetCount: profile.tweetCount !== null && profile.tweetCount !== undefined && Number.isFinite(Number(profile.tweetCount))
            ? Number(profile.tweetCount) : null,
        tweetCountRaw: profile.tweetCountRaw || null,
        listedCount: null,
        likesCount: null,
        mediaCount: null,
        subscriptionsCount: null,
        profileSource: profile.source || 'PERFIL_X_INTERFAZ_VISIBLE',
        captureTabId: tab.id
    };
}

function waitForProfileScrollCompletion(tabId) {
    return new Promise((resolve) => {
        const timeoutId = setTimeout(() => {
            if (!profileScrollCapture || profileScrollCapture.tabId !== tabId) return;
            const capture = profileScrollCapture;
            profileScrollCapture = null;
            capture.resolve = null;
            resolve({ success: false, reason: 'TIMEOUT', error: 'SCROLL_CAPTURE_TIMEOUT', total: capture.lastTotal || 0 });
        }, 6 * 60 * 60 * 1000);

        profileScrollCapture = {
            tabId,
            startedAt: Date.now(),
            lastProgressAt: Date.now(),
            lastTotal: 0,
            progressEvents: 0,
            resolve: (result) => {
                clearTimeout(timeoutId);
                resolve(result || { success: true, reason: 'END_REACHED', total: 0 });
            }
        };
    });
}

function exportablePostFromFeedRow(row) {
    const internalFields = new Set([
        'created_at_ms', 'first_seen_at', 'last_seen_at', 'seen_count', 'last_surface',
        'first_author_followers_count', 'first_view_count', 'first_bookmark_count',
        'first_favorite_count', 'first_retweet_count', 'first_reply_count', 'first_quote_count'
    ]);
    const output = {};
    for (const [key, value] of Object.entries(row || {})) {
        if (!internalFields.has(key)) output[key] = value;
    }
    output.scraped_at = row?.last_seen_at ? new Date(row.last_seen_at).toISOString() : new Date().toISOString();
    output.capture_surface = row?.last_surface || 'UserTweetsAndReplies';
    return output;
}

async function persistProfileScrollRows(rows) {
    currentExport.tweetCount = 0;
    currentExport.totalBatches = 0;
    currentExport.tweetBuffer = [];

    for (const row of rows) {
        currentExport.tweetBuffer.push(exportablePostFromFeedRow(row));
        currentExport.tweetCount += 1;
        recordFirstItemOnce();
        if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) {
            await flushExportBuffer();
        }
    }
    await flushExportBuffer();
}

async function _fetchPostsByProfileScrollLoop() {
    const tab = await findOpenRepliesTab(currentExport.username);
    if (!tab?.id) throw new Error('OPEN_REPLIES_PAGE');

    // A fresh export starts with an empty local database and from the top of
    // the timeline. A resumed export must preserve all captured IDs and keep
    // the current page position, otherwise it would count again from zero and
    // re-scroll the same 1,000+ posts.
    const resumeExisting = currentExport.profileScrollResume === true;
    if (!resumeExisting) {
        await XPorterPostDB.clear();
        currentExport.tweetCount = 0;
        currentExport.totalBatches = 0;
        currentExport.tweetBuffer = [];
    } else {
        const existing = await XPorterPostDB.getSummary();
        currentExport.tweetCount = existing.count;
        currentExport.tweetBuffer = [];
    }
    currentExport.status = 'scrolling';
    currentExport.captureMethod = 'BROWSER_SCROLL_PASSIVE';
    await saveCurrentState();

    const completion = waitForProfileScrollCompletion(tab.id);
    let started;
    try {
        started = await chrome.tabs.sendMessage(tab.id, {
            type: 'UCV_START_PROFILE_SCROLL',
            username: currentExport.username,
            options: {
                batchSize: 50,
                batchPauseMs: 4000,
                scrollDelayMs: 1400,
                stagnantProbeLimit: 10,
                endConfirmationLimit: 3,
                recoveryPauseMs: 6000,
                endStableMs: 30000,
                hardEndIdleMs: 55000,
                stepRatio: 0.82,
                quantityLimit: currentExport.settings?.quantityLimit || 0,
                capturePeriod: normalizeCapturePeriod(currentExport.settings?.capturePeriod),
                periodReferenceDateMs: Number(currentExport.scrollCaptureStats?.periodReferenceDateMs || 0) || null,
                periodCutoffDateMs: Number(currentExport.scrollCaptureStats?.periodCutoffDateMs || 0) || null,
                periodFrontierDateMs: Number(currentExport.scrollCaptureStats?.periodFrontierDateMs || 0) || null,
                startFromTop: !resumeExisting
            }
        });
    } catch (_) {
        if (profileScrollCapture?.tabId === tab.id) profileScrollCapture = null;
        throw new Error('RELOAD_X_PAGE');
    }

    if (!started?.success) {
        if (profileScrollCapture?.tabId === tab.id) profileScrollCapture = null;
        throw new Error(started?.error || 'SCROLL_CAPTURE_FAILED');
    }

    if (started.profile) {
        currentExport.userInfo = {
            ...currentExport.userInfo,
            ...started.profile,
            screenName: started.profile.screenName || currentExport.username,
            profileSource: started.profile.source || 'PERFIL_X_INTERFAZ_VISIBLE'
        };
        await saveCurrentState({ bestEffort: true });
    }

    broadcastStatus({
        running: true,
        status: 'scrolling',
        username: currentExport.username,
        tweetCount: currentExport.tweetCount,
        expectedTweets: getExpectedItemCount(),
        quantityLimit: currentExport.settings?.quantityLimit || 0,
        batch: 1,
        exportMode: currentExport.exportMode
    });

    const result = await completion;
    const terminalCaptureError = result?.error && result.reason === 'ERROR'
        ? result.error
        : (result?.error === 'SCROLL_CAPTURE_TIMEOUT' ? 'SCROLL_CAPTURE_TIMEOUT' : null);

    // Even if the page stopped with an error, preserve every unique row already
    // captured so the user can download the partial result instead of losing it.
    const allRows = await XPorterPostDB.getAllPosts();
    const databaseSummary = await XPorterPostDB.getSummary();
    const rawObservations = allRows.reduce(
        (sum, row) => sum + Math.max(1, Number(row?.seen_count || 1)),
        0
    );
    const filtered = allRows.filter(row => shouldIncludeCapturedPost(row, currentExport.settings));
    filtered.sort((a, b) => (b.created_at_ms || 0) - (a.created_at_ms || 0));

    const periodResult = filterRowsByCapturePeriod(
        filtered,
        currentExport.settings?.capturePeriod
    );
    const limit = Number(currentExport.settings?.quantityLimit || 0);
    const periodRows = periodResult.rows;
    const rows = limit > 0 ? periodRows.slice(0, limit) : periodRows;
    await persistProfileScrollRows(rows);
    currentExport.scrollCaptureResult = {
        reason: result?.reason || 'END_REACHED',
        cycles: Number(result?.cycles || 0),
        stagnantCycles: Number(result?.stagnantCycles || 0),
        endConfirmations: Number(result?.endConfirmations || 0),
        finalPosition: result?.finalPosition || null,
        rawUniquePosts: allRows.length,
        exportedPosts: rows.length,
        capturePeriod: periodResult.period,
        periodReferenceDate: periodResult.referenceDateMs
            ? new Date(periodResult.referenceDateMs).toISOString()
            : null,
        periodCutoffDate: periodResult.cutoffDateMs
            ? new Date(periodResult.cutoffDateMs).toISOString()
            : null,
        excludedBeforePeriod: periodResult.excludedBeforeCutoff,
        excludedWithoutDate: periodResult.excludedWithoutDate,
        includedWithoutTrustedDate: periodResult.includedWithoutTrustedDate,
        rawObservations,
        duplicatesMerged: Math.max(0, rawObservations - allRows.length),
        identifierQuality: {
            ids_numericos: allRows.filter(row => /^\d{5,30}$/.test(String(row?.id || ''))).length,
            ids_invalidos: allRows.filter(row => !/^\d{5,30}$/.test(String(row?.id || ''))).length,
            limite_base_local: Number(databaseSummary?.maxPosts || 0) || null
        },
        periodReachedInScroll: result?.periodReached === true
    };
    await saveCurrentState();
    if (terminalCaptureError) throw new Error(terminalCaptureError);
}


// Convierte contadores públicos a un número no negativo o null. Se mantiene
// en ámbito global porque lo utilizan los lectores de perfil de Instagram y
// Facebook.
function nullableCount(value) {
    if (value === null || value === undefined || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

// ==================== BI UCV: captura modular de Instagram ====================

function normalizeInstagramAccount(value) {
    return String(value || '').replace(/^@/, '').replace(/^\/+|\/+$/g, '').trim();
}

async function findOpenInstagramTab(account) {
    const wanted = normalizeInstagramAccount(account).toLowerCase();
    const patterns = ['https://www.instagram.com/*', 'https://instagram.com/*'];
    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true, url: patterns }).catch(() => []);
    const allTabs = await chrome.tabs.query({ url: patterns }).catch(() => []);
    const tabs = [...activeTabs, ...allTabs.filter(tab => !activeTabs.some(active => active.id === tab.id))];
    let postFallback = null;
    for (const tab of tabs) {
        try {
            const url = new URL(tab.url || '');
            const first = decodeURIComponent(url.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
            const postPage = /\/(?:p|reel|tv)\//i.test(url.pathname);
            if (!wanted || first === wanted) return tab;
            if (!postFallback && postPage) postFallback = tab;
        } catch (_) { /* skip */ }
    }
    return postFallback;
}

async function readProfileFromOpenInstagramTab(account) {
    const tab = await findOpenInstagramTab(account);
    if (!tab?.id) throw new Error('OPEN_INSTAGRAM_PROFILE');
    let response;
    try {
        response = await chrome.tabs.sendMessage(tab.id, { type: 'IG_READ_PROFILE' });
    } catch (_) {
        throw new Error('RELOAD_INSTAGRAM_PAGE');
    }
    if (!response?.success || !response.profile) throw new Error(response?.error || 'INSTAGRAM_PROFILE_READ_FAILED');
    const profile = response.profile;
    const screenName = profile.screenName || profile.username || normalizeInstagramAccount(account);
    return {
        id: profile.id || `instagram:${screenName}`,
        name: profile.name || screenName,
        screenName,
        url: profile.url || `https://www.instagram.com/${screenName}/`,
        biography: profile.biography || null,
        profileImageUrl: profile.profileImageUrl || null,
        followersCount: nullableCount(profile.followersCount),
        followersCountRaw: profile.followersCountRaw || null,
        followingCount: nullableCount(profile.followingCount),
        followingCountRaw: profile.followingCountRaw || null,
        postsCount: nullableCount(profile.postsCount),
        postsCountRaw: profile.postsCountRaw || null,
        tweetCount: nullableCount(profile.postsCount),
        isProtected: profile.isProtected === true,
        isVerified: profile.isVerified === true,
        source: profile.source || 'PERFIL_INSTAGRAM_INTERFAZ_VISIBLE',
        captureTabId: tab.id
    };
}

function waitForInstagramScrollCompletion(tabId) {
    return new Promise((resolve) => {
        const timeoutId = setTimeout(() => {
            if (!instagramScrollCapture || instagramScrollCapture.tabId !== tabId) return;
            const capture = instagramScrollCapture;
            instagramScrollCapture = null;
            resolve({ success: false, reason: 'TIMEOUT', error: 'INSTAGRAM_CAPTURE_TIMEOUT', total: capture.lastTotal || 0 });
        }, 6 * 60 * 60 * 1000);
        instagramScrollCapture = {
            tabId,
            startedAt: Date.now(),
            lastProgressAt: Date.now(),
            lastTotal: 0,
            processed: 0,
            duplicates: 0,
            capturePeriod: currentExport?.settings?.capturePeriod || 'first_10',
            resolve: (result) => {
                clearTimeout(timeoutId);
                resolve(result || { success: true, reason: 'END_REACHED', total: 0 });
            }
        };
    });
}

function exportableInstagramRow(row) {
    const internal = new Set(['first_seen_at', 'last_seen_at']);
    const result = {};
    for (const [key, value] of Object.entries(row || {})) if (!internal.has(key)) result[key] = value;
    result.observation_count = Math.max(1, Number(row?.seen_count || 1));
    delete result.seen_count;
    result.scraped_at = row?.last_seen_at ? new Date(row.last_seen_at).toISOString() : new Date().toISOString();
    return result;
}

function instagramCaracasDayKey(timestamp) {
    const numeric = Number(timestamp || 0);
    if (!Number.isFinite(numeric) || numeric <= 0) return 0;
    const date = new Date(numeric);
    if (!Number.isFinite(date.getTime())) return 0;
    try {
        const parts = new Intl.DateTimeFormat('en-CA', {
            timeZone: 'America/Caracas',
            year: 'numeric', month: '2-digit', day: '2-digit'
        }).formatToParts(date);
        const map = Object.fromEntries(parts.map(part => [part.type, part.value]));
        return Number(`${map.year}${map.month}${map.day}`) || 0;
    } catch (_) {
        return Number(date.toISOString().slice(0, 10).replaceAll('-', '')) || 0;
    }
}

function filterInstagramRowsForPeriod(rows, result, fallbackPeriod) {
    const period = String(result?.capturePeriod || fallbackPeriod || 'first_10');
    const cutoffDayKey = Number(result?.periodCutoffDayKey || 0);
    const referenceDayKey = instagramCaracasDayKey(result?.periodReferenceDateMs);
    if (!['last_month', 'last_3_months', 'last_year'].includes(period) || !cutoffDayKey) {
        return { rows: rows || [], excludedBefore: 0, excludedAfter: 0, undatedIncluded: 0 };
    }
    const kept = [];
    let excludedBefore = 0;
    let excludedAfter = 0;
    let undatedIncluded = 0;
    for (const row of rows || []) {
        const currentDayKey = instagramCaracasDayKey(row?.created_at_ms);
        if (!currentDayKey) {
            kept.push(row);
            undatedIncluded++;
        } else if (currentDayKey < cutoffDayKey) {
            excludedBefore++;
        } else if (referenceDayKey && currentDayKey > referenceDayKey) {
            excludedAfter++;
        } else {
            kept.push(row);
        }
    }
    return { rows: kept, excludedBefore, excludedAfter, undatedIncluded };
}

async function persistInstagramRows(rows) {
    currentExport.tweetCount = 0;
    currentExport.totalBatches = 0;
    currentExport.tweetBuffer = [];
    for (const row of rows || []) {
        currentExport.tweetBuffer.push(exportableInstagramRow(row));
        currentExport.tweetCount += 1;
        recordFirstItemOnce();
        if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) await flushExportBuffer();
    }
    await flushExportBuffer();
}

async function _fetchInstagramByModalLoop() {
    let tab = null;
    const preferredTabId = Number(currentExport?.userInfo?.captureTabId || 0);
    if (preferredTabId > 0) {
        tab = await chrome.tabs.get(preferredTabId).catch(() => null);
        if (tab) {
            try {
                if (!/(^|\.)instagram\.com$/i.test(new URL(tab.url || '').hostname)) tab = null;
            } catch (_) {
                tab = null;
            }
        }
    }
    if (!tab) tab = await findOpenInstagramTab(currentExport.username);
    if (!tab?.id) throw new Error('OPEN_INSTAGRAM_PROFILE');
    const resumeExisting = currentExport.instagramScrollResume === true;
    if (!resumeExisting) {
        await InstagramPostDB.clear();
        currentExport.tweetCount = 0;
        currentExport.totalBatches = 0;
        currentExport.tweetBuffer = [];
    } else {
        const existing = await InstagramPostDB.getSummary();
        currentExport.tweetCount = existing.count;
        currentExport.tweetBuffer = [];
    }
    currentExport.status = 'scrolling';
    currentExport.captureMethod = 'INSTAGRAM_MODAL_NEXT_PASSIVE';
    await saveCurrentState();

    const completion = waitForInstagramScrollCompletion(tab.id);
    let started;
    try {
        started = await chrome.tabs.sendMessage(tab.id, {
            type: 'IG_START_PROFILE_CAPTURE',
            username: currentExport.username,
            capturePeriod: currentExport.settings?.capturePeriod || 'first_10',
            resumeExisting
        });
    } catch (_) {
        if (instagramScrollCapture?.tabId === tab.id) {
            const failed = instagramScrollCapture;
            instagramScrollCapture = null;
            failed.resolve?.({ success: false, reason: 'ERROR', error: 'RELOAD_INSTAGRAM_PAGE', total: 0 });
        }
        throw new Error('RELOAD_INSTAGRAM_PAGE');
    }
    if (!started?.success) {
        if (instagramScrollCapture?.tabId === tab.id) {
            const failed = instagramScrollCapture;
            instagramScrollCapture = null;
            failed.resolve?.({ success: false, reason: 'ERROR', error: started?.error || 'INSTAGRAM_CAPTURE_FAILED', total: 0 });
        }
        throw new Error(started?.error || 'INSTAGRAM_CAPTURE_FAILED');
    }

    broadcastStatus({ running: true, status: 'scrolling', username: currentExport.username, socialPlatform: 'instagram', tweetCount: currentExport.tweetCount, batch: 1, exportMode: 'posts' });
    const result = await completion;
    const allRows = await InstagramPostDB.getAllPosts();
    const periodFilter = filterInstagramRowsForPeriod(allRows, result, currentExport.settings?.capturePeriod);
    const exportRows = periodFilter.rows;
    await persistInstagramRows(exportRows);
    currentExport.scrollCaptureResult = {
        reason: result?.reason || 'END_REACHED',
        rawUniquePosts: allRows.length,
        rawObservations: allRows.reduce((sum, row) => sum + Math.max(1, Number(row?.seen_count || 1)), 0),
        duplicatesMerged: Number(result?.duplicates || 0),
        exportedPosts: exportRows.length,
        excludedBeforePeriod: periodFilter.excludedBefore,
        excludedAfterReference: periodFilter.excludedAfter,
        undatedIncludedForQualityReview: periodFilter.undatedIncluded,
        capturePeriod: result?.capturePeriod || currentExport.settings?.capturePeriod || 'first_10',
        periodReferenceDate: result?.periodReferenceDateMs ? new Date(result.periodReferenceDateMs).toISOString() : null,
        periodCutoffDayKey: Number(result?.periodCutoffDayKey || 0) || null,
        periodReachedInScroll: result?.periodReached === true,
        processed: Number(result?.processed || 0),
        structuredPayloadsIndexed: Number(result?.structuredPayloadsIndexed || 0),
        currentShortcode: result?.currentShortcode || null,
        withDate: exportRows.filter(row => Number(row?.created_at_ms || 0) > 0).length,
        withoutDate: exportRows.filter(row => Number(row?.created_at_ms || 0) <= 0).length,
        withLikes: exportRows.filter(row => row?.like_count !== null).length,
        withComments: exportRows.filter(row => row?.comment_count !== null).length,
        withViews: exportRows.filter(row => row?.view_count !== null || row?.play_count !== null).length
    };
    await saveCurrentState();
    if (result?.reason === 'ERROR') throw new Error(result?.error || 'INSTAGRAM_CAPTURE_FAILED');
    if (result?.error === 'INSTAGRAM_CAPTURE_TIMEOUT') throw new Error('INSTAGRAM_CAPTURE_TIMEOUT');
}

// ==================== BI UCV: captura modular de Facebook ====================

function normalizeFacebookAccount(value) {
    return String(value || '').replace(/^@/, '').replace(/^\/+|\/+$/g, '').trim();
}

async function findOpenFacebookTab(account) {
    const wanted = normalizeFacebookAccount(account).toLowerCase();
    const tabs = await chrome.tabs.query({ url: ['https://www.facebook.com/*', 'https://web.facebook.com/*', 'https://m.facebook.com/*'] }).catch(() => []);
    for (const tab of tabs) {
        try {
            const url = new URL(tab.url || '');
            const first = decodeURIComponent(url.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
            const profileId = url.searchParams.get('id') || '';
            if (!wanted || first === wanted || profileId === wanted) return tab;
        } catch (_) { /* skip */ }
    }
    return null;
}

async function readProfileFromOpenFacebookTab(account) {
    const tab = await findOpenFacebookTab(account);
    if (!tab?.id) throw new Error('OPEN_FACEBOOK_PROFILE');
    let response;
    try {
        response = await chrome.tabs.sendMessage(tab.id, { type: 'FB_READ_PROFILE' });
    } catch (_) {
        throw new Error('RELOAD_FACEBOOK_PAGE');
    }
    if (!response?.success || !response.profile) throw new Error(response?.error || 'FACEBOOK_PROFILE_READ_FAILED');
    const profile = response.profile;
    const screenName = profile.screenName || normalizeFacebookAccount(account);
    return {
        id: profile.id || `facebook:${screenName}`,
        name: profile.name || screenName,
        screenName,
        url: profile.url || `https://www.facebook.com/${screenName}`,
        profileImageUrl: profile.profileImageUrl || null,
        accountType: profile.accountType || 'PERFIL',
        friendsCount: nullableCount(profile.friendsCount),
        friendsCountRaw: profile.friendsCountRaw || null,
        followersCount: nullableCount(profile.followersCount),
        followersCountRaw: profile.followersCountRaw || null,
        tweetCount: null,
        isProtected: false,
        isVerified: false,
        source: profile.source || 'PERFIL_FACEBOOK_INTERFAZ_VISIBLE',
        captureTabId: tab.id
    };
}

function waitForFacebookScrollCompletion(tabId) {
    return new Promise((resolve) => {
        const timeoutId = setTimeout(() => {
            if (!facebookScrollCapture || facebookScrollCapture.tabId !== tabId) return;
            const capture = facebookScrollCapture;
            facebookScrollCapture = null;
            capture.resolve = null;
            resolve({ success: false, reason: 'TIMEOUT', error: 'FACEBOOK_SCROLL_CAPTURE_TIMEOUT', total: capture.lastTotal || 0 });
        }, 6 * 60 * 60 * 1000);
        facebookScrollCapture = {
            tabId,
            startedAt: Date.now(),
            lastProgressAt: Date.now(),
            lastTotal: 0,
            progressEvents: 0,
            resolve: (result) => {
                clearTimeout(timeoutId);
                resolve(result || { success: true, reason: 'END_REACHED', total: 0 });
            }
        };
    });
}

const FACEBOOK_ANALYTICAL_DATE_PRECISIONS = new Set([
    'EXACTA', 'APROXIMADA_CALENDARIO'
]);
const FACEBOOK_ANALYTICAL_DATE_SOURCES = new Set([
    'DATA_UTIME', 'TIME_DATETIME', 'ABBR_TITLE', 'ARIA_LABELLEDBY_HEADER',
    'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT', 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT',
    'AUTHOR_DATE_HOVER_TOOLTIP',
    'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY', 'AUTHOR_DATE_ARIA_LABEL', 'AUTHOR_DATE_TITLE', 'AUTHOR_DATE_DIRECT_TEXT',
    'PERMALINK_ARIA_LABEL', 'PERMALINK_TITLE', 'PERMALINK_LABEL'
]);
const FACEBOOK_DIRECT_DATE_PRECISIONS = new Set(['EXACTA', 'APROXIMADA_CALENDARIO', 'RELATIVA_CONFIABLE']);

function isTrustedFacebookPublicationDate(row) {
    const precision = String(row?.date_precision || '').toUpperCase();
    const source = String(row?.date_source || '').toUpperCase();
    const ms = Number(row?.created_at_ms || 0);
    return FACEBOOK_ANALYTICAL_DATE_PRECISIONS.has(precision)
        && FACEBOOK_ANALYTICAL_DATE_SOURCES.has(source)
        && ms > 0
        && ms <= Date.now() + 10 * 60e3;
}

function isDirectFacebookPublicationDate(row) {
    return FACEBOOK_DIRECT_DATE_PRECISIONS.has(String(row?.date_precision || '').toUpperCase())
        && isTrustedFacebookPublicationDate(row);
}

function localDayStart(timestamp) {
    const date = new Date(Number(timestamp || 0));
    if (!Number.isFinite(date.getTime())) return null;
    date.setHours(0, 0, 0, 0);
    return date.getTime();
}

function localDayEnd(timestamp) {
    const date = new Date(Number(timestamp || 0));
    if (!Number.isFinite(date.getTime())) return null;
    date.setHours(23, 59, 59, 999);
    return date.getTime();
}

function localNoon(timestamp) {
    const date = new Date(Number(timestamp || 0));
    if (!Number.isFinite(date.getTime())) return Date.now();
    date.setHours(12, 0, 0, 0);
    return date.getTime();
}

function comparableFacebookText(value) {
    return String(value || '')
        .normalize('NFKC')
        .toLowerCase()
        .replace(/\b(?:ver más|ver menos|see more|see less)\b/gi, ' ')
        .replace(/https?:\/\/\S+/gi, ' ')
        .replace(/[^\p{L}\p{N}\s]+/gu, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function facebookRowsLikelySame(a, b) {
    const x = comparableFacebookText(a?.text);
    const y = comparableFacebookText(b?.text);
    if (!x || !y) return true;
    const shorter = x.length <= y.length ? x : y;
    const longer = x.length > y.length ? x : y;
    if (shorter.length >= 40 && longer.startsWith(shorter.slice(0, Math.min(shorter.length, 220)))) return true;
    const words = new Set(shorter.split(' ').filter(word => word.length > 3));
    if (!words.size) return shorter === longer;
    const common = longer.split(' ').filter(word => words.has(word)).length;
    return common / words.size >= 0.72;
}

function consolidateFacebookRowsBeforeDates(rows) {
    const output = [];
    const byId = new Map();
    const bySignature = new Map();
    const byMedia = new Map();
    const maxMetric = (a, b) => {
        const x = Number.isFinite(Number(a)) ? Number(a) : null;
        const y = Number.isFinite(Number(b)) ? Number(b) : null;
        if (x === null) return y;
        if (y === null) return x;
        return Math.max(x, y);
    };
    const merge = (existing, incoming) => {
        const base = { ...existing, ...incoming };
        const longer = String(incoming?.text || '').length > String(existing?.text || '').length ? incoming : existing;
        base.text = longer?.text || existing?.text || incoming?.text || '';
        base.content_signature = longer?.content_signature || existing?.content_signature || incoming?.content_signature || '';
        for (const metric of ['reactions_count', 'comments_count', 'shares_count', 'views_count']) base[metric] = maxMetric(existing?.[metric], incoming?.[metric]);
        base.media_urls = Array.from(new Set([...(existing?.media_urls || []), ...(incoming?.media_urls || [])])).slice(0, 30);
        base.media_asset_ids = Array.from(new Set([...(existing?.media_asset_ids || []), ...(incoming?.media_asset_ids || [])])).slice(0, 30);
        base.external_links = Array.from(new Set([...(existing?.external_links || []), ...(incoming?.external_links || [])])).slice(0, 30);
        base.feed_order = Math.min(...[existing?.feed_order, incoming?.feed_order].map(Number).filter(value => value > 0));
        if (!Number.isFinite(base.feed_order)) base.feed_order = Number(existing?.feed_order || incoming?.feed_order || 0);
        base.seen_count = Number(existing?.seen_count || 1) + Number(incoming?.seen_count || 1);
        const existingDirect = isDirectFacebookPublicationDate(existing);
        const incomingDirect = isDirectFacebookPublicationDate(incoming);
        const preferredDate = existingDirect ? existing : (incomingDirect ? incoming : (Number(existing?.created_at_ms || 0) > 0 ? existing : incoming));
        for (const field of ['created_at','created_at_ms','date_raw','date_visible_raw','date_tooltip_raw','date_privacy_title','date_precision','date_reference_at','date_source','date_has_explicit_time','date_timezone','date_is_estimated','date_confidence','date_interval_from','date_interval_to','date_locked']) base[field] = preferredDate?.[field];
        return base;
    };
    for (const row of rows || []) {
        let index = byId.get(row?.id);
        if (index === undefined && row?.content_signature) index = bySignature.get(row.content_signature);
        if (index === undefined) {
            for (const asset of row?.media_asset_ids || []) {
                const candidateIndex = byMedia.get(asset);
                if (candidateIndex !== undefined && facebookRowsLikelySame(output[candidateIndex], row)) { index = candidateIndex; break; }
            }
        }
        if (index === undefined) {
            index = output.length;
            output.push({ ...row });
        } else {
            output[index] = merge(output[index], row);
        }
        const saved = output[index];
        if (saved?.id) byId.set(saved.id, index);
        if (saved?.content_signature) bySignature.set(saved.content_signature, index);
        for (const asset of saved?.media_asset_ids || []) byMedia.set(asset, index);
    }
    return output;
}

function completeFacebookPublicationDates(rows, capturePeriod, referenceHint = null, cutoffHint = null) {
    const period = normalizeCapturePeriod(capturePeriod);
    const months = UCV_CAPTURE_PERIOD_MONTHS[period] || 0;
    const output = consolidateFacebookRowsBeforeDates(rows).map(row => ({ ...row }));
    const ordered = output.slice().sort((a, b) => {
        const ao = Number(a?.feed_order || 0);
        const bo = Number(b?.feed_order || 0);
        if (ao && bo && ao !== bo) return ao - bo;
        if (ao && !bo) return -1;
        if (!ao && bo) return 1;
        const ay = Number(a?.first_seen_scroll_y || 0);
        const by = Number(b?.first_seen_scroll_y || 0);
        if (ay !== by) return ay - by;
        const ac = Number(a?.first_seen_cycle || 0);
        const bc = Number(b?.first_seen_cycle || 0);
        if (ac !== bc) return ac - bc;
        return Number(a?.first_seen_at || 0) - Number(b?.first_seen_at || 0);
    });

    const directDates = ordered.filter(isDirectFacebookPublicationDate);
    const observedMax = Math.max(0, ...directDates.map(row => Number(row.created_at_ms || 0)));
    const referenceDateMs = Math.min(
        Number(referenceHint || 0) || observedMax || Date.now(),
        Date.now()
    );
    const rawCutoff = Number(cutoffHint || 0) || (months ? subtractUtcCalendarMonths(referenceDateMs, months) : null);
    const cutoffDateMs = rawCutoff ? localDayStart(rawCutoff) : null;

    let inferredByOrder = 0;
    let inferredByLimit = 0;
    let captureFallback = 0;

    ordered.forEach((row) => {
        if (isTrustedFacebookPublicationDate(row)) {
            row.date_is_estimated = row.date_is_estimated === true;
            row.date_confidence = row.date_confidence || 'ALTA';
            return;
        }

        // Desde esta versión no se interpolan fechas por posición en el feed.
        // Si no se logra leer una fecha visible del encabezado, la publicación
        // conserva el estado NO_DETECTADA para evitar fechas inventadas.
        row.created_at = '';
        row.created_at_ms = 0;
        row.date_raw = row.date_raw || null;
        row.date_precision = 'NO_DETECTADA';
        row.date_source = 'NO_DETECTADA';
        row.date_reference_at = '';
        row.date_has_explicit_time = false;
        row.date_timezone = row.date_timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || null;
        row.date_is_estimated = false;
        row.date_confidence = 'NO_DISPONIBLE';
        row.date_interval_from = '';
        row.date_interval_to = '';
    });

    return {
        rows: output,
        orderedRows: ordered,
        period,
        referenceDateMs,
        cutoffDateMs,
        inferredByOrder,
        inferredByLimit,
        captureFallback,
        originalMissingDates: output.filter(row => !isTrustedFacebookPublicationDate(row)).length
    };
}

async function waitForTabComplete(tabId, timeoutMs = 20000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
        const tab = await chrome.tabs.get(tabId).catch(() => null);
        if (!tab) throw new Error('AUXILIARY_TAB_CLOSED');
        if (tab.status === 'complete') return tab;
        await new Promise(resolve => setTimeout(resolve, 250));
    }
    throw new Error('AUXILIARY_TAB_TIMEOUT');
}

async function enrichFacebookRowsWithAuxiliaryTab(rows, account) {
    const candidates = (rows || []).filter(row => currentExport?.running !== false
        && String(row?.identifier_scope || '').toUpperCase() === 'MULTIMEDIA'
        && Boolean(row?.permalink));
    if (!candidates.length) return { attempted: 0, success: 0, failed: 0, securityStopped: false };
    let tabId = null;
    let attempted = 0;
    let success = 0;
    let failed = 0;
    let securityStopped = false;
    try {
        const created = await chrome.tabs.create({ url: 'about:blank', active: false });
        tabId = created?.id || null;
        if (!tabId) throw new Error('AUXILIARY_TAB_CREATE_FAILED');
        for (const row of candidates) {
            if (!currentExport?.running) break;
            attempted += 1;
            row.permalink_enrichment_attempted = true;
            row.permalink_enrichment_attempt_count = Math.max(0, Number(row.permalink_enrichment_attempt_count || 0)) + 1;
            try {
                await chrome.tabs.update(tabId, { url: row.permalink, active: false });
                await waitForTabComplete(tabId, 18000);
                await new Promise(resolve => setTimeout(resolve, 900));
                const response = await chrome.tabs.sendMessage(tabId, {
                    type: 'FB_RESOLVE_CURRENT_PAGE_PERMALINK',
                    account
                }).catch(() => ({ error: 'AUXILIARY_CONTENT_SCRIPT_UNAVAILABLE' }));
                if (response?.securityCheckpoint) {
                    row.permalink_enrichment_error = 'FACEBOOK_SECURITY_CHECK_DETECTED';
                    row.permalink_enrichment_success = false;
                    await FacebookPostDB.upsertPosts([row], { operationName: 'FacebookAuxiliaryTabV1' });
                    securityStopped = true;
                    failed += 1;
                    break;
                }
                const info = response?.permalinkInfo;
                if (!info?.nativeId || info?.identifierScope !== 'PUBLICACION') {
                    row.permalink_enrichment_error = response?.error || 'AUXILIARY_PERMALINK_NOT_FOUND';
                    row.permalink_enrichment_success = false;
                    await FacebookPostDB.upsertPosts([row], { operationName: 'FacebookAuxiliaryTabV1' });
                    failed += 1;
                } else {
                    const promoted = {
                        ...row,
                        id: `facebook:native:${info.nativeId}`,
                        native_id: info.nativeId,
                        identifier_quality: 'NATIVO',
                        identifier_source: `AUXILIARY_${info.identifierSource || 'PUBLICATION'}`,
                        identifier_scope: 'PUBLICACION',
                        provisional_id: false,
                        permalink: info.href,
                        permalink_source: info.sourceHref || info.href,
                        permalink_quality: info.permalinkQuality || 'NATIVA',
                        permalink_enrichment_source: 'AUXILIARY_TAB',
                        permalink_enrichment_success: true,
                        permalink_enrichment_error: '',
                        source_method: 'FACEBOOK_AUXILIARY_TAB_V1'
                    };
                    await FacebookPostDB.upsertPosts([promoted], { operationName: 'FacebookAuxiliaryTabV1' });
                    success += 1;
                }
            } catch (error) {
                row.permalink_enrichment_error = error?.message || 'AUXILIARY_PERMALINK_FAILED';
                row.permalink_enrichment_success = false;
                await FacebookPostDB.upsertPosts([row], { operationName: 'FacebookAuxiliaryTabV1' }).catch(() => {});
                failed += 1;
            }
            await new Promise(resolve => setTimeout(resolve, 1200));
        }
    } finally {
        if (tabId) await chrome.tabs.remove(tabId).catch(() => {});
    }
    return { attempted, success, failed, securityStopped };
}

function filterFacebookRowsByPeriod(rows, capturePeriod, referenceHint = null, cutoffHint = null) {
    const completion = completeFacebookPublicationDates(rows, capturePeriod, referenceHint, cutoffHint);
    const period = completion.period;
    if (period === 'first_10') {
        const orderedRows = completion.rows.slice().sort((a, b) => {
            const ao = Number(a?.feed_order || 0);
            const bo = Number(b?.feed_order || 0);
            if (ao > 0 && bo > 0 && ao !== bo) return ao - bo;
            if (ao > 0 && bo <= 0) return -1;
            if (ao <= 0 && bo > 0) return 1;
            return Number(a?.first_seen_at || 0) - Number(b?.first_seen_at || 0);
        });
        const selected = orderedRows.slice(0, 10);
        const validDates = selected
            .filter(isTrustedFacebookPublicationDate)
            .map(row => Number(row?.created_at_ms || 0))
            .filter(value => value > 0);
        const referenceDateMs = validDates.length ? Math.max(...validDates) : completion.referenceDateMs;
        const undatedRows = selected.filter(row => !isTrustedFacebookPublicationDate(row));
        return {
            rows: selected,
            period,
            referenceDateMs: referenceDateMs || null,
            cutoffDateMs: null,
            excludedBeforeCutoff: 0,
            excludedAfterReference: 0,
            excludedWithoutDate: 0,
            includedWithoutTrustedDate: undatedRows.length,
            pendingWithoutDate: undatedRows.length,
            inferredByOrder: 0,
            inferredByLimit: 0,
            captureFallback: 0,
            originalMissingDates: completion.originalMissingDates
        };
    }
    const months = UCV_CAPTURE_PERIOD_MONTHS[period] || 0;
    const referenceDateMs = completion.referenceDateMs;
    const cutoffDateMs = completion.cutoffDateMs;
    const referenceEndMs = localDayEnd(referenceDateMs) || Date.now();
    let excludedBeforeCutoff = 0;
    let excludedAfterReference = 0;
    const datedRows = [];
    const undatedRows = [];

    for (const row of completion.rows) {
        const ms = Number(row?.created_at_ms || 0);
        if (!ms || !isTrustedFacebookPublicationDate(row)) {
            undatedRows.push(row);
            continue;
        }
        if (months && cutoffDateMs && localDayStart(ms) < cutoffDateMs) {
            excludedBeforeCutoff += 1;
            continue;
        }
        if (localDayStart(ms) > localDayStart(referenceEndMs)) {
            excludedAfterReference += 1;
            continue;
        }
        datedRows.push(row);
    }

    datedRows.sort((a, b) => Number(b.created_at_ms || 0) - Number(a.created_at_ms || 0)
        || Number(a.feed_order || 0) - Number(b.feed_order || 0));
    undatedRows.sort((a, b) => Number(a.feed_order || 0) - Number(b.feed_order || 0));

    return {
        // Los registros sin fecha no se eliminan: viajan al JSON y serán
        // separados en publicaciones_pendientes_fecha por downloads.js.
        rows: [...datedRows, ...undatedRows],
        period,
        referenceDateMs,
        cutoffDateMs,
        excludedBeforeCutoff,
        excludedAfterReference,
        excludedWithoutDate: 0,
        includedWithoutTrustedDate: undatedRows.length,
        pendingWithoutDate: undatedRows.length,
        inferredByOrder: 0,
        inferredByLimit: 0,
        captureFallback: 0,
        originalMissingDates: completion.originalMissingDates
    };
}

function exportableFacebookRow(row) {
    const internal = new Set(['first_seen_at', 'last_seen_at']);
    const result = {};
    for (const [key, value] of Object.entries(row || {})) if (!internal.has(key)) result[key] = value;
    result.observation_count = Math.max(1, Number(row?.seen_count || 1));
    delete result.seen_count;
    result.scraped_at = row?.last_seen_at ? new Date(row.last_seen_at).toISOString() : new Date().toISOString();
    return result;
}

async function persistFacebookRows(rows) {
    currentExport.tweetCount = 0;
    currentExport.totalBatches = 0;
    currentExport.tweetBuffer = [];
    for (const row of rows) {
        currentExport.tweetBuffer.push(exportableFacebookRow(row));
        currentExport.tweetCount += 1;
        recordFirstItemOnce();
        if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) await flushExportBuffer();
    }
    await flushExportBuffer();
}

async function _fetchFacebookByProfileScrollLoop() {
    const tab = await findOpenFacebookTab(currentExport.username);
    if (!tab?.id) throw new Error('OPEN_FACEBOOK_PROFILE');
    const resumeExisting = currentExport.facebookScrollResume === true;
    if (!resumeExisting) {
        await FacebookPostDB.clear();
        currentExport.tweetCount = 0;
        currentExport.totalBatches = 0;
        currentExport.tweetBuffer = [];
    } else {
        const existing = await FacebookPostDB.getSummary();
        currentExport.tweetCount = existing.count;
        currentExport.tweetBuffer = [];
    }
    currentExport.status = 'scrolling';
    currentExport.captureMethod = 'FACEBOOK_BROWSER_ONE_PASS_ACTION_MENU';
    await saveCurrentState();

    const requestedZoom = 0.4;
    let originalZoom = 1;
    let appliedZoom = null;
    let result;

    try {
        // La comunidad se lee antes de modificar el zoom. Luego la captura de
        // publicaciones usa un zoom temporal y se restaura en el bloque finally.
        const preZoomProfile = await chrome.tabs.sendMessage(tab.id, { type: 'FB_READ_PROFILE' }).catch(() => null);
        if (preZoomProfile?.success && preZoomProfile.profile) {
            currentExport.userInfo = {
                ...currentExport.userInfo,
                ...preZoomProfile.profile,
                id: currentExport.userInfo?.id || `facebook:${currentExport.username}`
            };
        }

        originalZoom = await chrome.tabs.getZoom(tab.id).catch(() => 1);
        await chrome.tabs.setZoom(tab.id, requestedZoom);
        await new Promise(resolve => setTimeout(resolve, 1450));
        appliedZoom = await chrome.tabs.getZoom(tab.id).catch(() => requestedZoom);

        const completion = waitForFacebookScrollCompletion(tab.id);
        let started;
        try {
            started = await chrome.tabs.sendMessage(tab.id, {
                type: 'FB_START_PROFILE_SCROLL',
                account: currentExport.username,
                options: {
                    batchSize: 100,
                    batchPauseMs: 700,
                    scrollDelayMs: 620,
                    stagnantProbeLimit: 8,
                    endConfirmationLimit: 3,
                    endStableMs: 12000,
                    captureZoom: appliedZoom,
                    alignSettleMs: 135,
                    expandDelayMs: 260,
                    dateAttempts: 6,
                    dateDelayMs: 90,
                    confirmDelayMs: 155,
                    metricDelayMs: 185,
                    tooltipDelayMs: 260,
                    capturePeriod: normalizeCapturePeriod(currentExport.settings?.capturePeriod),
                    periodReferenceDateMs: Number(currentExport.scrollCaptureStats?.periodReferenceDateMs || 0) || null,
                    periodCutoffDateMs: Number(currentExport.scrollCaptureStats?.periodCutoffDateMs || 0) || null,
                    periodFrontierDateMs: Number(currentExport.scrollCaptureStats?.periodFrontierDateMs || 0) || null,
                    startFromTop: !resumeExisting
                }
            });
        } catch (_) {
            if (facebookScrollCapture?.tabId === tab.id) {
                const failedCapture = facebookScrollCapture;
                facebookScrollCapture = null;
                failedCapture.resolve?.({ success: false, reason: 'ERROR', error: 'RELOAD_FACEBOOK_PAGE', total: 0 });
            }
            throw new Error('RELOAD_FACEBOOK_PAGE');
        }
        if (!started?.success) {
            if (facebookScrollCapture?.tabId === tab.id) {
                const failedCapture = facebookScrollCapture;
                facebookScrollCapture = null;
                failedCapture.resolve?.({ success: false, reason: 'ERROR', error: started?.error || 'FACEBOOK_SCROLL_CAPTURE_FAILED', total: 0 });
            }
            throw new Error(started?.error || 'FACEBOOK_SCROLL_CAPTURE_FAILED');
        }
        if (started.profile) {
            currentExport.userInfo = {
                ...currentExport.userInfo,
                ...started.profile,
                id: currentExport.userInfo?.id || `facebook:${currentExport.username}`
            };
            await saveCurrentState({ bestEffort: true });
        }
        broadcastStatus({ running: true, status: 'scrolling', username: currentExport.username, socialPlatform: 'facebook', tweetCount: currentExport.tweetCount, batch: 1, exportMode: 'posts' });
        result = await completion;
    } finally {
        await chrome.tabs.setZoom(tab.id, Number(originalZoom || 1)).catch(() => null);
    }

    const allRows = await FacebookPostDB.getAllPosts();
    const databaseSummary = await FacebookPostDB.getSummary();
    const periodResult = filterFacebookRowsByPeriod(
        allRows,
        currentExport.settings?.capturePeriod,
        result?.periodReferenceDateMs,
        result?.periodCutoffDateMs
    );
    await persistFacebookRows(periodResult.rows);
    currentExport.scrollCaptureResult = {
        reason: result?.reason || 'END_REACHED',
        cycles: Number(result?.cycles || 0),
        stagnantCycles: Number(result?.stagnantCycles || 0),
        endConfirmations: Number(result?.endConfirmations || 0),
        finalPosition: result?.finalPosition || null,
        rawUniquePosts: allRows.length,
        rawObservations: Number(databaseSummary?.observations || 0),
        duplicatesMerged: Number(databaseSummary?.duplicatesMerged || 0),
        exportedPosts: periodResult.rows.length,
        capturePeriod: periodResult.period,
        periodReferenceDate: periodResult.referenceDateMs ? new Date(periodResult.referenceDateMs).toISOString() : null,
        periodCutoffDate: periodResult.cutoffDateMs ? new Date(periodResult.cutoffDateMs).toISOString() : null,
        excludedBeforePeriod: periodResult.excludedBeforeCutoff,
        excludedWithoutDate: periodResult.excludedWithoutDate,
        includedWithoutTrustedDate: periodResult.includedWithoutTrustedDate,
        pendingWithoutDate: periodResult.pendingWithoutDate,
        excludedAfterReference: periodResult.excludedAfterReference,
        inferredByOrder: periodResult.inferredByOrder,
        inferredByLimit: periodResult.inferredByLimit,
        captureDateFallback: periodResult.captureFallback,
        originalMissingDates: periodResult.originalMissingDates,
        periodReachedInScroll: result?.periodReached === true,
        traversalMode: result?.traversalMode || 'ONE_PASS_PRIVACY_TOOLTIP_V26',
        originalZoom: Number(originalZoom || 1),
        captureZoom: Number(result?.captureZoom || appliedZoom || requestedZoom),
        zoomRestored: true,
        cardsProcessed: Number(result?.cardsProcessed || 0),
        actionMenusProcessed: Number(result?.actionMenusProcessed || 0),
        cardsWithDate: Number(result?.cardsWithDate || 0),
        cardsWithoutDate: Number(result?.cardsWithoutDate || 0),
        cardsWithMetricZone: Number(result?.cardsWithMetricZone || 0),
        cardsWithHeaderVisible: Number(result?.cardsWithHeaderVisible || 0),
        cardsWithoutHeaderVisible: Number(result?.cardsWithoutHeaderVisible || 0),
        cardsFullyVisible: Number(result?.cardsFullyVisible || 0),
        cardsWithLocalDateRetry: Number(result?.cardsWithLocalDateRetry || 0),
        localMetricFallbacks: Number(result?.localMetricFallbacks || 0),
        relativeDateTooltipAttempts: Number(result?.relativeDateTooltipAttempts || 0),
        relativeDateTooltipResolved: Number(result?.relativeDateTooltipResolved || 0),
        privacyDateLinksFound: Number(result?.privacyDateLinksFound || 0),
        privacyTooltipAttempts: Number(result?.privacyTooltipAttempts || 0),
        privacyTooltipResolved: Number(result?.privacyTooltipResolved || 0),
        expandedCards: Number(result?.expandedCards || 0),
        loadProbes: Number(result?.loadProbes || 0)
    };
    await saveCurrentState();
    if (result?.reason === 'ERROR') throw new Error(result?.error || 'FACEBOOK_SCROLL_CAPTURE_FAILED');
    if (result?.error === 'FACEBOOK_SCROLL_CAPTURE_TIMEOUT') throw new Error('FACEBOOK_SCROLL_CAPTURE_TIMEOUT');
}

// ==================== Posts Fetch Loop ====================

// Seed a de-dup set with saved IDs. Cursor-based exports only need a recent
// overlap window, but date-range search capture restarts from the beginning of
// the X search page on resume, so it must preload the whole saved export.
async function preloadSeenIds(seenIds) {
    if (!currentExport || !currentExport.totalBatches) return;
    try {
        if (currentExport.dateFrom || currentExport.dateTo) {
            const savedItems = await XPorterStorage.loadAllTweets();
            for (const item of savedItems) {
                if (item?.id) seenIds.add(item.id);
            }
            return;
        }

        const startBatch = Math.max(0, currentExport.totalBatches - 3);
        for (let i = startBatch; i < currentExport.totalBatches; i++) {
            const batch = await XPorterStorage.loadTweetBatch(i);
            for (const item of batch) {
                if (item?.id) seenIds.add(item.id);
            }
        }
    } catch (_) { /* best-effort dedup */ }
}

// Cursor pagination can overlap around page boundaries, but retaining every ID
// from a multi-million-row run wastes hundreds of MB. Keep only a generous
// recent window; persisted batches remain the source of truth across resumes.
function createRecentIdTracker(seed, requestedLimit) {
    const limit = Math.max(1, Number(requestedLimit) || XPORTER_CONFIG.RECENT_EXPORT_ID_LIMIT || 1000);
    const order = Array.from(seed || []).slice(-limit);
    const seen = new Set(order);
    let nextEviction = 0;

    return {
        add(id) {
            if (seen.has(id)) return false;
            if (seen.size === limit) {
                seen.delete(order[nextEviction]);
                order[nextEviction] = id;
                nextEviction = (nextEviction + 1) % limit;
            } else {
                order.push(id);
            }
            seen.add(id);
            return true;
        },
        get size() { return seen.size; }
    };
}

function quantityLimitReached() {
    const limit = currentExport?.settings?.quantityLimit || 0;
    return limit > 0 && currentExport.tweetCount >= limit;
}

function getExpectedItemCount(exportState = currentExport) {
    const info = exportState?.userInfo || {};
    if (exportState?.exportMode === 'posts'
        && exportState?.settings?.capturePeriod === 'first_10') {
        return 10;
    }
    switch (exportState?.exportMode) {
        case 'following':
            return info.followingCount || 0;
        case 'followers':
        case 'verified_followers':
            return info.followersCount || 0;
        case 'posts':
        default:
            return info.tweetCount || 0;
    }
}

async function flushExportBuffer() {
    if (!currentExport?.tweetBuffer?.length) return;
    const ok = await XPorterStorage.saveTweetBatch(currentExport.totalBatches, currentExport.tweetBuffer);
    if (!ok) {
        // A failed write (quota, corruption) must abort the export loudly —
        // silently dropping the batch would produce a "successful" export with
        // missing rows. Everything already persisted stays downloadable.
        // The in-memory rows are not downloadable and will disappear when the
        // worker stops. Roll the public count back to the persisted count so a
        // resume can refetch this page instead of stopping early at the limit.
        currentExport.tweetCount = Math.max(0, currentExport.tweetCount - currentExport.tweetBuffer.length);
        currentExport.tweetBuffer = [];
        throw new Error('STORAGE_FULL');
    }
    currentExport.totalBatches++;
    currentExport.tweetBuffer = [];
}


async function ensureRepliesEndpointReady() {
    if (currentExport?.settings?.timelineMode !== 'user_tweets_and_replies') return true;
    if (await XPorterAPI.waitForEndpoint('UserTweetsAndReplies', 1200)) return true;

    // Ask the currently visible Replies tab to make a normal small scroll so X
    // emits another UserTweetsAndReplies request that the interceptor can learn.
    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs.find(item => item?.id && /^https:\/\/(x\.com|twitter\.com)\//.test(item.url || ''));
        if (tab?.id) {
            await chrome.tabs.sendMessage(tab.id, { type: 'UCV_WARMUP_REPLIES' }).catch(() => null);
        }
    } catch (_) { /* discovery will still try bundles/cache below */ }

    return await XPorterAPI.waitForEndpoint('UserTweetsAndReplies', 8000);
}

async function _fetchPostsLoop() {
    if (currentExport.settings?.timelineMode === 'user_tweets_and_replies' && !currentExport.cursor) {
        await ensureRepliesEndpointReady();
    }

    if (currentExport.dateFrom || currentExport.dateTo) {
        await _fetchPostsByDateRangeLoop();
        return;
    }

    let hasMore = true;
    let emptyPages = 0;
    const seenIds = new Set();
    await preloadSeenIds(seenIds);
    const recentIds = createRecentIdTracker(seenIds);

    while (hasMore && currentExport.running) {
        // Check quantity limit
        if (quantityLimitReached()) {
            break;
        }

        const requestCursor = currentExport.cursor;
        const result = await rateLimiter.executeWithRateLimit(async () => {
            const fetchTimeline = currentExport.settings.timelineMode === 'user_tweets_and_replies'
                ? XPorterAPI.fetchUserTweetsAndReplies
                : XPorterAPI.fetchUserTweets;
            return await fetchTimeline(
                currentExport.userId,
                requestCursor
            );
        });
        if (!currentExport.running) break;

        if (!result.tweets || result.tweets.length === 0) {
            const cursorAdvanced = !!result.nextCursor && result.nextCursor !== requestCursor;
            emptyPages = cursorAdvanced ? 0 : (emptyPages + 1);
            if (emptyPages >= 3) {
                hasMore = false;
                break;
            }
        } else {
            emptyPages = 0;
        }

        // Process tweets. (No date filtering here: exports with a date range are
        // diverted to _fetchPostsByDateRangeLoop at the top of _fetchPostsLoop.)
        for (const tweet of (result.tweets || [])) {
            if (!shouldIncludeCapturedPost(tweet, currentExport.settings)) continue;

            if (!recentIds.add(tweet.id)) continue;
            if (quantityLimitReached()) {
                hasMore = false;
                break;
            }
            // Inject author info if missing
            if (!tweet.author_name && currentExport.userInfo) {
                tweet.author_name = currentExport.userInfo.name || '';
                tweet.author_username = currentExport.userInfo.screenName || currentExport.username || '';
                if (tweet.tweet_url && tweet.tweet_url.includes('/undefined/')) {
                    tweet.tweet_url = tweet.tweet_url.replace('/undefined/', `/${tweet.author_username}/`);
                }
            }

            currentExport.tweetBuffer.push(tweet);
            currentExport.tweetCount++;
            recordFirstItemOnce();

            if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) {
                await flushExportBuffer();
            }
        }

        if (quantityLimitReached()) {
            hasMore = false;
        }

        // Update cursor
        // Keep the current cursor when stopping on a quantity limit so resume
        // can refetch the same page and skip already-saved IDs.
        if (hasMore && result.nextCursor) {
            currentExport.cursor = result.nextCursor;
        } else if (hasMore) {
            hasMore = false;
        }

        // Persist the buffer BEFORE the advanced cursor: if the SW dies after
        // saveCurrentState, resume starts past these items with an empty buffer
        // and they would be lost forever.
        await flushExportBuffer();
        await saveCurrentState();

        broadcastStatus({
            running: true,
            status: 'fetching',
            username: currentExport.username,
            socialPlatform: currentExport.socialPlatform || 'x',
            tweetCount: currentExport.tweetCount,
            expectedTweets: getExpectedItemCount(),
            quantityLimit: currentExport.settings?.quantityLimit || 0,
            batch: Math.floor(rateLimiter.totalRequests / rateLimiter.batchSize) + 1,
            totalRequests: rateLimiter.totalRequests,
            exportMode: currentExport.exportMode
        });
    }
}

function normalizeDateBoundary(dateValue, boundary) {
    if (!dateValue) return null;

    const normalized = new Date(`${dateValue}T00:00:00.000Z`);
    if (isNaN(normalized.getTime())) return null;

    if (boundary === 'end') {
        normalized.setUTCHours(23, 59, 59, 999);
    }

    return normalized;
}

async function _fetchPostsByDateRangeLoop() {
    let hasMore = true;
    let emptyPages = 0;
    const seenIds = new Set();
    await preloadSeenIds(seenIds);
    const recentIds = createRecentIdTracker(seenIds);
    const rawQuery = buildDateRangeSearchQuery(currentExport.username, currentExport.dateFrom, currentExport.dateTo);
    let payload = null;

    await openSearchCaptureTab(rawQuery);

    try {
        payload = await waitForSearchCapturePayload(20000);
        // Slow machines/connections routinely need more than 20s for X's
        // search page to boot (real churn case: SEARCH_CAPTURE_TIMEOUT on the
        // most engaged user we ever lost). Before giving up, actively ping the
        // capture tab — requestNextSearchCapturePayload retries with scroll
        // nudges for up to ~48 more seconds.
        if (!payload) {
            payload = await requestNextSearchCapturePayload();
        }
        if (!payload) {
            throw new Error('SEARCH_CAPTURE_TIMEOUT');
        }
        await sendSearchCaptureStatus({ phaseKey: 'exporting' });

        let badPageStreak = 0;

        while (hasMore && currentExport.running) {
            if (quantityLimitReached()) {
                break;
            }

            // A captured payload can be an X error response (e.g. 429 while the
            // search tab is rate-limited) or a truncated body. Neither must be
            // counted as an "empty page" — that would end the export as
            // "complete" with a fraction of the range. Pause and re-request.
            let parsedPayload = null;
            if (payload.status >= 400) {
                badPageStreak++;
                if (badPageStreak > 5) throw new Error('RATE_LIMITED');
                const waitMs = payload.status === 429 ? 60000 : 10000;
                lastTransientStatus = {
                    running: true,
                    status: 'cooldown',
                    duration: waitMs,
                    until: Date.now() + waitMs,
                    kind: 'window',
                    reason: `SearchTimeline HTTP ${payload.status}`
                };
                broadcastStatus(lastTransientStatus);
                // Mirror the pause on the in-page overlay (amber countdown).
                await sendSearchCaptureStatus({ pauseUntil: Date.now() + waitMs });
                await swSleep(waitMs);
                if (!currentExport.running) break;
                await sendSearchCaptureStatus({ phaseKey: 'scrolling' });
                payload = await requestNextSearchCapturePayload();
                if (!payload && !searchLikelyComplete()) payload = await recoverStalledSearchCapture();
                if (!payload) {
                    if (currentExport.running && !searchLikelyComplete()) {
                        await flushExportBuffer();
                        await saveCurrentState();
                        throw new Error('RATE_LIMITED');
                    }
                    hasMore = false;
                }
                continue;
            }
            try {
                parsedPayload = XPorterAPI.parseSearchTimelineResponse(JSON.parse(payload.bodyText));
            } catch (_) {
                badPageStreak++;
                if (badPageStreak > 5) throw new Error('SEARCH_CAPTURE_TIMEOUT');
                // Let a retry of the same cursor URL through. The first response
                // was unusable, so treating the URL as permanently seen would
                // discard the later successful response and force a timeout.
                searchCapture?.seenUrls.delete(payload.url);
                payload = await requestNextSearchCapturePayload();
                if (!payload) hasMore = false;
                continue;
            }
            badPageStreak = 0;
            if (!currentExport.running) break;

            if (!parsedPayload.tweets || parsedPayload.tweets.length === 0) {
                emptyPages++;
                if (emptyPages >= 3) {
                    hasMore = false;
                    break;
                }
            } else {
                emptyPages = 0;
            }

            for (const tweet of (parsedPayload.tweets || [])) {
                if (!shouldIncludeCapturedPost(tweet, currentExport.settings)) continue;
                if (seenIds.has(tweet.id)) continue;
                if (quantityLimitReached()) {
                    hasMore = false;
                    break;
                }
                seenIds.add(tweet.id);

                if (!tweet.author_name && currentExport.userInfo) {
                    tweet.author_name = currentExport.userInfo.name || '';
                    tweet.author_username = currentExport.userInfo.screenName || currentExport.username || '';
                    if (tweet.tweet_url && tweet.tweet_url.includes('/undefined/')) {
                        tweet.tweet_url = tweet.tweet_url.replace('/undefined/', `/${tweet.author_username}/`);
                    }
                }

                const createdMs = toEpochMs(tweet.created_at);
                if (Number.isFinite(createdMs) && searchCapture) {
                    searchCapture.oldestCollectedMs = Math.min(
                        searchCapture.oldestCollectedMs ?? Infinity, createdMs);
                }

                currentExport.tweetBuffer.push(tweet);
                currentExport.tweetCount++;
                recordFirstItemOnce();

                if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) {
                    await flushExportBuffer();
                }
            }

            if (quantityLimitReached()) {
                hasMore = false;
            }
            if (hasMore && parsedPayload.nextCursor) {
                currentExport.cursor = parsedPayload.nextCursor;
                await sendSearchCaptureStatus({ phaseKey: 'scrolling' });
                payload = await requestNextSearchCapturePayload();
                // A cursor means X advertised more results — silence here is a
                // stalled/blocked timeline ("Something went wrong"), NOT the
                // end of data. Wait it out and retry; content.js clicks Retry
                // on every scroll ping. Never fake a "complete" — EXCEPT when:
                //  · the collected posts already reach (≥95% cover) the start
                //    of the requested range — silence IS the end there; or
                //  · the last page(s) were EMPTY (e.g. a range with no posts:
                //    X renders "No results", there is nothing to scroll, so no
                //    new request will ever fire). Recovering for minutes and
                //    then failing RATE_LIMITED turned "0 posts in range" into
                //    a fake error.
                const silenceIsEnd = () => emptyPages > 0 || searchLikelyComplete();
                if (!payload && !silenceIsEnd()) payload = await recoverStalledSearchCapture();
                if (!payload) {
                    if (currentExport.running && !silenceIsEnd()) {
                        await flushExportBuffer();
                        await saveCurrentState();
                        throw new Error('RATE_LIMITED');
                    }
                    hasMore = false;
                }
            } else {
                hasMore = false;
            }

            await flushExportBuffer();
            await saveCurrentState();
            await sendSearchCaptureStatus({ phaseKey: 'exporting' });

            broadcastStatus({
                running: true,
                status: 'fetching',
                username: currentExport.username,
                tweetCount: currentExport.tweetCount,
                expectedTweets: getExpectedItemCount(),
                quantityLimit: currentExport.settings?.quantityLimit || 0,
                batch: Math.floor(rateLimiter.totalRequests / rateLimiter.batchSize) + 1,
                totalRequests: rateLimiter.totalRequests,
                exportMode: currentExport.exportMode
            });
        }
    } finally {
        await closeSearchCaptureTab();
    }
}

function buildDateRangeSearchQuery(username, dateFrom, dateTo) {
    const parts = [`(from:${username})`];

    if (dateFrom) {
        parts.push(`since:${formatDateForSearch(dateFrom)}`);
    }

    if (dateTo) {
        const dayAfter = new Date(dateTo.getTime());
        dayAfter.setUTCDate(dayAfter.getUTCDate() + 1);
        parts.push(`until:${formatDateForSearch(dayAfter)}`);
    }

    return parts.join(' ');
}

function formatDateForSearch(date) {
    return date.toISOString().slice(0, 10);
}

// The live search feed runs newest → oldest, so once the oldest collected
// post sits within a day of the range start, a silent timeline means the end
// of the data — NOT a stall. Finishing cleanly here beats minutes of pointless
// rate-limit retries and a "failed" export stuck at 98%.
function dateRangeCovered() {
    const fromMs = toEpochMs(currentExport?.dateFrom);
    const oldest = searchCapture?.oldestCollectedMs;
    if (!Number.isFinite(fromMs) || !Number.isFinite(oldest)) return false;
    return (oldest - fromMs) <= 24 * 60 * 60 * 1000;
}

// How much of the requested date window is already collected, in percent.
// Date coverage only — never the quantity-limit progress, which measures a
// different thing (a user stopping at their own limit is not "out of posts").
function computeDateCoveragePct() {
    const fromMs = toEpochMs(currentExport?.dateFrom);
    let toMs = toEpochMs(currentExport?.dateTo);
    const oldest = searchCapture?.oldestCollectedMs;
    if (!Number.isFinite(fromMs) || !Number.isFinite(oldest)) return null;
    if (!Number.isFinite(toMs)) toMs = Date.now();
    if (toMs <= fromMs) return null;
    return Math.min(100, Math.max(0, ((toMs - oldest) / (toMs - fromMs)) * 100));
}

// Real churn case: oldest post in range was Jan 2 with the range starting
// Jan 1 — 38h gap, so the 24h rule alone kept "recovering" a finished export.
// ≥95% of the window collected + a silent timeline = done for all practical
// purposes; the sliver left is a gap in the user's posting, not missing data.
function searchLikelyComplete() {
    if (dateRangeCovered()) return true;
    const pct = computeDateCoveragePct();
    return Number.isFinite(pct) && pct >= 95;
}

function buildSearchTimelinePageUrl(rawQuery) {
    return `https://x.com/search?q=${encodeURIComponent(rawQuery)}&src=typed_query&f=live`;
}

async function openSearchCaptureTab(rawQuery) {
    await closeSearchCaptureTab();

    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true }).catch(() => []);

    // Arm the capture state before navigating to X. Creating the tab directly
    // at the search URL leaves a race where document_start can relay the first
    // SearchTimeline response before chrome.tabs.create() resolves; the worker
    // then drops the only payload because searchCapture does not exist yet.
    const tab = await chrome.tabs.create({
        url: 'about:blank',
        active: true
    });

    searchCapture = {
        tabId: tab.id,
        returnTabId: activeTab?.id || null,
        queue: [],
        resolver: null,
        seenUrls: new Set(),
        oldestCollectedMs: null // drives the overlay's date-based progress %
    };

    try {
        await chrome.tabs.update(tab.id, {
            url: buildSearchTimelinePageUrl(rawQuery)
        });
    } catch (_) {
        await closeSearchCaptureTab();
        throw new Error('SEARCH_CAPTURE_TIMEOUT');
    }

    setTimeout(() => {
        sendSearchCaptureStatus({ phaseKey: 'preparing' }, 8);
    }, 1000);
}

async function closeSearchCaptureTab() {
    if (!searchCapture) return;

    const { tabId, returnTabId, resolver } = searchCapture;
    searchCapture = null;

    if (resolver) {
        resolver(null);
    }

    if (typeof tabId === 'number') {
        try {
            await chrome.tabs.remove(tabId);
        } catch (_) {
            // Tab may already be closed
        }
    }

    if (typeof returnTabId === 'number') {
        try {
            await chrome.tabs.update(returnTabId, { active: true });
        } catch (_) {
            // Original tab may already be closed
        }
    }
}

function waitForSearchCapturePayload(timeoutMs = 10000) {
    if (!searchCapture) return Promise.resolve(null);
    if (searchCapture.queue.length > 0) {
        return Promise.resolve(searchCapture.queue.shift());
    }

    return new Promise((resolve) => {
        const activeCapture = searchCapture;
        const timer = setTimeout(() => {
            if (activeCapture && activeCapture.resolver === resolver) {
                activeCapture.resolver = null;
            }
            resolve(null);
        }, timeoutMs);

        const resolver = (payload) => {
            clearTimeout(timer);
            resolve(payload);
        };

        activeCapture.resolver = resolver;
    });
}

// The search page went quiet while we still hold a cursor — X's timeline is
// stalled (soft rate limit / "Something went wrong"). Pause with an amber
// countdown on the overlay and retry a few times; each scroll ping also clicks
// X's Retry button. Returns the recovered payload, or null to give up.
async function recoverStalledSearchCapture(rounds = 3, waitMs = 60000) {
    for (let round = 0; round < rounds; round++) {
        if (!currentExport?.running || !searchCapture) return null;
        lastTransientStatus = {
            running: true,
            status: 'cooldown',
            duration: waitMs,
            until: Date.now() + waitMs,
            kind: 'window',
            reason: 'Search timeline stalled (likely rate-limited)'
        };
        broadcastStatus(lastTransientStatus);
        await sendSearchCaptureStatus({ pauseUntil: Date.now() + waitMs });
        await swSleep(waitMs);
        if (!currentExport?.running || !searchCapture) return null;
        await sendSearchCaptureStatus({ phaseKey: 'scrolling' });
        const payload = await requestNextSearchCapturePayload();
        if (payload) return payload;
    }
    return null;
}

async function requestNextSearchCapturePayload() {
    if (!searchCapture?.tabId) return null;

    for (let attempt = 0; attempt < 6; attempt++) {
        try {
            await chrome.tabs.sendMessage(searchCapture.tabId, { type: 'XPORTER_SCROLL_SEARCH_PAGE' });
        } catch (_) {
            // Tab may still be loading; wait for the payload timeout instead
        }

        const payload = await waitForSearchCapturePayload(8000);
        if (payload) {
            return payload;
        }
    }

    return null;
}

// How far through the date-range export we are, in percent (null = unknown).
// Two independent signals, whichever is further along wins: items vs the
// quantity limit, and — since the live search feed runs newest → oldest —
// how deep into the requested date window the oldest collected post sits.
function computeSearchCaptureProgress() {
    if (!currentExport) return null;
    let pct = null;

    const limit = Number(currentExport.settings?.quantityLimit || 0);
    if (limit > 0) {
        pct = Math.min(100, ((currentExport.tweetCount || 0) / limit) * 100);
    }

    const datePct = computeDateCoveragePct();
    if (datePct !== null) {
        pct = (pct === null) ? datePct : Math.max(pct, datePct);
    }

    return pct === null ? null : Math.round(pct);
}

function toEpochMs(value) {
    if (!value) return NaN;
    const ms = (value instanceof Date) ? value.getTime() : new Date(value).getTime();
    return Number.isFinite(ms) ? ms : NaN;
}

async function sendSearchCaptureStatus(overrides = {}, attempts = 1) {
    if (!searchCapture?.tabId || !currentExport) return false;

    const i18n = await getOverlayI18n();
    const { phaseKey, ...rest } = overrides;

    const message = {
        type: 'XPORTER_SEARCH_CAPTURE_STATUS',
        username: currentExport.username,
        tweetCount: currentExport.tweetCount || 0,
        quantityLimit: currentExport.settings?.quantityLimit || 0,
        dateFrom: currentExport.dateFrom ? formatDateForSearch(currentExport.dateFrom) : '',
        dateTo: currentExport.dateTo ? formatDateForSearch(currentExport.dateTo) : '',
        progressPct: computeSearchCaptureProgress(),
        // ≥95% of the date window collected → the overlay tells the user the
        // rest is almost certainly a posting gap, and highlights Stop.
        almostDone: (computeDateCoveragePct() ?? 0) >= 95,
        i18n,
        ...rest
    };
    if (phaseKey) {
        message.phase = overlayPhase(i18n, phaseKey, currentExport.username);
    }

    for (let attempt = 0; attempt < attempts; attempt++) {
        try {
            await chrome.tabs.sendMessage(searchCapture.tabId, message);
            return true;
        } catch (_) {
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }

    return false;
}

function handlePageGraphqlResponse(message, sender) {
    const senderTabId = sender?.tab?.id;
    if (!searchCapture || senderTabId !== searchCapture.tabId) {
        return { ignored: true };
    }

    if (message.operationName !== 'SearchTimeline' ||
        typeof message.bodyText !== 'string' ||
        !message.url) {
        return { ignored: true };
    }

    const status = Number(message.status) || 200;
    // Error responses must remain retryable: the successful retry uses the
    // same cursor URL. Successful payloads are deduplicated until parsing says
    // they were malformed and explicitly removes the URL from this set.
    if (status >= 200 && status < 300) {
        if (searchCapture.seenUrls.has(message.url)) {
            return { duplicate: true };
        }
        searchCapture.seenUrls.add(message.url);
    }

    const payload = {
        url: message.url,
        bodyText: message.bodyText,
        status
    };

    if (searchCapture.resolver) {
        const resolver = searchCapture.resolver;
        searchCapture.resolver = null;
        resolver(payload);
    } else {
        searchCapture.queue.push(payload);
    }

    return { success: true };
}

// ==================== Users (Followers/Following) Fetch Loop ====================

async function _fetchUsersLoop() {
    let hasMore = true;
    let emptyPages = 0;
    const seenIds = new Set();
    await preloadSeenIds(seenIds);
    const recentIds = createRecentIdTracker(seenIds);

    // Pick the right API function
    const fetchFn = {
        followers: XPorterAPI.fetchFollowers,
        following: XPorterAPI.fetchFollowing,
        verified_followers: XPorterAPI.fetchVerifiedFollowers
    }[currentExport.exportMode];

    if (!fetchFn) {
        throw new Error('Unknown export mode: ' + currentExport.exportMode);
    }

    while (hasMore && currentExport.running) {
        // Check quantity limit
        if (quantityLimitReached()) {
            break;
        }

        const result = await rateLimiter.executeWithRateLimit(async () => {
            return await fetchFn(
                currentExport.userId,
                currentExport.cursor
            );
        });
        if (!currentExport.running) break;

        const users = Array.isArray(result.users) ? result.users : [];
        const unexpectedInitialEmpty = users.length === 0 &&
            currentExport.tweetCount === 0 &&
            !currentExport.cursor &&
            getExpectedItemCount() > 0;

        if (users.length === 0) {
            emptyPages++;
            // A profile lookup just told us rows exist, so an empty first page
            // is not a successful zero-row export. Retry the same initial page
            // a few times through the normal pacing path; otherwise one empty
            // or malformed REST response becomes a green "complete" state.
            if (unexpectedInitialEmpty && emptyPages >= 3) {
                throw new Error('MAX_RETRIES_EXCEEDED');
            }
            if (emptyPages >= 3) {
                hasMore = false;
                break;
            }
        } else {
            emptyPages = 0;
        }

        // Process users
        for (const user of users) {
            if (!recentIds.add(user.id)) continue;
            if (quantityLimitReached()) {
                hasMore = false;
                break;
            }
            currentExport.tweetBuffer.push(user);
            currentExport.tweetCount++;
            recordFirstItemOnce();

            if (currentExport.tweetBuffer.length >= XPorterStorage.MAX_TWEETS_PER_BATCH) {
                await flushExportBuffer();
            }
        }

        if (quantityLimitReached()) {
            hasMore = false;
        }
        // Update cursor
        if (hasMore && result.nextCursor) {
            currentExport.cursor = result.nextCursor;
        } else if (!unexpectedInitialEmpty) {
            hasMore = false;
        }

        // Buffer first, then the advanced cursor — see _fetchPostsLoop.
        await flushExportBuffer();
        await saveCurrentState();

        const expectedCount = getExpectedItemCount();

        broadcastStatus({
            running: true,
            status: 'fetching',
            username: currentExport.username,
            socialPlatform: currentExport.socialPlatform || 'x',
            tweetCount: currentExport.tweetCount,
            expectedTweets: expectedCount,
            quantityLimit: currentExport.settings?.quantityLimit || 0,
            batch: Math.floor(rateLimiter.totalRequests / rateLimiter.batchSize) + 1,
            totalRequests: rateLimiter.totalRequests,
            exportMode: currentExport.exportMode
        });
    }
}

// ==================== Stop / Resume / Status ====================

async function stopExport() {
    // Only signal the loop — it does the single flush + persist + broadcast in
    // its own !running / ABORTED branches. Flushing here too raced the loop's
    // in-flight saveTweetBatch (double-written batch, gap in the indices).
    if (currentExport?.running) {
        currentExport.running = false;
    }
    if (rateLimiter) {
        rateLimiter.abort();
    }
    XPorterAPI.abortActiveRequests?.();
    await closeSearchCaptureTab();
    if (profileScrollCapture?.tabId) {
        const capture = profileScrollCapture;
        try {
            await chrome.tabs.sendMessage(capture.tabId, { type: 'UCV_STOP_PROFILE_SCROLL' }).catch(() => null);
        } catch (_) { /* best effort */ }
        profileScrollCapture = null;
        capture.resolve?.({ success: true, reason: 'STOPPED_BY_USER', total: capture.lastTotal || 0 });
    }
    if (instagramScrollCapture?.tabId) {
        const capture = instagramScrollCapture;
        let acknowledged = false;
        try {
            const response = await chrome.tabs.sendMessage(capture.tabId, { type: 'IG_STOP_PROFILE_CAPTURE' }).catch(() => null);
            acknowledged = response?.success === true;
        } catch (_) { /* best effort */ }
        if (!acknowledged && instagramScrollCapture === capture) {
            instagramScrollCapture = null;
            capture.resolve?.({ success: true, reason: 'STOPPED_BY_USER', total: capture.lastTotal || 0 });
        }
    }
    if (facebookScrollCapture?.tabId) {
        const capture = facebookScrollCapture;
        let acknowledged = false;
        try {
            const response = await chrome.tabs.sendMessage(capture.tabId, { type: 'FB_STOP_PROFILE_SCROLL' }).catch(() => null);
            acknowledged = response?.success === true;
        } catch (_) { /* best effort */ }
        // Cuando la página reconoce la orden, el content script envía
        // FB_SCROLL_CAPTURE_DONE con ciclos y geometría finales. Solo se usa
        // el cierre inmediato como respaldo si la pestaña ya no responde.
        if (!acknowledged && facebookScrollCapture === capture) {
            facebookScrollCapture = null;
            capture.resolve?.({
                success: true,
                reason: 'STOPPED_BY_USER',
                total: capture.lastTotal || 0,
                cycles: capture.cycles || 0,
                stagnantCycles: capture.stagnantCycles || 0,
                endConfirmations: capture.endConfirmations || 0,
                finalPosition: null
            });
        }
    }
    // Acknowledge only after the loop exits, so a Resume/Start issued right
    // after this response can't collide with the unwinding loop.
    await waitForLoopUnwind();
    return { success: true };
}

async function resumeExport(extraItems) {
    await waitForLoopUnwind();
    if (exportStarting || exportLoopPromise || (currentExport && currentExport.running)) {
        return { error: 'ALREADY_RUNNING' };
    }
    exportStarting = true;
    try {
        return await _resumeExportInner(extraItems);
    } finally {
        exportStarting = false;
    }
}

// Settings that only control request pacing, never the shape of the data.
const PACING_SETTING_KEYS = [
    'exportSpeed', 'customDelaySec', 'customBatchSize', 'customCooldownMin',
    'adaptivePacing', 'requestDelay', 'batchSize', 'cooldownDuration'
];

// Resume with the same FILTERS that produced the saved rows (the export
// snapshot; changing includeRetweets mid-export would make one half of the
// file contradict the other), but with the user's CURRENT pacing: switching
// to a slower speed is the natural escape hatch after rate limits, and a
// snapshot that silently ignored it would trap the export at the old pace.
// Merging on top of stored defaults keeps states from before snapshots
// were persisted working.
function buildResumeSettings(storedSettings, snapshot) {
    const settings = { ...storedSettings, ...(snapshot || {}) };
    for (const key of PACING_SETTING_KEYS) {
        if (storedSettings[key] !== undefined) settings[key] = storedSettings[key];
    }
    return settings;
}

async function _resumeExportInner(extraItems) {
    const savedState = await XPorterStorage.loadExportState();
    if (!savedState) {
        return { error: 'No export to resume' };
    }

    const storedSettings = await XPorterStorage.loadSettings();
    const settings = buildResumeSettings(storedSettings, savedState.settings);

    // Cursor/API exports may resume with "+N more". Browser-scroll capture is
    // different: Resume means continue the same unlimited timeline from the
    // current position and preserve all IndexedDB rows. Applying a hidden +100
    // limit here could stop a resumed historical capture prematurely.
    const passiveProfileResume = savedState.exportMode === 'posts'
        && (savedState.socialPlatform === 'facebook' || savedState.socialPlatform === 'instagram' || settings.timelineMode === 'user_tweets_and_replies');
    const extra = parseInt(extraItems, 10);
    let limitOverride = passiveProfileResume ? 0 : (savedState.limitOverride || 0);
    if (!passiveProfileResume && Number.isFinite(extra) && extra > 0) {
        limitOverride = (savedState.tweetCount || 0) + extra;
    }
    if (limitOverride > 0) {
        settings.quantityLimit = limitOverride;
    } else if (passiveProfileResume) {
        settings.quantityLimit = Number(savedState.settings?.quantityLimit || 0);
    }

    rateLimiter = ['facebook', 'instagram'].includes(savedState.socialPlatform)
        ? null
        : createRateLimiter(settings, savedState.exportMode || 'posts');
    lastTransientStatus = null;
    if (rateLimiter) {
        rateLimiter.restoreState(savedState.rateLimiterState);
        rateLimiter.onStatusChange((event) => {
            lastTransientStatus = event;
            broadcastStatus({ ...event, exportMode: savedState.exportMode });
        });
    }

    currentExport = {
        running: true,
        username: savedState.username,
        socialPlatform: savedState.socialPlatform || 'x',
        exportMode: savedState.exportMode || 'posts',
        outputFormat: savedState.outputFormat || 'csv',
        dateFrom: savedState.dateFrom ? new Date(savedState.dateFrom) : null,
        dateTo: savedState.dateTo ? new Date(savedState.dateTo) : null,
        settings: settings,
        tweetCount: savedState.tweetCount || 0,
        itemsRecordedBase: savedState.tweetCount || 0,
        totalBatches: savedState.totalBatches || 0,
        tweetBuffer: [],
        userId: savedState.userId,
        userInfo: savedState.userInfo,
        cursor: savedState.cursor,
        startedAt: savedState.startedAt,
        status: 'fetching',
        limitOverride: limitOverride || 0,
        captureMethod: savedState.captureMethod || null,
        scrollCaptureResult: savedState.scrollCaptureResult || null,
        scrollCaptureStats: savedState.scrollCaptureStats || null,
        profileScrollResume: savedState.socialPlatform !== 'facebook' && savedState.exportMode === 'posts' &&
            settings.timelineMode === 'user_tweets_and_replies',
        facebookScrollResume: savedState.socialPlatform === 'facebook' && savedState.exportMode === 'posts',
        instagramScrollResume: savedState.socialPlatform === 'instagram' && savedState.exportMode === 'posts'
    };

    // Persist the raised per-export limit and running state before the loop can
    // enter a long rate-limit wait or be terminated by Chrome.
    try {
        await saveCurrentState();
    } catch (error) {
        currentExport = null;
        rateLimiter = null;
        return { error: error.message };
    }

    // Enqueue the per-run usage reset before the loop can collect its first
    // resumed item. This keeps first_item_ms tied to this resume attempt.
    XPorterStorage.recordExportStart(currentExport.exportMode, currentExport.outputFormat, {
        resume: true,
        dateRange: !!(currentExport.dateFrom || currentExport.dateTo)
    }).then(XPorterFeedback.refresh).catch(() => {});
    _lastRecordedUsagePhase = 'fetching';

    launchExportLoop('Resume export error:');

    return {
        success: true,
        status: 'resumed',
        tweetCount: currentExport.tweetCount,
        username: currentExport.username,
        socialPlatform: currentExport.socialPlatform || 'x',
        captureMethod: currentExport.captureMethod || null,
        timelineMode: currentExport.settings?.timelineMode || null
    };
}

async function getExportStatus() {
    // Expiration must also run while a terminal export is still held in this
    // live worker. Previously it only ran after currentExport became null, so
    // a long-lived worker could retain "auto-cleared" data indefinitely.
    let savedSettings = null;
    if (!currentExport?.running) {
        savedSettings = await applyAutoExpiration();
    }

    if (currentExport) {
        const waitUntil = rateLimiter?.waitUntil || manualWaitUntil || null;
        const transient = currentExport.running && waitUntil > Date.now() && lastTransientStatus
            ? {
                ...lastTransientStatus,
                until: waitUntil,
                ...(lastTransientStatus.retryIn
                    ? { retryIn: Math.max(0, waitUntil - Date.now()) }
                    : {})
            }
            : {};
        return {
            running: currentExport.running,
            status: currentExport.status,
            username: currentExport.username,
            socialPlatform: currentExport.socialPlatform || 'x',
            tweetCount: currentExport.tweetCount,
            expectedTweets: getExpectedItemCount(currentExport),
            quantityLimit: currentExport.settings?.quantityLimit || 0,
            error: currentExport.error || null,
            startedAt: currentExport.startedAt,
            completedAt: currentExport.completedAt,
            userInfo: currentExport.userInfo,
            exportMode: currentExport.exportMode,
            outputFormat: currentExport.outputFormat,
            captureMethod: currentExport.captureMethod || null,
            timelineMode: currentExport.settings?.timelineMode || null,
            scrollCaptureResult: currentExport.scrollCaptureResult || null,
            until: waitUntil,
            canResume: !currentExport.running &&
                (currentExport.status === 'stopped' || currentExport.status === 'error') &&
                (!!currentExport.userId || isProfileScrollCaptureMode(currentExport) || currentExport.socialPlatform === 'facebook' || currentExport.socialPlatform === 'instagram'),
            ...transient
        };
    }

    // Check saved state
    if (!savedSettings) savedSettings = await applyAutoExpiration();
    const savedState = await XPorterStorage.loadExportState();
    if (savedState) {
        // A persisted running=true with no in-memory export means Chrome killed
        // the SW mid-export (sleep, crash, update). Repair it to a resumable
        // 'stopped' — otherwise the UI shows a phantom in-progress export with
        // neither Resume nor Download, forever.
        if (savedState.running) {
            savedState.running = false;
            savedState.status = 'stopped';
            await XPorterStorage.saveExportState(savedState);
        }

        return {
            running: false,
            status: savedState.status,
            username: savedState.username,
            socialPlatform: savedState.socialPlatform || 'x',
            tweetCount: savedState.tweetCount || 0,
            expectedTweets: getExpectedItemCount(savedState),
            quantityLimit: savedState.limitOverride > 0
                ? savedState.limitOverride
                : (savedState.settings?.quantityLimit ?? savedSettings?.quantityLimit ?? 0),
            error: savedState.error || null,
            startedAt: savedState.startedAt,
            completedAt: savedState.completedAt,
            userInfo: savedState.userInfo,
            exportMode: savedState.exportMode,
            outputFormat: savedState.outputFormat,
            captureMethod: savedState.captureMethod || null,
            timelineMode: savedState.settings?.timelineMode || null,
            scrollCaptureResult: savedState.scrollCaptureResult || null,
            canResume: (savedState.status === 'stopped' || savedState.status === 'error') &&
                (!!savedState.userId || isProfileScrollCaptureMode(savedState) || savedState.socialPlatform === 'facebook' || savedState.socialPlatform === 'instagram')
        };
    }

    return { running: false, status: 'idle' };
}

// ==================== Helpers ====================

async function saveCurrentState({ bestEffort = false } = {}) {
    if (!currentExport) return;

    const saved = await XPorterStorage.saveExportState({
        username: currentExport.username,
        socialPlatform: currentExport.socialPlatform || 'x',
        userId: currentExport.userId,
        userInfo: currentExport.userInfo,
        cursor: currentExport.cursor,
        tweetCount: currentExport.tweetCount,
        totalBatches: currentExport.totalBatches,
        dateFrom: currentExport.dateFrom?.toISOString() || null,
        dateTo: currentExport.dateTo?.toISOString() || null,
        exportMode: currentExport.exportMode,
        outputFormat: currentExport.outputFormat,
        status: currentExport.status,
        error: currentExport.error,
        startedAt: currentExport.startedAt,
        completedAt: currentExport.completedAt,
        running: currentExport.running,
        limitOverride: currentExport.limitOverride || 0,
        captureMethod: currentExport.captureMethod || null,
        scrollCaptureResult: currentExport.scrollCaptureResult || null,
        scrollCaptureStats: currentExport.scrollCaptureStats || null,
        profileScrollResume: currentExport.profileScrollResume === true,
        facebookScrollResume: currentExport.facebookScrollResume === true,
        instagramScrollResume: currentExport.instagramScrollResume === true,
        settings: { ...currentExport.settings },
        rateLimiterState: rateLimiter?.getState() || null
    });
    if (!saved && !bestEffort) throw new Error('STORAGE_FULL');
    return saved;
}

async function applyAutoExpiration() {
    const settings = await XPorterStorage.loadSettings();
    if (settings.autoExpireEnabled === false) return settings;

    const maxAge = Math.max(1, Number(settings.autoExpireHours) || 4) * 60 * 60 * 1000;
    const state = currentExport?.running ? null : await XPorterStorage.loadExportState();
    if (state?.updatedAt && Date.now() - state.updatedAt > maxAge) {
        await XPorterStorage.clearExportState();
        if (currentExport && !currentExport.running) currentExport = null;
    }
    await XPorterStorage.pruneExpiredExportHistory(settings);
    return settings;
}

// Cancellable sleep for waits outside RateLimitManager. Check the export flag
// every second so Stop does not leave a date-range export sleeping for a minute;
// touch an extension API every 20 seconds to keep the MV3 worker alive.
async function swSleep(ms) {
    manualWaitUntil = Date.now() + ms;
    let nextKeepAlive = Date.now() + 20000;
    try {
        while (Date.now() < manualWaitUntil) {
            if (!currentExport?.running) return;
            const step = Math.min(1000, manualWaitUntil - Date.now());
            await new Promise(resolve => setTimeout(resolve, step));
            if (Date.now() >= nextKeepAlive) {
                try { await chrome.runtime.getPlatformInfo(); } catch (_) { /* keepalive only */ }
                nextKeepAlive = Date.now() + 20000;
            }
        }
    } finally {
        manualWaitUntil = null;
    }
}

// ==================== Toolbar badge ====================
// The popup closes on any outside click, and churn rows show people start an
// export, lose the popup, see no sign of life and uninstall minutes later.
// The badge keeps the export visibly alive on the toolbar icon: live item
// count while running, ✓ / ! / II when it ends. A terminal badge is cleared
// as soon as a UI shows the final state (GET_STATUS with running:false).
const BADGE_COLORS = { run: '#1d9bf0', ok: '#00ba7c', err: '#f4212e', stop: '#e2b203' };

function formatBadgeCount(n) {
    if (!Number.isFinite(n) || n <= 0) return '';
    if (n < 1000) return String(n);
    if (n < 10000) return (Math.floor(n / 100) / 10) + 'k'; // 1.2k
    return Math.floor(n / 1000) + 'k';                      // 12k (badge fits 4 chars)
}

function setBadge(text, color) {
    try {
        chrome.action.setBadgeText({ text });
        if (color) chrome.action.setBadgeBackgroundColor({ color });
    } catch (_) { /* badge is best-effort */ }
}

function updateBadgeForStatus(event) {
    switch (event.status) {
        case 'resolving_user':
            setBadge('…', BADGE_COLORS.run);
            break;
        case 'fetching':
        case 'cooldown':
        case 'retrying':
            setBadge(formatBadgeCount(currentExport?.tweetCount) || '…', BADGE_COLORS.run);
            break;
        case 'error':
            // Transient retry errors (retryIn set, still running) keep the
            // running badge — only a dead export earns the red mark.
            if (event.running === false) {
                setBadge('!', BADGE_COLORS.err);
            }
            break;
        case 'complete':
            setBadge('✓', BADGE_COLORS.ok);
            break;
        case 'stopped':
            setBadge('II', BADGE_COLORS.stop);
            break;
    }
}

function broadcastStatus(event) {
    if (!chrome.runtime?.id) return;
    if (event.status === 'cooldown' || event.status === 'retrying') {
        recordUsagePhase('rate_limit');
    } else if (event.status === 'fetching') {
        recordUsagePhase('fetching');
    }
    updateBadgeForStatus(event);
    chrome.runtime.sendMessage({
        type: 'EXPORT_STATUS_UPDATE',
        exportMode: currentExport?.exportMode,
        outputFormat: currentExport?.outputFormat,
        username: currentExport?.username,
        socialPlatform: currentExport?.socialPlatform || 'x',
        startedAt: currentExport?.startedAt,
        ...event
    }).catch(() => {
        // No listeners — that's fine
    });
}

function launchExportLoop(logPrefix) {
    const exportInstance = currentExport;
    const tracked = runExportLoop()
        .catch(async (err) => {
            XLog.error(logPrefix, err.message);
            // A newer export must never be mutated by a late rejection from an
            // older loop. The loop guard normally prevents that replacement;
            // this identity check is the final safety net.
            if (!currentExport || currentExport !== exportInstance) return;

            // The user already pressed Stop — a late failure from the aborted
            // in-flight request must land as the 'stopped' they asked for,
            // not overwrite it with a scary terminal error.
            if (rateLimiter?._aborted && currentExport.running === false) {
                currentExport.status = 'stopped';
                await saveCurrentState({ bestEffort: true });
                recordExportStoppedOnce();
                broadcastStopped();
                return;
            }

            currentExport.running = false;
            currentExport.status = 'error';
            currentExport.error = err.message.startsWith('API_ERROR_400') ? 'STALE_QUERY_ID' : err.message;
            await saveCurrentState({ bestEffort: true });
            broadcastStatus({
                running: false,
                status: 'error',
                error: currentExport.error,
                tweetCount: currentExport.tweetCount,
                canResume: !!currentExport.userId
            });
            XPorterStorage.recordExportError(currentExport.error).then(XPorterFeedback.refresh).catch(() => {});
        })
        .finally(() => {
            if (exportLoopPromise === tracked) exportLoopPromise = null;
        });
    exportLoopPromise = tracked;
}

// A single stop can otherwise be reported up to three times (stopExport, the
// loop's !running branch, and the ABORTED catch). Broadcast 'stopped' just once
// per export instance — the flag lives on currentExport, which is rebuilt fresh
// on every start/resume, so it resets naturally.
function broadcastStopped() {
    if (!currentExport || currentExport._stoppedSent) return;
    currentExport._stoppedSent = true;
    broadcastStatus({
        running: false,
        status: 'stopped',
        tweetCount: currentExport.tweetCount,
        canResume: !!currentExport.userId,
        exportMode: currentExport.exportMode,
        captureMethod: currentExport.captureMethod || null,
        timelineMode: currentExport.settings?.timelineMode || null,
        scrollCaptureResult: currentExport.scrollCaptureResult || null
    });
}

function recordExportStoppedOnce() {
    if (!currentExport || currentExport._stopRecorded) return;
    currentExport._stopRecorded = true;
    XPorterStorage.recordExportStopped().then(XPorterFeedback.refresh).catch(() => {});
}

let _lastRecordedUsagePhase = '';

function recordUsagePhase(phase) {
    if (_lastRecordedUsagePhase === phase) return;
    _lastRecordedUsagePhase = phase;
    XPorterStorage.recordExportPhase(phase).then(XPorterFeedback.refresh).catch(() => {});
}

function recordFirstItemOnce() {
    // tweetCount can already be > 0 on Resume; this flag belongs to the newly
    // constructed in-memory run, so the first NEW row still records latency.
    if (!currentExport || currentExport._firstItemRecorded) return;
    currentExport._firstItemRecorded = true;
    XPorterStorage.recordFirstItem().then(XPorterFeedback.refresh).catch(() => {});
}

// ==================== Auto-Resume on Startup ====================

chrome.runtime.onStartup.addListener(async () => {
    const state = await XPorterStorage.loadExportState();
    if (state && state.running) {
        XLog.log('Resuming interrupted export...');
        state.running = false;
        state.status = 'stopped';
        await XPorterStorage.saveExportState(state);
        // The pre-restart badge still shows a live count — reflect reality:
        // the export survived as a resumable 'stopped', not as running.
        setBadge('II', BADGE_COLORS.stop);
    } else {
        setBadge(''); // don't carry a stale badge into a fresh session
    }

    // Pre-discover endpoints in background so first export is fast
    try {
        await XPorterAPI.discoverEndpoints();
        XLog.log('Endpoints pre-discovered on startup');
    } catch (e) {
        XLog.warn('Pre-discovery on startup failed (will retry on export):', e.message);
    }
});

// Also check on install/update
chrome.runtime.onInstalled.addListener(async (details) => {
    // BI UCV defaults: ready to run without configuration.
    if (details.reason === 'install' || details.reason === 'update') {
        await XPorterStorage.saveSettings({
            includeRetweets: true,
            includeReplies: true,
            includeArticles: true,
            timelineMode: 'user_tweets_and_replies',
            quantityLimit: 0,
            capturePeriod: 'unlimited',
            requestDelay: 3000,
            exportSpeed: 'standard',
            customDelaySec: 5,
            customBatchSize: 20,
            customCooldownMin: 3,
            batchSize: 20,
            cooldownDuration: 180000,
            adaptivePacing: true,
            theme: 'dark',
            exportMode: 'posts',
            outputFormat: 'json',
            socialPlatform: 'x',
            language: 'es',
            ucvDefaultsVersion: '1.5.0'
        });
    }

    // A stored queryId from an older build can pin the first request to a stale
    // endpoint. Clear it on update, then learn the current endpoints again.
    try {
        await XPorterAPI.clearEndpointCache();
        await XPorterAPI.discoverEndpoints(true);
        XLog.log('Endpoints refreshed on install/update');
    } catch (e) {
        XLog.warn('Endpoint refresh on install/update failed; live capture will retry:', e.message);
    }
});
