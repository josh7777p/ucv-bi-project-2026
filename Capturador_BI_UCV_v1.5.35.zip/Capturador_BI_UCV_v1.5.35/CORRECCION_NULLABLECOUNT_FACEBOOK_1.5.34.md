# Corrección de Facebook 1.5.34

## Incidencia corregida

Al iniciar una captura de Facebook podía aparecer el error:

```text
nullableCount is not defined
```

El conversor de contadores públicos estaba declarado dentro del lector de perfil de Instagram, pero el lector de Facebook también lo utilizaba. En la versión 1.5.34 se trasladó a un ámbito compartido para ambas plataformas.

## Alcance

- Se corrigió únicamente `background/service-worker.js`.
- Se conservó la opción de capturar las 10 primeras publicaciones en Facebook y X.
- No se modificaron los recorridos de Facebook, X ni Instagram.
- No se modificaron las bases IndexedDB ni el formato de los registros.
