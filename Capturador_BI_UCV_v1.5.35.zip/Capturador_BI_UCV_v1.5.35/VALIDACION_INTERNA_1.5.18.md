# Validación interna — Capturador BI UCV v1.5.18

## Comprobaciones realizadas

- Sintaxis válida en todos los archivos JavaScript mediante `node --check`.
- `manifest.json` válido y versión `1.5.18`.
- Estrategia estructural evaluada sobre `77777.html`:
  - 37 menús de publicación detectados.
  - 37 fechas únicas recuperadas.
  - 0 fechas faltantes.
  - 0 asociaciones ambiguas.
  - nivel estructural observado: 3.
- Los archivos principales de X/Twitter permanecen idénticos a la v1.5.17:
  - `content/content.js`
  - `content/feed-parser.js`
  - `content/interceptor.js`

## Criterios para la prueba real

- La fecha debe corresponder con el día mostrado en Facebook.
- `calidad_captura.fechas.no_detectadas` debe mantenerse en 0 o disminuir respecto a la v1.5.17.
- `observaciones_dom` y `duplicados_fusionados_durante_captura` deben reducirse notablemente.
- Las métricas deben conservar el máximo visible y actualizarse cuando cambien.
- La ejecución debe detenerse al alcanzar el período seleccionado.

La validación definitiva del rendimiento requiere una ejecución sobre el perfil dinámico de Facebook, debido a su virtualización e hidratación progresiva del DOM.
