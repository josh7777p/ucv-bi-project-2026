# Nomenclatura de archivos

Formato:

```text
RED_PERIODO_YYYY-MM-DD_HHmm.ext
```

Períodos:

- `COMPLETO`
- `ULTIMO_MES`
- `ULTIMOS_3_MESES`
- `ULTIMO_ANO`
- `RANGO_FECHAS`

Se usa `YYYY-MM-DD` porque ordena cronológicamente los archivos y `HHmm` en formato de 24 horas para evitar AM/PM.
