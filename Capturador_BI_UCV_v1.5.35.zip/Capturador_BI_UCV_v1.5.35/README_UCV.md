# Capturador BI UCV 1.5.33

Extensión local para capturar publicaciones y métricas visibles de X, Facebook e Instagram.


## Instagram: prueba inicial de 10 publicaciones

1. Abre el perfil de Instagram que deseas capturar.
2. Selecciona **Instagram** en la extensión.
3. Selecciona **Capturar las 10 primeras publicaciones**.
4. La extensión crea una cola ordenada con los enlaces visibles del grid y la utiliza como fuente de verdad del recorrido.
5. Mantiene abierto el modal y usa `Next` para avanzar con rapidez, pero valida que el `shortcode` obtenido coincida con el siguiente elemento de la cola.
6. Cuando `Next` salta una tarjeta, abre expresamente el permalink pendiente antes de continuar.
7. Al agotar la cola visible, cierra temporalmente el modal, desplaza el perfil para cargar otro bloque y amplía la cola sin repetir shortcodes.
8. Cada publicación se guarda inmediatamente por su `shortcode`.
9. Las respuestas JSON que la propia página ya solicita se observan de forma pasiva para completar métricas cuando estén disponibles.
10. No se realizan solicitudes adicionales a Instagram.
11. Los valores no expuestos permanecen en `null`.

La captura de Instagram fue validada con las primeras diez publicaciones, el último mes y el histórico completo. La opción de diez publicaciones se amplía ahora a X y Facebook.

## Facebook: fecha exacta desde el enlace temporal

1. Lee primero los datos generales de la comunidad con el zoom original.
2. Guarda el zoom actual y aplica temporalmente 40 %.
3. Usa el menú `Acciones en esta publicación` para conservar el orden del feed.
4. Coloca el encabezado de la tarjeta debajo del menú fijo de Facebook.
5. Localiza dentro de la tarjeta el icono `Compartido con: ...`.
6. Identifica el enlace temporal situado inmediatamente antes del icono.
7. Reconstruye el texto visible aunque Facebook fragmente sus caracteres.
8. Provoca el tooltip del enlace y extrae la fecha completa con día, mes, año y hora.
9. Guarda la fecha exacta antes de expandir o desplazar la publicación.
10. Expande `Ver más`, extrae ID, URL, descripción y métricas, y persiste el registro.
11. Avanza a la siguiente tarjeta sin volver al inicio ni ejecutar una segunda pasada general.
12. Restaura el zoom original y genera el JSON.

Una expresión relativa como `5 h` se conserva como evidencia, pero no se considera fecha analítica cuando no aparece el tooltip exacto. No se usan fechas del cuerpo, comentarios ni inferencias por orden.

## Instalación

1. Descomprime el ZIP.
2. Abre `chrome://extensions/`.
3. Activa **Modo desarrollador**.
4. Pulsa **Cargar descomprimida**.
5. Selecciona la carpeta `Capturador_BI_UCV_v1.5.32`.
6. Recarga por completo el perfil de la plataforma antes de iniciar la prueba.


## Corrección de X y período uniforme 1.5.26

- X corrige el cierre `databaseSummary is not defined`.
- `bookmark_count` se extrae del número asociado a elementos guardados, no del primer número de la etiqueta combinada.
- X y Facebook calculan los períodos desde la publicación propia más reciente recuperada.
- El día límite se incluye completo.
- La lógica aprobada de fechas, métricas, identificadores, zoom y recorrido de Facebook se conserva.


## Ajustes finales de trazabilidad 1.5.25

- Los contadores del icono de privacidad y del tooltip ahora viajan hasta el resumen exportado.
- `metricas` conserva exactamente los mismos valores numéricos máximos destinados al DW.
- `metricas_raw` corresponde a la observación que produjo cada máximo.
- Se añaden evidencias raw de la primera y de la última observación sin alterar los cálculos.

## Normalización de fechas de X 1.5.27

Los valores de `created_at` de X se exportan de forma uniforme en ISO 8601. Este ajuste está aislado en la base local de X y no modifica la lógica de Facebook.


## Captura rápida de 10 publicaciones

La opción **Capturar las 10 primeras publicaciones** está disponible para X, Facebook e Instagram. Cada módulo conserva su mecanismo validado de recorrido y únicamente añade una condición de parada al completar diez registros únicos. Los archivos se nombran con el bloque `PRIMERAS_10`.
