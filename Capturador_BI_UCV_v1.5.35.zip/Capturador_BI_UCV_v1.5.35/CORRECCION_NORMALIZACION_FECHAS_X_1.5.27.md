# Corrección de normalización de fechas de X — v1.5.27

## Objetivo

Uniformar `created_at` en los registros de X sin modificar el período, las métricas, los identificadores ni la lógica estable de Facebook.

## Cambio aplicado

La base local de X convierte toda fecha válida a ISO 8601 antes de conservar el registro:

```text
Wed Mar 13 14:31:41 +0000 2024
```

se guarda como:

```text
2024-03-13T14:31:41.000Z
```

Si X entregara una fecha no interpretable, se conserva el texto original y `created_at_ms` queda en cero, igual que en la regla anterior.

## Alcance

Solo se modificó `utils/post-database.js`, componente utilizado por X. No se alteraron los archivos de captura, fechas, métricas ni exportación de Facebook.
