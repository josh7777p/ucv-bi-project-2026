# Resultado de validación — v1.5.24

## Correcciones verificadas

- Las fuentes `AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT` y `AUTHOR_DATE_PRIVACY_VISUAL_EXACT` son aceptadas por la exportación JSON.
- Las fechas sin hora se conservan como fechas válidas; `hora_publicacion` queda en `null`.
- El día límite se incluye completo. La captura no se detiene por una publicación del propio día límite aunque no tenga hora.
- Los contadores de enlaces de fecha y tooltips de privacidad llegan al resumen final.

## Pruebas

- Sintaxis JavaScript: aprobada en todos los archivos.
- Archivos JSON: válidos.
- Prueba del exportador: 2 de 2 publicaciones aptas para DW, incluida una fecha `23 de junio` sin hora.
- Prueba estática del DOM: 34 de 34 publicaciones con fecha y zona de métricas.
- Prueba de período: se conservaron publicaciones del 23 de junio con hora y sin hora; la captura se detuvo después de dos publicaciones de días anteriores (`22` y `21 de junio`).
- Módulos principales de X: hashes idénticos a v1.5.23.

La ejecución dinámica real en Facebook debe confirmarse con una nueva captura.
