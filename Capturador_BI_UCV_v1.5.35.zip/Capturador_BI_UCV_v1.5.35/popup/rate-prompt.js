// XPorter UCV — institutional local build.
// Chrome Web Store rating prompts are disabled.
(function () {
  window.XPorterRatePrompt = {
    async maybeShow() { return false; },
    async incrementExports() { return false; },
    async rateNow() { return false; }
  };
})();
