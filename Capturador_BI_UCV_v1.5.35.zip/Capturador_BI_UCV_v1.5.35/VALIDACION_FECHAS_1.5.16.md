# Validación interna de fechas — v1.5.16

## Resultado sobre el HTML suministrado

- Botones de acciones de publicación detectados: **37**.
- Publicaciones con exactamente una fecha: **37**.
- Publicaciones sin fecha: **0**.
- Publicaciones con más de una fecha candidata: **0**.
- Cobertura: **100 %**.
- Nivel mínimo encontrado desde el botón de acciones: **3** en los 37 casos.

## Integridad del módulo X/Twitter

Los archivos `content/content.js`, `content/feed-parser.js` y `content/interceptor.js` conservan exactamente los mismos SHA-256 que en la v1.5.15.

## Formatos de salida

- `fecha_publicacion`: ISO 8601.
- `fecha_publicacion_fecha`: `YYYY-MM-DD`.
- `fecha_publicacion_visual`: `DD/MM/YYYY`.
- `fecha_raw`: valor mostrado por Facebook, por ejemplo `4 h`, `1 día` o `14 de julio a las 4:08 pm`.
- `fecha_referencia_calculo`: fecha y hora desde la cual se convirtió un valor relativo.

## Ejemplos comprobados con zona horaria America/Caracas

Tomando como referencia `22/07/2026 14:00`:

| Valor de Facebook | Fecha analítica | Fecha visual | Precisión |
|---|---|---|---|
| `4 h` | `2026-07-22` | `22/07/2026` | `RELATIVA_CONFIABLE` |
| `1 día` | `2026-07-21` | `21/07/2026` | `RELATIVA_CONFIABLE` |
| `14 de julio a las 4:08 pm` | `2026-07-14` | `14/07/2026` | `APROXIMADA_CALENDARIO` |
| `18 de junio` | `2026-06-18` | `18/06/2026` | `APROXIMADA_CALENDARIO` |
