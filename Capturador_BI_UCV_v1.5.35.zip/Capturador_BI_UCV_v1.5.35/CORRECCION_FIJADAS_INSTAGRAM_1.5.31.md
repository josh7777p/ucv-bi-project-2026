# Corrección final de publicaciones fijadas — 1.5.31

La detección de publicaciones fijadas se limita a la tarjeta asociada a cada permalink. El selector puede ascender hasta un contenedor padre solo cuando ese contenedor contiene exactamente un `shortcode` de publicación. De este modo, un icono `Pinned post icon` no se atribuye a tarjetas vecinas.

La navegación, el cálculo de períodos, la clasificación de colaboraciones, las métricas y los módulos de Facebook y X permanecen sin cambios funcionales.
