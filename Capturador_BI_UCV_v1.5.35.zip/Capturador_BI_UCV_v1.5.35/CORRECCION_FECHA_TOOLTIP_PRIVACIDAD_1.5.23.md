# Capturador BI UCV v1.5.23 — fecha exacta mediante icono de privacidad

La fecha se obtiene desde el enlace situado inmediatamente antes del icono “Compartido con: Público”.

Orden aplicado:

1. Localizar la tarjeta desde el menú de acciones.
2. Localizar el icono de privacidad dentro de esa tarjeta.
3. Identificar el enlace temporal anterior.
4. Reconstruir el texto visible aunque Facebook fragmente los caracteres.
5. Provocar el tooltip y extraer la fecha completa.
6. Guardar la fecha exacta antes de expandir contenido o leer métricas.

Las expresiones relativas se conservan como evidencia, pero no se consideran aptas para el DW cuando el tooltip exacto no aparece.
