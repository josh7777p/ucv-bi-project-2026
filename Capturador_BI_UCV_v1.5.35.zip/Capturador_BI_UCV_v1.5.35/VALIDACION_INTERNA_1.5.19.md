# Validación interna — Capturador BI UCV v1.5.19

## Verificaciones realizadas

- `manifest.json` válido y versión `1.5.19`.
- Todos los archivos JavaScript superaron `node --check`.
- Los archivos principales de X/Twitter conservan exactamente el mismo SHA-256 que en v1.5.18:
  - `content/content.js`
  - `content/feed-parser.js`
  - `content/interceptor.js`
- El HTML guardado contiene 37 menús `Acciones en esta publicación` y la estrategia estructural resolvió 37 fechas únicas, todas a tres niveles del menú.
- Prueba de integración en Chromium sobre el HTML guardado:
  - 37 publicaciones detectadas.
  - 37 fechas recuperadas.
  - 0 fechas faltantes.
  - 37 identificadores únicos.
  - 37 cuerpos no vacíos.
  - 0 cuerpos terminados en `Ver menos`.
- Prueba de hidratación tardía:
  - se retiraron temporalmente los 37 nodos accesibles de fecha;
  - se restituyeron después de 1,8 segundos y después de 5 segundos;
  - en ambas pruebas se recuperaron 37 de 37 fechas mediante la ruta `AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT`.

## Alcance de la validación

Las pruebas confirman la sintaxis, la integración con el HTML guardado y el comportamiento ante hidratación tardía simulada. La cobertura y duración reales deben confirmarse con una captura nueva en Facebook, debido a la virtualización dinámica del sitio.
