# Resultado de validación 1.5.28

## Módulo de Instagram

- Se validaron los dos HTML suministrados.
- Se recuperaron correctamente shortcode, tipo, fecha ISO, descripción, autor, permalink y Me gusta.
- Los comentarios procedentes de la integración con Facebook no se interpretan como comentarios de Instagram.
- El botón exterior `Next` se distingue del botón interno de un carrusel.
- Una prueba sintética recorrió diez publicaciones consecutivas y finalizó con `FIRST_10_REACHED`.
- La persistencia fusiona observaciones repetidas mediante el máximo y conserva el raw y la fuente asociados al máximo.
- Los datos estructurados observados pasivamente pueden completar Me gusta, comentarios, visualizaciones, reproducciones, compartidos y guardados.
- Los registros anteriores al período utilizados para confirmar la detención se excluyen de la exportación final.
- El JSON de salida conserva `null` cuando una métrica no está disponible.

## Protección de Facebook y X

Los siguientes archivos permanecen byte por byte idénticos a la versión 1.5.27:

- `content/facebook-content.js`
- `utils/facebook-database.js`
- `content/content.js`
- `content/feed-parser.js`
- `content/interceptor.js`
- `utils/post-database.js`

## Alcance

Las pruebas internas confirman el parser y el recorrido controlado. La navegación real en Instagram debe validarse mediante la opción **Capturar las 10 primeras publicaciones** antes de ejecutar períodos extensos.
