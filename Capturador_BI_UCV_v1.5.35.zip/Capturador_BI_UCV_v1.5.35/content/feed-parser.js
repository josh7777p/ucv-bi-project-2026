// Capturador BI UCV — passive feed parser (MAIN world)
// Extracts compact post records from GraphQL responses already loaded by X.
(function () {
  const POST_OPERATION = /(Timeline|Tweets|TweetDetail|Bookmarks|Likes|Community|ListLatest|UserMedia)/i;
  const MAX_POSTS_PER_RESPONSE = 250;
  const METRIC_NAMES = [
    'view_count',
    'bookmark_count',
    'favorite_count',
    'retweet_count',
    'reply_count',
    'quote_count'
  ];

  function supportsOperation(operationName) {
    return typeof operationName === 'string' && POST_OPERATION.test(operationName);
  }

  function unwrapTweet(result) {
    if (result?.__typename === 'TweetWithVisibilityResults') return result.tweet;
    return result;
  }

  function normalizeUsername(value) {
    return String(value || '').replace(/^@/, '').trim().toLowerCase();
  }

  function getTargetUsername() {
    const match = String(window.location?.pathname || '').match(/^\/([A-Za-z0-9_]{1,15})(?:\/|$)/);
    return match ? match[1] : '';
  }

  function toCount(value) {
    if (value === '' || value === null || value === undefined) return null;
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
  }

  function rawCount(value) {
    if (value === '' || value === null || value === undefined) return null;
    return String(value);
  }

  function metricObject(result, legacy) {
    const bookmarkPresent = Object.prototype.hasOwnProperty.call(legacy || {}, 'bookmark_count');
    return {
      view_count: toCount(result?.views?.count),
      bookmark_count: bookmarkPresent ? toCount(legacy?.bookmark_count) : null,
      favorite_count: toCount(legacy?.favorite_count),
      retweet_count: toCount(legacy?.retweet_count),
      reply_count: toCount(legacy?.reply_count),
      quote_count: toCount(legacy?.quote_count)
    };
  }

  function rawMetricObject(result, legacy) {
    const bookmarkPresent = Object.prototype.hasOwnProperty.call(legacy || {}, 'bookmark_count');
    return {
      view_count: rawCount(result?.views?.count),
      bookmark_count: bookmarkPresent ? rawCount(legacy?.bookmark_count) : null,
      favorite_count: rawCount(legacy?.favorite_count),
      retweet_count: rawCount(legacy?.retweet_count),
      reply_count: rawCount(legacy?.reply_count),
      quote_count: rawCount(legacy?.quote_count)
    };
  }

  function emptyMetricObject() {
    return Object.fromEntries(METRIC_NAMES.map(name => [name, null]));
  }

  function classifyType({ isRetweet, legacy, authorUsername }) {
    if (isRetweet) return 'RETWEET';
    if (legacy?.in_reply_to_status_id_str) {
      const target = normalizeUsername(legacy.in_reply_to_screen_name);
      const author = normalizeUsername(authorUsername);
      return target && author && target === author ? 'THREAD_REPLY' : 'REPLY';
    }
    return 'TWEET';
  }

  function extractSource(sourceHtml) {
    if (!sourceHtml) return '';
    const match = String(sourceHtml).match(/>([^<]+)</);
    return match ? match[1] : String(sourceHtml);
  }

  function extractMedia(media) {
    const types = [...new Set(media.map(item => item?.type).filter(Boolean))];
    const urls = media.map(item => {
      if (item?.type === 'video' || item?.type === 'animated_gif') {
        const variants = (item.video_info?.variants || [])
          .filter(variant => variant?.content_type === 'video/mp4' && variant?.url)
          .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
        if (variants.length) return variants[0].url;
      }
      return item?.media_url_https || item?.media_url || '';
    }).filter(Boolean);
    const altTexts = media.map(item => item?.ext_alt_text || '').filter(Boolean);
    return {
      type: types.join(', '),
      urls: urls.join(', '),
      altTexts: altTexts.join(' | ')
    };
  }

  function extractCardUrl(result) {
    const card = result?.card?.legacy;
    if (!card) return '';
    const values = card.binding_values;
    const lookup = (key) => {
      if (Array.isArray(values)) {
        return values.find(value => value?.key === key)?.value?.string_value || '';
      }
      return values?.[key]?.string_value || '';
    };
    return lookup('website_url') || lookup('card_url') || card.url || '';
  }

  function extractArticle(result, username) {
    const article = result?.article?.article_results?.result;
    if (!article) return { title: '', url: '', text: '' };
    const articleId = article.rest_id || article.id || '';
    return {
      title: article.title || '',
      text: article.plain_text || article.preview_text || '',
      url: articleId && username ? `https://x.com/${username}/article/${articleId}` : ''
    };
  }

  function parseTweet(inputResult, options = {}) {
    const outerResult = unwrapTweet(inputResult);
    if (!outerResult) return null;

    const outerUser = outerResult.core?.user_results?.result;
    const outerUserLegacy = outerUser?.legacy || {};
    const outerUserCore = outerUser?.core || {};
    const reposterUsername = outerUserCore.screen_name || outerUserLegacy.screen_name || '';

    const retweetedResult = outerResult?.legacy?.retweeted_status_result?.result
      || outerResult?.retweeted_status_result?.result;
    const isRetweet = Boolean(retweetedResult || options.isRetweet);
    const result = retweetedResult ? unwrapTweet(retweetedResult) : outerResult;
    const legacy = result?.legacy;
    if (!legacy?.id_str) return null;

    const user = result.core?.user_results?.result;
    const userLegacy = user?.legacy || {};
    const userCore = user?.core || {};
    const username = userCore.screen_name || userLegacy.screen_name || '';
    const targetUsername = getTargetUsername();
    const accountUsername = isRetweet ? (reposterUsername || targetUsername) : targetUsername;

    let text = result.note_tweet?.note_tweet_results?.result?.text || legacy.full_text || '';
    const media = legacy.extended_entities?.media || legacy.entities?.media || [];
    const mediaInfo = extractMedia(media);
    const article = extractArticle(result, username);
    if (!text.trim() && article.title) text = article.title;
    let urls = (legacy.entities?.urls || []).map(item => item?.expanded_url).filter(Boolean).join(', ');
    if (!urls) urls = extractCardUrl(result);

    const metrics = metricObject(result, legacy);
    const rawMetrics = rawMetricObject(result, legacy);
    const isExternalRetweet = isRetweet
      && Boolean(normalizeUsername(username))
      && Boolean(normalizeUsername(accountUsername))
      && normalizeUsername(username) !== normalizeUsername(accountUsername);
    const isOwnPublication = !isExternalRetweet
      && (!targetUsername || normalizeUsername(username) === normalizeUsername(targetUsername));
    const metricsAttributable = isOwnPublication && !isExternalRetweet;
    const exportedMetrics = isExternalRetweet ? emptyMetricObject() : metrics;
    const exportedRawMetrics = isExternalRetweet ? emptyMetricObject() : rawMetrics;

    return {
      id: legacy.id_str,
      text,
      tweet_url: username ? `https://x.com/${username}/status/${legacy.id_str}` : '',
      language: legacy.lang || '',
      created_at: legacy.created_at || '',
      author_id: user?.rest_id || '',
      author_name: userCore.name || userLegacy.name || '',
      author_username: username,
      author_followers_count: toCount(userLegacy.followers_count),
      author_verified: Boolean(user?.is_blue_verified || userLegacy.verified),
      ...exportedMetrics,
      metricas_raw: exportedRawMetrics,
      metricas_contenido_original: isExternalRetweet ? metrics : null,
      metricas_raw_contenido_original: isExternalRetweet ? rawMetrics : null,
      metricas_origen: 'GRAPHQL_X',
      type: classifyType({ isRetweet, legacy, authorUsername: username }),
      in_reply_to_status_id: legacy.in_reply_to_status_id_str || '',
      in_reply_to_user_id: legacy.in_reply_to_user_id_str || '',
      in_reply_to_username: legacy.in_reply_to_screen_name || '',
      conversation_id: legacy.conversation_id_str || '',
      target_account_username: targetUsername || accountUsername || '',
      reposter_username: isRetweet ? (reposterUsername || targetUsername || '') : '',
      original_author_username: isRetweet ? username : '',
      cuenta_que_republica: isRetweet ? (reposterUsername || targetUsername || '') : '',
      autor_original: isRetweet ? username : '',
      es_publicacion_propia: Boolean(isOwnPublication),
      es_repost_externo: Boolean(isExternalRetweet),
      metricas_atribuibles_cuenta: Boolean(metricsAttributable),
      is_quote: Boolean(result.quoted_status_result),
      is_retweet: isRetweet,
      is_article: Boolean(result?.article?.article_results?.result),
      media_count: media.length,
      media_types: mediaInfo.type,
      media_type: mediaInfo.type,
      media_urls: mediaInfo.urls,
      media_alt_texts: mediaInfo.altTexts,
      source: extractSource(legacy.source),
      hashtags: (legacy.entities?.hashtags || []).map(tag => tag?.text).filter(Boolean).join(', '),
      urls,
      article_title: article.title,
      article_url: article.url,
      article_text: article.text
    };
  }

  function extractPosts(bodyText) {
    if (typeof bodyText === 'string' && !bodyText.includes('"tweet_results"')) return [];
    let root;
    try {
      root = typeof bodyText === 'string' ? JSON.parse(bodyText) : bodyText;
    } catch (_) {
      return [];
    }

    const posts = [];
    const seen = new Set();
    const stack = [root];

    while (stack.length && posts.length < MAX_POSTS_PER_RESPONSE) {
      const node = stack.pop();
      if (!node || typeof node !== 'object') continue;

      if (Array.isArray(node)) {
        for (let index = node.length - 1; index >= 0; index -= 1) {
          stack.push(node[index]);
        }
        continue;
      }

      const result = node.tweet_results?.result;
      if (result) {
        const post = parseTweet(result);
        if (post && !seen.has(post.id) && posts.length < MAX_POSTS_PER_RESPONSE) {
          seen.add(post.id);
          posts.push(post);
        }
      }

      for (const [key, value] of Object.entries(node)) {
        // Nested tweet payloads are handled explicitly above so the visible
        // retweet is canonicalized and an embedded quote is counted once.
        if (key === 'quoted_status_result' || key === 'retweeted_status_result' || key === 'tweet_results') {
          continue;
        }
        if (value && typeof value === 'object') stack.push(value);
      }
    }

    return posts;
  }

  window.XPorterFeedParser = {
    supportsOperation,
    extractPosts,
    parseTweet
  };
})();
