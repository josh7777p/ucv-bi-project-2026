// Capturador BI UCV — adaptador modular de Facebook.
// Lee únicamente información visible en la sesión abierta, conserva cada
// publicación antes de que Facebook la retire del DOM y controla el scroll.
(() => {
    'use strict';

    const RESERVED_PATHS = new Set([
        '', 'home.php', 'login', 'watch', 'marketplace', 'gaming', 'groups',
        'events', 'friends', 'messages', 'notifications', 'settings', 'help',
        'privacy', 'reel', 'reels', 'stories', 'search', 'pages', 'ads'
    ]);
    const PERIOD_MONTHS = Object.freeze({ last_month: 1, last_3_months: 3, last_year: 12 });
    const TRUSTED_DATE_PRECISIONS = new Set(['EXACTA', 'APROXIMADA_CALENDARIO']);
    const TRUSTED_DATE_SOURCES = new Set(['DATA_UTIME', 'TIME_DATETIME', 'ABBR_TITLE', 'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT', 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT', 'AUTHOR_DATE_HOVER_TOOLTIP', 'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT', 'AUTHOR_DATE_ARIA_LABELLEDBY', 'AUTHOR_DATE_ARIA_LABEL', 'AUTHOR_DATE_TITLE', 'AUTHOR_DATE_DIRECT_TEXT', 'PERMALINK_ARIA_LABEL', 'PERMALINK_TITLE', 'PERMALINK_LABEL']);
    const COPY_LINK_PATTERN = /(?:copiar (?:enlace|v[ií]nculo|link|direcci[oó]n del enlace)|copy (?:link|url)|copier le lien|link kopieren|copia (?:link|collegamento))/i;
    let captureState = null;
    let latestClipboardCapture = null;
    const permalinkEnrichmentCache = new Map();
    const permalinkEnrichmentAttempts = new Map();
    const feedOrderByEvidence = new Map();
    let nextFeedOrder = 1;

    // Caché efímera por nodos DOM. Se usa únicamente en Facebook para fijar la
    // fecha leída del encabezado antes de que una tarjeta sea re-renderizada o
    // retirada por la virtualización del feed.
    let actionDateByMenu = new WeakMap();
    let actionDateByCard = new WeakMap();
    let latestActionDateAudit = null;

    // Estado efímero de rendimiento de Facebook. No se comparte con X.
    // Evita persistir una tarjeta si fecha, contenido, URL y métricas no cambiaron.
    let persistedPostSnapshots = new Map();
    let pendingDatePositions = new Map();
    let pendingDateMenus = new Set();
    let dateMutationObserver = null;
    let dateObserverTimer = null;
    let dateObserverPersistTimer = null;
    let dateObserverPersistInFlight = false;
    let lastKnownFacebookTotal = 0;

    // Recorrido secuencial v1.5.25: el menú conserva el orden del feed, pero la
    // fecha se resuelve primero desde el enlace temporal que antecede al icono de
    // privacidad. Ruta: menú -> tarjeta -> icono de privacidad -> enlace de fecha
    // -> tooltip exacto -> contenido y métricas.
    let sequentialProcessedEvidence = new Set();
    let sequentialProcessedMenus = new WeakSet();
    let sequentialProcessedCards = new WeakSet();
    let sequentialQuickKeyByCard = new WeakMap();
    let sequentialQuickKeyByMenu = new WeakMap();
    let sequentialPrivacyDateEvidence = new Set();
    let sequentialCaptureStats = null;

    window.addEventListener('BIUCV_FB_CLIPBOARD_WRITE', (event) => {
        const text = String(event?.detail?.text || '').trim();
        if (!text || !/facebook\.com/i.test(text)) return;
        latestClipboardCapture = {
            text,
            source: event?.detail?.source || 'PAGE_CLIPBOARD_BRIDGE',
            capturedAt: Number(event?.detail?.capturedAt || Date.now())
        };
    });

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
    const normalizeSpaces = (value) => String(value || '').replace(/[\u00a0\u202f]/g, ' ').replace(/\s+/g, ' ').trim();

    function postEvidenceKey(post) {
        // Para el seguimiento durante una misma captura se prioriza el ID nativo.
        // La firma queda como respaldo cuando Facebook no expone otro identificador.
        return String(post?.native_id || post?.id || post?.content_signature || '').trim();
    }

    function persistenceSnapshot(post) {
        return JSON.stringify([
            post?.id || '',
            post?.native_id || '',
            post?.content_signature || '',
            Number(post?.created_at_ms || 0),
            post?.date_raw || '',
            post?.date_source || '',
            post?.permalink || '',
            post?.permalink_quality || '',
            post?.identifier_quality || '',
            post?.identifier_source || '',
            post?.identifier_scope || '',
            post?.post_type || '',
            hashText(post?.text || ''),
            Number(post?.reactions_count ?? -1),
            Number(post?.comments_count ?? -1),
            Number(post?.shares_count ?? -1),
            Number(post?.views_count ?? -1),
            post?.reaction_breakdown_raw || '',
            post?.metrics_zone_observed === true,
            post?.metrics_zone_visible === true,
            Number(post?.media_count || 0),
            (post?.media_asset_ids || []).join('|'),
            (post?.media_urls || []).join('|'),
            (post?.external_links || []).join('|'),
            post?.author_slug || '',
            post?.author_source || '',
            post?.audience || ''
        ]);
    }

    function changedPostsForPersistence(posts, force = false) {
        const changed = [];
        for (const post of posts || []) {
            const key = String(post?.id || postEvidenceKey(post));
            if (!key) continue;
            const snapshot = persistenceSnapshot(post);
            if (force || persistedPostSnapshots.get(key) !== snapshot) {
                changed.push({ post, key, snapshot });
            }
        }
        return changed;
    }

    function commitPersistenceSnapshots(changed) {
        for (const item of changed || []) persistedPostSnapshots.set(item.key, item.snapshot);
    }

    function updatePendingDatePositions(posts) {
        for (const post of posts || []) {
            if (post?.metrics_review_only) continue;
            const key = postEvidenceKey(post);
            if (!key) continue;
            if (Number(post?.created_at_ms || 0) > 0) {
                pendingDatePositions.delete(key);
                continue;
            }
            if (post?.is_own_publication !== true) continue;
            const scrollY = Math.max(0, Math.round(post?.first_seen_scroll_y ?? window.scrollY ?? 0));
            const current = pendingDatePositions.get(key);
            if (!current || Number(post?.first_seen_cycle || 0) < Number(current.firstSeenCycle || Infinity)) {
                pendingDatePositions.set(key, {
                    key,
                    scrollY,
                    firstSeenCycle: Number(post?.first_seen_cycle || 0),
                    lastSeenAt: Date.now()
                });
            } else {
                current.lastSeenAt = Date.now();
                current.scrollY = scrollY;
            }
        }
    }

    function currentProfileSlug() {
        const segments = location.pathname.split('/').filter(Boolean);
        if (!segments.length) return '';
        const first = decodeURIComponent(segments[0] || '').replace(/^@/, '').trim();
        if (!first || RESERVED_PATHS.has(first.toLowerCase())) return '';
        if (/^(profile\.php|permalink\.php|photo\.php|story\.php)$/i.test(first)) {
            return new URL(location.href).searchParams.get('id') || '';
        }
        return first;
    }

    function isFacebookProfilePage() {
        return Boolean(currentProfileSlug()) && !/\/(posts|photos|videos|reel|reels|stories)\//i.test(location.pathname);
    }

    function isSafeFacebookCaptureRoute(expectedSlug = captureState?.expectedProfileSlug || '') {
        const path = String(location.pathname || '').toLowerCase();
        const blockedRoutes = [
            /\/notes(?:\/|$)/,
            /\/photo(?:s)?(?:\/|$)/,
            /\/posts(?:\/|$)/,
            /\/videos?(?:\/|$)/,
            /\/reels?(?:\/|$)/,
            /\/watch(?:\/|$)/,
            /^\/(?:story|permalink|photo)\.php(?:\/|$)/
        ];

        if (blockedRoutes.some(pattern => pattern.test(path))) return false;
        if (!isFacebookProfilePage()) return false;

        const expected = String(expectedSlug || '').replace(/^@/, '').toLowerCase();
        const active = String(currentProfileSlug() || '').replace(/^@/, '').toLowerCase();
        return !expected || active === expected;
    }

    function assertSafeFacebookCaptureRoute() {
        if (isSafeFacebookCaptureRoute()) return;
        throw new Error(`FACEBOOK_PROFILE_ROUTE_CHANGED_DURING_CAPTURE:${location.pathname}`);
    }

    function notifyDetectedAccount() {
        const slug = currentProfileSlug();
        if (!slug) return;
        chrome.runtime.sendMessage({
            type: 'SET_SOCIAL_ACCOUNT',
            platform: 'facebook',
            account: slug,
            url: location.href
        }).catch(() => {});
    }

    notifyDetectedAccount();
    window.addEventListener('popstate', notifyDetectedAccount);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') notifyDetectedAccount();
    });

    function parseCompactNumber(value) {
        const text = normalizeSpaces(value).toLowerCase();
        if (!text) return null;
        const match = text.match(/-?\d[\d.,\s]*/);
        if (!match) return null;
        let numeric = match[0].replace(/\s+/g, '');
        let multiplier = 1;
        if (/(?:\bmil\b|\d[\d.,\s]*\s*k\b)/i.test(text)) multiplier = 1000;
        if (/(?:\bmill(?:ón|ones)?\b|\bmillion(?:s)?\b|\d[\d.,\s]*\s*m\b)/i.test(text)) multiplier = 1000000;
        const comma = numeric.lastIndexOf(',');
        const dot = numeric.lastIndexOf('.');
        const sepAt = Math.max(comma, dot);
        if (sepAt >= 0) {
            const sep = numeric[sepAt];
            const other = sep === ',' ? '.' : ',';
            const decimals = numeric.length - sepAt - 1;
            if (multiplier > 1) {
                numeric = numeric.replace(new RegExp('\\' + other, 'g'), '').replace(sep, '.');
            } else if (numeric.includes(other)) {
                numeric = numeric.replace(new RegExp('\\' + other, 'g'), '').replace(sep, '.');
            } else if (decimals === 3) {
                numeric = numeric.replace(/[.,]/g, '');
            } else {
                numeric = numeric.replace(sep, '.');
            }
        }
        const number = Number(numeric);
        return Number.isFinite(number) && number >= 0 ? Math.round(number * multiplier) : null;
    }

    function hashText(value) {
        let hash = 2166136261;
        for (const char of String(value || '')) {
            hash ^= char.charCodeAt(0);
            hash = Math.imul(hash, 16777619);
        }
        return (hash >>> 0).toString(36);
    }

    function cleanFacebookUrl(value, targetSlug = currentProfileSlug()) {
        const identity = extractNativeIdentity(value, targetSlug);
        return identity?.url || '';
    }

    function cleanProfileUrl(value) {
        if (!value) return '';
        try {
            const url = new URL(value, location.origin);
            if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return '';
            const profileId = url.searchParams.get('id');
            url.hash = '';
            url.search = profileId ? `id=${encodeURIComponent(profileId)}` : '';
            return url.toString();
        } catch (_) {
            return '';
        }
    }

    function extractNativeIdentity(urlValue, targetSlug = currentProfileSlug()) {
        if (!urlValue) return { id: '', url: '', source: '', quality: 'NO_DISPONIBLE', scope: 'NO_DISPONIBLE' };
        try {
            const rawUrl = String(urlValue || '').trim();
            const url = /^https?:\/\//i.test(rawUrl)
                ? new URL(rawUrl)
                : new URL(rawUrl, /^https?:/i.test(location.href) ? location.href : 'https://www.facebook.com/');
            if (!/(^|\.)facebook\.com$/i.test(url.hostname)) {
                return { id: '', url: '', source: '', quality: 'NO_DISPONIBLE', scope: 'NO_DISPONIBLE' };
            }

            const cleanPath = url.pathname.replace(/\/+/g, '/');
            const shareMatch = cleanPath.match(/^\/share\/([prv])\/([A-Za-z0-9_-]{5,})\/?/i);
            if (shareMatch) {
                const shareType = shareMatch[1].toLowerCase();
                const token = shareMatch[2];
                const source = shareType === 'r' ? 'SHARE_REEL' : (shareType === 'v' ? 'SHARE_VIDEO' : 'SHARE_POST');
                return {
                    id: `share_${shareType}_${token}`,
                    url: `https://www.facebook.com/share/${shareType}/${token}/`,
                    source,
                    quality: 'NATIVA',
                    scope: 'PUBLICACION'
                };
            }
            const setValue = url.searchParams.get('set') || '';
            const storyFbid = url.searchParams.get('story_fbid') || '';
            const fbid = url.searchParams.get('fbid') || '';
            const watchId = url.searchParams.get('v') || '';

            const pcbMatch = setValue.match(/^pcb\.(\d{5,})$/i);
            if (storyFbid && (/^\d{5,}$/.test(storyFbid) || /^pfbid[A-Za-z0-9_-]{8,}$/i.test(storyFbid))) {
                const profileId = url.searchParams.get('id') || targetSlug || '';
                const canonical = targetSlug
                    ? `https://www.facebook.com/${encodeURIComponent(targetSlug)}/posts/${storyFbid}`
                    : `https://www.facebook.com/permalink.php?story_fbid=${encodeURIComponent(storyFbid)}${profileId ? `&id=${encodeURIComponent(profileId)}` : ''}`;
                return { id: storyFbid, url: canonical, source: 'STORY_FBID', quality: 'NATIVA', scope: 'PUBLICACION' };
            }
            if (pcbMatch) {
                const id = pcbMatch[1];
                const canonical = targetSlug
                    ? `https://www.facebook.com/${encodeURIComponent(targetSlug)}/posts/${id}`
                    : `https://www.facebook.com/permalink.php?story_fbid=${id}`;
                return { id, url: canonical, source: 'SET_PCB', quality: 'NATIVA', scope: 'PUBLICACION' };
            }

            const postPatterns = [
                { re: /\/posts\/(?:[^/?#]+\/)?(pfbid[A-Za-z0-9_-]{8,})/i, source: 'POSTS_PFBID' },
                { re: /\/posts\/(?:[^/?#]+\/)?(\d{5,})/i, source: 'POSTS_ID' },
                { re: /\/permalink\/(\d{5,})/i, source: 'PERMALINK_PATH' },
                { re: /\/videos\/(\d{5,})/i, source: 'VIDEO_ID' },
                { re: /\/reel\/([A-Za-z0-9_-]{5,})/i, source: 'REEL_ID' }
            ];
            for (const pattern of postPatterns) {
                const match = cleanPath.match(pattern.re);
                if (!match) continue;
                const id = match[1];
                let canonical;
                if (pattern.source === 'REEL_ID') canonical = `https://www.facebook.com/reel/${id}`;
                else if (pattern.source === 'VIDEO_ID') canonical = `https://www.facebook.com/${encodeURIComponent(targetSlug || '')}/videos/${id}`.replace('/facebook.com//', '/facebook.com/');
                else canonical = targetSlug
                    ? `https://www.facebook.com/${encodeURIComponent(targetSlug)}/posts/${id}`
                    : `https://www.facebook.com${cleanPath}`;
                return { id, url: canonical, source: pattern.source, quality: 'NATIVA', scope: 'PUBLICACION' };
            }

            if (watchId && /^\d{5,}$/.test(watchId)) {
                return { id: watchId, url: `https://www.facebook.com/watch/?v=${watchId}`, source: 'WATCH_ID', quality: 'NATIVA', scope: 'PUBLICACION' };
            }

            if (fbid && (/^\d{5,}$/.test(fbid) || /^pfbid[A-Za-z0-9_-]{8,}$/i.test(fbid))) {
                return {
                    id: fbid,
                    url: `https://www.facebook.com/photo/?fbid=${encodeURIComponent(fbid)}`,
                    source: 'PHOTO_FBID',
                    quality: 'NATIVA',
                    scope: 'MULTIMEDIA'
                };
            }
        } catch (_) { /* ignore */ }
        return { id: '', url: '', source: '', quality: 'NO_DISPONIBLE', scope: 'NO_DISPONIBLE' };
    }

    function permalinkInfoFromIdentity(identity, sourceHref = '', anchor = null, label = '', score = 0) {
        if (!identity?.id) return null;
        return {
            anchor,
            href: identity.url,
            sourceHref: sourceHref || identity.url,
            label: normalizeSpaces(label),
            nativeId: identity.id,
            identifierSource: identity.source,
            permalinkQuality: identity.quality,
            identifierScope: identity.scope || 'PUBLICACION',
            score
        };
    }

    function extractFacebookUrlFromText(value) {
        const text = String(value || '').trim();
        if (!text) return '';
        const match = text.match(/https?:\/\/(?:www\.|web\.|m\.)?facebook\.com\/[^\s<>'"]+/i);
        return match ? match[0].replace(/[),.;!?]+$/, '') : '';
    }

    async function readClipboardTextSafe() {
        try {
            if (!navigator.clipboard || typeof navigator.clipboard.readText !== 'function') return '';
            return String(await navigator.clipboard.readText() || '').trim();
        } catch (_) {
            return '';
        }
    }

    function robustClick(element) {
        if (!element) return false;
        try {
            for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
                element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, button: 0 }));
            }
            return true;
        } catch (_) {
            try { element.click(); return true; } catch (_) { return false; }
        }
    }

    async function waitForVisibleCopyLinkControl(timeoutMs = 1400) {
        const started = Date.now();
        while (Date.now() - started < timeoutMs) {
            const candidates = Array.from(document.querySelectorAll('[role="menuitem"], [role="button"], button, div[tabindex="0"], span[tabindex="0"]'));
            const control = candidates.find(node => {
                if (!elementVisible(node)) return false;
                const text = normalizeSpaces([
                    node.getAttribute?.('aria-label'),
                    node.getAttribute?.('title'),
                    node.innerText,
                    node.textContent
                ].filter(Boolean).join(' '));
                return COPY_LINK_PATTERN.test(text) && text.length <= 180;
            });
            if (control) return control;
            await sleep(80);
        }
        return null;
    }

    function closeOpenFacebookMenu(actionButton = null) {
        try {
            if (actionButton?.getAttribute?.('aria-expanded') === 'true') actionButton.click();
        } catch (_) { /* ignore */ }
        try {
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
            document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', bubbles: true }));
        } catch (_) { /* ignore */ }
    }

    function enrichmentKeyForPost(post) {
        return String(post?.content_signature || post?.id || '').trim();
    }

    async function tryResolvePostPermalinkFromMenu(post, targetSlug) {
        const card = post?._card;
        const key = enrichmentKeyForPost(post);
        if (!card || !key || !document.contains(card)) return null;
        if (permalinkEnrichmentCache.has(key)) return permalinkEnrichmentCache.get(key);

        const attempt = permalinkEnrichmentAttempts.get(key) || { count: 0, lastAt: 0 };
        if (attempt.count >= 3 || Date.now() - attempt.lastAt < 3500) return null;
        permalinkEnrichmentAttempts.set(key, { count: attempt.count + 1, lastAt: Date.now() });
        post.permalink_enrichment_attempt_count = attempt.count + 1;
        post.permalink_enrichment_error = null;

        try {
            card.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'auto' });
            await sleep(160);
        } catch (_) { /* ignore */ }

        const actionButton = Array.from(card.querySelectorAll('[aria-label]'))
            .find(node => isPostActionLabel(node.getAttribute('aria-label')) && elementVisible(node));
        if (!actionButton) {
            post.permalink_enrichment_error = 'POST_ACTION_BUTTON_NOT_FOUND';
            return null;
        }

        const startedAt = Date.now();
        latestClipboardCapture = null;
        let beforeClipboard = '';
        try { beforeClipboard = await readClipboardTextSafe(); } catch (_) { /* ignore */ }

        try {
            robustClick(actionButton);
            const copyControl = await waitForVisibleCopyLinkControl(4200);
            if (!copyControl) {
                post.permalink_enrichment_error = 'COPY_LINK_OPTION_NOT_FOUND';
                closeOpenFacebookMenu(actionButton);
                return null;
            }

            const clickable = copyControl.closest?.('[role="menuitem"], [role="button"], button, a[href], div[tabindex="0"]') || copyControl;
            const directHref = extractFacebookUrlFromText(
                clickable.getAttribute?.('href')
                || clickable.querySelector?.('a[href]')?.href
                || copyControl.getAttribute?.('href')
                || ''
            );
            robustClick(clickable);

            let copied = '';
            for (let probe = 0; probe < 5 && !copied; probe += 1) {
                await sleep(160);
                copied = latestClipboardCapture?.capturedAt >= startedAt ? latestClipboardCapture.text : '';
                if (!copied) copied = await readClipboardTextSafe();
            }
            if (copied && copied === beforeClipboard && !latestClipboardCapture) copied = '';
            const urlValue = directHref || extractFacebookUrlFromText(copied);
            const identity = extractNativeIdentity(urlValue, targetSlug);
            closeOpenFacebookMenu(actionButton);
            if (!identity.id || identity.scope !== 'PUBLICACION') {
                post.permalink_enrichment_error = urlValue ? 'COPIED_URL_NOT_POST_PERMALINK' : 'CLIPBOARD_URL_NOT_CAPTURED';
                return null;
            }

            const info = permalinkInfoFromIdentity(identity, urlValue, null, 'COPIAR_ENLACE', 1000);
            post.permalink_enrichment_error = null;
            permalinkEnrichmentCache.set(key, info);
            return info;
        } catch (error) {
            post.permalink_enrichment_error = error?.message || 'MENU_COPY_LINK_FAILED';
            closeOpenFacebookMenu(actionButton);
            return null;
        }
    }

    function elementVisible(element) {
        if (!element) return false;
        const style = getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
    }

    function isObfuscatedText(value) {
        const text = normalizeSpaces(value);
        if (!text) return false;
        const tokens = text.split(/\s+/).filter(Boolean);
        if (tokens.length < 12) return false;
        const single = tokens.filter(token => token.length === 1).length;
        const average = tokens.reduce((sum, token) => sum + token.length, 0) / tokens.length;
        return single / tokens.length >= 0.58 && average <= 2.2;
    }

    function isLikelyDateText(text) {
        const value = normalizeSpaces(text);
        if (!value || isObfuscatedText(value) || /^(?:learn more|ver más|see more)$/i.test(value)) return false;
        return /(?:\b\d+\s*(?:min|h|d|sem|semana|semanas|w|día|días|hora|horas)\b|ayer|yesterday|hoy|today|\d{1,2}\s+de\s+[a-záéíóúñ]+|[a-z]+\s+\d{1,2}(?:,\s*\d{4})?|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})/i.test(value);
    }

    function extractStandaloneDateFragment(value) {
        let text = normalizeSpaces(value);
        if (!text || isObfuscatedText(text) || text.length > 120) return '';
        text = text
            .replace(/[·•]+\s*(?:público|public|amigos|friends)?\s*$/i, '')
            .replace(/\s+(?:público|public|amigos|friends)\s*$/i, '')
            .replace(/^[·•\-–—\s]+|[·•\-–—\s]+$/g, '')
            .trim();
        const patterns = [
            /^(?:hace\s+)?\d+\s*(?:min|minuto(?:s)?|h|hora(?:s)?|d|día(?:s)?|sem|semana(?:s)?|w)(?:\s+\d+\s*(?:min|minuto(?:s)?|h|hora(?:s)?|d|día(?:s)?|sem|semana(?:s)?|w))?$/i,
            /^(?:hoy|ayer|today|yesterday)(?:\s+(?:a\s+las|at)\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?$/i,
            /^(?:(?:lunes|martes|miércoles|miercoles|jueves|viernes|sábado|sabado|domingo)[,]?\s*)?\d{1,2}\s+de\s+[a-záéíóúñ]+(?:\s+de\s+\d{4})?(?:\s+a\s+las\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?$/i,
            /^(?:(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)[,]?\s*)?[a-z]+\s+\d{1,2}(?:,\s*\d{4})?(?:\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?)?$/i,
            /^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}(?:\s+\d{1,2}:\d{2}\s*(?:am|pm)?)?$/i,
            /^\d{4}-\d{2}-\d{2}(?:[T\s]\d{2}:\d{2}(?::\d{2})?)?$/i,
            /^(?:1[5-9]\d{8}|2\d{9})$/
        ];
        return patterns.some(pattern => pattern.test(text)) ? text : '';
    }

    function isStandaloneDateText(value) {
        return Boolean(extractStandaloneDateFragment(value));
    }

    function nodeHref(node) {
        const anchor = node?.closest?.('a[href]') || (node?.matches?.('a[href]') ? node : null);
        return String(anchor?.href || anchor?.getAttribute?.('href') || '');
    }

    function isCommentDateNode(node, card) {
        if (!node) return false;
        const href = nodeHref(node);
        if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) return true;
        const article = node.closest?.('[role="article"]');
        if (article && article !== card && card?.contains?.(article)) return true;
        return false;
    }

    function isTrustedHeaderDateNode(node, card, messageNode = null) {
        if (!node || !card || !card.contains(node)) return false;
        if (isCommentDateNode(node, card)) return false;
        const action = node.closest?.('[aria-label]');
        if (action && isPostActionLabel(action.getAttribute('aria-label'))) return false;

        // Facebook puede ordenar internamente los nodos accesibles de forma
        // distinta a la disposición visual. Se admite el nodo cuando pertenece
        // a la franja superior de la tarjeta, aunque en el DOM aparezca después
        // del bloque de texto principal.
        const cardRect = card.getBoundingClientRect();
        const nodeRect = node.getBoundingClientRect();
        const visuallyInHeader = nodeRect.width > 0 && nodeRect.height > 0
            && nodeRect.top >= cardRect.top - 20
            && nodeRect.top <= cardRect.top + Math.min(220, Math.max(90, cardRect.height * 0.38));
        if (messageNode && !nodeAppearsBefore(messageNode, node) && !visuallyInHeader) return false;
        return true;
    }

    function extractHeaderVisibleDateTexts(card, messageNode = null) {
        const values = [];
        const fullText = String(card?.innerText || '');
        const messageText = String(messageNode?.innerText || messageNode?.textContent || '');
        let headerText = fullText;
        if (messageText) {
            const index = fullText.indexOf(messageText);
            if (index >= 0) headerText = fullText.slice(0, index);
        }
        headerText = headerText.slice(0, 900);
        for (const line of headerText.split(/\n+/)) {
            const text = normalizeSpaces(line);
            if (text.length <= 100 && isLikelyDateText(text)) values.push(text);
        }
        // Respaldo para interfaces que unen autor y fecha en una misma línea.
        const inlinePatterns = [
            /(?:^|\s)(\d+\s*(?:min|minutos?|h|horas?|d|días?|sem|semanas?|w))(?:\s|$)/gi,
            /(?:^|\s)(\d{1,2}\s+de\s+[a-záéíóúñ]+(?:\s+de\s+\d{4})?(?:\s+a\s+las\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?)/gi,
            /(?:^|\s)((?:hoy|ayer|today|yesterday)(?:\s+a\s+las\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?)/gi
        ];
        for (const pattern of inlinePatterns) {
            for (const match of headerText.matchAll(pattern)) {
                const text = normalizeSpaces(match[1]);
                if (text && isLikelyDateText(text)) values.push(text);
            }
        }
        return Array.from(new Set(values));
    }

    function collectHeaderNodeDateTexts(card, messageNode = null) {
        const values = [];
        for (const node of card.querySelectorAll('a, span, div, abbr, time')) {
            if (!isTrustedHeaderDateNode(node, card, messageNode)) continue;
            const candidates = [
                node.getAttribute?.('aria-label'),
                node.getAttribute?.('title'),
                node.getAttribute?.('datetime'),
                node.getAttribute?.('data-utime')
            ];
            const directText = normalizeSpaces(node.innerText || node.textContent || '');
            if (directText.length <= 100) candidates.push(directText);
            for (const candidate of candidates) {
                const text = normalizeSpaces(candidate);
                if (text && text.length <= 100 && isLikelyDateText(text)) values.push({ text, node });
            }
        }
        return values;
    }

    function isTrustedDateRecord(value) {
        const precision = String(value?.date_precision || value?.precision || '').toUpperCase();
        const source = String(value?.date_source || value?.source || '').toUpperCase();
        const ms = Number(value?.created_at_ms || value?.ms || 0);
        if (!TRUSTED_DATE_PRECISIONS.has(precision) || !TRUSTED_DATE_SOURCES.has(source) || ms <= 0) return false;
        return ms <= Date.now() + 10 * 60e3;
    }

    function findPermalink(card, targetSlug = currentProfileSlug()) {
        const candidates = [];
        for (const anchor of card.querySelectorAll('a[href]')) {
            const rawHref = anchor.href || anchor.getAttribute('href') || '';
            if (!rawHref) continue;
            const identity = extractNativeIdentity(rawHref, targetSlug);
            if (!identity.id) continue;

            const label = normalizeSpaces([
                anchor.getAttribute('aria-label'),
                anchor.getAttribute('title'),
                anchor.innerText,
                anchor.textContent
            ].filter(Boolean).join(' '));

            let score = 0;
            if (identity.source === 'STORY_FBID') score += 24;
            if (/^POSTS_/.test(identity.source)) score += 23;
            if (identity.source === 'SET_PCB') score += 22;
            if (identity.source === 'VIDEO_ID' || identity.source === 'REEL_ID' || identity.source === 'WATCH_ID') score += 18;
            if (identity.source === 'PHOTO_FBID') score += 12;
            if (isLikelyDateText(label)) score += 5;
            // Un vínculo de comentario puede aportar el ID del post, pero nunca
            // se usa como fuente de fecha y recibe una penalización.
            if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(rawHref)) score -= 8;

            candidates.push({
                anchor,
                href: identity.url,
                sourceHref: rawHref,
                label,
                nativeId: identity.id,
                identifierSource: identity.source,
                permalinkQuality: identity.quality,
                identifierScope: identity.scope || 'PUBLICACION',
                score
            });
        }
        candidates.sort((a, b) => b.score - a.score);
        return candidates[0] || null;
    }

    function parseMonthName(value) {
        const key = normalizeSpaces(value).toLowerCase().replace('.', '');
        const months = {
            enero: 0, january: 0, jan: 0,
            febrero: 1, february: 1, feb: 1,
            marzo: 2, march: 2, mar: 2,
            abril: 3, april: 3, apr: 3,
            mayo: 4, may: 4,
            junio: 5, june: 5, jun: 5,
            julio: 6, july: 6, jul: 6,
            agosto: 7, august: 7, aug: 7,
            septiembre: 8, setiembre: 8, september: 8, sep: 8, sept: 8,
            octubre: 9, october: 9, oct: 9,
            noviembre: 10, november: 10, nov: 10,
            diciembre: 11, december: 11, dec: 11
        };
        return Object.prototype.hasOwnProperty.call(months, key) ? months[key] : null;
    }

    function parseClock(raw, fallbackHour = 12) {
        const match = String(raw || '').match(/(\d{1,2})(?::(\d{2}))?\s*(a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?/i);
        if (!match) return { hour: fallbackHour, minute: 0 };
        let hour = Number(match[1]);
        const minute = Number(match[2] || 0);
        const suffix = String(match[3] || '').replace(/[.\s]/g, '').toLowerCase();
        if (suffix === 'pm' && hour < 12) hour += 12;
        if (suffix === 'am' && hour === 12) hour = 0;
        return { hour: Math.min(23, hour), minute: Math.min(59, minute) };
    }

    function parseFacebookDate(rawValue, nowMs = Date.now(), source = 'TEXT') {
        const raw = normalizeSpaces(rawValue);
        if (!raw || isObfuscatedText(raw) || /^(?:learn more|ver más|see more|coordinación de extensión ciencias ucv)$/i.test(raw)) {
            return { iso: null, ms: 0, precision: 'NO_DETECTADA', raw: raw || null, referenceAt: null, source };
        }

        const lower = raw.toLowerCase();
        const now = new Date(nowMs);

        const timestamp = raw.match(/(?:^|\D)(1[5-9]\d{8}|2\d{9})(?:\D|$)/);
        if (timestamp) {
            const ms = Number(timestamp[1]) * 1000;
            return { iso: new Date(ms).toISOString(), ms, precision: 'EXACTA', raw, referenceAt: null, source, hasTime: true };
        }

        const isoMatch = raw.match(/\b(\d{4})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2})(?::(\d{2}))?)?/);
        if (isoMatch) {
            const date = new Date(
                Number(isoMatch[1]),
                Number(isoMatch[2]) - 1,
                Number(isoMatch[3]),
                Number(isoMatch[4] || 12),
                Number(isoMatch[5] || 0),
                Number(isoMatch[6] || 0)
            );
            return { iso: date.toISOString(), ms: date.getTime(), precision: 'EXACTA', raw, referenceAt: null, source, hasTime: Boolean(isoMatch[4]) };
        }

        let match = lower.match(/(?:lunes|martes|miércoles|miercoles|jueves|viernes|sábado|sabado|domingo|monday|tuesday|wednesday|thursday|friday|saturday|sunday)?[,]?\s*(\d{1,2})\s+de\s+([a-záéíóúñ]+)(?:\s+de\s+(\d{4}))?(?:\s+a\s+las\s+(\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?))?/i);
        if (match) {
            const month = parseMonthName(match[2]);
            if (month !== null) {
                let year = Number(match[3] || now.getFullYear());
                const clock = parseClock(match[4] || '', 12);
                let date = new Date(year, month, Number(match[1]), clock.hour, clock.minute);
                if (!match[3] && date.getTime() > nowMs + 36 * 3600e3) {
                    year -= 1;
                    date = new Date(year, month, Number(match[1]), clock.hour, clock.minute);
                }
                return {
                    iso: date.toISOString(),
                    ms: date.getTime(),
                    precision: match[3] ? 'EXACTA' : 'APROXIMADA_CALENDARIO',
                    raw,
                    referenceAt: null,
                    source,
                    hasTime: Boolean(match[4])
                };
            }
        }

        match = lower.match(/(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)?[,]?\s*([a-z]+)\s+(\d{1,2})(?:,\s*(\d{4}))?(?:\s+at\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm)?))?/i);
        if (match) {
            const month = parseMonthName(match[1]);
            if (month !== null) {
                let year = Number(match[3] || now.getFullYear());
                const clock = parseClock(match[4] || '', 12);
                let date = new Date(year, month, Number(match[2]), clock.hour, clock.minute);
                if (!match[3] && date.getTime() > nowMs + 36 * 3600e3) {
                    year -= 1;
                    date = new Date(year, month, Number(match[2]), clock.hour, clock.minute);
                }
                return {
                    iso: date.toISOString(),
                    ms: date.getTime(),
                    precision: match[3] ? 'EXACTA' : 'APROXIMADA_CALENDARIO',
                    raw,
                    referenceAt: null,
                    source,
                    hasTime: Boolean(match[4])
                };
            }
        }

        const compact = lower
            .replace(/[·•]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        const relative = compact.match(/^(?:hace\s+)?(\d+)\s*(min|minuto(?:s)?|h|hora(?:s)?|d|día(?:s)?|sem|semana(?:s)?|w)(?:\s+\d+\s*(?:min|minuto(?:s)?|h|hora(?:s)?|d|día(?:s)?|sem|semana(?:s)?|w))?$/i);
        if (relative && raw.length <= 60) {
            const amount = Number(relative[1]);
            const unit = relative[2].toLowerCase();
            let delta = 0;
            if (/^(?:min|minuto)/.test(unit)) delta = amount * 60e3;
            else if (/^(?:h|hora)/.test(unit)) delta = amount * 3600e3;
            else if (/^(?:d|día)/.test(unit)) delta = amount * 86400e3;
            else delta = amount * 7 * 86400e3;
            const ms = nowMs - delta;
            return {
                iso: new Date(ms).toISOString(),
                ms,
                precision: 'RELATIVA_CONFIABLE',
                raw,
                referenceAt: new Date(nowMs).toISOString(),
                source,
                hasTime: /^(?:min|minuto|h|hora)/.test(unit)
            };
        }

        if (/^(?:ayer|yesterday)(?:\s+a\s+las|\s+at)?/i.test(lower)) {
            const clock = parseClock(raw, 12);
            const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, clock.hour, clock.minute);
            return {
                iso: date.toISOString(),
                ms: date.getTime(),
                precision: 'RELATIVA_CONFIABLE',
                raw,
                referenceAt: new Date(nowMs).toISOString(),
                source,
                hasTime: /(?:\d{1,2}:\d{2}|a\.?\s*m\.?|p\.?\s*m\.?|am|pm)/i.test(raw)
            };
        }
        if (/^(?:hoy|today)(?:\s+a\s+las|\s+at)?/i.test(lower)) {
            const clock = parseClock(raw, now.getHours());
            const date = new Date(now.getFullYear(), now.getMonth(), now.getDate(), clock.hour, clock.minute);
            return {
                iso: date.toISOString(),
                ms: date.getTime(),
                precision: 'RELATIVA_CONFIABLE',
                raw,
                referenceAt: new Date(nowMs).toISOString(),
                source,
                hasTime: /(?:\d{1,2}:\d{2}|a\.?\s*m\.?|p\.?\s*m\.?|am|pm)/i.test(raw)
            };
        }

        return { iso: null, ms: 0, precision: 'NO_DETECTADA', raw, referenceAt: null, source };
    }

    function isPostActionLabel(value) {
        return /(?:acciones (?:en|para|de) esta publicación|actions? (?:in|for|on) this post|more actions for this post)/i.test(normalizeSpaces(value));
    }

    function hasPostEngagementControls(node) {
        for (const control of node.querySelectorAll('[aria-label], [role="button"], button')) {
            const label = normalizeSpaces([
                control.getAttribute?.('aria-label'),
                control.getAttribute?.('title'),
                control.innerText,
                control.textContent
            ].filter(Boolean).join(' '));
            if (/^(?:me gusta|like|comentar|comment|compartir|share)$/i.test(label)
                || /(?:dejar un comentario|leave a comment|envía esto a tus amigos|send this to your friends)/i.test(label)) {
                return true;
            }
        }
        return false;
    }

    function resolvePostCard(seed) {
        let node = seed?.nodeType === Node.ELEMENT_NODE ? seed : seed?.parentElement;
        let fallback = null;
        for (let depth = 0; node && depth < 18; depth += 1, node = node.parentElement) {
            const menus = Array.from(node.querySelectorAll('[aria-label]'))
                .filter(item => isPostActionLabel(item.getAttribute('aria-label')));
            if (menus.length !== 1) continue;
            const message = Boolean(node.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]'));
            const media = Boolean(node.querySelector('video, a[href*="/photo/"], a[href*="/photos/"], a[href*="/reel/"], a[href*="/videos/"]'));
            const engagement = hasPostEngagementControls(node);
            if (!message && !media && !engagement) continue;
            if (!fallback) fallback = node;
            if ((message || media) && engagement) return node;
        }
        return fallback;
    }

    function discoverPostCards() {
        const found = [];
        const unique = new Set();
        const add = (seed) => {
            const card = resolvePostCard(seed);
            if (!card || unique.has(card)) return;
            unique.add(card);
            found.push(card);
        };

        // El menú accesible de acciones es la señal principal del contenedor
        // exterior de una publicación. Los bloques de mensaje se usan como
        // respaldo para publicaciones sin menú disponible.
        let menuCount = 0;
        document.querySelectorAll('[aria-label]').forEach(node => {
            if (isPostActionLabel(node.getAttribute('aria-label'))) {
                menuCount += 1;
                add(node);
            }
        });
        if (!menuCount) {
            document.querySelectorAll('[data-ad-preview="message"], [data-ad-comet-preview="message"]').forEach(add);
        }

        // Si Facebook expone un bloque interior y otro exterior para la misma
        // tarjeta, se conserva el contenedor exterior mínimo con controles.
        return found.filter((card, index) => !found.some((other, otherIndex) => {
            if (index === otherIndex || !other.contains(card)) return false;
            const otherMenus = Array.from(other.querySelectorAll('[aria-label]'))
                .filter(node => isPostActionLabel(node.getAttribute('aria-label'))).length;
            return otherMenus === 1;
        }));
    }

    function nodeAppearsBefore(reference, candidate) {
        if (!reference || !candidate || reference === candidate) return true;
        return Boolean(candidate.compareDocumentPosition(reference) & Node.DOCUMENT_POSITION_FOLLOWING);
    }

    function dateTextHasExplicitTime(value) {
        const raw = normalizeSpaces(value);
        return /(?:\ba\s+las\b|\bat\b|\d{1,2}:\d{2}\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?\b)/i.test(raw);
    }

    function resolveAriaLabelledText(node) {
        const labelledBy = normalizeSpaces(node?.getAttribute?.('aria-labelledby'));
        if (!labelledBy) return [];
        const values = [];
        for (const id of labelledBy.split(/\s+/)) {
            const target = document.getElementById(id);
            const text = normalizeSpaces(target?.textContent || target?.innerText || '');
            if (text) values.push(text);
        }
        return Array.from(new Set(values));
    }

    // Facebook suele guardar la fecha legible en un nodo accesible oculto.
    // El elemento del encabezado puede apuntar directamente a la fecha o al
    // nodo auxiliar "Learn More" situado inmediatamente después. Solo se
    // inspecciona el objetivo directo y su hermano anterior inmediato.
    function resolveAriaLabelledDateTexts(node) {
        const labelledBy = normalizeSpaces(node?.getAttribute?.('aria-labelledby'));
        if (!labelledBy) return [];
        const values = [];
        const add = value => {
            const dateText = extractStandaloneDateFragment(value);
            if (dateText) values.push(dateText);
        };
        for (const id of labelledBy.split(/\s+/)) {
            const target = document.getElementById(id);
            if (!target) continue;
            add(target.textContent || target.innerText || '');
            const wrapper = target.parentElement;
            const previous = wrapper?.previousElementSibling || target.previousElementSibling;
            if (previous) add(previous.textContent || previous.innerText || '');
        }
        return Array.from(new Set(values));
    }

    function targetAuthorAnchor(card, targetSlug = currentProfileSlug()) {
        const anchors = Array.from(card?.querySelectorAll?.('a[href]') || [])
            .filter(anchor => profileAnchorMatchesTarget(anchor, targetSlug));
        if (!anchors.length) return null;

        // Facebook suele incluir primero el enlace de la foto de perfil y luego
        // el enlace textual con el nombre. Para localizar correctamente la línea
        // temporal se prioriza el enlace de texto, no el avatar.
        const ranked = anchors.map((anchor, index) => {
            const text = normalizeSpaces(anchor.innerText || anchor.textContent || '');
            const aria = normalizeSpaces(anchor.getAttribute?.('aria-label') || '');
            const rect = anchor.getBoundingClientRect();
            const visible = elementVisible(anchor);
            const hasImage = Boolean(anchor.querySelector?.('img, svg, image'));
            let score = 0;
            if (visible) score += 120;
            if (text && /[\p{L}]/u.test(text)) score += 180 + Math.min(80, text.length * 2);
            if (aria && /[\p{L}]/u.test(aria)) score += 60;
            if (hasImage && !text) score -= 180;
            if (rect.width >= 55 && rect.height >= 10 && rect.height <= 38) score += 45;
            if (rect.width <= 48 && rect.height >= 32) score -= 45;
            score -= index * 0.01;
            return { anchor, score };
        }).sort((a, b) => b.score - a.score);
        return ranked[0]?.anchor || anchors[0] || null;
    }


    function documentOrderIndex(root, node) {
        if (!root || !node) return -1;
        let index = 0;
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
        let current = root;
        while (current) {
            if (current === node) return index;
            index += 1;
            current = walker.nextNode();
        }
        return -1;
    }

    function lowestCommonAncestorWithin(a, b, boundary) {
        if (!a || !b || !boundary) return boundary || null;
        const ancestors = new Set();
        let current = a;
        while (current) {
            ancestors.add(current);
            if (current === boundary) break;
            current = current.parentElement;
        }
        current = b;
        while (current) {
            if (ancestors.has(current)) return current;
            if (current === boundary) break;
            current = current.parentElement;
        }
        return boundary;
    }

    function childBranchUnder(node, ancestor) {
        if (!node || !ancestor) return null;
        let current = node;
        let previous = node;
        while (current && current !== ancestor) {
            previous = current;
            current = current.parentElement;
        }
        return current === ancestor ? previous : null;
    }

    // Aísla la franja superior exacta de la tarjeta: foto, autor, línea de
    // fecha/audiencia y botón de acciones. La fecha se busca únicamente aquí.
    function resolvePostHeaderRegion(card, messageNode = null, targetSlug = currentProfileSlug()) {
        const author = targetAuthorAnchor(card, targetSlug);
        if (!author) return { author: null, region: null };

        if (messageNode && card.contains(messageNode)) {
            const common = lowestCommonAncestorWithin(author, messageNode, card);
            const branch = childBranchUnder(author, common);
            if (branch && branch !== messageNode && branch.contains(author)) {
                return { author, region: branch };
            }
        }

        let current = author;
        while (current && current !== card) {
            const actions = Array.from(current.querySelectorAll?.('[aria-label]') || [])
                .filter(node => isPostActionLabel(node.getAttribute('aria-label')));
            if (actions.length === 1) return { author, region: current };
            current = current.parentElement;
        }
        return { author, region: card };
    }

    function isNodeAfterAuthorBeforeMessage(node, author, messageNode, card) {
        if (!node || !author || !card || !card.contains(node)) return false;
        if (node === author || author.contains(node) || isCommentDateNode(node, card)) return false;
        const action = node.closest?.('[aria-label]');
        if (action && isPostActionLabel(action.getAttribute('aria-label'))) return false;

        const authorPosition = author.compareDocumentPosition(node);
        if (!(authorPosition & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        if (messageNode) {
            const nodePosition = node.compareDocumentPosition(messageNode);
            if (!(nodePosition & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
        }
        return true;
    }


    function normalizeVisualDateLine(value) {
        let text = normalizeSpaces(value)
            .replace(/\s*([·•])\s*/g, ' $1 ')
            .replace(/\s+/g, ' ')
            .trim();
        if (!text) return '';

        // Respaldo para fechas cuyos caracteres fueron visualmente ordenados
        // por CSS pero quedaron sin espacios al reconstruir la línea.
        const compact = text.replace(/\s+/g, '').toLowerCase();
        const months = '(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre|january|february|march|april|may|june|july|august|september|october|november|december)';
        const glued = compact.match(new RegExp('^(\\d{1,2})de' + months + '(?:de(\\d{4}))?(?:alas(\\d{1,2})(?::(\\d{2}))?(am|pm|a\\.?m\\.?|p\\.?m\\.?))?$','i'));
        if (glued) {
            const parts = [glued[1], 'de', glued[2]];
            if (glued[3]) parts.push('de', glued[3]);
            if (glued[4]) {
                parts.push('a las', glued[4] + (glued[5] ? `:${glued[5]}` : ''), glued[6] || '');
            }
            text = normalizeSpaces(parts.join(' '));
        }
        return text;
    }

    function reconstructVisualLine(fragments) {
        const sorted = fragments.slice().sort((a, b) => a.left - b.left || a.top - b.top);
        let result = '';
        let previousRight = null;
        let previousHeight = 14;
        for (const fragment of sorted) {
            const text = normalizeSpaces(fragment.text);
            if (!text) continue;
            if (result) {
                const gap = previousRight === null ? 0 : fragment.left - previousRight;
                const threshold = Math.max(1.4, Math.min(4.2, previousHeight * 0.14));
                const startsPunctuation = /^[,.:;·•)\]}]/.test(text);
                const endsOpening = /[(\[{]$/.test(result);
                if ((fragment.leadingSpace || gap > threshold) && !startsPunctuation && !endsOpening) result += ' ';
            }
            result += text;
            previousRight = Math.max(previousRight ?? fragment.right, fragment.right);
            previousHeight = fragment.height || previousHeight;
        }
        return normalizeVisualDateLine(result);
    }

    // Reconstruye la línea visible situada inmediatamente debajo del nombre del
    // autor. Se basa en coordenadas renderizadas, por lo que funciona aunque
    // Facebook fragmente u ordene los caracteres mediante CSS.
    function visualHeaderDateCandidates(card, messageNode = null, targetSlug = currentProfileSlug()) {
        const { author, region } = resolvePostHeaderRegion(card, messageNode, targetSlug);
        if (!author || !card) return [];
        const authorRect = author.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        if (authorRect.width <= 0 || authorRect.height <= 0 || cardRect.width <= 0) return [];

        const messageRect = messageNode?.getBoundingClientRect?.() || null;
        const topMin = authorRect.bottom - 4;
        let bottomMax = Math.min(cardRect.top + 155, authorRect.bottom + 58);
        if (messageRect && messageRect.width > 0 && messageRect.height > 0 && messageRect.top > authorRect.top) {
            bottomMax = Math.min(bottomMax, messageRect.top - 1);
        }
        if (bottomMax <= topMin + 4) bottomMax = authorRect.bottom + 52;
        const leftMin = Math.max(cardRect.left, authorRect.left - 18);
        const rightMax = cardRect.right - 46;
        const root = region && region.contains(author) ? region : card;
        const fragments = [];
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let textNode = walker.nextNode();
        let inspected = 0;
        while (textNode && inspected < 900) {
            inspected += 1;
            const parent = textNode.parentElement;
            const original = String(textNode.nodeValue || '');
            const text = normalizeSpaces(original);
            if (parent && text && !author.contains(parent)
                && !(messageNode && (messageNode === parent || messageNode.contains(parent)))
                && !isCommentDateNode(parent, card)) {
                const action = parent.closest?.('[aria-label]');
                const actionLabel = normalizeSpaces(action?.getAttribute?.('aria-label') || '');
                if (!isPostActionLabel(actionLabel)
                    && !/(?:me gusta|like|comentar|comment|compartir|share|acciones en esta publicación)/i.test(actionLabel)) {
                    try {
                        const range = document.createRange();
                        range.selectNodeContents(textNode);
                        const rects = Array.from(range.getClientRects());
                        range.detach?.();
                        for (const rect of rects) {
                            const centerY = rect.top + rect.height / 2;
                            if (rect.width <= 0 || rect.height <= 0) continue;
                            if (centerY < topMin || centerY > bottomMax) continue;
                            if (rect.right < leftMin || rect.left > rightMax) continue;
                            fragments.push({
                                text,
                                leadingSpace: /^\s/.test(original),
                                left: rect.left,
                                right: rect.right,
                                top: rect.top,
                                bottom: rect.bottom,
                                height: rect.height,
                                centerY,
                                node: parent
                            });
                        }
                    } catch (_) { /* best effort */ }
                }
            }
            textNode = walker.nextNode();
        }
        if (!fragments.length) return [];

        const lines = [];
        for (const fragment of fragments.sort((a, b) => a.centerY - b.centerY || a.left - b.left)) {
            let line = lines.find(item => Math.abs(item.centerY - fragment.centerY) <= Math.max(3.5, fragment.height * 0.28));
            if (!line) {
                line = { centerY: fragment.centerY, top: fragment.top, fragments: [] };
                lines.push(line);
            }
            line.fragments.push(fragment);
            line.centerY = (line.centerY * (line.fragments.length - 1) + fragment.centerY) / line.fragments.length;
            line.top = Math.min(line.top, fragment.top);
        }

        const candidates = [];
        const seen = new Set();
        for (const line of lines.sort((a, b) => a.top - b.top)) {
            const reconstructed = reconstructVisualLine(line.fragments);
            const raw = extractStandaloneDateFragment(reconstructed);
            if (!raw || seen.has(raw)) continue;
            const parsed = parseFacebookDate(raw, Date.now(), 'AUTHOR_DATE_VISUAL_LINE');
            if (!parsed?.ms || parsed.ms > Date.now() + 10 * 60e3) continue;
            parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
            parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
            parsed.node = line.fragments[0]?.node || null;
            const verticalDistance = Math.max(0, line.top - authorRect.bottom);
            candidates.push({ parsed, score: 1145 - Math.min(120, verticalDistance * 3) });
            seen.add(raw);
        }
        return candidates.sort((a, b) => b.score - a.score);
    }

    function postActionMenus(root = document) {
        if (!root) return [];
        const menus = [];
        if (root.matches?.('[aria-label]') && isPostActionLabel(root.getAttribute('aria-label'))) {
            menus.push(root);
        }
        for (const node of root.querySelectorAll?.('[aria-label]') || []) {
            if (isPostActionLabel(node.getAttribute('aria-label'))) menus.push(node);
        }
        return Array.from(new Set(menus));
    }

    function cardNearViewport(card, marginScreens = 1.1) {
        if (!card || !elementVisible(card)) return false;
        const rect = card.getBoundingClientRect();
        const viewport = Math.max(1, Number(innerHeight || document.documentElement?.clientHeight || 1));
        const margin = viewport * Math.max(0, Number(marginScreens) || 0);
        return rect.bottom >= -margin && rect.top <= viewport + margin;
    }

    function cloneResolvedDate(value) {
        if (!value) return null;
        return { ...value };
    }


    function extractExactCalendarDateFragment(value) {
        const text = normalizeSpaces(value);
        if (!text) return '';
        const spanish = text.match(/(?:lunes|martes|miércoles|miercoles|jueves|viernes|sábado|sabado|domingo)[,]?\s+\d{1,2}\s+de\s+(?:enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)\s+de\s+\d{4}(?:\s+a\s+las\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?/i)
            || text.match(/\d{1,2}\s+de\s+(?:enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)\s+de\s+\d{4}(?:\s+a\s+las\s+\d{1,2}(?::\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)?)?/i);
        if (spanish) return normalizeSpaces(spanish[0]);
        const english = text.match(/(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)[,]?\s+(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},\s+\d{4}(?:\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?)?/i)
            || text.match(/(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},\s+\d{4}(?:\s+at\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?)?/i);
        return english ? normalizeSpaces(english[0]) : '';
    }

    function privacyAudienceTitleNodes(card) {
        if (!card) return [];
        return Array.from(card.querySelectorAll('svg title')).filter(title =>
            /^(?:compartido con|shared with)\s*:/i.test(normalizeSpaces(title.textContent || ''))
        );
    }

    function visualLeafFragments(root) {
        if (!root) return [];
        const rootRect = root.getBoundingClientRect();
        if (rootRect.width <= 0 || rootRect.height <= 0) return [];
        const leaves = Array.from(root.querySelectorAll('span')).filter(node => !node.querySelector('span'));
        const fragments = [];
        for (const leaf of leaves) {
            if (!elementVisible(leaf)) continue;
            const original = String(leaf.textContent || '').replace(/[\u00a0\u202f]/g, ' ');
            if (!original) continue;
            const rect = leaf.getBoundingClientRect();
            if (rect.width <= 0 || rect.height <= 0) continue;
            if (rect.right < rootRect.left || rect.left > rootRect.right || rect.bottom < rootRect.top || rect.top > rootRect.bottom) continue;
            const x = Math.max(0, Math.min(innerWidth - 1, rect.left + rect.width / 2));
            const y = Math.max(0, Math.min(innerHeight - 1, rect.top + rect.height / 2));
            const hit = document.elementsFromPoint(x, y).some(node => node === leaf || leaf.contains(node) || node.contains(leaf));
            if (!hit) continue;
            fragments.push({
                text: original,
                leadingSpace: /^\s/.test(original),
                left: rect.left,
                right: rect.right,
                top: rect.top,
                bottom: rect.bottom,
                height: rect.height
            });
        }
        const unique = new Map();
        for (const fragment of fragments) {
            const key = `${Math.round(fragment.left)}:${Math.round(fragment.top)}:${fragment.text}`;
            if (!unique.has(key)) unique.set(key, fragment);
        }
        return Array.from(unique.values());
    }

    function reconstructVisibleTextFromElement(element) {
        const fragments = visualLeafFragments(element);
        if (!fragments.length) {
            const direct = normalizeSpaces(element?.innerText || element?.textContent || '');
            return isObfuscatedText(direct) ? '' : direct;
        }
        return reconstructVisualLine(fragments);
    }

    function findDateLinkByPrivacyIcon(card) {
        if (!card || !document.contains(card)) return null;
        const candidates = [];
        for (const title of privacyAudienceTitleNodes(card)) {
            const svg = title.closest('svg');
            if (!svg) continue;
            const svgRect = svg.getBoundingClientRect();
            let scope = svg.parentElement;
            for (let level = 0; scope && level <= 8 && card.contains(scope); level += 1, scope = scope.parentElement) {
                const links = Array.from(scope.querySelectorAll('a[role="link"], a[href]'));
                for (const link of links) {
                    if (!card.contains(link) || !elementVisible(link)) continue;
                    const position = link.compareDocumentPosition(svg);
                    if (!(position & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
                    const href = nodeHref(link);
                    if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) continue;
                    const rect = link.getBoundingClientRect();
                    const sameLine = Math.abs((rect.top + rect.height / 2) - (svgRect.top + svgRect.height / 2)) <= Math.max(24, svgRect.height * 2.5);
                    const gap = svgRect.left - rect.right;
                    const visibleRaw = extractStandaloneDateFragment(reconstructVisibleTextFromElement(link));
                    // La estructura real coloca el enlace de fecha como el último
                    // vínculo anterior al SVG. La geometría se usa como refuerzo,
                    // no como requisito, porque Facebook aplica transformaciones
                    // CSS que pueden hacer que el rectángulo del enlace abarque la
                    // fila completa aunque visualmente muestre solo “5 h”.
                    let score = 300 - level * 6;
                    if (visibleRaw) score += 260;
                    if (sameLine) score += 45;
                    if (gap >= -12 && gap <= 80) score += 35;
                    if (link.closest('div') === svg.closest('div')) score += 25;
                    candidates.push({ link, svg, title, visibleRaw, score, level, gap, sameLine });
                }
                if (candidates.some(item => item.visibleRaw && item.level === level)) break;
            }
        }
        candidates.sort((a, b) => b.score - a.score);
        return candidates[0] || null;
    }

    function tooltipNodeText(node) {
        return normalizeSpaces([
            node?.innerText,
            node?.textContent,
            node?.getAttribute?.('aria-label'),
            node?.getAttribute?.('title')
        ].filter(Boolean).join(' | '));
    }

    function collectExactTooltipDates(beforeState = new Map()) {
        const candidates = [];
        const nodes = Array.from(document.querySelectorAll('[role="tooltip"], [data-visualcompletion="ignore-dynamic"]'));
        for (const node of nodes) {
            const currentText = tooltipNodeText(node);
            const previousText = beforeState.get(node) || '';
            const changed = !beforeState.has(node) || currentText !== previousText;
            if (!changed || !elementVisible(node)) continue;
            const raw = extractExactCalendarDateFragment(currentText);
            if (!raw) continue;
            candidates.push({
                raw,
                node,
                fresh: !beforeState.has(node),
                changed,
                roleTooltip: node.getAttribute?.('role') === 'tooltip'
            });
        }
        return candidates;
    }

    async function hoverDateLinkForExactTooltip(dateLinkInfo, nowMs = Date.now(), options = {}) {
        const link = dateLinkInfo?.link;
        if (!link || !document.contains(link) || !elementVisible(link)) {
            return { attempted: false, resolved: false, date: null };
        }
        const before = new Map(Array.from(document.querySelectorAll('[role="tooltip"], [data-visualcompletion="ignore-dynamic"]')).map(node => [node, tooltipNodeText(node)]));
        const rect = link.getBoundingClientRect();
        const eventOptions = {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX: Math.round(rect.left + rect.width / 2),
            clientY: Math.round(rect.top + rect.height / 2),
            pointerType: 'mouse',
            isPrimary: true
        };
        try { link.focus({ preventScroll: true }); } catch (_) { /* best effort */ }
        for (const type of ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'mousemove', 'focus', 'focusin']) {
            try {
                const event = type.startsWith('pointer') && typeof PointerEvent === 'function'
                    ? new PointerEvent(type, eventOptions)
                    : new MouseEvent(type, eventOptions);
                link.dispatchEvent(event);
            } catch (_) { /* best effort */ }
        }

        const timeoutMs = Math.max(700, Number(options.timeoutMs || 1700));
        const pollMs = Math.max(80, Number(options.pollMs || 120));
        const started = Date.now();
        let best = null;
        while (Date.now() - started <= timeoutMs) {
            const exact = extractExactCalendarDateFragment(link.getAttribute('title'))
                || extractExactCalendarDateFragment(link.getAttribute('aria-label'));
            if (exact) {
                best = { raw: exact, node: link, fresh: true };
                break;
            }
            const candidates = collectExactTooltipDates(before);
            if (candidates.length) {
                candidates.sort((a, b) => Number(b.roleTooltip) - Number(a.roleTooltip) || Number(b.fresh) - Number(a.fresh));
                best = candidates[0];
                break;
            }
            await sleep(pollMs);
        }

        try {
            link.dispatchEvent(new MouseEvent('mouseout', { bubbles: true, cancelable: true, view: window }));
            link.dispatchEvent(new MouseEvent('mouseleave', { bubbles: false, cancelable: true, view: window }));
            link.blur?.();
        } catch (_) { /* best effort */ }

        if (!best?.raw) return { attempted: true, resolved: false, date: null };
        const parsed = parseFacebookDate(best.raw, nowMs, 'AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT');
        if (!parsed?.ms || String(parsed.precision || '').toUpperCase() === 'RELATIVA_CONFIABLE') {
            return { attempted: true, resolved: false, date: null };
        }
        parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(best.raw);
        parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
        parsed.node = link;
        parsed.visibleRaw = dateLinkInfo.visibleRaw || null;
        parsed.tooltipRaw = best.raw;
        parsed.privacyTitle = normalizeSpaces(dateLinkInfo.title?.textContent || '');
        return { attempted: true, resolved: true, date: parsed };
    }

    function resolveVisualDateByPrivacyIcon(card, nowMs = Date.now()) {
        const info = findDateLinkByPrivacyIcon(card);
        if (!info?.link) return { info: null, date: null };
        const raw = info.visibleRaw || extractStandaloneDateFragment(reconstructVisibleTextFromElement(info.link));
        info.visibleRaw = raw || null;
        if (!raw) return { info, date: null };
        const parsed = parseFacebookDate(raw, nowMs, 'AUTHOR_DATE_PRIVACY_VISUAL_EXACT');
        if (!parsed?.ms) return { info, date: null };
        parsed.node = info.link;
        parsed.visibleRaw = raw;
        parsed.tooltipRaw = null;
        parsed.privacyTitle = normalizeSpaces(info.title?.textContent || '');
        parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
        parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
        if (String(parsed.precision || '').toUpperCase() === 'RELATIVA_CONFIABLE') {
            parsed.source = 'AUTHOR_DATE_PRIVACY_VISUAL_RELATIVE';
        }
        return { info, date: parsed };
    }

    // Estrategia validada en DevTools: parte del botón accesible "Acciones en
    // esta publicación", asciende hasta el primer contenedor mínimo que todavía
    // contiene un solo menú de publicación y resuelve globalmente el nodo que
    // señala aria-labelledby. Las fechas repetidas con el mismo texto se
    // consideran una sola evidencia semántica, pues Facebook puede conservar
    // dos controles accesibles equivalentes durante una re-renderización.
    function resolveActionAnchoredDateForMenu(menu, targetSlug = currentProfileSlug(), nowMs = Date.now()) {
        if (!menu || !document.contains(menu)) return null;

        const cached = actionDateByMenu.get(menu);
        if (cached?.ms) return cloneResolvedDate(cached);

        let scope = menu.parentElement;
        for (let level = 1; scope && level <= 14; level += 1, scope = scope.parentElement) {
            const scopedMenus = postActionMenus(scope);

            // Cuando el contenedor ya incluye dos publicaciones, no se sigue
            // ascendiendo para impedir que una fecha se asocie a la tarjeta vecina.
            if (scopedMenus.length > 1) break;
            if (scopedMenus.length !== 1 || scopedMenus[0] !== menu) continue;

            const semanticCandidates = new Map();
            const labelledNodes = [];
            if (scope.matches?.('[aria-labelledby]')) labelledNodes.push(scope);
            for (const node of scope.querySelectorAll('[aria-labelledby]')) labelledNodes.push(node);

            for (const node of Array.from(new Set(labelledNodes))) {
                if (node === menu || menu.contains(node)) continue;

                const control = node.closest?.('a[role="link"], a[href], [role="link"]') || node;
                const href = nodeHref(control);
                if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) continue;

                const labelledBy = normalizeSpaces(node.getAttribute('aria-labelledby'));
                if (!labelledBy) continue;

                for (const id of labelledBy.split(/\s+/).filter(Boolean)) {
                    const target = document.getElementById(id);
                    if (!target) continue;

                    const targetText = normalizeSpaces(target.innerText || target.textContent || '');
                    const raw = extractStandaloneDateFragment(targetText);
                    if (!raw) continue;

                    const parsed = parseFacebookDate(raw, nowMs, 'AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT');
                    if (!parsed?.ms || parsed.ms > nowMs + 10 * 60e3) continue;

                    parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
                    parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
                    parsed.node = node;
                    parsed.ariaLabelledById = id;
                    parsed.actionScopeLevel = level;
                    parsed.actionMenuLabel = normalizeSpaces(menu.getAttribute('aria-label'));
                    parsed.targetProfileSlug = targetSlug || null;

                    // Deduplicación por el valor de fecha visible, no por el ID
                    // interno, porque Facebook puede duplicar temporalmente el
                    // control accesible con IDs distintos durante la hidratación.
                    const semanticKey = normalizeSpaces(raw).toLocaleLowerCase('es');
                    if (!semanticCandidates.has(semanticKey)) {
                        semanticCandidates.set(semanticKey, parsed);
                    }
                }
            }

            if (semanticCandidates.size === 1) {
                const parsed = cloneResolvedDate(Array.from(semanticCandidates.values())[0]);
                actionDateByMenu.set(menu, parsed);
                pendingDateMenus.delete(menu);
                const card = resolvePostCard(menu);
                if (card) actionDateByCard.set(card, parsed);
                return cloneResolvedDate(parsed);
            }

            // Dos fechas distintas en el mismo contenedor mínimo representan
            // ambigüedad real. No se infiere ni se usa la posición del feed.
            if (semanticCandidates.size > 1) return null;
        }
        return null;
    }

    function queuePostActionMenus(root) {
        if (!root || root.nodeType !== Node.ELEMENT_NODE) return;
        for (const menu of postActionMenus(root)) {
            if (!actionDateByMenu.get(menu)?.ms) pendingDateMenus.add(menu);
        }
    }

    function drainPendingDateMenus(limit = 80) {
        let processed = 0;
        let resolved = 0;
        for (const menu of Array.from(pendingDateMenus)) {
            if (processed >= limit) break;
            if (!document.contains(menu)) {
                pendingDateMenus.delete(menu);
                continue;
            }
            const card = resolvePostCard(menu);
            if (!cardNearViewport(card || menu, 1.35)) continue;
            processed += 1;
            const date = resolveActionAnchoredDateForMenu(menu, currentProfileSlug(), Date.now());
            if (date?.ms) {
                resolved += 1;
                pendingDateMenus.delete(menu);
            }
        }
        return { processed, resolved, pending: pendingDateMenus.size };
    }

    function scheduleResolvedDatePersistence(delayMs = 35) {
        if (!captureState?.running || dateObserverPersistTimer || dateObserverPersistInFlight) return;
        dateObserverPersistTimer = setTimeout(async () => {
            dateObserverPersistTimer = null;
            if (!captureState?.running || dateObserverPersistInFlight) return;
            dateObserverPersistInFlight = true;
            try {
                // La fecha resuelta por MutationObserver debe persistirse antes de
                // que el siguiente scroll permita a Facebook virtualizar la tarjeta.
                await captureVisiblePosts({
                    dateReviewOnly: true,
                    dateHydrationAttempts: 1,
                    dateHydrationDelayMs: 90
                });
            } catch (_) {
                // La captura principal volverá a intentarlo en el siguiente ciclo.
            } finally {
                dateObserverPersistInFlight = false;
            }
        }, Math.max(20, Number(delayMs) || 35));
    }

    function schedulePendingDateDrain() {
        if (dateObserverTimer) return;
        dateObserverTimer = setTimeout(() => {
            dateObserverTimer = null;
            if (!captureState?.running) return;
            const result = drainPendingDateMenus();
            if (result.resolved > 0) scheduleResolvedDatePersistence();
        }, 90);
    }

    function startFacebookDateObserver() {
        if (dateMutationObserver) return;
        queuePostActionMenus(document.documentElement);
        dateMutationObserver = new MutationObserver((mutations) => {
            let relevant = false;
            for (const mutation of mutations) {
                if (mutation.type === 'attributes') {
                    relevant = true;
                    queuePostActionMenus(mutation.target);
                    continue;
                }
                if (mutation.type !== 'childList' || !mutation.addedNodes?.length) continue;
                relevant = true;
                for (const node of mutation.addedNodes) queuePostActionMenus(node);
            }
            // El nodo oculto señalado por aria-labelledby puede agregarse lejos
            // de la tarjeta; cualquier hidratación del DOM activa un reintento
            // exclusivo de los menús pendientes, no de todas las publicaciones.
            if (relevant && pendingDateMenus.size) schedulePendingDateDrain();
        });
        dateMutationObserver.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['aria-label', 'aria-labelledby', 'id']
        });
    }

    function stopFacebookDateObserver() {
        try { dateMutationObserver?.disconnect(); } catch (_) { /* ignore */ }
        dateMutationObserver = null;
        if (dateObserverTimer) clearTimeout(dateObserverTimer);
        if (dateObserverPersistTimer) clearTimeout(dateObserverPersistTimer);
        dateObserverTimer = null;
        dateObserverPersistTimer = null;
        dateObserverPersistInFlight = false;
        pendingDateMenus.clear();
    }

    function auditActionAnchoredHeaderDates(options = {}) {
        const targetSlug = options.targetSlug || currentProfileSlug();
        const nowMs = Number(options.nowMs || Date.now());
        const menus = postActionMenus(document);
        const unresolved = [];
        const resolvedCards = new Set();
        let resolvedMenus = 0;

        drainPendingDateMenus();

        for (const menu of menus) {
            const card = resolvePostCard(menu);
            const nearViewport = cardNearViewport(card || menu, 1.2);
            let date = actionDateByMenu.get(menu);
            if (!date?.ms && nearViewport) {
                date = resolveActionAnchoredDateForMenu(menu, targetSlug, nowMs);
            }
            if (date?.ms) {
                resolvedMenus += 1;
                pendingDateMenus.delete(menu);
                if (card) {
                    actionDateByCard.set(card, date);
                    resolvedCards.add(card);
                }
            } else {
                unresolved.push({ menu, card, nearViewport });
                if (nearViewport) pendingDateMenus.add(menu);
            }
        }

        const unresolvedNearViewport = unresolved.filter(item => item.nearViewport);
        const audit = {
            totalMenus: menus.length,
            resolvedMenus,
            unresolvedMenus: unresolved.length,
            unresolvedNearViewport: unresolvedNearViewport.length,
            resolvedCards: resolvedCards.size,
            pendingQueue: pendingDateMenus.size,
            checkedAt: Date.now()
        };
        latestActionDateAudit = audit;
        return audit;
    }

    async function stabilizeActionAnchoredHeaderDates(options = {}) {
        const attempts = Math.max(1, Math.min(8, Number(options.attempts || 4)));
        const delayMs = Math.max(80, Math.min(700, Number(options.delayMs || 180)));
        let audit = null;
        let attemptsUsed = 0;

        for (let attempt = 1; attempt <= attempts; attempt += 1) {
            attemptsUsed = attempt;
            audit = auditActionAnchoredHeaderDates(options);
            if (!audit.unresolvedNearViewport) break;
            if (attempt < attempts) await sleep(delayMs + (attempt - 1) * 55);
        }

        return {
            ...(audit || auditActionAnchoredHeaderDates(options)),
            attemptsUsed
        };
    }

    // Ruta principal v1.5.25. Primero consulta la fecha fijada por el barrido
    // global y, si todavía no existe, reproduce de forma local la misma estrategia
    // validada en Console. No depende de distancias geométricas ni del texto del cuerpo.
    async function stabilizeSingleCardDate(card, options = {}) {
        const attempts = Math.max(1, Math.min(10, Number(options.attempts || 7)));
        const delayMs = Math.max(70, Math.min(450, Number(options.delayMs || 115)));
        const targetSlug = options.targetSlug || currentProfileSlug();
        let attemptsUsed = 0;
        let menus = [];
        let resolvedMenus = 0;

        for (let attempt = 1; attempt <= attempts; attempt += 1) {
            attemptsUsed = attempt;
            menus = postActionMenus(card).filter(menu => document.contains(menu));
            resolvedMenus = 0;
            for (const menu of menus) {
                const parsed = actionDateByMenu.get(menu)
                    || resolveActionAnchoredDateForMenu(menu, targetSlug, Date.now());
                if (parsed?.ms) {
                    resolvedMenus += 1;
                    actionDateByMenu.set(menu, parsed);
                    actionDateByCard.set(card, parsed);
                    pendingDateMenus.delete(menu);
                } else {
                    pendingDateMenus.add(menu);
                }
            }
            if (menus.length && resolvedMenus === menus.length) break;
            if (attempt < attempts) await sleep(delayMs + Math.min(160, (attempt - 1) * 28));
        }

        const unresolved = Math.max(0, menus.length - resolvedMenus);
        const audit = {
            totalMenus: menus.length,
            resolvedMenus,
            unresolvedMenus: unresolved,
            unresolvedNearViewport: unresolved,
            resolvedCards: resolvedMenus > 0 ? 1 : 0,
            pendingQueue: pendingDateMenus.size,
            checkedAt: Date.now(),
            attemptsUsed,
            scope: 'SINGLE_CARD'
        };
        latestActionDateAudit = audit;
        return audit;
    }

    async function tryResolveRelativeDateTooltip(card, options = {}) {
        const cached = actionDateByCard.get(card);
        if (!cached?.ms || String(cached.precision || '').toUpperCase() !== 'RELATIVA_CONFIABLE') {
            return { attempted: false, resolved: false, date: cached || null };
        }
        const control = cached.node;
        if (!control || !document.contains(control) || !elementVisible(control)) {
            return { attempted: false, resolved: false, date: cached };
        }

        const beforeTooltips = new Set(Array.from(document.querySelectorAll('[role="tooltip"]')));
        const events = ['pointerover', 'mouseover', 'mouseenter', 'mousemove'];
        for (const type of events) {
            try {
                control.dispatchEvent(new MouseEvent(type, {
                    bubbles: type !== 'mouseenter',
                    cancelable: true,
                    view: window,
                    clientX: Math.round(control.getBoundingClientRect().left + 4),
                    clientY: Math.round(control.getBoundingClientRect().top + 4)
                }));
            } catch (_) { /* best effort */ }
        }
        await sleep(Math.max(140, Number(options.delayMs || 230)));

        const candidates = [];
        const add = (value, node, score) => {
            const raw = extractStandaloneDateFragment(value);
            if (!raw) return;
            const parsed = parseFacebookDate(raw, Date.now(), 'AUTHOR_DATE_HOVER_TOOLTIP');
            if (!parsed?.ms || String(parsed.precision || '').toUpperCase() === 'RELATIVA_CONFIABLE') return;
            parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
            parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
            parsed.node = node || control;
            parsed.actionScopeLevel = cached.actionScopeLevel || 0;
            parsed.actionMenuLabel = cached.actionMenuLabel || '';
            parsed.ariaLabelledById = cached.ariaLabelledById || '';
            candidates.push({ parsed, score });
        };

        add(control.getAttribute('title'), control, 1500);
        add(control.getAttribute('aria-label'), control, 1490);
        for (const tooltip of document.querySelectorAll('[role="tooltip"]')) {
            if (!elementVisible(tooltip) && beforeTooltips.has(tooltip)) continue;
            add(tooltip.innerText || tooltip.textContent || '', tooltip, beforeTooltips.has(tooltip) ? 1400 : 1480);
        }
        candidates.sort((a, b) => b.score - a.score);
        const best = candidates[0]?.parsed || null;

        try {
            control.dispatchEvent(new MouseEvent('mouseout', { bubbles: true, cancelable: true, view: window }));
            control.dispatchEvent(new MouseEvent('mouseleave', { bubbles: false, cancelable: true, view: window }));
        } catch (_) { /* best effort */ }

        if (!best) return { attempted: true, resolved: false, date: cached };
        actionDateByCard.set(card, best);
        for (const menu of postActionMenus(card)) actionDateByMenu.set(menu, best);
        return { attempted: true, resolved: true, date: cloneResolvedDate(best) };
    }

    // Respaldo v1.5.25: inspecciona únicamente controles aria-labelledby
    // pertenecientes a la tarjeta y ubicados antes del cuerpo. No requiere que el
    // control conserve dimensiones visibles durante una re-renderización, pero
    // mantiene el vínculo estructural con la publicación actual.
    function strictCardAriaDateCandidates(card, messageNode = null) {
        if (!card) return [];
        const candidates = [];
        const semantic = new Map();
        const nodes = Array.from(card.querySelectorAll('[aria-labelledby]'));
        for (const node of nodes) {
            if (!card.contains(node) || isCommentDateNode(node, card)) continue;
            if (messageNode && (node === messageNode || messageNode.contains(node))) continue;
            if (messageNode && !nodeAppearsBefore(messageNode, node)) continue;
            const action = node.closest?.('[aria-label]');
            if (action && isPostActionLabel(action.getAttribute('aria-label'))) continue;
            const href = nodeHref(node.closest?.('a[role="link"], a[href], [role="link"]') || node);
            if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) continue;

            const labelledBy = normalizeSpaces(node.getAttribute('aria-labelledby'));
            if (!labelledBy) continue;
            for (const id of labelledBy.split(/\s+/).filter(Boolean)) {
                const target = document.getElementById(id);
                if (!target) continue;
                const raw = extractStandaloneDateFragment(target.innerText || target.textContent || '');
                if (!raw) continue;
                const parsed = parseFacebookDate(raw, Date.now(), 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT');
                if (!parsed?.ms || parsed.ms > Date.now() + 10 * 60e3) continue;
                parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
                parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
                parsed.node = node;
                parsed.ariaLabelledById = id;
                const key = normalizeSpaces(raw).toLocaleLowerCase('es');
                if (!semantic.has(key)) semantic.set(key, parsed);
            }
        }
        if (semantic.size !== 1) return [];
        const parsed = Array.from(semantic.values())[0];
        actionDateByCard.set(card, parsed);
        return [{ parsed, score: 1285 }];
    }

    function actionAnchoredHeaderDateCandidates(card, targetSlug = currentProfileSlug()) {
        if (!card) return [];

        const cachedCardDate = actionDateByCard.get(card);
        if (cachedCardDate?.ms) return [{ parsed: cloneResolvedDate(cachedCardDate), score: 1700 }];

        const results = [];
        for (const menu of postActionMenus(card)) {
            const parsed = resolveActionAnchoredDateForMenu(menu, targetSlug, Date.now());
            if (parsed?.ms) results.push({ parsed, score: 1650 - Number(parsed.actionScopeLevel || 0) });
        }

        const unique = new Map();
        for (const candidate of results) {
            const key = normalizeSpaces(candidate.parsed?.raw || '').toLocaleLowerCase('es');
            if (key && !unique.has(key)) unique.set(key, candidate);
        }
        if (unique.size === 1) {
            const candidate = Array.from(unique.values())[0];
            actionDateByCard.set(card, candidate.parsed);
            return [candidate];
        }
        return [];
    }

    // Ruta principal confirmada directamente en DevTools:
    // el control temporal visible dentro de la tarjeta contiene aria-labelledby
    // y el texto legible de la fecha se encuentra en un nodo externo del documento.
    // La asociación se conserva porque el control que porta aria-labelledby sí
    // pertenece a la tarjeta actual.
    function accessibleHeaderDateCandidates(card, messageNode = null, targetSlug = currentProfileSlug()) {
        if (!card) return [];
        const author = targetAuthorAnchor(card, targetSlug);
        const cardRect = card.getBoundingClientRect();
        const authorRect = author?.getBoundingClientRect?.() || null;
        const messageRect = messageNode?.getBoundingClientRect?.() || null;
        const candidates = [];
        const seen = new Set();

        for (const node of card.querySelectorAll('[aria-labelledby]')) {
            if (!card.contains(node) || isCommentDateNode(node, card)) continue;
            const control = node.closest?.('a[role="link"], a[href], [role="link"]') || node;
            if (!card.contains(control)) continue;

            const href = nodeHref(control);
            if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) continue;

            const controlRect = control.getBoundingClientRect();
            if (controlRect.width <= 0 || controlRect.height <= 0 || cardRect.width <= 0) continue;

            const relativeTop = controlRect.top - cardRect.top;
            const headerLimit = Math.min(210, Math.max(105, cardRect.height * 0.32));
            if (relativeTop < -24 || relativeTop > headerLimit) continue;

            // La fecha debe estar en la franja del encabezado: debajo o a la
            // altura del autor y antes del cuerpo principal cuando este sea visible.
            if (authorRect && authorRect.width > 0 && authorRect.height > 0) {
                if (controlRect.bottom < authorRect.top - 5) continue;
                if (controlRect.top > authorRect.bottom + 64) continue;
            }
            if (messageRect && messageRect.width > 0 && messageRect.height > 0
                && messageRect.top > cardRect.top && controlRect.top >= messageRect.top - 1) continue;

            const action = control.closest?.('[aria-label]');
            if (action && isPostActionLabel(action.getAttribute('aria-label'))) continue;

            const labelledBy = normalizeSpaces(node.getAttribute('aria-labelledby'));
            if (!labelledBy) continue;
            for (const id of labelledBy.split(/\s+/)) {
                const target = document.getElementById(id);
                if (!target) continue;
                const text = normalizeSpaces(target.innerText || target.textContent || '');
                const raw = extractStandaloneDateFragment(text);
                if (!raw) continue;
                const key = `${id}|${raw}`;
                if (seen.has(key)) continue;
                const parsed = parseFacebookDate(raw, Date.now(), 'AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT');
                if (!parsed?.ms || parsed.ms > Date.now() + 10 * 60e3) continue;
                parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
                parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
                parsed.node = node;
                parsed.ariaLabelledById = id;
                candidates.push({ parsed, score: 1320 - Math.min(120, Math.max(0, relativeTop) * 0.35) });
                seen.add(key);
            }
        }

        return candidates.sort((a, b) => b.score - a.score);
    }

    function structuralHeaderDateCandidates(card, messageNode = null, targetSlug = currentProfileSlug()) {
        const { author, region } = resolvePostHeaderRegion(card, messageNode, targetSlug);
        if (!author || !region) return [];

        const order = new Map();
        let orderIndex = 0;
        const walker = document.createTreeWalker(card, NodeFilter.SHOW_ELEMENT);
        let current = card;
        while (current) {
            order.set(current, orderIndex++);
            current = walker.nextNode();
        }

        const candidates = [];
        const seen = new Set();
        const add = (value, source, node, baseScore) => {
            const raw = extractStandaloneDateFragment(value);
            const normalizedSource = String(source || '').toUpperCase();
            if (!raw || !TRUSTED_DATE_SOURCES.has(normalizedSource)) return;
            if (!isNodeAfterAuthorBeforeMessage(node, author, messageNode, card)) return;
            const key = `${normalizedSource}|${raw}`;
            if (seen.has(key)) return;
            const parsed = parseFacebookDate(raw, Date.now(), normalizedSource);
            if (!parsed?.ms || parsed.ms > Date.now() + 10 * 60e3) return;
            seen.add(key);
            parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
            parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
            parsed.node = node;
            const distance = Math.max(0, Number(order.get(node) || 0) - Number(order.get(author) || 0));
            candidates.push({ parsed, score: baseScore - Math.min(160, distance) });
        };

        const selector = [
            'abbr[data-utime]',
            'time[datetime]',
            'abbr[title]',
            '[aria-labelledby]',
            '[aria-label]',
            '[title]'
        ].join(',');

        for (const node of region.querySelectorAll(selector)) {
            if (!isNodeAfterAuthorBeforeMessage(node, author, messageNode, card)) continue;
            add(node.getAttribute('data-utime'), 'DATA_UTIME', node, 1200);
            add(node.getAttribute('datetime'), 'TIME_DATETIME', node, 1200);
            add(node.querySelector?.('abbr[data-utime]')?.getAttribute('data-utime'), 'DATA_UTIME', node, 1190);
            add(node.querySelector?.('time[datetime]')?.getAttribute('datetime'), 'TIME_DATETIME', node, 1190);
            add(node.querySelector?.('abbr[title]')?.getAttribute('title'), 'ABBR_TITLE', node, 1160);

            for (const value of resolveAriaLabelledDateTexts(node)) {
                add(value, 'AUTHOR_DATE_ARIA_LABELLEDBY', node, 1180);
            }
            add(node.getAttribute('aria-label'), 'AUTHOR_DATE_ARIA_LABEL', node, 1100);
            add(node.getAttribute('title'), 'AUTHOR_DATE_TITLE', node, 1080);

            // Texto directo únicamente del control temporal situado entre el
            // autor y el cuerpo. Nunca se analiza el texto general de la tarjeta.
            if (node.matches('a, time, abbr, [aria-labelledby]')) {
                add(node.innerText || node.textContent || '', 'AUTHOR_DATE_DIRECT_TEXT', node, 1040);
            }
        }

        candidates.sort((a, b) => b.score - a.score);
        return candidates;
    }

    function readDate(card, permalinkInfo, messageNode = null) {
        const actionAnchored = actionAnchoredHeaderDateCandidates(card);
        if (actionAnchored.length) return actionAnchored[0].parsed;

        const strictAria = strictCardAriaDateCandidates(card, messageNode);
        if (strictAria.length) return strictAria[0].parsed;

        // Rutas anteriores conservadas exclusivamente como respaldo para otras
        // variantes del DOM de Facebook.
        const accessible = accessibleHeaderDateCandidates(card, messageNode);
        if (accessible.length) return accessible[0].parsed;

        const structural = structuralHeaderDateCandidates(card, messageNode);
        if (structural.length) return structural[0].parsed;

        // El vínculo temporal puede ser el mismo elemento que findPermalink
        // seleccionó. Solo se acepta si está en la franja del encabezado.
        const permalinkNode = permalinkInfo?.anchor || null;
        const { author, region } = resolvePostHeaderRegion(card, messageNode);
        if (permalinkNode && author && region?.contains(permalinkNode)
            && isNodeAfterAuthorBeforeMessage(permalinkNode, author, messageNode, card)) {
            const fallback = [];
            const addFallback = (value, source, score) => {
                const raw = extractStandaloneDateFragment(value);
                if (!raw || !TRUSTED_DATE_SOURCES.has(source)) return;
                const parsed = parseFacebookDate(raw, Date.now(), source);
                if (!parsed?.ms || parsed.ms > Date.now() + 10 * 60e3) return;
                parsed.hasTime = parsed.hasTime === true || dateTextHasExplicitTime(raw);
                parsed.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
                fallback.push({ parsed, score });
            };
            addFallback(permalinkNode.querySelector('abbr')?.getAttribute('data-utime'), 'DATA_UTIME', 1200);
            addFallback(permalinkNode.querySelector('time')?.getAttribute('datetime'), 'TIME_DATETIME', 1200);
            addFallback(permalinkNode.querySelector('abbr')?.getAttribute('title'), 'ABBR_TITLE', 1160);
            for (const value of resolveAriaLabelledDateTexts(permalinkNode)) {
                addFallback(value, 'AUTHOR_DATE_ARIA_LABELLEDBY', 1180);
            }
            addFallback(permalinkNode.getAttribute('aria-label'), 'PERMALINK_ARIA_LABEL', 1100);
            addFallback(permalinkNode.getAttribute('title'), 'PERMALINK_TITLE', 1080);
            addFallback(permalinkInfo?.label, 'PERMALINK_LABEL', 1040);
            fallback.sort((a, b) => b.score - a.score);
            if (fallback.length) return fallback[0].parsed;
        }

        return {
            iso: null,
            ms: 0,
            precision: 'NO_DETECTADA',
            raw: null,
            referenceAt: null,
            source: 'NO_DETECTADA',
            hasTime: false,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || null
        };
    }

    function facebookExpansionLabel(node) {
        return normalizeSpaces(
            node?.innerText
            || node?.textContent
            || node?.getAttribute?.('aria-label')
            || ''
        );
    }

    function resolveSafeFacebookTextExpander(node, card) {
        if (!(node instanceof HTMLElement) || !(card instanceof HTMLElement) || !card.contains(node)) {
            return null;
        }

        const label = facebookExpansionLabel(node);
        if (!/^(?:ver más|ver mas|see more|mostrar más|mostrar mas)$/i.test(label)) {
            return null;
        }

        // Los enlaces de notas, publicaciones, multimedia o sitios externos no
        // son expansores internos, aunque uno de sus descendientes diga "Ver más".
        if (node.closest('a[href], [role="link"]')) return null;

        let control = node.matches('button, [role="button"], div[tabindex="0"]')
            ? node
            : node.closest('button, [role="button"], div[tabindex="0"]');

        // Algunas variantes modernas usan un span con el controlador de clic
        // directamente dentro del cuerpo de la publicación. Se conserva ese caso
        // siempre que no sea un enlace y pertenezca a una zona textual.
        if (!control && node.matches('span')) {
            const textRegion = node.closest(
                '[data-ad-preview="message"], [data-ad-comet-preview="message"], div[dir="auto"]'
            );
            if (textRegion && card.contains(textRegion)) control = node;
        }

        if (!(control instanceof HTMLElement) || !card.contains(control)) return null;
        if (control.closest('a[href], [role="link"]')) return null;
        if (control.querySelector('a[href], [role="link"]')) return null;
        if (control.hasAttribute('href') || control.hasAttribute('target')) return null;

        // Evita controles pertenecientes al encabezado, navegación o multimedia.
        if (control.closest('header, nav, [data-visualcompletion="media-vc-image"]')) return null;

        return control;
    }

    function clickSeeMore(card) {
        let clicked = 0;
        const processedControls = new Set();

        for (const node of card.querySelectorAll('[role="button"], div[tabindex="0"], span')) {
            if (!elementVisible(node)) continue;
            const label = facebookExpansionLabel(node);
            if (!/^(?:ver más|ver mas|see more|mostrar más|mostrar mas)$/i.test(label)) continue;

            const control = resolveSafeFacebookTextExpander(node, card);
            if (!control) continue;

            if (processedControls.has(control)) continue;
            processedControls.add(control);

            try {
                control.click();
                clicked += 1;
            } catch (_) { /* best effort */ }
        }

        return clicked;
    }

    function cleanExtractedPostText(value) {
        return normalizeSpaces(value).replace(/\s*(?:Ver menos|See less)\s*$/i, '').trim();
    }

    function extractPostText(card) {
        const direct = card.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
        if (direct) return cleanExtractedPostText(direct.innerText || direct.textContent);
        const candidates = [];
        for (const node of card.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
            const text = normalizeSpaces(node.innerText || node.textContent);
            if (text.length < 20) continue;
            if (/^(?:me gusta|comentar|compartir|like|comment|share|seguir|follow)$/i.test(text)) continue;
            if (/\b(?:comentarios?|comments?|compartid[oa]s?|shares?|reacciones?|reactions?)\b/i.test(text) && text.length < 100) continue;
            const rect = node.getBoundingClientRect();
            candidates.push({ text, area: Math.max(1, rect.width * rect.height) });
        }
        candidates.sort((a, b) => b.text.length - a.text.length || b.area - a.area);
        return cleanExtractedPostText(candidates[0]?.text || '');
    }


    function normalizeTextForSignature(value) {
        return normalizeSpaces(String(value || '')
            .normalize('NFKC')
            .replace(/\b(?:ver menos|ver más|see less|see more)\b/gi, ' ')
            .replace(/https?:\/\/\S+/gi, ' ')
            .toLowerCase())
            .replace(/[“”"']/g, '')
            .replace(/[^\p{L}\p{N}\s#@_-]+/gu, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function normalizeExternalLink(value) {
        if (!value) return '';
        try {
            const url = new URL(value, location.origin);
            const host = url.hostname.toLowerCase().replace(/^www\./, '');
            if (/(^|\.)facebook\.com$/.test(host)) return '';
            if (host === 'youtube.com' || host === 'm.youtube.com') {
                const videoId = url.searchParams.get('v');
                return videoId ? `youtube:${videoId}` : `youtube:${url.pathname.replace(/\/+$/, '')}`;
            }
            if (host === 'youtu.be') return `youtube:${url.pathname.replace(/^\/+/, '').split('/')[0]}`;
            if (host === 'instagram.com') {
                const match = url.pathname.match(/\/(?:p|reel)\/([^/?#]+)/i);
                return match ? `instagram:${match[1]}` : `instagram:${url.pathname.replace(/\/+$/, '')}`;
            }
            return `${host}${url.pathname.replace(/\/+$/, '')}`;
        } catch (_) {
            return '';
        }
    }

    function extractExternalLinks(text, card) {
        const links = [];
        const add = (value) => {
            const normalized = normalizeExternalLink(value);
            if (normalized) links.push(normalized);
        };
        for (const match of String(text || '').matchAll(/https?:\/\/[^\s<>"']+/gi)) add(match[0].replace(/[),.;!?]+$/, ''));
        for (const anchor of card.querySelectorAll('a[href]')) add(anchor.href || anchor.getAttribute('href'));
        return Array.from(new Set(links)).sort().slice(0, 30);
    }

    function stableMediaAssetId(value) {
        if (!value) return '';
        try {
            const url = new URL(value, location.origin);
            const path = decodeURIComponent(url.pathname || '');
            const basename = path.split('/').filter(Boolean).pop() || '';
            const numeric = basename.match(/(?:^|_)(\d{8,})(?:_|\.|$)/g)?.join('_') || '';
            return `${url.hostname.toLowerCase()}:${numeric || basename}`;
        } catch (_) {
            return String(value).split('?')[0];
        }
    }

    function buildContentSignature({ authorSlug, postType, text, externalLinks, mediaAssetIds }) {
        const normalizedText = normalizeTextForSignature(text);
        const mediaGroup = /^(?:VIDEO|REEL)$/i.test(postType)
            ? 'VIDEO'
            : (/^(?:FOTO|GALERIA)$/i.test(postType) ? 'IMAGEN' : 'TEXTO');
        const stableLinks = (externalLinks || []).slice(0, 10).join('|');
        const stableMedia = (mediaAssetIds || []).slice(0, 4).join('|');
        const hasStrongText = normalizedText.length >= 24;
        const evidenceStrength = hasStrongText || Boolean(stableLinks) || Boolean(stableMedia);

        // Cuando existe texto suficiente, la firma no depende de las URLs
        // firmadas o de la carga parcial de miniaturas. Esto evita que la
        // misma publicación produzca un ID distinto en cada ciclo de scroll.
        // La multimedia solo participa cuando el texto es corto o inexistente.
        const material = hasStrongText
            ? [String(authorSlug || '').toLowerCase(), mediaGroup, normalizedText, stableLinks].join('||')
            : [String(authorSlug || '').toLowerCase(), mediaGroup, normalizedText, stableLinks, stableMedia].join('||');
        return {
            signature: evidenceStrength ? `facebook-signature:${hashText(material)}` : '',
            evidenceStrength
        };
    }

    function explicitMetricFromText(value, kind) {
        const text = normalizeSpaces(value);
        if (!text || text.length > 220) return null;
        const number = String.raw`([\d.,]+(?:\s*(?:mil|k|m|mill(?:ón|ones)?))?)`;
        const patterns = {
            comments: [
                new RegExp(`${number}\\s*(?:comentarios?|comments?)\\b`, 'i'),
                new RegExp(`\\b(?:comentarios?|comments?)\\s*${number}`, 'i')
            ],
            shares: [
                new RegExp(`${number}\\s*(?:veces?\\s+)?compartid[oa]s?\\b`, 'i'),
                new RegExp(`${number}\\s*shares?\\b`, 'i'),
                new RegExp(`\\b(?:compartid[oa]s?|shares?)\\s*${number}`, 'i')
            ],
            views: [
                new RegExp(`${number}\\s*(?:visualizaciones?|reproducciones?|views?|plays?)\\b`, 'i'),
                new RegExp(`\\b(?:visualizaciones?|reproducciones?|views?|plays?)\\s*${number}`, 'i')
            ],
            reactions: [
                new RegExp(`${number}\\s*(?:reacciones?|reactions?)\\b`, 'i'),
                new RegExp(`\\b(?:reacciones?|reactions?)\\s*${number}`, 'i'),
                new RegExp(`\\b(?:me gusta|likes?)\\s*${number}`, 'i')
            ]
        };
        for (const pattern of patterns[kind] || []) {
            const match = text.match(pattern);
            if (!match) continue;
            const rawNumber = match[1] || match[match.length - 1];
            const parsed = parseCompactNumber(rawNumber);
            if (parsed !== null) return { value: parsed, raw: text };
        }
        return null;
    }

    function extractMetric(card, kind) {
        const candidates = [];
        for (const node of card.querySelectorAll('[role="button"], button, a[aria-label], span[aria-label], [title]')) {
            const label = normalizeSpaces([node.getAttribute?.('aria-label'), node.getAttribute?.('title')].filter(Boolean).join(' '));
            const visibleText = normalizeSpaces(node.innerText || node.textContent);
            const combined = normalizeSpaces(`${label} ${visibleText}`);
            if (!combined || /^(?:comentario de|comment by)\b/i.test(combined)) continue;

            // Facebook coloca algunos contadores dentro del propio botón:
            // aria-label identifica la acción y el texto visible contiene solo
            // el número. Se acepta únicamente cuando el texto es numérico puro.
            const pureVisibleNumber = /^[\d.,]+(?:\s*(?:mil|k|m|mill(?:ón|ones)?))?$/i.test(visibleText)
                ? parseCompactNumber(visibleText)
                : null;
            if (kind === 'comments' && /^(?:dejar un comentario|leave a comment)$/i.test(label)) {
                if (pureVisibleNumber !== null) candidates.push({ value: pureVisibleNumber, raw: `${label}: ${visibleText}`, score: 8, source: 'ARIA_BUTTON_COUNTER', confidence: 'ALTA' });
                continue;
            }
            if (kind === 'shares' && /(?:envía esto a tus amigos|publícalo en tu perfil|send this to your friends|post it on your profile)/i.test(label)) {
                if (pureVisibleNumber !== null) candidates.push({ value: pureVisibleNumber, raw: `${label}: ${visibleText}`, score: 8, source: 'ARIA_BUTTON_COUNTER', confidence: 'ALTA' });
                continue;
            }
            if (kind === 'reactions' && /^(?:me gusta|like)$/i.test(label) && pureVisibleNumber !== null) {
                candidates.push({ value: pureVisibleNumber, raw: `${label}: ${visibleText}`, score: 9 });
                continue;
            }

            const explicit = explicitMetricFromText(combined, kind);
            if (!explicit) continue;
            let score = 1;
            if (label) score += 2;
            if (visibleText && /\d/.test(visibleText)) score += 3;
            candidates.push({ ...explicit, score, source: label ? 'ARIA_LABEL_EXPLICITA' : 'TEXTO_VISIBLE_EXPLICITO', confidence: label ? 'ALTA' : 'MEDIA' });
        }

        if (kind === 'reactions') {
            const breakdown = [];
            for (const node of card.querySelectorAll('[aria-label]')) {
                const label = normalizeSpaces(node.getAttribute('aria-label'));
                const match = label.match(/^(?:me gusta|me encanta|me importa|me divierte|me asombra|me entristece|me enoja|like|love|care|haha|wow|sad|angry)\s*:\s*([\d.,]+(?:\s*(?:mil|k|m))?)/i);
                if (match) {
                    const value = parseCompactNumber(match[1]);
                    if (value !== null) breakdown.push(value);
                }
            }
            if (breakdown.length) candidates.push({ value: breakdown.reduce((sum, value) => sum + value, 0), raw: extractReactionBreakdown(card), score: 4, source: 'ARIA_DESGLOSE_REACCIONES', confidence: 'MEDIA' });
        }

        candidates.sort((a, b) => b.score - a.score || b.value - a.value);
        return candidates[0] || { value: null, raw: null, source: 'NO_DISPONIBLE', confidence: 'NO_DISPONIBLE' };
    }

    function profileAnchorMatchesTarget(anchor, targetSlug) {
        if (!anchor || !targetSlug) return false;
        try {
            const url = new URL(anchor.href || anchor.getAttribute('href'), location.origin);
            if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return false;
            const segments = url.pathname.split('/').filter(Boolean).map(value => decodeURIComponent(value));
            const profileId = url.searchParams.get('id') || '';
            if (String(profileId).toLowerCase() === String(targetSlug).toLowerCase()) return true;
            return segments.length === 1 && String(segments[0]).toLowerCase() === String(targetSlug).toLowerCase();
        } catch (_) {
            return false;
        }
    }

    function validAuthorName(value) {
        const text = normalizeSpaces(value);
        if (!text || text.length < 2 || text.length > 180) return '';
        if (isLikelyDateText(text) || isObfuscatedText(text)) return '';
        if (/^(?:photo|reel|video|facebook|learn more|ver más|see more)$/i.test(text)) return '';
        return text;
    }

    function extractAuthor(card, permalinkInfo, targetSlug, targetName = '') {
        const actionButton = Array.from(card.querySelectorAll('[aria-label]'))
            .find(node => isPostActionLabel(node.getAttribute('aria-label')));
        const actionLabel = normalizeSpaces(actionButton?.getAttribute('aria-label') || '');
        const actionAuthorMatch = actionLabel.match(/(?:publicación|post)\s+(?:de|by)\s+(.+)$/i);
        const actionAuthorName = validAuthorName(actionAuthorMatch?.[1] || '');

        const exactTargetAnchors = Array.from(card.querySelectorAll('a[href]'))
            .filter(anchor => profileAnchorMatchesTarget(anchor, targetSlug));
        const targetAnchor = exactTargetAnchors.find(anchor => validAuthorName(anchor.getAttribute('aria-label')))
            || exactTargetAnchors.find(anchor => validAuthorName(anchor.textContent))
            || exactTargetAnchors[0]
            || null;

        const targetCandidateName = validAuthorName(targetAnchor?.getAttribute('aria-label'))
            || validAuthorName(targetAnchor?.textContent)
            || validAuthorName(targetName)
            || targetSlug;

        // En el perfil estudiado el encabezado exterior de cada tarjeta debe
        // pertenecer a la cuenta objetivo. El menú de acciones es la señal más
        // robusta porque Facebook lo expresa como "publicación de <autor>".
        if (targetAnchor || (actionAuthorName && normalizeSpaces(actionAuthorName).toLowerCase() === normalizeSpaces(targetCandidateName).toLowerCase())) {
            return {
                authorName: targetCandidateName,
                authorUrl: `https://www.facebook.com/${targetSlug}`,
                authorSlug: targetSlug,
                authorSource: actionAuthorName ? 'POST_ACTION_LABEL_TARGET' : 'TARGET_PROFILE_ANCHOR',
                isTargetAuthor: true
            };
        }

        if (actionAuthorName) {
            const actionAnchor = Array.from(card.querySelectorAll('a[href]')).find(anchor => {
                const value = validAuthorName(anchor.getAttribute('aria-label')) || validAuthorName(anchor.textContent);
                return value && value.toLowerCase() === actionAuthorName.toLowerCase();
            });
            const authorUrl = cleanProfileUrl(actionAnchor?.href || '');
            let authorSlug = '';
            try {
                const url = new URL(authorUrl || location.origin);
                authorSlug = url.searchParams.get('id') || url.pathname.split('/').filter(Boolean)[0] || '';
            } catch (_) { /* ignore */ }
            return {
                authorName: actionAuthorName,
                authorUrl: authorUrl || null,
                authorSlug,
                authorSource: 'POST_ACTION_LABEL_EXTERNAL',
                isTargetAuthor: String(authorSlug).toLowerCase() === String(targetSlug).toLowerCase()
            };
        }

        // Último recurso: solo aceptar enlaces raíz de perfil. Nunca se usan
        // enlaces /photo, /reel, /posts ni el texto relativo de la fecha.
        const fallbackAnchor = Array.from(card.querySelectorAll('a[href]')).find(anchor => {
            try {
                const url = new URL(anchor.href || anchor.getAttribute('href'), location.origin);
                const segments = url.pathname.split('/').filter(Boolean);
                if (segments.length !== 1 || RESERVED_PATHS.has(String(segments[0]).toLowerCase())) return false;
                return Boolean(validAuthorName(anchor.getAttribute('aria-label')) || validAuthorName(anchor.textContent));
            } catch (_) {
                return false;
            }
        });
        const fallbackName = validAuthorName(fallbackAnchor?.getAttribute('aria-label'))
            || validAuthorName(fallbackAnchor?.textContent)
            || targetCandidateName;
        const fallbackUrl = cleanProfileUrl(fallbackAnchor?.href || '') || `https://www.facebook.com/${targetSlug}`;
        let fallbackSlug = targetSlug;
        try {
            const url = new URL(fallbackUrl);
            fallbackSlug = url.searchParams.get('id') || url.pathname.split('/').filter(Boolean)[0] || targetSlug;
        } catch (_) { /* ignore */ }
        return {
            authorName: fallbackName,
            authorUrl: fallbackUrl,
            authorSlug: fallbackSlug,
            authorSource: 'PROFILE_ROOT_FALLBACK',
            isTargetAuthor: String(fallbackSlug).toLowerCase() === String(targetSlug).toLowerCase()
        };
    }

    function extractMedia(card) {
        const urls = [];
        let hasVideo = Array.from(card.querySelectorAll('video')).some(video => elementVisible(video));
        for (const image of card.querySelectorAll('img[src]')) {
            const rect = image.getBoundingClientRect();
            const src = image.currentSrc || image.src || '';
            if (!src || rect.width < 180 || rect.height < 120) continue;
            if (/emoji|profile|scontent.*(?:_s|cp0\/e15\/q65)/i.test(src) && rect.width < 260) continue;
            urls.push(src);
        }
        const unique = Array.from(new Set(urls)).slice(0, 30);
        const permalink = findPermalink(card)?.href || '';
        const isReel = /\/reel\//i.test(permalink) || /\breel\b/i.test(normalizeSpaces(card.innerText).slice(0, 300));
        let type = 'TEXTO';
        if (isReel) type = 'REEL';
        else if (hasVideo) type = 'VIDEO';
        else if (unique.length > 1) type = 'GALERIA';
        else if (unique.length === 1) type = 'FOTO';
        return { type, mediaType: hasVideo ? 'VIDEO' : (unique.length ? 'IMAGEN' : 'NINGUNO'), mediaUrls: unique, mediaCount: unique.length + (hasVideo ? 1 : 0) };
    }

    function extractReactionBreakdown(card) {
        const labels = [];
        for (const node of card.querySelectorAll('[aria-label]')) {
            const label = normalizeSpaces(node.getAttribute('aria-label'));
            if (/\b(?:me gusta|me encanta|me importa|me divierte|me asombra|me entristece|me enoja|like|love|care|haha|wow|sad|angry)\b/i.test(label)) {
                labels.push(label);
            }
        }
        return Array.from(new Set(labels)).join(' | ') || null;
    }

    function detectProfileDisplayName(slug, root = document) {
        const normalizedSlug = String(slug || '').toLowerCase();
        const generic = /^(?:facebook|inicio|todo|información|amigos|fotos|reels|más|publicaciones|posts|empleo|formación académica|ver todos los amigos|ver todas las fotos)$/i;
        const scores = new Map();
        const add = (value, score = 1) => {
            const text = normalizeSpaces(value);
            if (!text || text.length < 3 || text.length > 140 || generic.test(text) || isObfuscatedText(text)) return;
            if (/^(?:\d[\d.,]*\s*(?:mil|k|m)?\s*(?:amigos|seguidores)|fotos de la publicación)/i.test(text)) return;
            scores.set(text, (scores.get(text) || 0) + score);
        };

        for (const anchor of root.querySelectorAll('a[href]')) {
            try {
                const url = new URL(anchor.href || anchor.getAttribute('href'), /^https?:/i.test(location.href) ? location.href : 'https://www.facebook.com/');
                if (!/(^|\.)facebook\.com$/i.test(url.hostname)) continue;
                const first = decodeURIComponent(url.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
                const id = String(url.searchParams.get('id') || '').toLowerCase();
                if (first !== normalizedSlug && id !== normalizedSlug) continue;
                add(anchor.innerText || anchor.textContent, 5);
                add(anchor.getAttribute('aria-label'), 3);
            } catch (_) { /* ignore */ }
        }
        for (const heading of root.querySelectorAll('h1, h2')) add(heading.innerText || heading.textContent, 1);
        return Array.from(scores.entries()).sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)[0]?.[0] || '';
    }

    function sourceLocatorForPost(post) {
        const scope = String(post?.identifier_scope || '').toUpperCase();
        const postUrl = scope === 'PUBLICACION' ? String(post?.permalink || '') : '';
        const nativeMediaUrl = scope === 'MULTIMEDIA' ? String(post?.permalink || '') : '';
        const fallbackMediaUrl = nativeMediaUrl || String(post?.media_urls?.[0] || '');
        const stableId = String(post?.native_id || post?.content_signature || post?.id || '');
        let referenceType = 'IDENTIFICADOR_DERIVADO';
        let referenceQuality = 'DERIVADA_ESTABLE';
        let referenceUrl = '';
        if (postUrl) {
            referenceType = 'URL_PUBLICACION';
            referenceQuality = 'NATIVA_PUBLICACION';
            referenceUrl = postUrl;
        } else if (fallbackMediaUrl) {
            referenceType = /\/(?:reel|videos|watch)\b/i.test(fallbackMediaUrl) || String(post?.media_type || '').toUpperCase() === 'VIDEO'
                ? 'URL_VIDEO'
                : 'URL_IMAGEN';
            referenceQuality = nativeMediaUrl ? 'NATIVA_MULTIMEDIA' : 'TEMPORAL_MULTIMEDIA';
            referenceUrl = fallbackMediaUrl;
        }
        return { postUrl, contentUrl: fallbackMediaUrl, stableId, referenceType, referenceQuality, referenceUrl };
    }

    function strictDwEligibility(post) {
        const locator = sourceLocatorForPost(post);
        const precision = String(post?.date_precision || '').toUpperCase();
        const hasStableLocator = Boolean(locator.stableId);
        const hasDate = TRUSTED_DATE_PRECISIONS.has(precision) && Number(post?.created_at_ms || 0) > 0;
        const hasAuthor = Boolean(normalizeSpaces(post?.author_name)) && Boolean(normalizeSpaces(post?.author_slug));
        const hasContent = Boolean(normalizeSpaces(post?.text)) || Number(post?.media_count || 0) > 0;
        return hasStableLocator && hasDate && hasAuthor && hasContent;
    }

    function qualityIssuesForPost(post) {
        const issues = [];
        const locator = sourceLocatorForPost(post);
        if (!locator.stableId) issues.push('SIN_IDENTIFICADOR_ESTABLE');
        if (!TRUSTED_DATE_PRECISIONS.has(String(post?.date_precision || '').toUpperCase()) || Number(post?.created_at_ms || 0) <= 0) issues.push('SIN_FECHA_CONFIABLE');
        if (!normalizeSpaces(post?.author_name) || !normalizeSpaces(post?.author_slug)) issues.push('SIN_AUTOR_CONFIABLE');
        if (!normalizeSpaces(post?.text) && Number(post?.media_count || 0) <= 0) issues.push('SIN_CONTENIDO');
        return issues;
    }

    function refreshPostQuality(post) {
        const issues = qualityIssuesForPost(post);
        const locator = sourceLocatorForPost(post);
        post.dw_eligible = issues.length === 0;
        post.dw_ineligible_reason = issues.join('|');
        post.record_quality_status = post.dw_eligible
            ? 'LISTO_DW'
            : (normalizeSpaces(post?.text) || Number(post?.media_count || 0) > 0 ? 'PENDIENTE_FECHA_O_IDENTIFICADOR' : 'SOLO_STAGING');
        post.quality_issues = issues;
        post.post_url = locator.postUrl;
        post.content_url = locator.contentUrl;
        post.reference_url = locator.referenceUrl;
        post.reference_type = locator.referenceType;
        post.reference_quality = locator.referenceQuality;
        post.source_locator_id = locator.stableId;
        return post;
    }

    function applyPermalinkInfoToPost(post, info, source = 'DOM') {
        if (!post || !info?.nativeId || info.identifierScope !== 'PUBLICACION') return post;
        post.id = `facebook:native:${info.nativeId}`;
        post.native_id = info.nativeId;
        post.identifier_quality = 'NATIVO';
        post.identifier_source = source === 'MENU_COPY_LINK' ? `COPY_LINK_${info.identifierSource}` : info.identifierSource;
        post.identifier_scope = 'PUBLICACION';
        post.provisional_id = false;
        post.permalink = info.href;
        post.permalink_source = info.sourceHref || info.href;
        post.permalink_quality = info.permalinkQuality || 'NATIVA';
        post.permalink_enrichment_source = source;
        post.permalink_enrichment_success = true;
        refreshPostQuality(post);
        return post;
    }

    function feedOrderKey(canonicalId, contentSignature) {
        return contentSignature || canonicalId || '';
    }

    function assignFeedOrder(canonicalId, contentSignature) {
        const key = feedOrderKey(canonicalId, contentSignature);
        if (!key) return nextFeedOrder++;
        if (feedOrderByEvidence.has(key)) return feedOrderByEvidence.get(key);
        const order = nextFeedOrder++;
        feedOrderByEvidence.set(key, order);
        return order;
    }

    function metricZoneState(card) {
        const cardRect = card.getBoundingClientRect();
        let controlsPresent = false;
        let controlsVisible = false;
        for (const node of card.querySelectorAll('[role="button"], button, a[aria-label], span[aria-label]')) {
            const label = normalizeSpaces([
                node.getAttribute?.('aria-label'),
                node.getAttribute?.('title'),
                node.innerText,
                node.textContent
            ].filter(Boolean).join(' '));
            if (!/(?:me gusta|like|dejar un comentario|leave a comment|compartir|share|envía esto a tus amigos|send this to your friends)/i.test(label)) continue;
            controlsPresent = true;
            const rect = node.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0 && rect.bottom >= 0 && rect.top <= innerHeight) controlsVisible = true;
        }
        const lowerEdgeVisible = cardRect.bottom >= 0 && cardRect.bottom <= innerHeight + 80;
        return {
            observed: controlsPresent || lowerEdgeVisible,
            visible: controlsVisible || lowerEdgeVisible,
            controlsPresent,
            lowerEdgeVisible
        };
    }

    function extractVisiblePosts(options = {}) {
        const targetSlug = currentProfileSlug();
        const targetName = detectProfileDisplayName(targetSlug)
            || normalizeSpaces(document.title.replace(/^\(\d+\+?\)\s*/, '').replace(/\s*\|.*$/, ''))
            || targetSlug;
        const rows = [];
        const seenCards = new Set();
        const cards = (options.onlyCard ? [options.onlyCard] : discoverPostCards()).sort((a, b) => {
            const ar = a.getBoundingClientRect();
            const br = b.getBoundingClientRect();
            return ar.top - br.top;
        });
        const metricsOnly = options.metricsOnly === true;
        const dateReviewOnly = options.dateReviewOnly === true;

        for (const card of cards) {
            if (!elementVisible(card) || card.getBoundingClientRect().height < 120) continue;
            const messageNodeBeforeExpansion = card.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
            const permalinkInfo = findPermalink(card, targetSlug);
            const nativeId = permalinkInfo?.nativeId || '';

            // La fecha del encabezado se captura primero y queda fijada en la
            // observación. Después puede expandirse el cuerpo sin perderla.
            let date = metricsOnly
                ? { iso: null, ms: 0, precision: 'NO_DETECTADA', raw: null, referenceAt: null, source: 'NO_DETECTADA', hasTime: false, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || null }
                : readDate(card, permalinkInfo, messageNodeBeforeExpansion);

            if (!metricsOnly) clickSeeMore(card);
            const messageNode = card.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]') || messageNodeBeforeExpansion;
            const text = extractPostText(card);

            // Reintento conservador para una tarjeta que hubiera terminado de
            // renderizar su encabezado durante la misma observación.
            if (!metricsOnly && !date.ms) {
                date = readDate(card, permalinkInfo, messageNode);
            }
            const media = extractMedia(card);
            const author = extractAuthor(card, permalinkInfo, targetSlug, targetName);
            const externalLinks = extractExternalLinks(text, card);
            const mediaAssetIds = Array.from(new Set((media.mediaUrls || []).map(stableMediaAssetId).filter(Boolean))).sort();
            const signatureResult = buildContentSignature({
                authorSlug: author.authorSlug || targetSlug,
                postType: media.type,
                text,
                externalLinks,
                mediaAssetIds
            });

            let identifierQuality = 'PROVISIONAL';
            let canonicalId = '';
            if (nativeId) {
                identifierQuality = 'NATIVO';
                canonicalId = `facebook:native:${nativeId}`;
            } else if (signatureResult.evidenceStrength && signatureResult.signature) {
                identifierQuality = 'DERIVADO';
                canonicalId = `facebook:derived:${hashText(signatureResult.signature)}`;
            } else {
                const weakMaterial = [targetSlug, media.type, normalizeTextForSignature(text).slice(0, 240), mediaAssetIds[0] || ''].join('|');
                canonicalId = `facebook:provisional:${hashText(weakMaterial)}`;
            }

            if (!canonicalId || seenCards.has(canonicalId)) continue;
            if (!text && media.mediaCount === 0 && !date.ms) continue;
            seenCards.add(canonicalId);

            const cardText = normalizeSpaces(card.innerText || '');
            const pinned = /\b(?:publicación fijada|fijado|fijada|pinned post|pinned)\b/i.test(cardText.slice(0, 600));
            const postActionCount = Array.from(card.querySelectorAll('[aria-label]'))
                .filter(node => isPostActionLabel(node.getAttribute('aria-label'))).length;
            const shared = /\b(?:compartió una publicación|compartió|shared a post|shared)\b/i.test(cardText.slice(0, 900))
                || postActionCount > 1;
            const own = author.isTargetAuthor === true;

            const reactions = extractMetric(card, 'reactions');
            const comments = extractMetric(card, 'comments');
            const shares = extractMetric(card, 'shares');
            const views = extractMetric(card, 'views');
            const metricZone = metricZoneState(card);
            const feedOrder = assignFeedOrder(canonicalId, signatureResult.signature);
            const audienceNode = Array.from(card.querySelectorAll('[aria-label]')).find(node => /^(?:público|public|amigos|friends)$/i.test(normalizeSpaces(node.getAttribute('aria-label'))));

            const row = {
                id: canonicalId,
                native_id: nativeId,
                content_signature: signatureResult.signature,
                identifier_quality: identifierQuality,
                identifier_source: permalinkInfo?.identifierSource || (identifierQuality === 'DERIVADO' ? 'FIRMA_CONTENIDO' : 'EVIDENCIA_INSUFICIENTE'),
                identifier_scope: permalinkInfo?.identifierScope || (identifierQuality === 'DERIVADO' ? 'CONTENIDO_DERIVADO' : 'PROVISIONAL'),
                provisional_id: identifierQuality === 'PROVISIONAL',
                permalink: permalinkInfo?.href || '',
                permalink_source: permalinkInfo?.sourceHref || '',
                permalink_quality: permalinkInfo?.permalinkQuality || 'NO_DISPONIBLE',
                permalink_enrichment_source: permalinkInfo?.identifierScope === 'PUBLICACION' ? 'DOM_PERMALINK' : 'PENDIENTE',
                permalink_enrichment_success: permalinkInfo?.identifierScope === 'PUBLICACION',
                permalink_enrichment_attempted: false,
                permalink_enrichment_attempt_count: 0,
                permalink_enrichment_error: null,
                post_type: shared ? 'CONTENIDO_COMPARTIDO' : media.type,
                text,
                author_name: author.authorName || targetName,
                author_slug: author.authorSlug || targetSlug,
                author_url: author.authorUrl || `https://www.facebook.com/${targetSlug}`,
                author_source: author.authorSource || 'NO_DETECTADO',
                target_profile_slug: targetSlug,
                target_profile_name: targetName,
                created_at: date.iso || '',
                created_at_ms: date.ms || 0,
                date_raw: date.tooltipRaw || date.raw,
                date_visible_raw: date.visibleRaw || (date.source === 'AUTHOR_DATE_PRIVACY_VISUAL_RELATIVE' ? date.raw : null),
                date_tooltip_raw: date.tooltipRaw || null,
                date_privacy_title: date.privacyTitle || null,
                date_precision: date.precision,
                date_reference_at: date.referenceAt || '',
                date_source: date.source || '',
                date_aria_labelledby_id: date.ariaLabelledById || '',
                date_action_scope_level: Number(date.actionScopeLevel || 0),
                date_action_menu_label: date.actionMenuLabel || '',
                date_has_explicit_time: date.hasTime === true,
                date_timezone: date.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || null,
                date_is_estimated: date.precision === 'RELATIVA_CONFIABLE',
                date_locked: !metricsOnly && date.ms > 0 && TRUSTED_DATE_SOURCES.has(String(date.source || '').toUpperCase()),
                metrics_review_only: metricsOnly,
                date_review_only: dateReviewOnly,
                date_confidence: date.ms ? (date.precision === 'RELATIVA_CONFIABLE' ? 'ALTA' : 'ALTA') : 'NO_DISPONIBLE',
                date_interval_from: '',
                date_interval_to: '',
                feed_order: feedOrder,
                first_seen_scroll_y: Math.max(0, Math.round(window.scrollY || document.scrollingElement?.scrollTop || 0)),
                first_seen_cycle: Number(captureState?.currentCycle || 0),
                is_pinned: pinned,
                is_own_publication: own,
                is_shared_content: shared,
                metrics_attributable_to_account: true,
                reactions_count: reactions.value,
                comments_count: comments.value,
                shares_count: shares.value,
                views_count: views.value,
                reactions_raw: reactions.raw,
                comments_raw: comments.raw,
                shares_raw: shares.raw,
                views_raw: views.raw,
                reactions_source: reactions.source,
                comments_source: comments.source,
                shares_source: shares.source,
                views_source: views.source,
                reactions_confidence: reactions.confidence,
                comments_confidence: comments.confidence,
                shares_confidence: shares.confidence,
                views_confidence: views.confidence,
                metrics_zone_observed: metricZone.observed || [reactions.value, comments.value, shares.value, views.value].some(value => value !== null),
                metrics_zone_visible: metricZone.visible || [reactions.value, comments.value, shares.value, views.value].some(value => value !== null),
                engagement_controls_present: metricZone.controlsPresent,
                card_lower_edge_observed: metricZone.lowerEdgeVisible,
                reactions_observed_count: reactions.value !== null ? 1 : 0,
                comments_observed_count: comments.value !== null ? 1 : 0,
                shares_observed_count: shares.value !== null ? 1 : 0,
                views_observed_count: views.value !== null ? 1 : 0,
                reactions_first_value: reactions.value,
                comments_first_value: comments.value,
                shares_first_value: shares.value,
                views_first_value: views.value,
                reactions_last_value: reactions.value,
                comments_last_value: comments.value,
                shares_last_value: shares.value,
                views_last_value: views.value,
                reaction_breakdown_raw: extractReactionBreakdown(card),
                audience: normalizeSpaces(audienceNode?.getAttribute('aria-label') || ''),
                media_type: media.mediaType,
                media_count: media.mediaCount,
                media_urls: media.mediaUrls,
                media_asset_ids: mediaAssetIds,
                external_links: externalLinks,
                source_method: metricsOnly ? 'FACEBOOK_METRICS_REVIEW_V25' : (dateReviewOnly ? 'FACEBOOK_DATE_REVIEW_V25' : 'FACEBOOK_DOM_PRIVACY_TOOLTIP_V25')
            };
            refreshPostQuality(row);
            Object.defineProperty(row, '_card', { value: card, enumerable: false, configurable: true });
            rows.push(row);
        }
        return rows;
    }

    async function enrichVisiblePostPermalinks(posts, maxPerCycle = 2, enabled = false) {
        if (!enabled) return posts;
        const ordered = Array.from(posts || []).sort((a, b) => {
            const ar = a?._card?.getBoundingClientRect?.() || { top: 999999, bottom: 999999 };
            const br = b?._card?.getBoundingClientRect?.() || { top: 999999, bottom: 999999 };
            const aVisible = ar.bottom >= 0 && ar.top <= innerHeight ? 0 : 1;
            const bVisible = br.bottom >= 0 && br.top <= innerHeight ? 0 : 1;
            const aAttempts = Number(permalinkEnrichmentAttempts.get(enrichmentKeyForPost(a))?.count || 0);
            const bAttempts = Number(permalinkEnrichmentAttempts.get(enrichmentKeyForPost(b))?.count || 0);
            return aVisible - bVisible || aAttempts - bAttempts || Math.abs(ar.top) - Math.abs(br.top);
        });
        let processed = 0;
        for (const post of ordered) {
            if (String(post?.identifier_scope || '').toUpperCase() === 'PUBLICACION' && post?.permalink) continue;
            const key = enrichmentKeyForPost(post);
            const cached = key ? permalinkEnrichmentCache.get(key) : null;
            if (cached) {
                applyPermalinkInfoToPost(post, cached, 'MENU_COPY_LINK_CACHE');
                continue;
            }
            const attempt = key ? permalinkEnrichmentAttempts.get(key) : null;
            if (Number(attempt?.count || 0) >= 3) continue;
            if (attempt?.lastAt && Date.now() - Number(attempt.lastAt) < 3500) continue;
            if (!post?._card || !document.contains(post._card)) continue;
            const rect = post._card.getBoundingClientRect();
            if (rect.bottom < -40 || rect.top > innerHeight + 40) continue;
            if (processed >= maxPerCycle) break;
            processed += 1;
            post.permalink_enrichment_attempted = true;
            const info = await tryResolvePostPermalinkFromMenu(post, post.target_profile_slug || currentProfileSlug());
            if (info) applyPermalinkInfoToPost(post, info, 'MENU_COPY_LINK');
            else {
                post.permalink_enrichment_success = false;
                post.permalink_enrichment_error = post.permalink_enrichment_error || 'PERMALINK_NOT_RESOLVED';
                refreshPostQuality(post);
            }
            await sleep(350);
        }
        return posts;
    }

    async function captureVisiblePosts(options = {}) {
        let dateAudit = latestActionDateAudit;
        if (options.metricsOnly !== true) {
            if (options.onlyCard) {
                dateAudit = await stabilizeSingleCardDate(options.onlyCard, {
                    attempts: Number(options.dateHydrationAttempts || (options.dateReviewOnly ? 5 : 3)),
                    delayMs: Number(options.dateHydrationDelayMs || (options.dateReviewOnly ? 135 : 105)),
                    targetSlug: currentProfileSlug()
                });
            } else {
                dateAudit = await stabilizeActionAnchoredHeaderDates({
                    attempts: Number(options.dateHydrationAttempts || (options.dateReviewOnly ? 6 : 4)),
                    delayMs: Number(options.dateHydrationDelayMs || (options.dateReviewOnly ? 210 : 175)),
                    targetSlug: currentProfileSlug()
                });
            }
        }

        const posts = extractVisiblePosts({ ...options, dateAudit });
        updatePendingDatePositions(posts);
        const serializablePosts = posts.map(post => ({ ...post }));
        const changed = changedPostsForPersistence(serializablePosts, options.forcePersist === true);
        const postsToPersist = changed.map(item => item.post);

        if (postsToPersist.length) {
            const operationName = options.metricsOnly
                ? 'FacebookMetricsReviewV25'
                : (options.dateReviewOnly ? 'FacebookDateReviewV25' : 'FacebookDOMPrivacyTooltipV25');
            const result = await chrome.runtime.sendMessage({ type: 'FB_CAPTURE_POSTS', posts: postsToPersist, operationName }).catch(() => null);
            if (result) {
                commitPersistenceSnapshots(changed);
                lastKnownFacebookTotal = Number(result?.total || lastKnownFacebookTotal || 0);
            }
            return {
                total: lastKnownFacebookTotal,
                posts: serializablePosts,
                persistedPosts: postsToPersist.length,
                skippedUnchangedPosts: Math.max(0, serializablePosts.length - postsToPersist.length),
                dateAudit
            };
        }

        if (!lastKnownFacebookTotal) {
            const summary = await chrome.runtime.sendMessage({ type: 'GET_FACEBOOK_DB_SUMMARY' }).catch(() => null);
            lastKnownFacebookTotal = Number(summary?.count || 0);
        }
        return {
            total: lastKnownFacebookTotal,
            posts: serializablePosts,
            persistedPosts: 0,
            skippedUnchangedPosts: serializablePosts.length,
            dateAudit
        };
    }

    function profileTextWindow() {
        const main = document.querySelector('[role="main"]') || document.body;
        return normalizeSpaces(main?.innerText || '').slice(0, 3500);
    }

    function readProfileInfo() {
        const slug = currentProfileSlug();
        const main = document.querySelector('[role="main"]') || document;
        const titleName = normalizeSpaces(document.title.replace(/^\(\d+\+?\)\s*/, '').replace(/\s*\|.*$/, ''));
        const detectedName = detectProfileDisplayName(slug, main);
        const name = detectedName || (!/^facebook$/i.test(titleName) ? titleName : '') || slug;
        const text = profileTextWindow();
        const friendsMatch = text.match(/([\d.,]+(?:\s*(?:mil|k|m|mill(?:ón|ones)?))?)\s+(?:amigos|friends)\b/i);
        const followersMatch = text.match(/([\d.,]+(?:\s*(?:mil|k|m|mill(?:ón|ones)?))?)\s+(?:seguidores|followers)\b/i);
        const friendsRaw = friendsMatch ? normalizeSpaces(friendsMatch[0]) : null;
        const followersRaw = followersMatch ? normalizeSpaces(followersMatch[0]) : null;
        const image = main.querySelector('img[alt][src]');
        return {
            id: null,
            name: name || slug,
            screenName: slug,
            url: slug ? `https://www.facebook.com/${slug}` : location.href,
            profileImageUrl: image?.src || null,
            accountType: 'PERFIL',
            friendsCount: parseCompactNumber(friendsRaw || ''),
            friendsCountRaw: friendsRaw,
            followersCount: parseCompactNumber(followersRaw || ''),
            followersCountRaw: followersRaw,
            source: 'PERFIL_FACEBOOK_INTERFAZ_VISIBLE'
        };
    }

    function timelineSnapshot() {
        const scrolling = document.scrollingElement || document.documentElement || document.body;
        const pageHeight = Math.max(scrolling?.scrollHeight || 0, document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0);
        const scrollTop = Math.max(0, Math.round(scrolling?.scrollTop ?? window.scrollY ?? 0));
        const viewportHeight = Math.max(1, Math.round(scrolling?.clientHeight || innerHeight || 1));
        return { pageHeight: Math.round(pageHeight), scrollTop, viewportHeight, distanceToBottom: Math.max(0, Math.round(pageHeight - scrollTop - viewportHeight)) };
    }

    function timelineLoading() {
        for (const node of document.querySelectorAll('[role="progressbar"], [aria-busy="true"]')) {
            if (elementVisible(node) && node.getBoundingClientRect().top > innerHeight * 0.35) return true;
        }
        return false;
    }

    function timelineHasExplicitEnd() {
        const text = normalizeSpaces((document.querySelector('[role="main"]') || document.body)?.innerText || '').slice(-1800);
        return /(?:no hay más publicaciones|no more posts|has llegado al final|you(?:'|’)ve reached the end)/i.test(text);
    }

    function visibleFingerprint() {
        const cards = discoverPostCards().slice(-8);
        return cards.map(card => {
            const targetSlug = currentProfileSlug();
            const permalink = findPermalink(card, targetSlug);
            if (permalink?.nativeId) return `n:${permalink.nativeId}`;
            const message = card.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
            const text = cleanExtractedPostText(message?.innerText || message?.textContent || '').slice(0, 180);
            return `t:${hashText(text)}`;
        }).join('|');
    }

    function clickRetry() {
        for (const node of document.querySelectorAll('[role="button"], button')) {
            const text = normalizeSpaces(node.textContent || node.getAttribute('aria-label'));
            if (/^(?:reintentar|intentar de nuevo|retry|try again)$/i.test(text) && elementVisible(node)) {
                try { node.click(); return true; } catch (_) { /* ignore */ }
            }
        }
        return false;
    }

    function subtractCalendarMonths(timestamp, months) {
        const source = new Date(Number(timestamp));
        if (!Number.isFinite(source.getTime())) return null;
        const day = source.getDate();
        const target = new Date(source.getTime());
        target.setDate(1);
        target.setMonth(target.getMonth() - months);
        const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
        target.setDate(Math.min(day, lastDay));
        return target.getTime();
    }

    // Compara únicamente el día calendario local. La ausencia de hora nunca
    // invalida una fecha ni provoca que se excluya una publicación del día
    // límite solicitado.
    function localCalendarDayStart(timestamp) {
        const date = new Date(Number(timestamp || 0));
        if (!Number.isFinite(date.getTime()) || date.getTime() <= 0) return null;
        date.setHours(0, 0, 0, 0);
        return date.getTime();
    }

    async function sendProgress(payload) {
        return chrome.runtime.sendMessage({ type: 'FB_SCROLL_CAPTURE_PROGRESS', ...payload }).catch(() => null);
    }

    function unresolvedActionMenusNearViewport(marginScreens = 1.35) {
        const unresolved = [];
        for (const menu of postActionMenus(document)) {
            if (actionDateByMenu.get(menu)?.ms) continue;
            const card = resolvePostCard(menu);
            if (!cardNearViewport(card || menu, marginScreens)) continue;
            unresolved.push({ menu, card });
        }
        return unresolved;
    }

    async function focusResolvePendingDateMenus(options = {}) {
        const maxMenus = Math.max(1, Math.min(16, Number(options.maxMenus || 10)));
        const maxAttempts = Math.max(1, Math.min(7, Number(options.maxAttempts || 5)));
        const originalY = Math.max(0, Math.round(window.scrollY || document.scrollingElement?.scrollTop || 0));
        let resolved = 0;
        let inspected = 0;

        for (const item of unresolvedActionMenusNearViewport(1.45).slice(0, maxMenus)) {
            if (!captureState?.running || !document.contains(item.menu)) continue;
            inspected += 1;
            try {
                item.menu.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'auto' });
            } catch (_) {
                // Si el navegador no admite las opciones, se mantiene el scroll actual.
            }
            await sleep(140);

            for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
                if (!document.contains(item.menu)) break;
                const date = resolveActionAnchoredDateForMenu(item.menu, currentProfileSlug(), Date.now());
                if (date?.ms) {
                    resolved += 1;
                    break;
                }
                if (attempt < maxAttempts) await sleep(120 + attempt * 65);
            }
        }

        if (Math.abs((window.scrollY || 0) - originalY) > 4) {
            window.scrollTo({ top: originalY, left: 0, behavior: 'auto' });
            await sleep(130);
        }

        if (resolved > 0) {
            await captureVisiblePosts({
                dateReviewOnly: true,
                dateHydrationAttempts: 2,
                dateHydrationDelayMs: 125
            });
        }

        const audit = auditActionAnchoredHeaderDates({ targetSlug: currentProfileSlug() });
        return { resolved, inspected, audit };
    }

    async function settleCurrentViewportDates(initialCapture, options = {}) {
        let capture = initialCapture;
        if (!capture || Number(capture.dateAudit?.unresolvedNearViewport || 0) <= 0) return capture;

        // Primer refuerzo: misma posición y más tiempo de hidratación.
        await sleep(Math.max(140, Number(options.initialDelayMs || 220)));
        capture = await captureVisiblePosts({
            dateReviewOnly: true,
            dateHydrationAttempts: Math.max(4, Number(options.retryAttempts || 5)),
            dateHydrationDelayMs: Math.max(160, Number(options.retryDelayMs || 210))
        });

        if (Number(capture.dateAudit?.unresolvedNearViewport || 0) > 0) {
            // Segundo refuerzo: centra exclusivamente los encabezados pendientes.
            await focusResolvePendingDateMenus({
                maxMenus: Number(options.maxMenus || 10),
                maxAttempts: Number(options.focusAttempts || 5)
            });
            capture = await captureVisiblePosts({
                dateReviewOnly: true,
                dateHydrationAttempts: 3,
                dateHydrationDelayMs: 150
            });
        }

        return capture;
    }

    async function reviewPendingDatePositions(state, options = {}) {
        if (!state?.running || !pendingDatePositions.size) {
            return { positionsReviewed: 0, unresolvedNearViewport: 0, pendingRecords: pendingDatePositions.size };
        }

        const originalY = Math.max(0, Math.round(window.scrollY || document.scrollingElement?.scrollTop || 0));
        const viewport = Math.max(1, Number(innerHeight || document.documentElement?.clientHeight || 1));
        const rawPositions = Array.from(pendingDatePositions.values())
            .map(item => Math.max(0, Number(item.scrollY || 0)))
            .sort((a, b) => b - a);

        // Agrupa posiciones cercanas para no visitar varias veces la misma pantalla.
        const positions = [];
        for (const position of rawPositions) {
            if (!positions.some(existing => Math.abs(existing - position) < viewport * 0.42)) {
                positions.push(position);
            }
            if (positions.length >= 120) break;
        }

        let positionsReviewed = 0;
        let lastAudit = latestActionDateAudit;

        for (const position of positions) {
            if (!state.running || !pendingDatePositions.size) break;
            for (const offset of [-0.38, 0, 0.38]) {
                if (!state.running || !pendingDatePositions.size) break;
                const target = Math.max(0, position + Math.round(viewport * offset));
                window.scrollTo({ top: target, left: 0, behavior: 'auto' });
                await sleep(260);
                let result = await captureVisiblePosts({
                    dateReviewOnly: true,
                    dateHydrationAttempts: 4,
                    dateHydrationDelayMs: 175
                });
                if (Number(result.dateAudit?.unresolvedNearViewport || 0) > 0) {
                    result = await settleCurrentViewportDates(result, {
                        initialDelayMs: 150,
                        retryAttempts: 4,
                        retryDelayMs: 175,
                        maxMenus: 8,
                        focusAttempts: 4
                    });
                }
                lastAudit = result.dateAudit || lastAudit;
                positionsReviewed += 1;
            }
        }

        // Respaldo acotado para períodos finitos. Si Facebook movió las alturas
        // del documento, los scrollY históricos pueden dejar de apuntar a la tarjeta.
        // En ese caso se hace un barrido rápido y solapado, sin persistir registros
        // sin cambios. No se aplica a “Ejecutar todo” para evitar recorridos enormes.
        const capturePeriod = String(options.capturePeriod || 'unlimited');
        const maxSweepByPeriod = { last_month: 130, last_3_months: 320, last_year: 720 };
        const maxSweepSteps = Number(maxSweepByPeriod[capturePeriod] || 0);
        if (state.running && pendingDatePositions.size && maxSweepSteps > 0) {
            let y = originalY;
            const step = Math.max(480, Math.round(viewport * 0.68));
            let sweepSteps = 0;
            while (state.running && pendingDatePositions.size && y > 0 && sweepSteps < maxSweepSteps) {
                y = Math.max(0, y - step);
                window.scrollTo({ top: y, left: 0, behavior: 'auto' });
                await sleep(230);
                let result = await captureVisiblePosts({
                    dateReviewOnly: true,
                    dateHydrationAttempts: 3,
                    dateHydrationDelayMs: 145
                });
                if (Number(result.dateAudit?.unresolvedNearViewport || 0) > 0) {
                    result = await settleCurrentViewportDates(result, {
                        initialDelayMs: 120,
                        retryAttempts: 3,
                        retryDelayMs: 155,
                        maxMenus: 6,
                        focusAttempts: 3
                    });
                }
                lastAudit = result.dateAudit || lastAudit;
                positionsReviewed += 1;
                sweepSteps += 1;
            }
        }

        window.scrollTo({ top: originalY, left: 0, behavior: 'auto' });
        await sleep(320);
        let finalResult = await captureVisiblePosts({
            dateReviewOnly: true,
            dateHydrationAttempts: 4,
            dateHydrationDelayMs: 175
        });
        if (Number(finalResult.dateAudit?.unresolvedNearViewport || 0) > 0) {
            finalResult = await settleCurrentViewportDates(finalResult, { maxMenus: 8, focusAttempts: 4 });
        }
        lastAudit = finalResult.dateAudit || lastAudit;

        return {
            positionsReviewed: positionsReviewed + 1,
            unresolvedNearViewport: Number(lastAudit?.unresolvedNearViewport || 0),
            totalMenus: Number(lastAudit?.totalMenus || 0),
            resolvedMenus: Number(lastAudit?.resolvedMenus || 0),
            pendingRecords: pendingDatePositions.size
        };
    }


    async function reviewTrailingMetricZones(state, screens = 5) {
        if (!state?.running) return;
        const original = Math.max(0, Math.round(window.scrollY || document.scrollingElement?.scrollTop || 0));
        const step = Math.max(360, Math.round(innerHeight * 0.62));
        const positions = [];
        for (let index = 1; index <= screens; index += 1) positions.push(Math.max(0, original - step * index));
        for (const position of positions) {
            if (!state.running) break;
            window.scrollTo({ top: position, left: 0, behavior: 'auto' });
            await sleep(650);
            await captureVisiblePosts({ metricsOnly: true });
        }
        for (const position of positions.slice().reverse()) {
            if (!state.running) break;
            window.scrollTo({ top: Math.min(original, position + step), left: 0, behavior: 'auto' });
            await sleep(550);
            await captureVisiblePosts({ metricsOnly: true });
        }
        window.scrollTo({ top: original, left: 0, behavior: 'auto' });
        await sleep(650);
        await captureVisiblePosts({ metricsOnly: true });
    }

    function facebookHeaderOffset() {
        const viewport = Math.max(1, Number(innerHeight || document.documentElement?.clientHeight || 1));
        let bottom = 0;
        const candidates = Array.from(document.querySelectorAll('[role="banner"], header')).slice(0, 12);
        for (const node of candidates) {
            if (!elementVisible(node)) continue;
            const rect = node.getBoundingClientRect();
            const style = getComputedStyle(node);
            const anchored = style.position === 'fixed' || style.position === 'sticky' || rect.top <= 4;
            if (!anchored || rect.height < 20 || rect.height > Math.min(220, viewport * 0.28)) continue;
            if (rect.width < Math.max(320, innerWidth * 0.45)) continue;
            bottom = Math.max(bottom, rect.bottom);
        }
        return Math.max(8, Math.min(Math.round(bottom + 10), Math.round(viewport * 0.25)));
    }

    function cardHeaderAnchor(card) {
        if (!card) return null;
        const menus = postActionMenus(card).filter(menu => document.contains(menu));
        if (menus.length) return menus[0];
        return targetAuthorAnchor(card, currentProfileSlug()) || card;
    }

    async function alignCardBelowHeader(card, options = {}) {
        if (!card || !document.contains(card)) return null;
        const settleMs = Math.max(80, Number(options.settleMs || 145));
        const topPadding = Math.max(4, Math.min(24, Number(options.topPadding || 7)));
        let offset = facebookHeaderOffset();

        // Tres correcciones cortas absorben cambios de altura ocasionados por el
        // encabezado fijo, imágenes hidratadas y la expansión de texto.
        for (let pass = 0; pass < 3; pass += 1) {
            if (!document.contains(card)) return null;
            const rect = card.getBoundingClientRect();
            const desiredTop = offset + topPadding;
            const delta = rect.top - desiredTop;
            if (Math.abs(delta) > 2) {
                window.scrollBy({ top: Math.round(delta), left: 0, behavior: 'auto' });
            }
            await sleep(settleMs);
            offset = facebookHeaderOffset();
        }

        // La cabecera de la publicación debe quedar realmente visible. Si el
        // contenedor fue calculado desde una zona interior, se corrige usando el
        // menú de acciones o el autor como ancla, sin abandonar la tarjeta.
        const anchor = cardHeaderAnchor(card);
        if (anchor && document.contains(anchor)) {
            const anchorRect = anchor.getBoundingClientRect();
            const desiredAnchorTop = offset + Math.max(10, topPadding + 5);
            if (anchorRect.top < offset + 2 || anchorRect.top > offset + 150) {
                window.scrollBy({ top: Math.round(anchorRect.top - desiredAnchorTop), left: 0, behavior: 'auto' });
                await sleep(settleMs);
                offset = facebookHeaderOffset();
            }
        }

        const rect = card.getBoundingClientRect();
        const anchorRect = anchor?.getBoundingClientRect?.() || null;
        return {
            headerOffset: offset,
            top: rect.top,
            bottom: rect.bottom,
            height: rect.height,
            availableHeight: Math.max(1, innerHeight - offset - 8),
            fullyVisible: rect.top >= offset - 10 && rect.bottom <= innerHeight + 8,
            headerVisible: Boolean(anchorRect && anchorRect.bottom > offset && anchorRect.top < Math.min(innerHeight, offset + 170)),
            actionMenuCount: postActionMenus(card).length
        };
    }

    async function alignActionMenuBelowHeader(menu, options = {}) {
        if (!menu || !document.contains(menu)) return null;
        const settleMs = Math.max(70, Number(options.settleMs || 105));
        const topPadding = Math.max(8, Math.min(42, Number(options.topPadding || 18)));
        let offset = facebookHeaderOffset();

        // Se alinea la fila del menú, que comparte altura con autor y fecha. Esto
        // evita depender del límite exterior que Facebook asigne a la tarjeta.
        for (let pass = 0; pass < 3; pass += 1) {
            if (!document.contains(menu)) return null;
            const rect = menu.getBoundingClientRect();
            const desiredTop = offset + topPadding;
            const delta = rect.top - desiredTop;
            if (Math.abs(delta) > 2) {
                window.scrollBy({ top: Math.round(delta), left: 0, behavior: 'auto' });
            }
            await sleep(settleMs);
            offset = facebookHeaderOffset();
        }

        const card = resolvePostCard(menu);
        const menuRect = menu.getBoundingClientRect();
        const cardRect = card?.getBoundingClientRect?.() || null;
        return {
            menu,
            card,
            headerOffset: offset,
            menuTop: menuRect.top,
            menuBottom: menuRect.bottom,
            headerVisible: menuRect.bottom > offset && menuRect.top < Math.min(innerHeight, offset + 185),
            fullyVisible: Boolean(cardRect && cardRect.top >= offset - 14 && cardRect.bottom <= innerHeight + 8),
            top: cardRect?.top ?? null,
            bottom: cardRect?.bottom ?? null,
            height: cardRect?.height ?? null,
            availableHeight: Math.max(1, innerHeight - offset - 8),
            actionMenuCount: card ? postActionMenus(card).length : 1
        };
    }

    function quickCardEvidenceKey(card) {
        if (!card) return '';
        const cached = sequentialQuickKeyByCard.get(card);
        if (cached) return cached;
        const permalink = findPermalink(card, currentProfileSlug());
        if (permalink?.nativeId) {
            const key = `native:${permalink.nativeId}`;
            sequentialQuickKeyByCard.set(card, key);
            return key;
        }
        const message = card.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"]');
        const textPrefix = normalizeTextForSignature(message?.innerText || message?.textContent || '').slice(0, 320);
        const media = extractMedia(card);
        const mediaIds = Array.from(new Set((media.mediaUrls || []).map(stableMediaAssetId).filter(Boolean))).slice(0, 3);
        const key = `quick:${hashText([currentProfileSlug(), media.type, textPrefix, mediaIds.join('|')].join('|'))}`;
        sequentialQuickKeyByCard.set(card, key);
        return key;
    }

    function quickMenuEvidenceKey(menu, card = null) {
        if (!menu) return '';
        const cached = sequentialQuickKeyByMenu.get(menu);
        if (cached) return cached;
        const resolvedCard = card || resolvePostCard(menu);
        const key = resolvedCard ? quickCardEvidenceKey(resolvedCard) : '';
        if (key) sequentialQuickKeyByMenu.set(menu, key);
        return key;
    }

    function nextSequentialActionMenu() {
        const headerOffset = facebookHeaderOffset();
        const menus = postActionMenus(document)
            .filter(menu => document.contains(menu))
            .sort((a, b) => {
                const ar = a.getBoundingClientRect();
                const br = b.getBoundingClientRect();
                return (ar.top + window.scrollY) - (br.top + window.scrollY);
            });

        for (const menu of menus) {
            if (sequentialProcessedMenus.has(menu)) continue;
            const card = resolvePostCard(menu);
            if (!card || !document.contains(card)) continue;

            const quickKey = quickMenuEvidenceKey(menu, card);
            if (quickKey && sequentialProcessedEvidence.has(quickKey)) {
                sequentialProcessedMenus.add(menu);
                sequentialProcessedCards.add(card);
                continue;
            }

            const rect = menu.getBoundingClientRect();
            const cardRect = card.getBoundingClientRect();
            // Una recreación de una tarjeta ya superada se ignora por evidencia.
            // Un menú nuevo que esté cerca o debajo del encabezado puede procesarse.
            if (cardRect.height < 120) continue;
            if (rect.bottom <= headerOffset + 2 && quickKey && sequentialProcessedEvidence.has(quickKey)) {
                sequentialProcessedMenus.add(menu);
                sequentialProcessedCards.add(card);
                continue;
            }
            return { menu, card, quickKey };
        }
        return null;
    }

    function reacquireSequentialActionMenu(item) {
        const originalMenu = item?.menu;
        if (originalMenu && document.contains(originalMenu)
            && isPostActionLabel(originalMenu.getAttribute('aria-label'))) {
            const card = resolvePostCard(originalMenu) || item?.card || null;
            return { menu: originalMenu, card };
        }

        const quickKey = item?.quickKey
            || (item?.card ? quickCardEvidenceKey(item.card) : '')
            || (originalMenu ? sequentialQuickKeyByMenu.get(originalMenu) : '');

        for (const menu of postActionMenus(document)) {
            if (!document.contains(menu) || sequentialProcessedMenus.has(menu)) continue;
            const card = resolvePostCard(menu);
            if (!card) continue;
            if (quickKey && quickMenuEvidenceKey(menu, card) === quickKey) {
                return { menu, card };
            }
        }
        return { menu: null, card: item?.card && document.contains(item.card) ? item.card : null };
    }

    function preserveSequentialDate(preferred, candidate) {
        if (!candidate) return preferred || null;
        if (!preferred || !Number(preferred.created_at_ms || 0) || Number(candidate.created_at_ms || 0)) return candidate;
        const dateFields = [
            'created_at', 'created_at_ms', 'date_raw', 'date_visible_raw', 'date_tooltip_raw', 'date_privacy_title', 'date_precision',
            'date_reference_at', 'date_source', 'date_aria_labelledby_id',
            'date_action_scope_level', 'date_action_menu_label',
            'date_has_explicit_time', 'date_timezone', 'date_is_estimated',
            'date_locked', 'date_confidence', 'date_interval_from', 'date_interval_to'
        ];
        for (const field of dateFields) candidate[field] = preferred[field];
        refreshPostQuality(candidate);
        return candidate;
    }

    async function readSequentialActionMenuDate(item, options = {}) {
        let active = reacquireSequentialActionMenu(item);
        let activeMenu = active.menu;
        let activeCard = active.card;
        let parsedDate = null;
        let relativeEvidence = null;
        const phases = [
            { attempts: Math.max(2, Number(options.dateAttempts || 3)), delayMs: Math.max(90, Number(options.dateDelayMs || 110)), topPadding: 18 },
            { attempts: 2, delayMs: 180, topPadding: 20 }
        ];

        for (let phaseIndex = 0; phaseIndex < phases.length; phaseIndex += 1) {
            active = reacquireSequentialActionMenu({ ...item, menu: activeMenu, card: activeCard });
            activeMenu = active.menu;
            activeCard = active.card || (activeMenu ? resolvePostCard(activeMenu) : null);
            if (!activeMenu || !document.contains(activeMenu) || !activeCard || !document.contains(activeCard)) break;

            const phase = phases[phaseIndex];
            await alignActionMenuBelowHeader(activeMenu, {
                settleMs: options.alignSettleMs || 120,
                topPadding: phase.topPadding
            });

            for (let attempt = 1; attempt <= phase.attempts; attempt += 1) {
                sequentialCaptureStats.localDateAttempts += 1;

                const visual = resolveVisualDateByPrivacyIcon(activeCard, Date.now());
                if (visual.info?.link) {
                    const privacyEvidenceKey = item?.quickKey
                        || quickMenuEvidenceKey(activeMenu, activeCard)
                        || quickCardEvidenceKey(activeCard)
                        || `privacy-link:${activeMenu?.getAttribute?.('aria-label') || ''}:${activeCard?.getBoundingClientRect?.().top || 0}`;
                    if (!sequentialPrivacyDateEvidence.has(privacyEvidenceKey)) {
                        sequentialPrivacyDateEvidence.add(privacyEvidenceKey);
                        sequentialCaptureStats.privacyDateLinksFound += 1;
                    }
                }

                if (visual.date?.ms) {
                    if (String(visual.date.precision || '').toUpperCase() === 'RELATIVA_CONFIABLE') {
                        relativeEvidence = cloneResolvedDate(visual.date);
                    } else if (isTrustedDateRecord(visual.date)) {
                        parsedDate = cloneResolvedDate(visual.date);
                        break;
                    }
                }

                if (visual.info?.link) {
                    const tooltip = await hoverDateLinkForExactTooltip(visual.info, Date.now(), {
                        timeoutMs: options.tooltipTimeoutMs || 1700,
                        pollMs: options.tooltipPollMs || 120
                    });
                    if (tooltip.attempted) sequentialCaptureStats.privacyTooltipAttempts += 1;
                    if (tooltip.resolved && isTrustedDateRecord(tooltip.date)) {
                        sequentialCaptureStats.privacyTooltipResolved += 1;
                        parsedDate = cloneResolvedDate(tooltip.date);
                        break;
                    }
                }

                const actionCandidate = actionDateByMenu.get(activeMenu)
                    || resolveActionAnchoredDateForMenu(activeMenu, currentProfileSlug(), Date.now());
                if (actionCandidate?.ms) {
                    if (String(actionCandidate.precision || '').toUpperCase() === 'RELATIVA_CONFIABLE') {
                        relativeEvidence = relativeEvidence || cloneResolvedDate(actionCandidate);
                    } else if (isTrustedDateRecord(actionCandidate)) {
                        parsedDate = cloneResolvedDate(actionCandidate);
                        break;
                    }
                }

                pendingDateMenus.add(activeMenu);
                if (attempt < phase.attempts) await sleep(phase.delayMs + Math.min(120, (attempt - 1) * 45));
            }

            if (parsedDate?.ms) break;
            if (phaseIndex < phases.length - 1) {
                sequentialCaptureStats.cardsWithLocalDateRetry += 1;
                await sleep(160);
            }
        }

        active = reacquireSequentialActionMenu({ ...item, menu: activeMenu, card: activeCard });
        activeMenu = active.menu || activeMenu;
        activeCard = active.card || activeCard || (activeMenu ? resolvePostCard(activeMenu) : null);

        // No se convierte una fecha relativa en fecha analítica cuando el tooltip
        // exacto no apareció. Se conserva como evidencia para auditoría, pero el
        // registro queda pendiente y la protección de calidad detiene la captura.
        if (!parsedDate?.ms && relativeEvidence) {
            parsedDate = cloneResolvedDate(relativeEvidence);
            parsedDate.ms = 0;
            parsedDate.iso = null;
            parsedDate.precision = 'RELATIVA_APROXIMADA';
            parsedDate.source = 'AUTHOR_DATE_PRIVACY_VISUAL_RELATIVE';
            parsedDate.hasTime = false;
        }

        if (parsedDate?.ms && isTrustedDateRecord(parsedDate)) {
            if (activeMenu) actionDateByMenu.set(activeMenu, cloneResolvedDate(parsedDate));
            pendingDateMenus.delete(activeMenu);
            if (activeCard) actionDateByCard.set(activeCard, cloneResolvedDate(parsedDate));
        }

        return { menu: activeMenu, card: activeCard, date: parsedDate };
    }

    async function captureSequentialActionMenu(item, options = {}) {
        assertSafeFacebookCaptureRoute();
        let active = reacquireSequentialActionMenu(item);
        let menu = active.menu;
        let card = active.card;
        if (!menu || !document.contains(menu)) return { captured: false, reason: 'ACTION_MENU_REMOVED' };
        if (!card || !document.contains(card)) card = resolvePostCard(menu);
        if (!card) return { captured: false, reason: 'POST_CONTAINER_NOT_FOUND' };
        const quickKey = item?.quickKey || quickMenuEvidenceKey(menu, card) || quickCardEvidenceKey(card);

        // Misma dirección que el script de consola validado: menú -> fecha -> tarjeta.
        const dateResult = await readSequentialActionMenuDate({ ...item, menu, card, quickKey }, options);
        menu = dateResult.menu || menu;
        card = dateResult.card || card || (menu ? resolvePostCard(menu) : null);
        const parsedDate = dateResult.date || null;
        if (!card || !document.contains(card)) {
            if (menu) sequentialProcessedMenus.add(menu);
            return { captured: false, reason: 'CARD_REMOVED_AFTER_DATE' };
        }

        if (parsedDate?.ms) {
            actionDateByCard.set(card, cloneResolvedDate(parsedDate));
            if (menu) actionDateByMenu.set(menu, cloneResolvedDate(parsedDate));
        }

        let row = null;
        let layout = await alignCardBelowHeader(card, { settleMs: options.alignSettleMs || 115, topPadding: 7 });
        if (!layout || !document.contains(card)) return { captured: false, reason: 'CARD_REMOVED_BEFORE_CONTENT' };

        assertSafeFacebookCaptureRoute();
        const expanded = clickSeeMore(card);
        if (expanded > 0) {
            sequentialCaptureStats.expandedCards += 1;
            await sleep(Math.max(160, Number(options.expandDelayMs || 230)));
            assertSafeFacebookCaptureRoute();
            active = reacquireSequentialActionMenu({ ...item, menu, card, quickKey });
            menu = active.menu || menu;
            card = active.card || card;
            if (parsedDate?.ms && card) {
                actionDateByCard.set(card, cloneResolvedDate(parsedDate));
                if (menu) actionDateByMenu.set(menu, cloneResolvedDate(parsedDate));
                for (const cardMenu of postActionMenus(card)) actionDateByMenu.set(cardMenu, cloneResolvedDate(parsedDate));
            }
            layout = await alignCardBelowHeader(card, { settleMs: 110, topPadding: 7 }) || layout;
        }

        const mainCapture = await captureVisiblePosts({
            onlyCard: card,
            dateHydrationAttempts: 1,
            dateHydrationDelayMs: 70
        });
        row = mainCapture.posts[0] || null;
        if (parsedDate?.ms && row && !Number(row.created_at_ms || 0)) {
            actionDateByCard.set(card, cloneResolvedDate(parsedDate));
            const dateRecapture = await captureVisiblePosts({
                onlyCard: card,
                dateReviewOnly: true,
                dateHydrationAttempts: 1,
                dateHydrationDelayMs: 70
            });
            row = preserveSequentialDate(row, dateRecapture.posts[0] || null);
        }

        let metricFallback = false;
        const currentRect = card.getBoundingClientRect();
        const metricState = metricZoneState(card);
        const cardFitsViewport = currentRect.top >= (layout.headerOffset || 0) - 12
            && currentRect.bottom <= innerHeight + 8;
        if (!metricState.visible || !cardFitsViewport) {
            metricFallback = true;
            sequentialCaptureStats.localMetricFallbacks += 1;
            const target = Math.max(0, Math.round((window.scrollY || 0) + currentRect.bottom - innerHeight + 10));
            window.scrollTo({ top: target, left: 0, behavior: 'auto' });
            await sleep(Math.max(120, Number(options.metricDelayMs || 170)));
        } else {
            await sleep(Math.max(100, Number(options.confirmDelayMs || 135)));
        }

        const confirmation = await captureVisiblePosts({
            onlyCard: card,
            dateHydrationAttempts: 1,
            dateHydrationDelayMs: 70
        });
        row = preserveSequentialDate(row, confirmation.posts[0] || null);

        const hasTrustedDate = Boolean(row && Number(row.created_at_ms || 0) > 0 && isTrustedDateRecord(row));
        if (menu) sequentialProcessedMenus.add(menu);
        sequentialProcessedCards.add(card);
        try { card.dataset.biUcvEstado = hasTrustedDate ? 'guardada' : 'pendiente_fecha'; } catch (_) { /* best effort */ }
        if (quickKey) sequentialProcessedEvidence.add(quickKey);
        const finalKey = postEvidenceKey(row);
        if (finalKey) sequentialProcessedEvidence.add(finalKey);
        if (row?.content_signature) sequentialProcessedEvidence.add(String(row.content_signature));

        sequentialCaptureStats.cardsProcessed += 1;
        sequentialCaptureStats.actionMenusProcessed += 1;
        if (hasTrustedDate) sequentialCaptureStats.cardsWithDate += 1;
        else sequentialCaptureStats.cardsWithoutDate += 1;
        if (row?.metrics_zone_observed === true) sequentialCaptureStats.cardsWithMetricZone += 1;
        if (layout?.headerVisible === true) sequentialCaptureStats.cardsWithHeaderVisible += 1;
        else sequentialCaptureStats.cardsWithoutHeaderVisible += 1;
        if (layout?.fullyVisible === true) sequentialCaptureStats.cardsFullyVisible += 1;

        return {
            captured: Boolean(row),
            row,
            total: Number(confirmation.total || mainCapture.total || lastKnownFacebookTotal || 0),
            persistedPosts: Number(mainCapture.persistedPosts || 0) + Number(confirmation.persistedPosts || 0),
            metricFallback,
            expanded: expanded > 0,
            layout,
            hasTrustedDate
        };
    }

    async function runScrollCapture(options = {}) {
        const state = captureState;
        const batchSize = Math.max(20, Number(options.batchSize) || 100);
        const batchPauseMs = Math.max(350, Number(options.batchPauseMs) || 700);
        const loadDelayMs = Math.max(350, Number(options.scrollDelayMs) || 620);
        const stagnantProbeLimit = Math.max(5, Number(options.stagnantProbeLimit) || 8);
        const endConfirmationLimit = Math.max(2, Number(options.endConfirmationLimit) || 3);
        const endStableMs = Math.max(6000, Number(options.endStableMs) || 12000);
        const capturePeriod = options.capturePeriod === 'first_10'
            ? 'first_10'
            : (Object.prototype.hasOwnProperty.call(PERIOD_MONTHS, options.capturePeriod) ? options.capturePeriod : 'unlimited');
        const months = PERIOD_MONTHS[capturePeriod] || 0;
        // La referencia se fija con la publicación propia, no fijada y con
        // fecha confiable más reciente que se capture. En reanudaciones se
        // conserva el valor recibido del service worker.
        let periodReferenceDateMs = Number(options.periodReferenceDateMs || 0) || null;
        let periodCutoffDateMs = Number(options.periodCutoffDateMs || 0)
            || (months && periodReferenceDateMs ? subtractCalendarMonths(periodReferenceDateMs, months) : null);
        let periodFrontierDateMs = Number(options.periodFrontierDateMs || 0) || null;
        const oldBoundaryIds = new Set();
        let cycles = 0;
        let stagnantCycles = 0;
        let endConfirmations = 0;
        let lastTotal = 0;
        let lastPauseBatch = 0;
        let lastNewAt = Date.now();
        let finishReason = 'END_REACHED';
        let lastGeometry = null;
        let lastCardResult = null;
        let consecutiveDateFailures = 0;

        sequentialCaptureStats = {
            traversalMode: 'ONE_PASS_PRIVACY_TOOLTIP_V26',
            captureZoom: Number(options.captureZoom || 0) || null,
            cardsProcessed: 0,
            actionMenusProcessed: 0,
            cardsWithDate: 0,
            cardsWithoutDate: 0,
            cardsWithMetricZone: 0,
            cardsWithHeaderVisible: 0,
            cardsWithoutHeaderVisible: 0,
            cardsFullyVisible: 0,
            cardsWithLocalDateRetry: 0,
            localDateAttempts: 0,
            localMetricFallbacks: 0,
            relativeDateTooltipAttempts: 0,
            relativeDateTooltipResolved: 0,
            privacyDateLinksFound: 0,
            privacyTooltipAttempts: 0,
            privacyTooltipResolved: 0,
            expandedCards: 0,
            loadProbes: 0
        };

        try {
            if (options.startFromTop !== false) {
                window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
                await sleep(700);
            }

            while (state?.running && cycles < 30000) {
                assertSafeFacebookCaptureRoute();
                const next = nextSequentialActionMenu();
                if (next) {
                    cycles += 1;
                    state.currentCycle = cycles;
                    const result = await captureSequentialActionMenu(next, options);
                    if (!result.captured) {
                        if (next.menu) sequentialProcessedMenus.add(next.menu);
                        if (next.card) sequentialProcessedCards.add(next.card);
                        stagnantCycles += 1;
                        continue;
                    }

                    lastCardResult = result;
                    lastTotal = Math.max(lastTotal, Number(result.total || 0));
                    lastNewAt = Date.now();
                    stagnantCycles = 0;
                    endConfirmations = 0;

                    const row = result.row;
                    if (row?.is_own_publication && !row.is_pinned && Number(row.created_at_ms || 0) > 0
                        && TRUSTED_DATE_PRECISIONS.has(String(row.date_precision || '').toUpperCase())
                        && isTrustedDateRecord(row)) {
                        if (!periodReferenceDateMs) {
                            periodReferenceDateMs = Number(row.created_at_ms);
                            if (months) periodCutoffDateMs = subtractCalendarMonths(periodReferenceDateMs, months);
                        }
                        periodFrontierDateMs = periodFrontierDateMs
                            ? Math.min(periodFrontierDateMs, Number(row.created_at_ms))
                            : Number(row.created_at_ms);
                        const rowDayStart = localCalendarDayStart(row.created_at_ms);
                        const cutoffDayStart = localCalendarDayStart(periodCutoffDateMs);
                        // El día límite se incluye completo. Solo una fecha de un
                        // día anterior confirma que ya se salió del período.
                        if (cutoffDayStart !== null && rowDayStart !== null && rowDayStart < cutoffDayStart) {
                            oldBoundaryIds.add(String(row.id || row.content_signature || row.feed_order));
                        }
                    }

                    if (result.hasTrustedDate) consecutiveDateFailures = 0;
                    else consecutiveDateFailures += 1;

                    const processedForHealth = Number(sequentialCaptureStats.cardsProcessed || 0);
                    const dateCoverage = processedForHealth > 0
                        ? Number(sequentialCaptureStats.cardsWithDate || 0) / processedForHealth
                        : 0;
                    const earlyCoverageFailure = processedForHealth >= 5 && processedForHealth <= 10 && dateCoverage < 0.8;
                    const sustainedDateFailure = processedForHealth > 10 && consecutiveDateFailures >= 3;
                    if (earlyCoverageFailure || sustainedDateFailure) {
                        finishReason = 'DATE_CAPTURE_QUALITY_LOW';
                        break;
                    }

                    if (capturePeriod === 'first_10'
                        && Number(sequentialCaptureStats.cardsProcessed || 0) >= 10) {
                        finishReason = 'FIRST_10_REACHED';
                        break;
                    }

                    const hardPastCutoffMs = periodCutoffDateMs ? periodCutoffDateMs - (7 * 24 * 60 * 60 * 1000) : null;
                    const confirmedBoundary = periodCutoffDateMs && periodFrontierDateMs
                        && periodFrontierDateMs <= periodCutoffDateMs && oldBoundaryIds.size >= 2;
                    const hardSafetyBoundary = hardPastCutoffMs && periodFrontierDateMs
                        && periodFrontierDateMs <= hardPastCutoffMs;
                    if (confirmedBoundary || hardSafetyBoundary) {
                        finishReason = 'DATE_WINDOW_REACHED';
                        break;
                    }

                    const batch = Math.floor(sequentialCaptureStats.cardsProcessed / batchSize);
                    if (batch > lastPauseBatch && sequentialCaptureStats.cardsProcessed > 0) {
                        lastPauseBatch = batch;
                        await sendProgress({
                            total: lastTotal,
                            cycles,
                            stagnantCycles,
                            autoWaiting: true,
                            pauseReason: 'BATCH_PAUSE',
                            pauseUntil: Date.now() + batchPauseMs,
                            capturePeriod,
                            periodReferenceDateMs,
                            periodCutoffDateMs,
                            periodFrontierDateMs,
                            ...sequentialCaptureStats,
                            ...timelineSnapshot()
                        });
                        await sleep(batchPauseMs);
                    } else if (cycles === 1 || cycles % 3 === 0) {
                        await sendProgress({
                            total: lastTotal,
                            cycles,
                            stagnantCycles,
                            endConfirmations,
                            capturePeriod,
                            periodReferenceDateMs,
                            periodCutoffDateMs,
                            periodFrontierDateMs,
                            ...sequentialCaptureStats,
                            ...timelineSnapshot()
                        });
                    }
                    continue;
                }

                // No quedan tarjetas nuevas en el DOM actual. Solo se avanza hacia
                // abajo para solicitar el siguiente bloque a Facebook.
                cycles += 1;
                state.currentCycle = cycles;
                sequentialCaptureStats.loadProbes += 1;
                const before = timelineSnapshot();
                window.scrollBy({ top: Math.max(420, Math.round(innerHeight * 0.78)), left: 0, behavior: 'auto' });
                await sleep(loadDelayMs);
                clickRetry();
                const after = timelineSnapshot();
                stagnantCycles += 1;

                const atBottom = after.distanceToBottom <= Math.max(180, after.viewportHeight * 0.22);
                const stableGeometry = lastGeometry
                    && Math.abs(after.pageHeight - lastGeometry.pageHeight) < 35
                    && Math.abs(after.scrollTop - lastGeometry.scrollTop) < 35;
                const loading = timelineLoading();
                const explicitEnd = timelineHasExplicitEnd();
                const idleMs = Date.now() - lastNewAt;

                if (explicitEnd || (atBottom && !loading && idleMs >= endStableMs && stableGeometry)) {
                    endConfirmations += 1;
                } else {
                    endConfirmations = 0;
                }
                lastGeometry = after;

                await sendProgress({
                    total: lastTotal,
                    cycles,
                    stagnantCycles,
                    endConfirmations,
                    endConfirmationLimit,
                    autoWaiting: true,
                    pauseReason: 'CARGANDO_SIGUIENTE_TARJETA',
                    pauseUntil: Date.now() + loadDelayMs,
                    loading,
                    atBottom,
                    capturePeriod,
                    periodReferenceDateMs,
                    periodCutoffDateMs,
                    periodFrontierDateMs,
                    ...sequentialCaptureStats,
                    ...after
                });

                if (explicitEnd || endConfirmations >= endConfirmationLimit) {
                    finishReason = 'END_REACHED';
                    break;
                }

                // Respaldo sin retorno: si el scroll no se movió, solicita el fondo
                // actual. Nunca se desplaza hacia arriba ni inicia una segunda pasada.
                if (after.scrollTop === before.scrollTop && stagnantCycles >= stagnantProbeLimit) {
                    window.scrollTo({
                        top: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
                        left: 0,
                        behavior: 'auto'
                    });
                    await sleep(Math.max(500, loadDelayMs));
                    stagnantCycles = Math.max(1, stagnantProbeLimit - 2);
                }
            }

            if (!state?.running) finishReason = 'STOPPED_BY_USER';
            const summary = await chrome.runtime.sendMessage({ type: 'GET_FACEBOOK_DB_SUMMARY' }).catch(() => null);
            lastTotal = Math.max(lastTotal, Number(summary?.count || 0));
            await chrome.runtime.sendMessage({
                type: 'FB_SCROLL_CAPTURE_DONE',
                reason: finishReason,
                total: lastTotal,
                cycles,
                stagnantCycles,
                endConfirmations,
                periodReached: finishReason === 'DATE_WINDOW_REACHED',
                capturePeriod,
                periodReferenceDateMs,
                periodCutoffDateMs,
                periodFrontierDateMs,
                traversalMode: sequentialCaptureStats.traversalMode,
                captureZoom: sequentialCaptureStats.captureZoom,
                cardsProcessed: sequentialCaptureStats.cardsProcessed,
                actionMenusProcessed: sequentialCaptureStats.actionMenusProcessed || 0,
                cardsWithDate: sequentialCaptureStats.cardsWithDate,
                cardsWithoutDate: sequentialCaptureStats.cardsWithoutDate,
                cardsWithMetricZone: sequentialCaptureStats.cardsWithMetricZone,
                cardsWithHeaderVisible: sequentialCaptureStats.cardsWithHeaderVisible || 0,
                cardsWithoutHeaderVisible: sequentialCaptureStats.cardsWithoutHeaderVisible || 0,
                cardsFullyVisible: sequentialCaptureStats.cardsFullyVisible || 0,
                cardsWithLocalDateRetry: sequentialCaptureStats.cardsWithLocalDateRetry,
                localMetricFallbacks: sequentialCaptureStats.localMetricFallbacks,
                relativeDateTooltipAttempts: sequentialCaptureStats.relativeDateTooltipAttempts,
                relativeDateTooltipResolved: sequentialCaptureStats.relativeDateTooltipResolved,
                privacyDateLinksFound: sequentialCaptureStats.privacyDateLinksFound,
                privacyTooltipAttempts: sequentialCaptureStats.privacyTooltipAttempts,
                privacyTooltipResolved: sequentialCaptureStats.privacyTooltipResolved,
                expandedCards: sequentialCaptureStats.expandedCards,
                loadProbes: sequentialCaptureStats.loadProbes,
                finalPosition: timelineSnapshot()
            }).catch(() => null);
        } catch (error) {
            await chrome.runtime.sendMessage({
                type: 'FB_SCROLL_CAPTURE_DONE',
                reason: 'ERROR',
                error: error?.message || 'FACEBOOK_SCROLL_CAPTURE_FAILED',
                total: lastTotal,
                cycles,
                stagnantCycles,
                endConfirmations,
                capturePeriod,
                periodReferenceDateMs,
                periodCutoffDateMs,
                periodFrontierDateMs,
                traversalMode: sequentialCaptureStats?.traversalMode || 'ONE_PASS_PRIVACY_TOOLTIP_V26',
                captureZoom: sequentialCaptureStats?.captureZoom || null,
                cardsProcessed: sequentialCaptureStats?.cardsProcessed || 0,
                actionMenusProcessed: sequentialCaptureStats?.actionMenusProcessed || 0,
                cardsWithDate: sequentialCaptureStats?.cardsWithDate || 0,
                cardsWithoutDate: sequentialCaptureStats?.cardsWithoutDate || 0,
                cardsWithMetricZone: sequentialCaptureStats?.cardsWithMetricZone || 0,
                cardsWithHeaderVisible: sequentialCaptureStats?.cardsWithHeaderVisible || 0,
                cardsWithoutHeaderVisible: sequentialCaptureStats?.cardsWithoutHeaderVisible || 0,
                cardsFullyVisible: sequentialCaptureStats?.cardsFullyVisible || 0,
                cardsWithLocalDateRetry: sequentialCaptureStats?.cardsWithLocalDateRetry || 0,
                localMetricFallbacks: sequentialCaptureStats?.localMetricFallbacks || 0,
                relativeDateTooltipAttempts: sequentialCaptureStats?.relativeDateTooltipAttempts || 0,
                relativeDateTooltipResolved: sequentialCaptureStats?.relativeDateTooltipResolved || 0,
                privacyDateLinksFound: sequentialCaptureStats?.privacyDateLinksFound || 0,
                privacyTooltipAttempts: sequentialCaptureStats?.privacyTooltipAttempts || 0,
                privacyTooltipResolved: sequentialCaptureStats?.privacyTooltipResolved || 0,
                expandedCards: sequentialCaptureStats?.expandedCards || 0,
                loadProbes: sequentialCaptureStats?.loadProbes || 0,
                finalPosition: timelineSnapshot()
            }).catch(() => null);
        } finally {
            stopFacebookDateObserver();
            captureState = null;
        }
    }

    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message?.type === 'FB_READ_PROFILE') {
            try { sendResponse({ success: true, profile: readProfileInfo(), path: location.pathname }); }
            catch (error) { sendResponse({ error: error?.message || 'FACEBOOK_PROFILE_READ_FAILED' }); }
            return true;
        }
        if (message?.type === 'FB_START_PROFILE_SCROLL') {
            const expected = String(message.account || '').toLowerCase();
            const active = String(currentProfileSlug() || '').toLowerCase();
            if (!isFacebookProfilePage()) {
                sendResponse({ error: 'OPEN_FACEBOOK_PROFILE' });
                return true;
            }
            if (expected && active !== expected) {
                sendResponse({ error: 'WRONG_FACEBOOK_PROFILE_OPEN' });
                return true;
            }
            if (captureState?.running) {
                sendResponse({ error: 'ALREADY_RUNNING' });
                return true;
            }
            feedOrderByEvidence.clear();
            nextFeedOrder = 1;
            actionDateByMenu = new WeakMap();
            actionDateByCard = new WeakMap();
            latestActionDateAudit = null;
            persistedPostSnapshots = new Map();
            pendingDatePositions = new Map();
            pendingDateMenus = new Set();
            dateObserverPersistTimer = null;
            dateObserverPersistInFlight = false;
            lastKnownFacebookTotal = 0;
            sequentialProcessedEvidence = new Set();
            sequentialProcessedMenus = new WeakSet();
            sequentialProcessedCards = new WeakSet();
            sequentialQuickKeyByCard = new WeakMap();
            sequentialQuickKeyByMenu = new WeakMap();
            sequentialPrivacyDateEvidence = new Set();
            sequentialCaptureStats = null;
            captureState = {
                running: true,
                startedAt: Date.now(),
                currentCycle: 0,
                expectedProfileSlug: expected || active
            };
            runScrollCapture(message.options || {});
            sendResponse({ success: true, profile: readProfileInfo() });
            return true;
        }
        if (message?.type === 'FB_RESOLVE_CURRENT_PAGE_PERMALINK') {
            try {
                const targetSlug = String(message.account || currentProfileSlug() || '').replace(/^@/, '');
                const candidates = [];
                const addUrl = (value, score, source) => {
                    const identity = extractNativeIdentity(value, targetSlug);
                    if (!identity.id || identity.scope !== 'PUBLICACION') return;
                    candidates.push({ identity, score, source, sourceHref: String(value || '') });
                };
                addUrl(location.href, 260, 'AUXILIARY_LOCATION');
                addUrl(document.querySelector('link[rel="canonical"]')?.href, 250, 'AUXILIARY_CANONICAL');
                addUrl(document.querySelector('meta[property="og:url"]')?.content, 245, 'AUXILIARY_OG_URL');
                for (const anchor of document.querySelectorAll('a[href]')) {
                    const href = anchor.href || anchor.getAttribute('href') || '';
                    let score = 100;
                    if (/\/posts\//i.test(href)) score += 80;
                    if (/story_fbid=|set=pcb\./i.test(href)) score += 70;
                    if (/(?:[?&](?:comment_id|reply_comment_id)=|__tn__=R-R)/i.test(href)) score -= 15;
                    addUrl(href, score, 'AUXILIARY_DOM');
                }
                candidates.sort((a, b) => b.score - a.score);
                const best = candidates[0];
                const securityText = normalizeSpaces(document.body?.innerText || '').slice(0, 2500);
                const securityCheckpoint = /(?:captcha|verificación de seguridad|security check|actividad inusual|confirmar tu identidad|checkpoint)/i.test(securityText)
                    || /checkpoint|login/i.test(location.pathname);
                if (securityCheckpoint) {
                    sendResponse({ error: 'FACEBOOK_SECURITY_CHECK_DETECTED', securityCheckpoint: true });
                } else if (best) {
                    sendResponse({ success: true, permalinkInfo: permalinkInfoFromIdentity(best.identity, best.sourceHref, null, best.source, best.score) });
                } else {
                    sendResponse({ error: 'AUXILIARY_PERMALINK_NOT_FOUND' });
                }
            } catch (error) {
                sendResponse({ error: error?.message || 'AUXILIARY_PERMALINK_FAILED' });
            }
            return true;
        }
        if (message?.type === 'FB_STOP_PROFILE_SCROLL') {
            if (captureState) captureState.running = false;
            sendResponse({ success: true });
            return true;
        }
        return false;
    });
})();
