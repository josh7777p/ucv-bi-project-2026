// Capturador BI UCV — observador pasivo de respuestas JSON de Instagram.
// Se ejecuta en el mundo MAIN y solo copia las respuestas que la propia página
// ya solicitó. No realiza peticiones adicionales.
(() => {
    'use strict';

    if (window.__BIUCV_INSTAGRAM_INTERCEPTOR__) return;
    window.__BIUCV_INSTAGRAM_INTERCEPTOR__ = true;

    const MAX_BODY_LENGTH = 6 * 1024 * 1024;
    const interestingUrl = (value) => {
        const url = String(value || '');
        return /instagram\.com\/(?:api\/v1\/|graphql\/query|graphql\/web|ajax\/|web\/)/i.test(url)
            || /(?:doc_id|query_hash|xdt_api__v1__feed__user_timeline_graphql_connection)/i.test(url);
    };

    const publish = (url, bodyText, status = 200) => {
        if (typeof bodyText !== 'string' || !bodyText || bodyText.length > MAX_BODY_LENGTH) return;
        const trimmed = bodyText.trim();
        if (!trimmed || (trimmed[0] !== '{' && trimmed[0] !== '[')) return;
        try {
            window.postMessage({
                source: 'BI_UCV_INSTAGRAM_MAIN',
                type: 'IG_NETWORK_PAYLOAD',
                url: String(url || ''),
                status: Number(status || 0),
                bodyText: trimmed
            }, window.location.origin);
        } catch (_) { /* best effort */ }
    };

    const originalFetch = window.fetch;
    if (typeof originalFetch === 'function') {
        window.fetch = async function (...args) {
            const response = await originalFetch.apply(this, args);
            try {
                const url = response?.url || args?.[0]?.url || args?.[0] || '';
                if (interestingUrl(url)) {
                    response.clone().text().then(text => publish(url, text, response.status)).catch(() => {});
                }
            } catch (_) { /* pass through */ }
            return response;
        };
    }

    const OriginalXHR = window.XMLHttpRequest;
    if (typeof OriginalXHR === 'function') {
        const originalOpen = OriginalXHR.prototype.open;
        const originalSend = OriginalXHR.prototype.send;
        OriginalXHR.prototype.open = function (method, url, ...rest) {
            this.__biucvIgUrl = String(url || '');
            return originalOpen.call(this, method, url, ...rest);
        };
        OriginalXHR.prototype.send = function (...args) {
            if (!this.__biucvIgListenerAdded) {
                this.__biucvIgListenerAdded = true;
                this.addEventListener('load', () => {
                    try {
                        if (!interestingUrl(this.responseURL || this.__biucvIgUrl)) return;
                        if (this.responseType && this.responseType !== '' && this.responseType !== 'text') return;
                        publish(this.responseURL || this.__biucvIgUrl, this.responseText, this.status);
                    } catch (_) { /* pass through */ }
                });
            }
            return originalSend.apply(this, args);
        };
    }
})();
