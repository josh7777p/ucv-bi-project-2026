// Capturador BI UCV — captura asistida de publicaciones de Instagram.
// Navega el detalle visible de una publicación a la siguiente, guarda cada
// registro inmediatamente y usa datos estructurados pasivos cuando existen.
(() => {
    'use strict';

    if (window.__BIUCV_INSTAGRAM_CONTENT__) return;
    window.__BIUCV_INSTAGRAM_CONTENT__ = true;

    const NETWORK_MEDIA = new Map();
    const NETWORK_MEDIA_LIMIT = 12000;
    const CARACAS_TZ = 'America/Caracas';
    let captureState = null;

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    function cleanText(value, maxLength = 50000) {
        return typeof value === 'string'
            ? value.normalize('NFKC').replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim().slice(0, maxLength)
            : '';
    }

    function finiteCount(value) {
        if (value === null || value === undefined || value === '') return null;
        if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? Math.round(value) : null;
        const raw = String(value).trim().toLowerCase();
        if (!raw) return null;
        const compact = raw.replace(/\s+/g, '');
        const match = compact.match(/-?\d+(?:[.,]\d+)?/);
        if (!match) return null;
        const token = match[0];
        const hasThousandsSuffix = /(?:\d|[.,])(?:k|mil)(?:\s|$)/i.test(compact);
        const hasMillionsSuffix = /(?:\d|[.,])(?:m|mill[oó]n|millones)(?:\s|$)/i.test(compact);
        let normalized = token;
        if (!hasThousandsSuffix && !hasMillionsSuffix && /^\d{1,3}(?:[.,]\d{3})+$/.test(token)) {
            normalized = token.replace(/[.,]/g, '');
        } else {
            normalized = token.replace(',', '.');
        }
        let number = Number(normalized);
        if (!Number.isFinite(number) || number < 0) return null;
        if (hasThousandsSuffix) number *= 1000;
        else if (hasMillionsSuffix) number *= 1000000;
        return Math.round(number);
    }

    function getPathValue(object, paths) {
        for (const path of paths) {
            let current = object;
            let valid = true;
            for (const part of path.split('.')) {
                if (current === null || current === undefined || !Object.prototype.hasOwnProperty.call(current, part)) {
                    valid = false;
                    break;
                }
                current = current[part];
            }
            if (valid && current !== null && current !== undefined) return current;
        }
        return null;
    }

    function shortcodeFromUrl(value) {
        try {
            const rawUrl = value || location.href;
            const url = /^https?:/i.test(String(rawUrl))
                ? new URL(rawUrl)
                : new URL(rawUrl, 'https://www.instagram.com/');
            const match = url.pathname.match(/\/(?:p|reel|tv)\/([A-Za-z0-9_-]{5,120})(?:\/|$)/i)
                || url.pathname.match(/\/[^/]+\/(?:p|reel|tv)\/([A-Za-z0-9_-]{5,120})(?:\/|$)/i);
            return match?.[1] || '';
        } catch (_) {
            return '';
        }
    }

    function profileUsernameFromUrl(value = location.href) {
        try {
            const url = new URL(value, location.origin && location.origin !== 'null' ? location.origin : 'https://www.instagram.com/');
            if (!/(^|\.)instagram\.com$/i.test(url.hostname)) return '';
            const first = decodeURIComponent(url.pathname.split('/').filter(Boolean)[0] || '').replace(/^@/, '');
            const reserved = new Set(['p', 'reel', 'reels', 'tv', 'explore', 'accounts', 'direct', 'stories', 'about', 'developer']);
            return first && !reserved.has(first.toLowerCase()) ? first : '';
        } catch (_) {
            return '';
        }
    }

    function canonicalPostUrl(shortcode, type = 'POST') {
        if (!shortcode) return '';
        const segment = String(type || '').toUpperCase() === 'REEL' ? 'reel' : 'p';
        return `https://www.instagram.com/${segment}/${shortcode}/`;
    }

    function normalizeInstagramUsername(value) {
        return cleanText(String(value || '').replace(/^@/, ''), 220).toLowerCase();
    }

    function extractHashtags(text) {
        return [...new Set((cleanText(text, 50000).match(/#[\p{L}\p{N}_]+/gu) || [])
            .map(value => value.slice(1))
            .filter(Boolean))];
    }

    function extractMentions(text) {
        const source = cleanText(text, 50000);
        const values = [];
        const seen = new Set();
        const regex = /@([A-Za-z0-9._]{1,30})/g;
        let match;
        while ((match = regex.exec(source)) !== null) {
            const previous = match.index > 0 ? source[match.index - 1] : '';
            // Evita interpretar el dominio de una dirección de correo como mención.
            if (previous && /[A-Za-z0-9._%+-]/.test(previous)) continue;
            const username = match[1].replace(/\.+$/, '');
            if (!username || username.length > 30 || username.includes('..')) continue;
            const key = username.toLowerCase();
            if (!seen.has(key)) {
                seen.add(key);
                values.push(username);
            }
        }
        return values;
    }

    function mediaUrlStableKey(value) {
        try {
            const url = new URL(String(value || ''), location.origin && location.origin !== 'null'
                ? location.origin
                : 'https://www.instagram.com/');
            const cacheKey = url.searchParams.get('ig_cache_key');
            if (cacheKey) return `ig_cache:${cacheKey.replace(/=+$/g, '')}`;
            const filename = decodeURIComponent(url.pathname.split('/').pop() || '');
            const mediaId = filename.match(/^(\d+_\d+_\d+)_n(?:\.|$)/i)?.[1]
                || filename.match(/^(\d{8,})/i)?.[1];
            if (mediaId) return `media:${mediaId}`;
            return `path:${url.pathname.replace(/\.(?:jpe?g|webp|heic|png|mp4)$/i, '')}`;
        } catch (_) {
            return `raw:${String(value || '').split('?')[0]}`;
        }
    }

    function mediaUrlQualityScore(value) {
        const raw = String(value || '');
        let score = 0;
        if (/\.mp4(?:\?|$)/i.test(raw)) score += 100000;
        if (!/[?&]stp=/i.test(raw)) score += 10000;
        for (const match of raw.matchAll(/(?:^|[_?&])(?:s|p|cstp=mx|ctp=s)(\d{2,5})(?:x(\d{2,5}))?/gi)) {
            score = Math.max(score, Number(match[1] || 0) * Number(match[2] || match[1] || 0));
        }
        return score;
    }

    function dedupeMediaUrls(values) {
        const selected = new Map();
        for (const value of values || []) {
            const url = cleanText(String(value || ''), 1800);
            if (!url || /^blob:/i.test(url)) continue;
            const key = mediaUrlStableKey(url);
            const previous = selected.get(key);
            if (!previous || mediaUrlQualityScore(url) > mediaUrlQualityScore(previous)) selected.set(key, url);
        }
        return [...selected.values()];
    }

    function collectStructuredUsernames(value, depth = 0, output = new Set()) {
        if (!value || depth > 5) return output;
        if (Array.isArray(value)) {
            for (const item of value) collectStructuredUsernames(item, depth + 1, output);
            return output;
        }
        if (typeof value !== 'object') return output;
        const username = normalizeInstagramUsername(value.username || value.user?.username || value.owner?.username || '');
        if (username) output.add(username);
        for (const child of Object.values(value)) {
            if (child && typeof child === 'object') collectStructuredUsernames(child, depth + 1, output);
        }
        return output;
    }

    function hasPinnedSignal(node) {
        if (!node || typeof node.querySelectorAll !== 'function') return false;

        // La señal de fijado debe quedar aislada a la tarjeta de una sola
        // publicación. No se recorren contenedores amplios que también puedan
        // incluir tarjetas vecinas de la misma fila o de la fila siguiente.
        let postAnchor = null;
        if (node.matches?.('a[href]') && shortcodeFromUrl(node.href)) {
            postAnchor = node;
        } else {
            const closestAnchor = node.closest?.('a[href]');
            if (closestAnchor && shortcodeFromUrl(closestAnchor.href)) postAnchor = closestAnchor;
        }

        let scope = postAnchor || node;
        if (postAnchor) {
            const shortcode = shortcodeFromUrl(postAnchor.href);
            let current = postAnchor.parentElement;
            for (let index = 0; current && index < 3; index++, current = current.parentElement) {
                const shortcodesInScope = new Set(Array.from(current.querySelectorAll('a[href]'))
                    .map(anchor => shortcodeFromUrl(anchor.href))
                    .filter(Boolean));
                if (shortcodesInScope.size === 1 && shortcodesInScope.has(shortcode)) {
                    scope = current;
                } else {
                    break;
                }
            }
        }

        const candidates = [
            scope,
            ...Array.from(scope.querySelectorAll('[aria-label], [title], [data-testid]')).slice(0, 80)
        ];
        for (const candidate of candidates) {
            const signal = cleanText([
                candidate.getAttribute?.('aria-label') || '',
                candidate.getAttribute?.('title') || '',
                candidate.getAttribute?.('data-testid') || ''
            ].join(' '), 300);
            if (/pinned(?:\s+post|\s+publication)?|publicaci[oó]n\s+fijad[ao]|fijad[ao]\s+en\s+el\s+perfil/i.test(signal)) return true;
        }
        return false;
    }

    function classifyInstagramPost(post, targetUsername) {
        const target = normalizeInstagramUsername(targetUsername || post?.target_username || '');
        const author = normalizeInstagramUsername(post?.author_username || '');
        const collaborators = [...new Set((post?.collaborator_usernames || [])
            .map(normalizeInstagramUsername)
            .filter(Boolean))];
        const targetIsAuthor = Boolean(target && author === target);
        const targetIsCollaborator = Boolean(target && collaborators.includes(target));
        const hasOtherCollaborators = collaborators.some(username => username !== author);
        const appearsInTargetGrid = post?.from_target_profile_grid !== false;
        const collaborative = Boolean(post?.is_collaboration)
            || hasOtherCollaborators
            || (!targetIsAuthor && appearsInTargetGrid);
        const targetParticipates = targetIsAuthor
            || targetIsCollaborator
            || (!targetIsAuthor && appearsInTargetGrid);
        let classification = 'AJENA_NO_CLASIFICADA';
        if (targetIsAuthor && collaborative) classification = 'PROPIA_COLABORATIVA';
        else if (targetIsAuthor) classification = 'PROPIA_EXCLUSIVA';
        else if (targetParticipates && collaborative) classification = 'COLABORACION_PUBLICADA_POR_TERCERO';
        const source = targetIsCollaborator || hasOtherCollaborators || post?.is_collaboration
            ? 'DATOS_ESTRUCTURADOS_COLABORADORES'
            : (!targetIsAuthor && appearsInTargetGrid
                ? 'AUTOR_DISTINTO_EN_GRID_PRINCIPAL_CUENTA_OBJETIVO'
                : 'COMPARACION_AUTOR_CUENTA_OBJETIVO');
        return {
            ...post,
            target_username: target || null,
            collaborator_usernames: collaborators,
            is_own_post: targetIsAuthor,
            is_collaboration: collaborative,
            target_account_participates: targetParticipates,
            metrics_attributable_to_target: targetParticipates,
            exclusive_target_production: targetIsAuthor && !collaborative,
            account_link_classification: classification,
            account_link_classification_source: source
        };
    }

    function parseProfileNumber(raw, labelPattern) {
        const text = cleanText(raw, 2000);
        const match = text.match(new RegExp(`([\\d.,]+(?:\\s*(?:K|M|mil|millones?))?)\\s+${labelPattern}`, 'i'));
        return match ? { value: finiteCount(match[1]), raw: cleanText(match[0], 160) } : { value: null, raw: null };
    }

    function readProfile() {
        const username = profileUsernameFromUrl() || cleanText(document.querySelector('header h2, header h1')?.textContent, 220);
        const ogTitle = document.querySelector('meta[property="og:title"]')?.content || '';
        const ogDescription = document.querySelector('meta[property="og:description"]')?.content || '';
        const pageDescription = document.querySelector('meta[name="description"]')?.content || '';
        const description = pageDescription || ogDescription;
        const followers = parseProfileNumber(description, '(?:Followers|seguidores)');
        const following = parseProfileNumber(description, '(?:Following|seguidos|siguiendo)');
        const posts = parseProfileNumber(description, '(?:Posts|publicaciones)');
        const titleName = cleanText(ogTitle.split('(@')[0].replace(/\s*[•·].*$/, ''), 300);
        const profileImage = document.querySelector('meta[property="og:image"]')?.content
            || document.querySelector('header img')?.src
            || null;
        const metaBioSource = pageDescription || ogDescription;
        const metaBioMatch = metaBioSource.match(/on Instagram:\s*[“"']([^”"']+)[”"']/i)
            || metaBioSource.match(/Instagram:\s*[“"']([^”"']+)[”"']/i);
        const bioCandidates = Array.from(document.querySelectorAll('header section, header div'))
            .map(node => cleanText(node.innerText || '', 2000))
            .filter(text => text && text.length > 20
                && !/followers|seguidores|following|publicaciones|posts|\bfollow\b|\bseguir\b/i.test(text));
        return {
            id: username ? `instagram:${username.toLowerCase()}` : null,
            name: titleName || username,
            screenName: username,
            username,
            url: username ? `https://www.instagram.com/${username}/` : location.href,
            biography: cleanText(metaBioMatch?.[1] || '', 2000) || bioCandidates.sort((a, b) => a.length - b.length)[0] || null,
            profileImageUrl: profileImage,
            followersCount: followers.value,
            followersCountRaw: followers.raw,
            followingCount: following.value,
            followingCountRaw: following.raw,
            postsCount: posts.value,
            postsCountRaw: posts.raw,
            isProtected: false,
            source: 'PERFIL_INSTAGRAM_INTERFAZ_VISIBLE'
        };
    }

    function normalizeStructuredMedia(node, fallbackCode = '') {
        if (!node || typeof node !== 'object') return null;
        const shortcode = cleanText(
            getPathValue(node, ['code', 'shortcode', 'media.code', 'media.shortcode']) || fallbackCode,
            120
        );
        if (!shortcode || !/^[A-Za-z0-9_-]{5,120}$/.test(shortcode)) return null;
        const captionValue = getPathValue(node, [
            'caption.text', 'caption', 'edge_media_to_caption.edges.0.node.text',
            'media.caption.text', 'media.caption'
        ]);
        const user = getPathValue(node, ['user', 'owner', 'media.user', 'media.owner']) || {};
        const takenAt = getPathValue(node, ['taken_at', 'taken_at_timestamp', 'created_at', 'media.taken_at']);
        const takenMs = Number(takenAt) > 1000000000000
            ? Number(takenAt)
            : (Number(takenAt) > 1000000000 ? Number(takenAt) * 1000 : Date.parse(takenAt || ''));
        const mediaTypeNumber = Number(getPathValue(node, ['media_type', 'media.media_type']) || 0);
        const productType = String(getPathValue(node, ['product_type', 'media.product_type', '__typename']) || '').toLowerCase();
        const isVideo = Boolean(getPathValue(node, ['is_video', 'media.is_video'])) || mediaTypeNumber === 2 || /video|reel/.test(productType);
        const carousel = getPathValue(node, ['carousel_media', 'edge_sidecar_to_children.edges', 'media.carousel_media']);
        const mediaUrls = [];
        const altTexts = [];
        const collaboratorSources = [
            getPathValue(node, ['coauthor_producers', 'media.coauthor_producers']),
            getPathValue(node, ['invited_coauthor_producers', 'media.invited_coauthor_producers']),
            getPathValue(node, ['collaborators', 'media.collaborators']),
            getPathValue(node, ['coauthors', 'media.coauthors'])
        ].filter(Boolean);
        const collaboratorUsernames = [...collectStructuredUsernames(collaboratorSources)];
        const isPinned = Boolean(getPathValue(node, [
            'is_pinned', 'is_pinned_to_profile', 'is_pinned_for_user',
            'media.is_pinned', 'media.is_pinned_to_profile', 'media.is_pinned_for_user'
        ]));
        const addMedia = (item) => {
            if (!item || typeof item !== 'object') return;
            const candidate = getPathValue(item, [
                'image_versions2.candidates.0.url', 'display_url', 'thumbnail_src',
                'video_versions.0.url', 'url'
            ]);
            if (candidate) mediaUrls.push(String(candidate));
            const alt = getPathValue(item, ['accessibility_caption', 'alt_text']);
            if (alt) altTexts.push(String(alt));
        };
        addMedia(node);
        if (Array.isArray(carousel)) {
            for (const child of carousel) addMedia(child?.node || child);
        }
        return {
            shortcode,
            media_id: cleanText(String(getPathValue(node, ['pk', 'id', 'media_id', 'media.pk', 'media.id']) || ''), 160) || null,
            author_username: cleanText(getPathValue(user, ['username']) || '', 220),
            author_name: cleanText(getPathValue(user, ['full_name']) || '', 300),
            caption: typeof captionValue === 'string' ? cleanText(captionValue) : '',
            created_at: Number.isFinite(takenMs) ? new Date(takenMs).toISOString() : '',
            created_at_ms: Number.isFinite(takenMs) ? takenMs : 0,
            post_type: Array.isArray(carousel) && carousel.length > 1 ? 'CAROUSEL' : (isVideo ? 'REEL' : 'POST'),
            media_count: Array.isArray(carousel) ? carousel.length : 1,
            media_urls: dedupeMediaUrls(mediaUrls),
            media_alt_texts: [...new Set(altTexts)],
            collaborator_usernames: collaboratorUsernames,
            is_collaboration: collaboratorUsernames.length > 0,
            is_pinned: isPinned,
            location_name: cleanText(getPathValue(node, ['location.name', 'media.location.name']) || '', 500) || null,
            metrics: {
                like_count: finiteCount(getPathValue(node, ['like_count', 'edge_media_preview_like.count', 'edge_liked_by.count', 'media.like_count'])),
                comment_count: finiteCount(getPathValue(node, ['comment_count', 'edge_media_to_parent_comment.count', 'edge_media_to_comment.count', 'media.comment_count'])),
                view_count: finiteCount(getPathValue(node, ['view_count', 'video_view_count', 'media.view_count'])),
                play_count: finiteCount(getPathValue(node, ['play_count', 'video_play_count', 'media.play_count'])),
                share_count: finiteCount(getPathValue(node, ['share_count', 'reshare_count', 'media.share_count'])),
                save_count: finiteCount(getPathValue(node, ['save_count', 'saved_count', 'media.save_count']))
            },
            structured_data_found: true
        };
    }

    function indexNetworkPayload(bodyText) {
        let root;
        try { root = JSON.parse(bodyText); } catch (_) { return; }
        const stack = [{ value: root, depth: 0 }];
        const visited = new Set();
        let inspected = 0;
        while (stack.length && inspected < 100000) {
            const { value, depth } = stack.pop();
            if (!value || typeof value !== 'object' || depth > 12 || visited.has(value)) continue;
            visited.add(value);
            inspected++;
            const candidateCode = cleanText(value.code || value.shortcode || '', 120);
            if (candidateCode && /^[A-Za-z0-9_-]{5,120}$/.test(candidateCode)) {
                const normalized = normalizeStructuredMedia(value, candidateCode);
                if (normalized) {
                    const previous = NETWORK_MEDIA.get(candidateCode) || {};
                    NETWORK_MEDIA.set(candidateCode, { ...previous, ...normalized, metrics: { ...(previous.metrics || {}), ...(normalized.metrics || {}) } });
                }
            }
            if (Array.isArray(value)) {
                for (let i = value.length - 1; i >= 0; i--) stack.push({ value: value[i], depth: depth + 1 });
            } else {
                for (const child of Object.values(value)) {
                    if (child && typeof child === 'object') stack.push({ value: child, depth: depth + 1 });
                }
            }
        }
        if (NETWORK_MEDIA.size > NETWORK_MEDIA_LIMIT) {
            const excess = NETWORK_MEDIA.size - NETWORK_MEDIA_LIMIT;
            for (const key of Array.from(NETWORK_MEDIA.keys()).slice(0, excess)) NETWORK_MEDIA.delete(key);
        }
    }

    window.addEventListener('message', event => {
        if (event.source !== window || event.origin !== location.origin) return;
        const data = event.data;
        if (data?.source !== 'BI_UCV_INSTAGRAM_MAIN' || data?.type !== 'IG_NETWORK_PAYLOAD') return;
        indexNetworkPayload(data.bodyText);
    });

    function findDialog() {
        const dialogs = Array.from(document.querySelectorAll('[role="dialog"]'));
        return dialogs.find(dialog => dialog.querySelector('time[datetime]') && dialog.querySelector('svg[aria-label="Like"], svg[aria-label="Me gusta"]'))
            || dialogs.find(dialog => dialog.querySelector('time[datetime]'))
            || null;
    }

    function findCurrentShortcode(dialog) {
        for (const anchor of dialog?.querySelectorAll('a[href]') || []) {
            const code = shortcodeFromUrl(anchor.href);
            if (code && !/\/c\//.test(anchor.pathname || '')) return code;
        }
        return shortcodeFromUrl(location.href);
    }

    function findPostType(dialog, shortcode) {
        if (/\/reel\//i.test(location.pathname)) return 'REEL';
        for (const anchor of dialog?.querySelectorAll('a[href]') || []) {
            if (anchor.href.includes(shortcode) && /\/reel\//i.test(anchor.href)) return 'REEL';
        }
        if (dialog?.querySelector('video')) return 'VIDEO';
        const carouselNext = Array.from(dialog?.querySelectorAll('button, [role="button"]') || [])
            .some(node => /next|siguiente/i.test(node.getAttribute('aria-label') || '') && !node.querySelector('svg[aria-label="Next"]'));
        return carouselNext ? 'CAROUSEL' : 'POST';
    }

    function findAuthorAndCaption(dialog, firstTime, targetUsername) {
        const row = firstTime?.closest('li') || firstTime?.parentElement?.parentElement?.parentElement;
        let caption = cleanText(row?.querySelector('h1')?.innerText || '', 50000);
        if (!caption && row) {
            const candidates = Array.from(row.querySelectorAll('span[dir="auto"], div[dir="auto"]'))
                .map(node => cleanText(node.innerText || '', 50000))
                .filter(text => text && text !== targetUsername && !/^\d+[smhdwy]$/i.test(text));
            caption = candidates.sort((a, b) => b.length - a.length)[0] || '';
        }
        const authorAnchor = row?.querySelector(`a[href="/${CSS.escape(targetUsername)}/"], a[href*="instagram.com/${CSS.escape(targetUsername)}/"]`)
            || row?.querySelector('h2 a[href], a[role="link"][href]')
            || dialog?.querySelector(`a[href="/${CSS.escape(targetUsername)}/"]`);
        let authorUsername = profileUsernameFromUrl(authorAnchor?.href || '') || cleanText(authorAnchor?.textContent || '', 220);
        if (!authorUsername || /^(?:follow|seguir)$/i.test(authorUsername)) authorUsername = targetUsername;
        return {
            row,
            caption,
            author_username: authorUsername,
            author_name: cleanText(authorAnchor?.getAttribute('title') || '', 300) || authorUsername,
            author_url: authorUsername ? `https://www.instagram.com/${authorUsername}/` : null
        };
    }

    function countFromVisibleText(dialog, patterns) {
        const candidates = [...new Set(Array.from(dialog?.querySelectorAll('button, a, span, div') || [])
            .map(node => cleanText(node.innerText || node.textContent || '', 180))
            .filter(text => text && text.length <= 180
                && !/comments? from Facebook|comentarios? de Facebook/i.test(text)))]
            .sort((a, b) => a.length - b.length);
        for (const text of candidates) {
            for (const pattern of patterns) {
                const match = text.match(pattern);
                if (match) return { value: finiteCount(match[1]), raw: text };
            }
        }
        return { value: null, raw: null };
    }

    function collectMedia(dialog) {
        const urls = [];
        const altTexts = [];
        for (const image of dialog?.querySelectorAll('img') || []) {
            const width = Number(image.naturalWidth || image.width || 0);
            const height = Number(image.naturalHeight || image.height || 0);
            const alt = cleanText(image.alt || '', 2000);
            if (/profile picture|foto del perfil/i.test(alt)) continue;
            if (width && height && Math.max(width, height) < 220) continue;
            const url = image.currentSrc || image.src;
            if (url && !/^blob:/i.test(url) && !/profile|s150x150|s100x100|t51\.(?:2885|82787)-19/i.test(url)) urls.push(url);
            if (alt) altTexts.push(alt);
        }
        for (const video of dialog?.querySelectorAll('video') || []) {
            if (video.poster) urls.push(video.poster);
            const videoUrl = video.currentSrc || video.src;
            if (videoUrl && !/^blob:/i.test(videoUrl)) urls.push(videoUrl);
        }
        return { media_urls: dedupeMediaUrls(urls), media_alt_texts: [...new Set(altTexts)] };
    }

    function extractVisiblePost(dialog, targetUsername, feedOrder) {
        const shortcode = findCurrentShortcode(dialog);
        if (!shortcode) return null;
        const firstTime = dialog.querySelector('time[datetime]');
        const createdAt = firstTime?.getAttribute('datetime') || '';
        const createdMs = Date.parse(createdAt);
        const authorCaption = findAuthorAndCaption(dialog, firstTime, targetUsername);
        const type = findPostType(dialog, shortcode);
        const likes = countFromVisibleText(dialog, [
            /([\d.,]+(?:\s*(?:k|m|mil))?)\s+(?:likes?|me gusta)\b/i
        ]);
        const comments = countFromVisibleText(dialog, [
            /(?:view|ver)\s+(?:all|los)\s+([\d.,]+(?:\s*(?:k|m|mil))?)\s+(?:comments?|comentarios?)/i,
            /([\d.,]+(?:\s*(?:k|m|mil))?)\s+(?:comments?|comentarios?)\b/i
        ]);
        const views = countFromVisibleText(dialog, [
            /([\d.,]+(?:\s*(?:k|m|mil))?)\s+(?:views?|visualizaciones?)\b/i
        ]);
        const plays = countFromVisibleText(dialog, [
            /([\d.,]+(?:\s*(?:k|m|mil))?)\s+(?:plays?|reproducciones?)\b/i
        ]);
        const media = collectMedia(dialog);
        const hashtags = extractHashtags(authorCaption.caption);
        const mentions = extractMentions(authorCaption.caption);
        return {
            shortcode,
            media_id: null,
            permalink: canonicalPostUrl(shortcode, type, targetUsername),
            post_type: type,
            author_username: authorCaption.author_username,
            author_name: authorCaption.author_name,
            author_url: authorCaption.author_url,
            caption: authorCaption.caption,
            created_at: Number.isFinite(createdMs) ? new Date(createdMs).toISOString() : '',
            created_at_ms: Number.isFinite(createdMs) ? createdMs : 0,
            date_raw: cleanText(firstTime?.textContent || '', 100),
            timezone: 'UTC',
            location_name: null,
            hashtags,
            mentions,
            target_username: normalizeInstagramUsername(targetUsername),
            from_target_profile_grid: true,
            is_pinned: Boolean(captureState?.pinnedShortcodes?.has(shortcode) || hasPinnedSignal(dialog)),
            collaborator_usernames: [],
            is_collaboration: false,
            media_count: Math.max(1, media.media_urls.length),
            ...media,
            metrics: {
                like_count: likes.value,
                comment_count: comments.value,
                view_count: views.value,
                play_count: plays.value,
                share_count: null,
                save_count: null
            },
            metrics_raw: {
                like_count: likes.raw,
                comment_count: comments.raw,
                view_count: views.raw,
                play_count: plays.raw,
                share_count: null,
                save_count: null
            },
            metric_sources: {
                like_count: likes.value !== null ? 'DOM_VISIBLE' : null,
                comment_count: comments.value !== null ? 'DOM_VISIBLE' : null,
                view_count: views.value !== null ? 'DOM_VISIBLE' : null,
                play_count: plays.value !== null ? 'DOM_VISIBLE' : null,
                share_count: null,
                save_count: null
            },
            structured_data_found: false,
            capture_surface: 'INSTAGRAM_MODAL_DOM',
            feed_order: feedOrder
        };
    }

    function mergeStructured(visible) {
        const structured = NETWORK_MEDIA.get(visible.shortcode);
        if (!structured) return classifyInstagramPost({
            ...visible,
            hashtags: extractHashtags(visible.caption),
            mentions: extractMentions(visible.caption),
            media_urls: dedupeMediaUrls(visible.media_urls || [])
        }, visible.target_username || captureState?.username);
        const metrics = {};
        const raws = { ...(visible.metrics_raw || {}) };
        const sources = { ...(visible.metric_sources || {}) };
        for (const name of ['like_count', 'comment_count', 'view_count', 'play_count', 'share_count', 'save_count']) {
            const structuredValue = finiteCount(structured.metrics?.[name]);
            const visibleValue = finiteCount(visible.metrics?.[name]);
            if (structuredValue !== null && (visibleValue === null || structuredValue >= visibleValue)) {
                metrics[name] = structuredValue;
                raws[name] = String(structuredValue);
                sources[name] = 'RESPUESTA_ESTRUCTURADA_INSTAGRAM';
            } else {
                metrics[name] = visibleValue;
            }
        }
        const caption = (structured.caption || '').length >= (visible.caption || '').length
            ? structured.caption
            : visible.caption;
        const merged = {
            ...visible,
            media_id: structured.media_id || visible.media_id,
            author_username: structured.author_username || visible.author_username,
            author_name: structured.author_name || visible.author_name,
            caption,
            hashtags: extractHashtags(caption),
            mentions: extractMentions(caption),
            created_at: structured.created_at || visible.created_at,
            created_at_ms: structured.created_at_ms || visible.created_at_ms,
            post_type: structured.post_type || visible.post_type,
            media_count: Math.max(visible.media_count || 0, structured.media_count || 0),
            media_urls: dedupeMediaUrls([...(visible.media_urls || []), ...(structured.media_urls || [])]),
            media_alt_texts: [...new Set([...(visible.media_alt_texts || []), ...(structured.media_alt_texts || [])])],
            collaborator_usernames: [...new Set([...(visible.collaborator_usernames || []), ...(structured.collaborator_usernames || [])])],
            is_collaboration: Boolean(visible.is_collaboration || structured.is_collaboration),
            is_pinned: Boolean(visible.is_pinned || structured.is_pinned),
            location_name: structured.location_name || visible.location_name,
            metrics,
            metrics_raw: raws,
            metric_sources: sources,
            structured_data_found: true,
            capture_surface: 'INSTAGRAM_MODAL_DOM_Y_RESPUESTA_ESTRUCTURADA'
        };
        return classifyInstagramPost(merged, visible.target_username || captureState?.username);
    }

    function findNextButton(dialog) {
        const candidates = Array.from(document.querySelectorAll('button, [role="button"]'));
        return candidates.find(node => {
            if (dialog?.contains(node)) return false;
            const aria = cleanText(node.getAttribute('aria-label') || '', 80);
            const text = cleanText(node.innerText || node.textContent || '', 80);
            return /^(?:next|siguiente)$/i.test(aria) || /^(?:next|siguiente)$/i.test(text);
        }) || null;
    }

    function collectGridPostLinks(targetUsername) {
        const collectFrom = (root) => {
            const rows = [];
            const seen = new Set();
            for (const anchor of root.querySelectorAll('a[href]')) {
                const shortcode = shortcodeFromUrl(anchor.href);
                if (!shortcode || seen.has(shortcode) || /\/c\//.test(anchor.pathname || '')) continue;
                // En el grid principal pueden aparecer colaboraciones cuyo permalink usa
                // el usuario del autor original; siguen perteneciendo al recorrido del perfil objetivo.
                seen.add(shortcode);
                rows.push({ shortcode, href: anchor.href, anchor, isPinned: hasPinnedSignal(anchor) });
            }
            return rows;
        };
        const main = document.querySelector('main');
        const mainRows = main ? collectFrom(main) : [];
        return mainRows.length ? mainRows : collectFrom(document);
    }

    function mergeGridLinksIntoQueue(links) {
        const state = captureState;
        if (!state || !Array.isArray(links)) return 0;
        const existing = new Map(state.gridQueue.map(item => [item.shortcode, item]));
        let added = 0;
        for (const link of links) {
            if (!link?.shortcode) continue;
            const current = existing.get(link.shortcode);
            if (current) {
                if (link.href) current.href = link.href;
                current.isPinned = Boolean(current.isPinned || link.isPinned);
            } else {
                const item = {
                    shortcode: link.shortcode,
                    href: link.href,
                    isPinned: Boolean(link.isPinned)
                };
                state.gridQueue.push(item);
                existing.set(item.shortcode, item);
                added++;
            }
            state.gridShortcodes.add(link.shortcode);
            if (link.isPinned) state.pinnedShortcodes.add(link.shortcode);
        }
        return added;
    }

    function expectedQueuedGridItem() {
        const state = captureState;
        if (!state?.gridQueue?.length) return null;
        return state.gridQueue.find(item => !state.seen.has(item.shortcode)) || null;
    }

    async function waitForDialog(timeoutMs = 20000) {
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
            if (captureState?.stopRequested) return null;
            const dialog = findDialog();
            if (dialog && findCurrentShortcode(dialog)) return dialog;
            await sleep(150);
        }
        return null;
    }

    async function waitForShortcodeChange(previousShortcode, timeoutMs = 18000) {
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
            if (captureState?.stopRequested) return null;
            const dialog = findDialog();
            const shortcode = findCurrentShortcode(dialog);
            if (dialog && shortcode && shortcode !== previousShortcode) {
                await sleep(450);
                return dialog;
            }
            await sleep(150);
        }
        return null;
    }

    function dayPartsInCaracas(timestamp) {
        const date = new Date(timestamp);
        if (!Number.isFinite(date.getTime())) return null;
        const parts = new Intl.DateTimeFormat('en-CA', {
            timeZone: CARACAS_TZ,
            year: 'numeric', month: '2-digit', day: '2-digit'
        }).formatToParts(date);
        const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
        return { year: Number(values.year), month: Number(values.month), day: Number(values.day) };
    }

    function dayKey(parts) {
        return parts ? parts.year * 10000 + parts.month * 100 + parts.day : 0;
    }

    function subtractCalendarMonths(parts, months) {
        if (!parts) return null;
        let year = parts.year;
        let monthIndex = parts.month - 1 - months;
        year += Math.floor(monthIndex / 12);
        monthIndex = ((monthIndex % 12) + 12) % 12;
        const lastDay = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
        return { year, month: monthIndex + 1, day: Math.min(parts.day, lastDay) };
    }

    function captureMonths(period) {
        return { last_month: 1, last_3_months: 3, last_year: 12 }[period] || 0;
    }

    async function clickFirstPublication(targetUsername) {
        const deadline = Date.now() + 20000;
        let links = [];
        while (Date.now() < deadline && !captureState?.stopRequested) {
            links = collectGridPostLinks(targetUsername);
            if (links.length) break;
            await sleep(250);
        }
        if (!links.length) return false;
        mergeGridLinksIntoQueue(links);
        const first = captureState?.gridQueue?.[0];
        const current = first ? links.find(item => item.shortcode === first.shortcode) : links[0];
        if (!current?.anchor) return false;
        current.anchor.scrollIntoView({ block: 'center', behavior: 'auto' });
        current.anchor.click();
        return Boolean(await waitForSpecificShortcode(current.shortcode));
    }

    async function waitForDialogClosed(timeoutMs = 5000) {
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
            if (!findDialog()) return true;
            await sleep(100);
        }
        return !findDialog();
    }

    async function closeCurrentDialog(dialog) {
        const candidates = Array.from(document.querySelectorAll('button, [role="button"]'));
        const closeButton = candidates.find(node => {
            const aria = cleanText(node.getAttribute('aria-label') || '', 80);
            const title = cleanText(node.getAttribute('title') || '', 80);
            return /^(?:close|cerrar)$/i.test(aria) || /^(?:close|cerrar)$/i.test(title);
        });
        if (closeButton) closeButton.click();
        else {
            try {
                const target = dialog || document;
                target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
            } catch (_) { /* fallback */ }
        }
        return waitForDialogClosed();
    }

    async function waitForSpecificShortcode(expectedShortcode, timeoutMs = 16000) {
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
            if (captureState?.stopRequested) return null;
            const dialog = findDialog();
            if (dialog && findCurrentShortcode(dialog) === expectedShortcode) {
                await sleep(350);
                return dialog;
            }
            await sleep(120);
        }
        return null;
    }

    function nextQueuedGridItem() {
        const state = captureState;
        if (!state?.gridQueue?.length) return null;
        return state.gridQueue.find(item => !state.seen.has(item.shortcode) && !state.failedGridShortcodes.has(item.shortcode)) || null;
    }

    async function clickQueuedGridAnchor(item, targetUsername) {
        if (!item?.shortcode) return null;
        const links = collectGridPostLinks(targetUsername);
        mergeGridLinksIntoQueue(links);
        const current = links.find(link => link.shortcode === item.shortcode);
        if (!current?.anchor) return null;
        current.anchor.scrollIntoView({ block: 'center', behavior: 'auto' });
        current.anchor.click();
        return waitForSpecificShortcode(item.shortcode, 12000);
    }

    async function openQueuedGridPublication(item, dialog, targetUsername) {
        if (!item?.shortcode) return null;

        // Primer intento: cambiar directamente al permalink esperado sin cerrar
        // el modal. Instagram suele interceptar el clic y sustituir el detalle.
        let opened = await clickQueuedGridAnchor(item, targetUsername);
        if (opened) return opened;

        // Respaldo: cerrar el modal, volver a localizar la tarjeta y abrirla.
        const activeDialog = findDialog() || dialog;
        if (activeDialog) {
            const closed = await closeCurrentDialog(activeDialog);
            if (!closed) return null;
        }
        await sleep(250);
        opened = await clickQueuedGridAnchor(item, targetUsername);
        return opened;
    }

    async function expandGridQueue(dialog, targetUsername) {
        const activeDialog = findDialog() || dialog;
        if (activeDialog) {
            const closed = await closeCurrentDialog(activeDialog);
            if (!closed) return false;
        }

        let stagnant = 0;
        let previousSize = captureState?.gridQueue?.length || 0;
        for (let cycle = 0; cycle < 10 && captureState && !captureState.stopRequested; cycle++) {
            const links = collectGridPostLinks(targetUsername);
            const added = mergeGridLinksIntoQueue(links);
            if (expectedQueuedGridItem()) {
                captureState.gridExpansionCycles += cycle + 1;
                return true;
            }

            const currentSize = captureState.gridQueue.length;
            stagnant = added > 0 || currentSize > previousSize ? 0 : stagnant + 1;
            previousSize = currentSize;
            const lastAnchor = links.at(-1)?.anchor;
            if (lastAnchor) lastAnchor.scrollIntoView({ block: 'end', behavior: 'auto' });
            try {
                window.scrollTo({ top: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), behavior: 'auto' });
            } catch (_) {
                window.scrollTo(0, Math.max(document.body.scrollHeight, document.documentElement.scrollHeight));
            }
            await sleep(900 + cycle * 120);
            if (stagnant >= 4) break;
        }
        captureState.gridExpansionCycles += 1;
        return Boolean(expectedQueuedGridItem());
    }

    async function advanceToNext(dialog, previousShortcode) {
        const nextButton = findNextButton(dialog);
        if (nextButton) {
            nextButton.click();
            const changed = await waitForShortcodeChange(previousShortcode, 16000);
            if (changed) return changed;
        }
        try {
            window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', bubbles: true }));
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', bubbles: true }));
        } catch (_) { /* fallback */ }
        return await waitForShortcodeChange(previousShortcode, 7000);
    }

    async function advanceToExpectedGridItem(dialog, previousShortcode, expectedItem, targetUsername) {
        if (!expectedItem?.shortcode) return null;
        const changedDialog = await advanceToNext(dialog, previousShortcode);
        const changedShortcode = findCurrentShortcode(changedDialog);
        if (changedDialog && changedShortcode === expectedItem.shortcode) return changedDialog;

        if (changedDialog && changedShortcode && changedShortcode !== expectedItem.shortcode) {
            captureState.gridSequenceCorrections++;
            await reportProgress({
                gridSequenceExpected: expectedItem.shortcode,
                gridSequenceObserved: changedShortcode
            });
        }
        return openQueuedGridPublication(expectedItem, changedDialog || dialog, targetUsername);
    }

    async function reportProgress(extra = {}) {
        const message = {
            type: 'IG_SCROLL_CAPTURE_PROGRESS',
            captured: captureState?.captured || 0,
            processed: captureState?.processed || 0,
            duplicates: captureState?.duplicates || 0,
            capturePeriod: captureState?.period || 'first_10',
            periodReferenceDateMs: captureState?.referenceMs || null,
            periodCutoffDayKey: captureState?.cutoffDayKey || null,
            currentShortcode: captureState?.currentShortcode || null,
            pinnedDetected: captureState?.pinnedShortcodes?.size || 0,
            gridQueueSize: captureState?.gridQueue?.length || 0,
            gridQueueFailures: captureState?.failedGridShortcodes?.size || 0,
            gridSequenceCorrections: captureState?.gridSequenceCorrections || 0,
            gridExpansionCycles: captureState?.gridExpansionCycles || 0,
            ...extra
        };
        try { await chrome.runtime.sendMessage(message); } catch (_) { /* popup/SW can restart */ }
    }

    async function finishCapture(reason, error = null) {
        const state = captureState;
        captureState = null;
        try {
            await chrome.runtime.sendMessage({
                type: 'IG_SCROLL_CAPTURE_DONE',
                reason,
                error,
                captured: state?.captured || 0,
                processed: state?.processed || 0,
                duplicates: state?.duplicates || 0,
                capturePeriod: state?.period || 'first_10',
                periodReached: reason === 'DATE_WINDOW_REACHED' || reason === 'FIRST_10_REACHED',
                periodReferenceDateMs: state?.referenceMs || null,
                periodCutoffDayKey: state?.cutoffDayKey || null,
                currentShortcode: state?.currentShortcode || null,
                pinnedDetected: state?.pinnedShortcodes?.size || 0,
                gridQueueSize: state?.gridQueue?.length || 0,
                gridQueueFailures: state?.failedGridShortcodes?.size || 0,
                gridSequenceCorrections: state?.gridSequenceCorrections || 0,
                gridExpansionCycles: state?.gridExpansionCycles || 0,
                structuredPayloadsIndexed: NETWORK_MEDIA.size
            });
        } catch (_) { /* best effort */ }
    }

    async function runCapture(options) {
        const targetUsername = cleanText(options?.username || profileUsernameFromUrl(), 220).replace(/^@/, '');
        const period = ['first_10', 'last_month', 'last_3_months', 'last_year', 'unlimited'].includes(options?.capturePeriod)
            ? options.capturePeriod
            : 'first_10';
        captureState = {
            running: true,
            stopRequested: false,
            username: targetUsername,
            period,
            captured: 0,
            processed: 0,
            duplicates: 0,
            seen: new Set(),
            referenceMs: null,
            cutoffDayKey: null,
            olderStreak: 0,
            currentShortcode: null,
            gridQueue: [],
            gridShortcodes: new Set(),
            pinnedShortcodes: new Set(),
            failedGridShortcodes: new Set(),
            gridSequenceCorrections: 0,
            gridExpansionCycles: 0
        };

        try {
            let dialog = findDialog();
            if (!dialog) {
                const opened = await clickFirstPublication(targetUsername);
                if (!opened) throw new Error('INSTAGRAM_FIRST_POST_NOT_FOUND');
                dialog = await waitForDialog();
            }
            if (!dialog) throw new Error('INSTAGRAM_POST_DIALOG_NOT_FOUND');

            while (captureState && !captureState.stopRequested) {
                const shortcode = findCurrentShortcode(dialog);
                if (!shortcode) throw new Error('INSTAGRAM_SHORTCODE_NOT_FOUND');
                captureState.currentShortcode = shortcode;
                captureState.processed++;

                let post = extractVisiblePost(dialog, targetUsername, captureState.processed);
                if (!post || !post.created_at_ms || !post.caption) {
                    await sleep(700);
                    post = extractVisiblePost(findDialog() || dialog, targetUsername, captureState.processed) || post;
                }
                if (!post) throw new Error('INSTAGRAM_POST_READ_FAILED');
                post = mergeStructured(post);

                const isNewInSession = !captureState.seen.has(post.shortcode);
                if (isNewInSession) captureState.seen.add(post.shortcode);
                else captureState.duplicates++;
                const result = await chrome.runtime.sendMessage({
                    type: 'IG_CAPTURE_POSTS',
                    posts: [post],
                    operationName: post.capture_surface
                });
                if (result?.error) throw new Error(result.error);
                captureState.captured = Number(result?.total || captureState.seen.size);

                if (post.created_at_ms > 0 && post.target_account_participates !== false) {
                    // La referencia temporal usa la fecha cronológicamente máxima.
                    // Una publicación fijada antigua no domina el período por estar arriba,
                    // pero una fijada que realmente sea la más reciente sí puede ser la referencia.
                    captureState.referenceMs = Math.max(captureState.referenceMs || 0, post.created_at_ms);
                    const months = captureMonths(period);
                    if (months > 0) {
                        const referenceParts = dayPartsInCaracas(captureState.referenceMs);
                        captureState.cutoffDayKey = dayKey(subtractCalendarMonths(referenceParts, months));
                        if (post.is_pinned !== true) {
                            const currentDayKey = dayKey(dayPartsInCaracas(post.created_at_ms));
                            captureState.olderStreak = currentDayKey < captureState.cutoffDayKey
                                ? captureState.olderStreak + 1
                                : 0;
                        }
                    }
                }

                await reportProgress();

                if (period === 'first_10' && captureState.captured >= 10) {
                    await finishCapture('FIRST_10_REACHED');
                    return;
                }
                if (captureMonths(period) > 0
                    && captureState.processed >= 6
                    && captureState.olderStreak >= 3) {
                    await finishCapture('DATE_WINDOW_REACHED');
                    return;
                }

                const previous = shortcode;
                // La cola del grid es la fuente de verdad del recorrido. Next se usa
                // para avanzar rápido, pero el shortcode obtenido debe coincidir con
                // el siguiente elemento pendiente de la cuadrícula.
                let queuedItem = nextQueuedGridItem();
                if (!queuedItem) {
                    const expanded = await expandGridQueue(findDialog() || dialog, targetUsername);
                    queuedItem = expanded ? nextQueuedGridItem() : null;
                    if (queuedItem) {
                        const queuedDialog = await openQueuedGridPublication(queuedItem, null, targetUsername);
                        if (queuedDialog) {
                            dialog = queuedDialog;
                            continue;
                        }
                    }
                } else {
                    const nextDialog = await advanceToExpectedGridItem(
                        findDialog() || dialog,
                        previous,
                        queuedItem,
                        targetUsername
                    );
                    if (nextDialog) {
                        dialog = nextDialog;
                        continue;
                    }
                }

                if (queuedItem) {
                    captureState.failedGridShortcodes.add(queuedItem.shortcode);
                    await reportProgress({ gridQueueFailure: queuedItem.shortcode });
                    await finishCapture('NAVIGATION_INTERRUPTED');
                    return;
                }

                const incompleteReason = period === 'unlimited'
                    ? 'END_REACHED'
                    : 'NAVIGATION_INTERRUPTED';
                await finishCapture(incompleteReason);
                return;
            }

            await finishCapture('STOPPED_BY_USER');
        } catch (error) {
            await finishCapture('ERROR', error?.message || 'INSTAGRAM_CAPTURE_FAILED');
        }
    }

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message?.type === 'IG_READ_PROFILE') {
            sendResponse({ success: true, profile: readProfile() });
            return false;
        }
        if (message?.type === 'IG_START_PROFILE_CAPTURE') {
            if (captureState?.running) {
                sendResponse({ error: 'ALREADY_RUNNING' });
                return false;
            }
            sendResponse({ success: true, started: true });
            setTimeout(() => runCapture(message), 0);
            return false;
        }
        if (message?.type === 'IG_STOP_PROFILE_CAPTURE') {
            if (captureState) captureState.stopRequested = true;
            sendResponse({ success: true });
            return false;
        }
        return false;
    });

    // Expuesto solo para pruebas estáticas locales; no modifica la página.
    window.__BIUCVInstagramTest = {
        readProfile,
        findDialog,
        extractVisiblePost: (username = profileUsernameFromUrl()) => {
            const dialog = findDialog();
            return dialog ? mergeStructured(extractVisiblePost(dialog, username, 1)) : null;
        },
        shortcodeFromUrl,
        findNextButton,
        indexNetworkPayload,
        extractHashtags,
        extractMentions,
        dedupeMediaUrls,
        mediaUrlStableKey,
        classifyInstagramPost,
        collectGridPostLinks,
        mergeGridLinksIntoQueue,
        expectedQueuedGridItem,
        hasPinnedSignal
    };
})();
