// XPorter — Content Script
// Detects the current X/Twitter username from the page URL
// Runs on x.com and twitter.com pages at document_start (document.body
// does not exist yet — never touch it at top level).

const RESERVED_PATHS = new Set([
    'home', 'explore', 'search', 'notifications', 'messages',
    'settings', 'i', 'compose', 'intent', 'account', 'login',
    'logout', 'signup', 'tos', 'privacy', 'about', 'help',
    'hashtag', 'lists', 'communities', 'premium', 'jobs',
    'who_to_follow', 'trending', 'bookmarks', 'topics',
    'display', 'download', 'follower_requests'
]);

function extractUsername() {
    const path = window.location.pathname;

    // Match /username or /username/anything
    const match = path.match(/^\/([a-zA-Z0-9_]{1,15})(\/|$)/);

    if (!match) return null;

    const potentialUsername = match[1].toLowerCase();

    // Skip reserved paths
    if (RESERVED_PATHS.has(potentialUsername)) return null;

    return match[1]; // Return original case
}

function sendUsername(username) {
    if (username) {
        // Guard: chrome.runtime may be undefined after extension update/reload
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) return;
        chrome.runtime.sendMessage({
            type: 'SET_USERNAME',
            username: username
        }).catch(() => {
            // Extension context may not be available
        });
    }
}

// Detect on initial page load
const initialUsername = extractUsername();
if (initialUsername) {
    sendUsername(initialUsername);
}

// Detect on SPA navigation (X is a single-page app)
let lastUrl = window.location.href;

// Use MutationObserver to detect URL changes in SPA.
// We run at document_start, where document.body is still null —
// observe document.documentElement instead (it exists at document_start),
// and fall back to DOMContentLoaded just in case.
const observer = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        const username = extractUsername();
        sendUsername(username);
    }
});

function startUrlObserver() {
    const root = document.documentElement || document.body;
    if (!root) return false;
    observer.observe(root, {
        childList: true,
        subtree: true
    });
    return true;
}

if (!startUrlObserver()) {
    document.addEventListener('DOMContentLoaded', startUrlObserver, { once: true });
}

// Also listen for popstate events (back/forward navigation)
window.addEventListener('popstate', () => {
    const username = extractUsername();
    sendUsername(username);
});


// BI UCV: gently trigger one more Replies timeline request when the worker has
// not yet received the live UserTweetsAndReplies queryId. This uses the page's
// own normal scrolling behavior; it does not inject credentials or tokens.
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'UCV_WARMUP_REPLIES') return;

    const isRepliesPage = /^\/[a-zA-Z0-9_]{1,15}\/with_replies\/?$/.test(window.location.pathname);
    if (!isRepliesPage) {
        sendResponse({ success: false, reason: 'NOT_REPLIES_PAGE' });
        return;
    }

    const step = Math.max(520, Math.floor(window.innerHeight * 0.9));
    // Several measured steps are more reliable than one jump: X normally asks
    // for the next Replies page only when the viewport approaches the bottom of
    // the currently rendered timeline.
    for (let index = 0; index < 6; index++) {
        setTimeout(() => {
            window.scrollBy({ top: step, left: 0, behavior: index === 0 ? 'smooth' : 'auto' });
        }, index * 650);
    }
    sendResponse({ success: true, steps: 6 });
});

// ==================== GraphQL QueryId Discovery via Fetch Interception ====================
// X.com makes GraphQL requests with the correct queryIds.
// content/interceptor.js (registered in manifest.json in the MAIN world at
// document_start) intercepts these in the page context and forwards them to
// us via window.postMessage; we relay them to the service worker so the
// extension always has up-to-date queryIds without fragile JS-bundle scanning.
// This listener must attach at document_start so early captures are not lost.

// Must mirror TRACKED in content/interceptor.js — anything else is dropped.
const RELAY_TRACKED_OPERATIONS = new Set([
    'Followers', 'Following', 'BlueVerifiedFollowers',
    'UserTweets', 'UserTweetsAndReplies', 'UserByScreenName', 'SearchTimeline'
]);
const RELAY_QUERYID_PATTERN = /^[A-Za-z0-9_-]{10,40}$/;
const RELAY_MAX_BODY_CHARS = 8 * 1024 * 1024; // must match interceptor.js
const RELAY_MAX_SEEN_POSTS = 250;
const RELAY_POST_ID_PATTERN = /^\d{5,30}$/;
const RELAY_POST_OPERATION_PATTERN = /(Timeline|Tweets|TweetDetail|Bookmarks|Likes|Community|ListLatest|UserMedia)/i;
const RELAY_MAX_TEMPLATE_CHARS = 160 * 1024;

function sanitizeGraphqlTemplate(template) {
    if (!template || typeof template !== 'object' || Array.isArray(template)) return null;
    try {
        const serialized = JSON.stringify(template);
        if (!serialized || serialized.length > RELAY_MAX_TEMPLATE_CHARS) return null;
        const clean = JSON.parse(serialized);
        const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);
        if (!isObject(clean.variables) || !isObject(clean.features)) return null;
        if (clean.fieldToggles != null && !isObject(clean.fieldToggles)) return null;
        return {
            variables: clean.variables,
            features: clean.features,
            fieldToggles: clean.fieldToggles || null
        };
    } catch (_) {
        return null;
    }
}

function sanitizeSeenPost(post) {
    const text = (value, max) => typeof value === 'string' ? value.slice(0, max) : '';
    const count = (value) => {
        if (typeof value !== 'number' && typeof value !== 'string') return null;
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
    };
    const bool = (value) => value === true;
    const metricNames = [
        'view_count', 'bookmark_count', 'favorite_count',
        'retweet_count', 'reply_count', 'quote_count'
    ];
    const metricObject = (value, raw = false) => {
        const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
        const result = {};
        for (const name of metricNames) {
            result[name] = raw
                ? (source[name] === null || source[name] === undefined ? null : text(String(source[name]), 120))
                : count(source[name]);
        }
        return result;
    };
    const normalizedType = (() => {
        const rawType = String(post.type || '').toUpperCase();
        if (rawType === 'RETWEET') return 'RETWEET';
        if (rawType === 'THREAD_REPLY') return 'THREAD_REPLY';
        if (rawType === 'REPLY') return 'REPLY';
        return 'TWEET';
    })();

    return {
        id: String(post.id),
        text: text(post.text, 25000),
        tweet_url: text(post.tweet_url, 300),
        language: text(post.language, 16),
        created_at: text(post.created_at, 80),
        author_id: text(post.author_id, 32),
        author_name: text(post.author_name, 200),
        author_username: text(post.author_username, 40),
        author_followers_count: count(post.author_followers_count),
        author_verified: bool(post.author_verified),
        view_count: count(post.view_count),
        bookmark_count: count(post.bookmark_count),
        favorite_count: count(post.favorite_count),
        retweet_count: count(post.retweet_count),
        reply_count: count(post.reply_count),
        quote_count: count(post.quote_count),
        metricas_raw: metricObject(post.metricas_raw, true),
        metricas_contenido_original: post.metricas_contenido_original ? metricObject(post.metricas_contenido_original) : null,
        metricas_raw_contenido_original: post.metricas_raw_contenido_original
            ? metricObject(post.metricas_raw_contenido_original, true)
            : null,
        metricas_origen: text(post.metricas_origen, 80),
        metricas_fuente_detalle: post.metricas_fuente_detalle && typeof post.metricas_fuente_detalle === 'object'
            ? Object.fromEntries(Object.entries(post.metricas_fuente_detalle)
                .filter(([key]) => /^[A-Za-z0-9_]{1,80}$/.test(key))
                .map(([key, value]) => [key, value === null || value === undefined ? null : text(String(value), 160)]))
            : {},
        type: normalizedType,
        in_reply_to_status_id: text(post.in_reply_to_status_id, 32),
        in_reply_to_user_id: text(post.in_reply_to_user_id, 32),
        in_reply_to_username: text(post.in_reply_to_username, 40),
        conversation_id: text(post.conversation_id, 32),
        target_account_username: text(post.target_account_username, 40),
        reposter_username: text(post.reposter_username, 40),
        original_author_username: text(post.original_author_username, 40),
        cuenta_que_republica: text(post.cuenta_que_republica, 40),
        autor_original: text(post.autor_original, 40),
        es_publicacion_propia: bool(post.es_publicacion_propia),
        es_repost_externo: bool(post.es_repost_externo),
        metricas_atribuibles_cuenta: bool(post.metricas_atribuibles_cuenta),
        is_quote: bool(post.is_quote),
        is_retweet: bool(post.is_retweet),
        is_article: bool(post.is_article),
        media_count: count(post.media_count),
        media_types: text(post.media_types, 80),
        media_type: text(post.media_type, 80),
        media_urls: text(post.media_urls, 20000),
        media_alt_texts: text(post.media_alt_texts, 12000),
        source: text(post.source, 300),
        hashtags: text(post.hashtags, 5000),
        urls: text(post.urls, 12000),
        article_title: text(post.article_title, 2000),
        article_url: text(post.article_url, 1000),
        article_text: text(post.article_text, 25000)
    };
}

// Listen for messages from the MAIN-world interceptor
window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.type === '__XPORTER_QUERYID__') {
        // Strict validation before relaying to the SW (defense in depth —
        // any page script can postMessage; drop anything unexpected silently).
        const { queryId, operationName } = event.data;
        const requestTemplate = sanitizeGraphqlTemplate(event.data.requestTemplate);
        if (typeof operationName !== 'string' || !RELAY_TRACKED_OPERATIONS.has(operationName)) return;
        if (typeof queryId !== 'string' || !RELAY_QUERYID_PATTERN.test(queryId)) return;
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) return;
        chrome.runtime.sendMessage({
            type: 'DISCOVERED_QUERYID',
            queryId: queryId,
            operationName: operationName,
            requestTemplate
        }).catch(() => { });
    }
    if (event.data?.type === '__XPORTER_GRAPHQL_RESPONSE__') {
        const { operationName, bodyText } = event.data;
        if (typeof operationName !== 'string' || !RELAY_TRACKED_OPERATIONS.has(operationName)) return;
        // Cap relayed body size — oversized payloads are dropped, not truncated.
        if (typeof bodyText !== 'string' || bodyText.length > RELAY_MAX_BODY_CHARS) return;
        const status = Number(event.data.status);
        if (!Number.isInteger(status) || status < 100 || status > 599) return;
        if (typeof event.data.url !== 'string' || !event.data.url.includes('/i/api/graphql/')) return;
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) return;
        chrome.runtime.sendMessage({
            type: 'PAGE_GRAPHQL_RESPONSE',
            operationName: operationName,
            url: event.data.url,
            status: status,
            bodyText: bodyText
        }).catch(() => { });
    }
    if (event.data?.type === '__XPORTER_SEEN_POSTS__') {
        const { operationName, posts } = event.data;
        if (typeof operationName !== 'string' ||
            !/^[A-Za-z0-9_]{1,80}$/.test(operationName) ||
            !RELAY_POST_OPERATION_PATTERN.test(operationName)) return;
        if (!Array.isArray(posts) || posts.length === 0 || posts.length > RELAY_MAX_SEEN_POSTS) return;
        if (!posts.every(post => (
            post && typeof post === 'object' &&
            RELAY_POST_ID_PATTERN.test(String(post.id || '')) &&
            typeof post.text === 'string' &&
            post.text.length <= 25000
        ))) return;
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) return;
        chrome.runtime.sendMessage({
            type: 'CAPTURE_FEED_POSTS',
            operationName,
            posts: posts.map(sanitizeSeenPost)
        }).catch(() => { });
    }
});

function ensureXporterCaptureOverlay() {
    let overlay = document.getElementById('xporter-capture-overlay');
    if (overlay) return overlay;

    overlay = document.createElement('div');
    overlay.id = 'xporter-capture-overlay';
    overlay.innerHTML = `
        <button class="xporter-capture-toggle" type="button" aria-label="Collapse XPorter status">−</button>
        <div class="xporter-capture-title">XPorter date range export</div>
        <div class="xporter-capture-subtitle" data-xporter-subtitle>Preparing search page...</div>
        <div class="xporter-capture-bar"><span data-xporter-bar></span></div>
        <div class="xporter-capture-meta">
            <span data-xporter-count>0 posts collected</span>
            <span class="xporter-capture-meta-right">
                <span class="xporter-capture-pct" data-xporter-pct></span>
                <span class="xporter-capture-range" data-xporter-range></span>
            </span>
        </div>
        <div class="xporter-capture-limit" data-xporter-limit>No post limit</div>
        <div class="xporter-capture-note">Keep this tab open. XPorter is scrolling it to collect posts.</div>
        <button class="xporter-capture-stop" type="button" data-xporter-stop>Stop export</button>
    `;

    const style = document.createElement('style');
    style.id = 'xporter-capture-overlay-style';
    style.textContent = `
        #xporter-capture-overlay {
            position: fixed;
            left: 50%;
            top: 112px;
            z-index: 2147483647;
            box-sizing: border-box;
            width: min(560px, calc(100vw - 32px));
            transform: translateX(-50%);
            padding: 14px 16px;
            border: 1px solid rgba(96, 184, 255, 0.28);
            border-radius: 14px;
            background: linear-gradient(150deg, rgba(13, 21, 34, 0.97), rgba(28, 39, 69, 0.97));
            color: #fff;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), 0 2px 8px rgba(0, 0, 0, 0.35);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            pointer-events: auto;
            transition: width 0.2s ease, top 0.2s ease, right 0.2s ease, bottom 0.2s ease, left 0.2s ease, transform 0.2s ease;
        }
        #xporter-capture-overlay .xporter-capture-toggle {
            position: absolute;
            top: 10px;
            right: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            border: 1px solid rgba(255, 255, 255, 0.24);
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.9);
            cursor: pointer;
            font: inherit;
            font-size: 15px;
            line-height: 1;
        }
        #xporter-capture-overlay .xporter-capture-title {
            padding-right: 28px;
            font-size: 15px;
            font-weight: 750;
            line-height: 1.25;
        }
        #xporter-capture-overlay .xporter-capture-subtitle,
        #xporter-capture-overlay .xporter-capture-note,
        #xporter-capture-overlay .xporter-capture-limit {
            margin-top: 4px;
            color: rgba(255, 255, 255, 0.78);
            font-size: 12px;
            line-height: 1.35;
        }
        #xporter-capture-overlay .xporter-capture-bar {
            height: 7px;
            margin-top: 10px;
            overflow: hidden;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.16);
        }
        #xporter-capture-overlay .xporter-capture-bar span {
            display: block;
            width: 42%;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(90deg, #60B8FF, #00BA7C);
            animation: xporter-capture-bar-sweep 1.35s ease-in-out infinite alternate;
        }
        /* Determinate mode: real progress is known — freeze the sweep and
           show a width-driven fill instead. */
        #xporter-capture-overlay.xporter-capture-determinate .xporter-capture-bar span {
            animation: none;
            transform: none;
            transition: width 0.35s ease;
        }
        /* Paused on a rate limit: amber fill, no motion. */
        #xporter-capture-overlay.xporter-capture-paused .xporter-capture-bar span {
            animation: none;
            background: linear-gradient(90deg, #FFD400, #FFAD1F);
        }
        /* ≥95% of the date range collected: the rest is almost certainly a
           posting gap — say so, and flip Stop into an inviting green finish. */
        #xporter-capture-overlay.xporter-capture-almost .xporter-capture-subtitle {
            color: #34D399;
            font-weight: 650;
        }
        #xporter-capture-overlay.xporter-capture-almost .xporter-capture-stop {
            border-color: rgba(0, 186, 124, 0.65);
            background: rgba(0, 186, 124, 0.14);
            color: #34D399;
            animation: xporter-capture-stop-pulse 1.8s ease-out infinite;
        }
        @keyframes xporter-capture-stop-pulse {
            0% { box-shadow: 0 0 0 0 rgba(0, 186, 124, 0.35); }
            70% { box-shadow: 0 0 0 8px rgba(0, 186, 124, 0); }
            100% { box-shadow: 0 0 0 0 rgba(0, 186, 124, 0); }
        }
        @keyframes xporter-capture-bar-sweep {
            from { transform: translateX(-75%); }
            to { transform: translateX(220%); }
        }
        #xporter-capture-overlay .xporter-capture-meta {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-top: 8px;
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            font-weight: 650;
        }
        #xporter-capture-overlay .xporter-capture-meta-right {
            display: inline-flex;
            gap: 10px;
            align-items: baseline;
        }
        #xporter-capture-overlay .xporter-capture-pct {
            color: #7CD4A8;
            font-variant-numeric: tabular-nums;
        }
        #xporter-capture-overlay.xporter-capture-paused .xporter-capture-pct,
        #xporter-capture-overlay.xporter-capture-paused [data-xporter-subtitle] {
            color: #FFD400;
        }
        #xporter-capture-overlay .xporter-capture-stop {
            display: block;
            box-sizing: border-box;
            width: 100%;
            margin-top: 12px;
            padding: 8px 12px;
            border: 1px solid rgba(244, 33, 46, 0.55);
            border-radius: 9px;
            background: rgba(244, 33, 46, 0.14);
            color: #FF6B72;
            cursor: pointer;
            font: inherit;
            font-size: 13px;
            font-weight: 700;
            line-height: 1.2;
            transition: background 0.15s ease, color 0.15s ease;
        }
        #xporter-capture-overlay .xporter-capture-stop:hover {
            background: rgba(244, 33, 46, 0.28);
            color: #fff;
        }
        #xporter-capture-overlay .xporter-capture-stop:disabled {
            cursor: default;
            opacity: 0.6;
        }
        #xporter-capture-overlay.xporter-capture-collapsed {
            left: auto;
            top: auto;
            right: 22px;
            bottom: 88px;
            width: min(260px, calc(100vw - 32px));
            transform: none;
            padding: 12px 44px 12px 14px;
        }
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-subtitle,
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-bar,
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-range,
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-limit,
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-note,
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-stop {
            display: none;
        }
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-title {
            padding-right: 0;
            font-size: 13px;
        }
        #xporter-capture-overlay.xporter-capture-collapsed .xporter-capture-meta {
            margin-top: 4px;
        }
    `;

    document.documentElement.appendChild(style);
    document.documentElement.appendChild(overlay);

    overlay.querySelector('.xporter-capture-toggle').addEventListener('click', () => {
        const collapsed = overlay.classList.toggle('xporter-capture-collapsed');
        const button = overlay.querySelector('.xporter-capture-toggle');
        const i = overlay._xporterI18n || {};
        button.textContent = collapsed ? '+' : '−';
        button.setAttribute('aria-label', collapsed
            ? (i.expand || 'Expand XPorter status')
            : (i.collapse || 'Collapse XPorter status'));
    });

    overlay.querySelector('[data-xporter-stop]').addEventListener('click', (event) => {
        const button = event.currentTarget;
        const i = overlay._xporterI18n || {};
        button.disabled = true;
        button.textContent = i.stopping || 'Stopping…';
        if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
            chrome.runtime.sendMessage({ type: 'STOP_EXPORT' }).catch(() => { });
        }
    });

    return overlay;
}

const CAPTURE_POST_LABELS = {
    en: {
        postsCollected: { one: 'post collected', other: 'posts collected' },
        postsUnit: { one: 'post', other: 'posts' }
    },
    ru: {
        postsCollected: { one: 'пост собран', few: 'поста собрано', many: 'постов собрано', other: 'поста собрано' },
        postsUnit: { one: 'пост', few: 'поста', many: 'постов', other: 'поста' }
    },
    ar: {
        postsCollected: { zero: 'منشورات تم جمعها', one: 'منشور تم جمعه', two: 'منشوران تم جمعهما', few: 'منشورات تم جمعها', many: 'منشورًا تم جمعه', other: 'منشور تم جمعه' },
        postsUnit: { zero: 'منشورات', one: 'منشور', two: 'منشوران', few: 'منشورات', many: 'منشورًا', other: 'منشور' }
    },
    de: {
        postsCollected: { one: 'Beitrag gesammelt', other: 'Beiträge gesammelt' },
        postsUnit: { one: 'Beitrag', other: 'Beiträge' }
    },
    es: {
        postsCollected: { one: 'publicación recopilada', other: 'publicaciones recopiladas' },
        postsUnit: { one: 'publicación', other: 'publicaciones' }
    },
    fr: {
        postsCollected: { one: 'publication collectée', other: 'publications collectées' },
        postsUnit: { one: 'publication', other: 'publications' }
    },
    it: {
        postsCollected: { one: 'post raccolto', other: 'post raccolti' },
        postsUnit: { one: 'post', other: 'post' }
    },
    pt: {
        postsCollected: { one: 'publicação coletada', other: 'publicações coletadas' },
        postsUnit: { one: 'publicação', other: 'publicações' }
    },
    tr: {
        postsCollected: { other: 'gönderi toplandı' },
        postsUnit: { other: 'gönderi' }
    },
    id: {
        postsCollected: { other: 'postingan terkumpul' },
        postsUnit: { other: 'postingan' }
    },
    hi: {
        postsCollected: { other: 'पोस्ट एकत्रित' },
        postsUnit: { other: 'पोस्ट' }
    },
    ja: {
        postsCollected: { other: '件のポスト取得済み' },
        postsUnit: { other: '件のポスト' }
    },
    ko: {
        postsCollected: { other: '개 게시물 수집됨' },
        postsUnit: { other: '개 게시물' }
    },
    zh: {
        postsCollected: { other: '条帖子已收集' },
        postsUnit: { other: '条帖子' }
    }
};

function capturePluralLabel(key, count, i) {
    const lang = String(i.lang || 'en').toLowerCase().split('-')[0];
    const forms = CAPTURE_POST_LABELS[lang]?.[key] || CAPTURE_POST_LABELS.en[key];
    let category = (Number(count) === 1) ? 'one' : 'other';
    try {
        category = new Intl.PluralRules(lang).select(Math.abs(Number(count) || 0));
    } catch (_) { /* keep simple fallback */ }
    return forms?.[category] || forms?.other || i[key] || i.posts || 'posts';
}

function updateXporterCaptureOverlay(status) {
    const overlay = ensureXporterCaptureOverlay();
    const i = status.i18n || {};
    overlay._xporterI18n = i;
    if (i.lang) overlay.setAttribute('lang', i.lang);
    if (i.dir) overlay.setAttribute('dir', i.dir);
    const count = Number(status.tweetCount || 0);
    const limit = Number(status.quantityLimit || 0);
    const range = [status.dateFrom, status.dateTo].filter(Boolean).join(' → ');
    const locale = i.lang || undefined;
    const postsWord = capturePluralLabel('postsUnit', limit, i);
    const limitText = limit > 0
        ? `${i.limitLabel || 'Limit:'} ${limit.toLocaleString(locale)} ${postsWord}`
        : (i.noLimit || 'No post limit');

    // Localize static labels once translations arrive.
    if (status.i18n) {
        const titleEl = overlay.querySelector('.xporter-capture-title');
        if (titleEl && i.title) titleEl.textContent = i.title;
        const noteEl = overlay.querySelector('.xporter-capture-note');
        if (noteEl && i.note) noteEl.textContent = i.note;
        const toggle = overlay.querySelector('.xporter-capture-toggle');
        if (toggle) {
            const collapsed = overlay.classList.contains('xporter-capture-collapsed');
            toggle.setAttribute('aria-label', collapsed
                ? (i.expand || 'Expand XPorter status')
                : (i.collapse || 'Collapse XPorter status'));
        }
    }

    overlay.querySelector('[data-xporter-count]').textContent =
        `${count.toLocaleString(locale)} ${capturePluralLabel('postsCollected', count, i)}`;
    overlay.querySelector('[data-xporter-range]').textContent = range;
    overlay.querySelector('[data-xporter-limit]').textContent = limitText;

    // Stop button label (unless a click already put it into "Stopping…").
    const stopBtn = overlay.querySelector('[data-xporter-stop]');
    if (stopBtn && !stopBtn.disabled) stopBtn.textContent = i.stop || 'Stop export';

    // Real progress when the SW can compute it (quantity limit and/or how far
    // back into the date range we've collected); sweeping bar otherwise.
    // NB: null must stay indeterminate — Number(null) is 0, so gate on != null.
    const pct = (status.progressPct != null) ? Number(status.progressPct) : NaN;
    const barFill = overlay.querySelector('[data-xporter-bar]');
    const pctEl = overlay.querySelector('[data-xporter-pct]');
    if (Number.isFinite(pct) && pct >= 0) {
        overlay.classList.add('xporter-capture-determinate');
        const clamped = Math.max(0, Math.min(100, pct));
        // Never a fully empty track while running — keep a visible sliver.
        if (barFill) barFill.style.width = Math.max(2, clamped) + '%';
        if (pctEl) pctEl.textContent = Math.round(clamped) + '%';
    } else {
        overlay.classList.remove('xporter-capture-determinate');
        if (barFill) barFill.style.width = '';
        if (pctEl) pctEl.textContent = '';
    }

    // Rate-limit pause: live countdown in the subtitle until `pauseUntil`.
    const subtitleEl = overlay.querySelector('[data-xporter-subtitle]');
    if (overlay._xporterPauseTicker) {
        clearInterval(overlay._xporterPauseTicker);
        overlay._xporterPauseTicker = null;
    }
    const pauseUntil = Number(status.pauseUntil);
    if (Number.isFinite(pauseUntil) && pauseUntil > Date.now()) {
        overlay.classList.add('xporter-capture-paused');
        overlay.classList.remove('xporter-capture-almost');
        const renderPause = () => {
            const remaining = Math.max(0, Math.ceil((pauseUntil - Date.now()) / 1000));
            subtitleEl.textContent = `${i.rateLimited || 'X rate limit — retrying in'} ` +
                `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`;
            if (remaining <= 0 && overlay._xporterPauseTicker) {
                clearInterval(overlay._xporterPauseTicker);
                overlay._xporterPauseTicker = null;
            }
        };
        renderPause();
        overlay._xporterPauseTicker = setInterval(renderPause, 1000);
    } else {
        overlay.classList.remove('xporter-capture-paused');
        // Near the end of the date window the honest message is "that's
        // probably all of them" — not another phase line that suggests more
        // posts are coming.
        if (status.almostDone) {
            overlay.classList.add('xporter-capture-almost');
            subtitleEl.textContent = i.almostDone
                || "Looks like that's all the posts in this range — you can stop the export";
        } else {
            overlay.classList.remove('xporter-capture-almost');
            subtitleEl.textContent = status.phase || i.preparingPage || 'Preparing search page...';
        }
    }
}

// "Retry" button labels across the major X UI locales
// (compared against trimmed, lowercased button text).
const RETRY_BUTTON_LABELS = new Set([
    'retry', 'try again',               // en
    'повторить', 'повторить попытку',   // ru
    'إعادة المحاولة',                    // ar
    'erneut versuchen',                 // de
    'reintentar', 'intentar de nuevo',  // es
    'réessayer',                        // fr
    'riprova',                          // it
    'tentar novamente',                 // pt
    'tekrar dene',                      // tr
    'coba lagi',                        // id
    'पुनः प्रयास करें',                    // hi
    '再試行', '再試行する',               // ja
    '다시 시도', '다시 시도하기',          // ko
    '重试', '重試'                       // zh
]);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'XPORTER_SEARCH_CAPTURE_STATUS') {
        try {
            updateXporterCaptureOverlay(message);
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ error: error.message });
        }
        return true;
    }

    if (message?.type === 'XPORTER_SCROLL_SEARCH_PAGE') {
        try {
            // Scope to the timeline/main region when present so we never click
            // unrelated buttons elsewhere on the page.
            const scope = document.querySelector('main[role="main"]')
                || document.querySelector('[data-testid="primaryColumn"]')
                || document;
            const retryButton = Array.from(scope.querySelectorAll('button, [role="button"]')).find((button) => {
                const text = (button.textContent || '').trim().toLowerCase();
                return RETRY_BUTTON_LABELS.has(text);
            });
            retryButton?.click();

            const target = Math.max(
                document.documentElement?.scrollHeight || 0,
                document.body?.scrollHeight || 0
            );
            window.scrollTo(0, target);
            sendResponse({ success: true, scrollTop: target });
        } catch (error) {
            sendResponse({ error: error.message });
        }
        return true;
    }

    return false;
});

// ==================== BI UCV: profile scroll capture ====================
// This capture path deliberately lets X load its own timeline requests. The
// extension only scrolls the already-open profile, passively reads the
// successful responses and keeps a DOM fallback for visible cards. This avoids
// replaying private GraphQL requests that may require transient page headers.
let __ucvProfileScrollState = null;
let __ucvFeedOrderById = new Map();
let __ucvNextFeedOrder = 1;

function ucvSleep(ms) {
    return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

function ucvNormalizeSpaces(value) {
    return String(value || '').replace(/[\u00a0\u202f]/g, ' ').replace(/\s+/g, ' ').trim();
}

function ucvParseCompactNumber(value) {
    let text = ucvNormalizeSpaces(value).toLowerCase();
    if (!text) return null;

    const numericMatch = text.match(/-?\d[\d.,\s]*/);
    if (!numericMatch) return null;
    let numeric = numericMatch[0].replace(/\s+/g, '');

    const hasThousandSuffix = /(?:mil|k)\b/i.test(text);
    const hasMillionSuffix = /(?:mill(?:ón|ones)?|m|million(?:s)?)\b/i.test(text);
    let multiplier = hasMillionSuffix ? 1000000 : (hasThousandSuffix ? 1000 : 1);

    const lastComma = numeric.lastIndexOf(',');
    const lastDot = numeric.lastIndexOf('.');
    const lastSep = Math.max(lastComma, lastDot);

    if (lastSep >= 0) {
        const decimals = numeric.length - lastSep - 1;
        const sep = numeric[lastSep];
        const otherSep = sep === ',' ? '.' : ',';
        const hasOther = numeric.includes(otherSep);

        if (multiplier > 1) {
            // Compact values such as "64,1 mil" or "30.2K" use the last
            // separator as decimal punctuation.
            numeric = numeric.replace(new RegExp('\\' + otherSep, 'g'), '');
            numeric = numeric.replace(sep, '.');
        } else if (hasOther) {
            // The last separator is the decimal separator; earlier punctuation
            // is grouping punctuation.
            numeric = numeric.replace(new RegExp('\\' + otherSep, 'g'), '');
            numeric = numeric.replace(sep, '.');
        } else if (decimals === 3) {
            // 4.748 / 9,024 are normally thousands in profile counters.
            numeric = numeric.replace(/[.,]/g, '');
        } else {
            numeric = numeric.replace(sep, '.');
        }
    }

    const parsed = Number(numeric);
    if (!Number.isFinite(parsed) || parsed < 0) return null;
    return Math.round(parsed * multiplier);
}

function ucvFirstText(selector, root = document) {
    const element = root.querySelector(selector);
    return ucvNormalizeSpaces(element?.textContent || element?.innerText || '');
}

function ucvReadProfileInfo() {
    const username = extractUsername() || '';
    const primary = document.querySelector('[data-testid="primaryColumn"]')
        || document.querySelector('main[role="main"]')
        || document;

    const userNameBlock = primary.querySelector('[data-testid="UserName"]');
    const userNameText = ucvNormalizeSpaces(userNameBlock?.innerText || '');
    const name = ucvNormalizeSpaces(
        userNameBlock?.querySelector('span')?.textContent
        || primary.querySelector('h2[role="heading"] span')?.textContent
        || document.title.replace(/\s*\(@?[^)]+\).*$/, '')
        || username
    );

    const followingLink = primary.querySelector(`a[href="/${username}/following"]`)
        || primary.querySelector('a[href$="/following"]');
    const followersLink = primary.querySelector(`a[href="/${username}/verified_followers"]`)
        || primary.querySelector(`a[href="/${username}/followers"]`)
        || primary.querySelector('a[href$="/verified_followers"]')
        || primary.querySelector('a[href$="/followers"]');

    const followingCountRaw = ucvNormalizeSpaces(followingLink?.innerText || followingLink?.textContent || '') || null;
    const followersCountRaw = ucvNormalizeSpaces(followersLink?.innerText || followersLink?.textContent || '') || null;
    const followingCount = ucvParseCompactNumber(followingCountRaw || '');
    const followersCount = ucvParseCompactNumber(followersCountRaw || '');

    // Limit the text window to the top of the profile so post bodies do not
    // accidentally satisfy the "posts/publicaciones" expression.
    const headerText = ucvNormalizeSpaces(primary.innerText || '').slice(0, 1800);
    const postsMatch = headerText.match(/([\d.,]+(?:\s*(?:mil|k|m|mill(?:ón|ones)?))?)\s+(?:posts?|publicaciones|tweets?)\b/i);
    const tweetCountRaw = postsMatch ? ucvNormalizeSpaces(postsMatch[1]) : null;
    const tweetCount = tweetCountRaw ? ucvParseCompactNumber(tweetCountRaw) : null;

    const bio = ucvFirstText('[data-testid="UserDescription"]', primary) || null;
    const location = ucvFirstText('[data-testid="UserLocation"]', primary) || null;
    const joinedText = ucvFirstText('[data-testid="UserJoinDate"]', primary) || null;
    const profileLink = primary.querySelector('[data-testid="UserUrl"] a[href]');
    const profileImage = primary.querySelector('img[src*="profile_images"]');

    return {
        id: null,
        name: name || username,
        screenName: username,
        bio,
        location,
        url: profileLink?.href || null,
        createdAt: joinedText,
        profileImageUrl: profileImage?.src || null,
        isProtected: false,
        isVerified: Boolean(userNameBlock?.querySelector('[data-testid="icon-verified"]')),
        followersCount,
        followersCountRaw,
        followingCount,
        followingCountRaw,
        tweetCount,
        tweetCountRaw,
        listedCount: null,
        likesCount: null,
        mediaCount: null,
        subscriptionsCount: null,
        source: 'PERFIL_X_INTERFAZ_VISIBLE',
        rawUserNameText: userNameText || null
    };
}

function ucvMetricCandidateTexts(element) {
    if (!element) return [];
    return [
        element.getAttribute?.('aria-label'),
        element.getAttribute?.('title'),
        element.textContent,
        element.innerText,
        element.parentElement?.getAttribute?.('aria-label'),
        element.closest?.('[aria-label]')?.getAttribute?.('aria-label')
    ].map(ucvNormalizeSpaces).filter(Boolean);
}

function ucvCountFromElement(element) {
    for (const candidate of ucvMetricCandidateTexts(element)) {
        const parsed = ucvParseCompactNumber(candidate);
        if (parsed !== null) return parsed;
    }
    return null;
}

// X suele agrupar respuestas, reposts, Me gusta, guardados y vistas en una
// misma etiqueta accesible. Para guardados no se puede usar el primer número
// de la cadena porque normalmente pertenece a otra métrica.
function ucvParseBookmarkCount(value) {
    const text = ucvNormalizeSpaces(value);
    if (!text) return null;
    if (/^0(?:[.,]0+)?$/.test(text)) return 0;

    const numberToken = String.raw`(?:\d{1,3}(?:[.\s]\d{3})+|\d+(?:[.,]\d+)?)(?:\s*(?:k|m|b|mil|mill[oó]n(?:es)?))?`;
    const patterns = [
        new RegExp(String.raw`(${numberToken})\s+(?:elemento\s+guardado|elementos\s+guardados)\b`, 'i'),
        new RegExp(String.raw`(${numberToken})\s+(?:guardado|guardados|bookmark|bookmarks)\b`, 'i')
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (!match) continue;
        const parsed = ucvParseCompactNumber(match[1]);
        if (parsed !== null) return parsed;
    }
    return null;
}

function ucvMetricDetailFromArticle(
    article,
    testIds,
    keywordPattern,
    zeroWhenControlIsBlank = false,
    valueParser = ucvParseCompactNumber
) {
    let foundControl = false;
    for (const testId of testIds) {
        const control = article.querySelector(`[data-testid="${testId}"]`);
        if (!control) continue;
        foundControl = true;
        for (const candidate of ucvMetricCandidateTexts(control)) {
            const value = valueParser(candidate);
            if (value !== null) {
                return {
                    value,
                    raw: candidate,
                    identified: true,
                    source: `DATA_TESTID_${String(testId).toUpperCase()}`
                };
            }
        }
    }

    for (const element of article.querySelectorAll('[aria-label]')) {
        const label = ucvNormalizeSpaces(element.getAttribute('aria-label'));
        if (label && keywordPattern.test(label)) {
            const value = valueParser(label);
            if (value !== null) {
                return {
                    value,
                    raw: label,
                    identified: true,
                    source: 'ARIA_LABEL_EXPLICITA'
                };
            }
        }
    }

    if (foundControl && zeroWhenControlIsBlank) {
        return {
            value: 0,
            raw: null,
            identified: true,
            source: 'CONTROL_VISIBLE_SIN_CONTADOR_INTERPRETADO_CERO'
        };
    }
    return { value: null, raw: null, identified: false, source: null };
}

function ucvMetricFromArticle(article, testIds, keywordPattern, zeroWhenControlIsBlank = false) {
    return ucvMetricDetailFromArticle(article, testIds, keywordPattern, zeroWhenControlIsBlank).value;
}

function ucvExtractVisiblePosts() {
    const posts = [];
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    const targetUsername = extractUsername() || '';
    const normalizeUsername = (value) => String(value || '').replace(/^@/, '').trim().toLowerCase();
    const emptyMetrics = () => ({
        view_count: null,
        bookmark_count: null,
        favorite_count: null,
        retweet_count: null,
        reply_count: null,
        quote_count: null
    });

    for (const article of articles) {
        const time = article.querySelector('time[datetime]');
        const timeLink = time?.closest('a[href*="/status/"]');
        const fallbackLink = article.querySelector('a[href*="/status/"]');
        const href = timeLink?.getAttribute('href') || fallbackLink?.getAttribute('href') || '';
        const match = href.match(/^\/([^/]+)\/status\/(\d+)/i)
            || String(timeLink?.href || fallbackLink?.href || '').match(/x\.com\/([^/]+)\/status\/(\d+)/i);
        if (!match) continue;

        const authorUsername = decodeURIComponent(match[1]);
        const id = match[2];
        let feedOrder = __ucvFeedOrderById.get(id);
        if (!feedOrder) {
            feedOrder = __ucvNextFeedOrder++;
            __ucvFeedOrderById.set(id, feedOrder);
        }
        const textElement = article.querySelector('[data-testid="tweetText"]');
        const text = textElement?.innerText || textElement?.textContent || '';
        const userBlock = article.querySelector('[data-testid="User-Name"]');
        const userLines = String(userBlock?.innerText || '').split('\n').map(ucvNormalizeSpaces).filter(Boolean);
        const authorName = userLines.find(line => !line.startsWith('@')) || '';
        const socialContext = ucvNormalizeSpaces(article.querySelector('[data-testid="socialContext"]')?.innerText || '');
        const isPinned = /(?:pinned|fijado|fijada|épinglé|angeheftet|fissato|fixado)/i.test(socialContext);
        const articleText = ucvNormalizeSpaces(article.innerText || '');
        const isRetweet = /(?:reposteó|reposted|retweeted|republicó)/i.test(socialContext);
        const replyMatch = articleText.slice(0, 700).match(/(?:en respuesta a|replying to|respondiendo a)\s+@([A-Za-z0-9_]+)/i);
        const inReplyToUsername = replyMatch?.[1] || '';
        const isReply = Boolean(inReplyToUsername) || /(?:en respuesta a|replying to|respondiendo a)/i.test(articleText.slice(0, 700));
        const type = isRetweet
            ? 'RETWEET'
            : (isReply
                ? (normalizeUsername(inReplyToUsername) && normalizeUsername(inReplyToUsername) === normalizeUsername(authorUsername)
                    ? 'THREAD_REPLY'
                    : 'REPLY')
                : 'TWEET');

        const photoElements = Array.from(article.querySelectorAll('[data-testid="tweetPhoto"] img'));
        const videoElements = Array.from(article.querySelectorAll('video'));
        const photoCount = photoElements.length;
        const videoCount = videoElements.length;
        const mediaTypes = [];
        if (photoCount) mediaTypes.push('photo');
        if (videoCount) mediaTypes.push('video');
        const mediaUrls = [
            ...photoElements.map(element => element.currentSrc || element.src || ''),
            ...videoElements.map(element => element.currentSrc || element.src || element.querySelector('source')?.src || '')
        ].filter(Boolean);
        const expandedUrls = Array.from(article.querySelectorAll('[data-testid="tweetText"] a[href], [data-testid="card.wrapper"] a[href]'))
            .map(element => element.href || '')
            .filter(url => url && !/\/status\/\d+/.test(url));
        const hashtags = Array.from(String(text || '').matchAll(/#([\p{L}\p{N}_]+)/gu)).map(matchItem => matchItem[1]);

        const metricDetails = {
            view_count: ucvMetricDetailFromArticle(article, [], /\b(?:views?|vistas?|visualizaciones?)\b/i),
            bookmark_count: ucvMetricDetailFromArticle(
                article,
                ['bookmark', 'removeBookmark'],
                /\b(?:bookmarks?|guardados?|elementos?\s+guardados?)\b/i,
                false,
                ucvParseBookmarkCount
            ),
            favorite_count: ucvMetricDetailFromArticle(article, ['like', 'unlike'], /\b(?:likes?|me gusta)\b/i, true),
            retweet_count: ucvMetricDetailFromArticle(article, ['retweet', 'unretweet'], /\b(?:reposts?|retweets?|republicaciones?)\b/i, true),
            reply_count: ucvMetricDetailFromArticle(article, ['reply'], /\b(?:replies?|respuestas?|comentarios?)\b/i, true),
            quote_count: { value: null, raw: null, identified: false, source: null }
        };
        const originalMetrics = Object.fromEntries(Object.entries(metricDetails).map(([key, detail]) => [key, detail.value]));
        const originalRawMetrics = Object.fromEntries(Object.entries(metricDetails).map(([key, detail]) => [key, detail.raw]));
        const originalMetricSources = Object.fromEntries(Object.entries(metricDetails).map(([key, detail]) => [key, detail.source]));

        const isExternalRetweet = isRetweet
            && normalizeUsername(authorUsername)
            && normalizeUsername(targetUsername)
            && normalizeUsername(authorUsername) !== normalizeUsername(targetUsername);
        const isOwnPublication = !isExternalRetweet
            && (!targetUsername || normalizeUsername(authorUsername) === normalizeUsername(targetUsername));
        const metricsAttributable = isOwnPublication && !isExternalRetweet;
        const exportedMetrics = isExternalRetweet ? emptyMetrics() : originalMetrics;
        const exportedRawMetrics = isExternalRetweet ? emptyMetrics() : originalRawMetrics;

        posts.push({
            id,
            feed_order: feedOrder,
            text: String(text || '').slice(0, 25000),
            tweet_url: `https://x.com/${authorUsername}/status/${id}`,
            language: article.getAttribute('lang') || textElement?.getAttribute('lang') || '',
            created_at: time?.getAttribute('datetime') || '',
            author_id: '',
            author_name: authorName,
            author_username: authorUsername,
            author_followers_count: null,
            author_verified: Boolean(userBlock?.querySelector('[data-testid="icon-verified"]')),
            ...exportedMetrics,
            metricas_raw: exportedRawMetrics,
            metricas_contenido_original: isExternalRetweet ? originalMetrics : null,
            metricas_raw_contenido_original: isExternalRetweet ? originalRawMetrics : null,
            metricas_origen: 'INTERFAZ_VISIBLE_X',
            metricas_fuente_detalle: originalMetricSources,
            type,
            in_reply_to_status_id: '',
            in_reply_to_user_id: '',
            in_reply_to_username: inReplyToUsername,
            conversation_id: '',
            target_account_username: targetUsername,
            reposter_username: isRetweet ? targetUsername : '',
            original_author_username: isRetweet ? authorUsername : '',
            cuenta_que_republica: isRetweet ? targetUsername : '',
            autor_original: isRetweet ? authorUsername : '',
            es_publicacion_propia: Boolean(isOwnPublication),
            es_repost_externo: Boolean(isExternalRetweet),
            metricas_atribuibles_cuenta: Boolean(metricsAttributable),
            is_quote: false,
            is_retweet: isRetweet,
            is_article: false,
            is_pinned: Boolean(isPinned),
            media_count: photoCount + videoCount,
            media_types: mediaTypes.join(', '),
            media_type: mediaTypes.join(', '),
            media_urls: [...new Set(mediaUrls)].join(', '),
            media_alt_texts: photoElements.map(element => element.alt || '').filter(Boolean).join(' | '),
            source: '',
            hashtags: [...new Set(hashtags)].join(', '),
            urls: [...new Set(expandedUrls)].join(', '),
            article_title: '',
            article_url: '',
            article_text: ''
        });
    }

    return posts;
}

async function ucvCaptureVisiblePosts() {
    const posts = ucvExtractVisiblePosts();
    let total = 0;
    let inserted = 0;
    let updated = 0;

    if (posts.length > 0) {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CAPTURE_FEED_POSTS',
                operationName: 'UserTweetsAndRepliesDOM',
                posts
            });
            total = Number(response?.total || 0);
            inserted = Number(response?.inserted || 0);
            updated = Number(response?.updated || 0);
        } catch (_) { /* extension may be reloading */ }
    }

    if (!total) {
        try {
            const summary = await chrome.runtime.sendMessage({ type: 'GET_FEED_DB_SUMMARY' });
            total = Number(summary?.count || 0);
        } catch (_) { /* best effort */ }
    }

    // Para calcular una ventana temporal no usamos posts fijados ni retweets
    // externos: X muestra la fecha del contenido original y eso podría detener
    // prematuramente una captura reciente. La frontera se basa en publicaciones
    // propias, respuestas propias y continuaciones de hilo.
    const chronologicalDates = posts
        .filter(post => post.es_publicacion_propia === true
            && post.es_repost_externo !== true
            && post.is_pinned !== true)
        .map(post => Date.parse(post.created_at || ''))
        .filter(Number.isFinite);

    return {
        total,
        inserted,
        updated,
        visible: posts.length,
        visibleNewestChronologicalMs: chronologicalDates.length
            ? Math.max(...chronologicalDates)
            : null,
        visibleOldestChronologicalMs: chronologicalDates.length
            ? Math.min(...chronologicalDates)
            : null
    };
}

function ucvClickVisibleRetryButton() {
    const labels = /^(?:retry|try again|reintentar|intentar de nuevo|volver a intentar|повторить|réessayer|riprova|tentar novamente|tekrar dene|coba lagi|再試行|다시 시도|重试)$/i;
    const scope = document.querySelector('[data-testid="primaryColumn"]') || document;
    const button = Array.from(scope.querySelectorAll('button, [role="button"]')).find(element => {
        const text = ucvNormalizeSpaces(element.textContent || element.innerText || '');
        return labels.test(text);
    });
    if (button) {
        button.click();
        return true;
    }
    return false;
}

function ucvProfileTimelineSnapshot() {
    const scrollingElement = document.scrollingElement || document.documentElement || document.body;
    const fallbackHeight = Math.max(
        document.body?.scrollHeight || 0,
        document.documentElement?.scrollHeight || 0
    );
    const pageHeight = Math.max(0, Math.round(scrollingElement?.scrollHeight || fallbackHeight));
    const scrollTop = Math.max(
        0,
        Math.round(scrollingElement?.scrollTop ?? window.scrollY ?? window.pageYOffset ?? 0)
    );
    const viewportHeight = Math.max(1, Math.round(scrollingElement?.clientHeight || window.innerHeight || 1));
    const distanceToBottom = Math.max(0, pageHeight - (scrollTop + viewportHeight));
    return { pageHeight, scrollTop, viewportHeight, distanceToBottom };
}

function ucvElementIsVisible(element) {
    const rect = element?.getBoundingClientRect?.();
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;
    const style = window.getComputedStyle?.(element);
    if (style && (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0)) {
        return false;
    }
    return rect.bottom >= -20 && rect.top <= (window.innerHeight || 0) + 80;
}

function ucvProfileTimelineIsLoading() {
    const scope = document.querySelector('[data-testid="primaryColumn"]')
        || document.querySelector('main[role="main"]')
        || document;

    // X contains many decorative SVG icons. Earlier builds treated an empty
    // aria-label on any visible SVG as a loading indicator, so the end detector
    // could remain blocked forever. Only explicit progress bars or elements
    // whose accessible label actually says "loading" count here.
    const progressBarVisible = Array.from(scope.querySelectorAll('[role="progressbar"]'))
        .some(ucvElementIsVisible);
    if (progressBarVisible) return true;

    const loadingLabel = /(?:loading|cargando|chargement|laden|caricamento|読み込み|加载|載入|carregando)/i;
    return Array.from(scope.querySelectorAll('[aria-label]')).some(element => {
        if (!ucvElementIsVisible(element)) return false;
        const label = ucvNormalizeSpaces(element.getAttribute?.('aria-label') || '');
        return label.length > 0 && loadingLabel.test(label);
    });
}

function ucvProfileTimelineHasExplicitEnd() {
    const scope = document.querySelector('[data-testid="primaryColumn"]')
        || document.querySelector('main[role="main"]')
        || document;
    const text = ucvNormalizeSpaces(scope.innerText || '').slice(-3500);
    return /(?:no more posts|no hay más publicaciones|no hay más posts|you.?re all caught up|estás al día|nothing to see here|no results|sin resultados|no quedan más publicaciones)/i.test(text);
}

function ucvVisibleTimelineFingerprint() {
    const scope = document.querySelector('[data-testid="primaryColumn"]')
        || document.querySelector('main[role="main"]')
        || document;
    const ids = [];
    const seen = new Set();

    for (const article of Array.from(scope.querySelectorAll('article[data-testid="tweet"], article'))) {
        const rect = article.getBoundingClientRect?.();
        if (!rect || rect.bottom < -100 || rect.top > (window.innerHeight || 0) + 250) continue;

        const links = Array.from(article.querySelectorAll('a[href*="/status/"]'));
        for (const link of links) {
            const match = String(link.getAttribute('href') || '').match(/\/status\/(\d+)/);
            const id = match?.[1];
            if (id && !seen.has(id)) {
                seen.add(id);
                ids.push(id);
                break;
            }
        }
    }

    return ids.slice(-8).join('|');
}

async function ucvSendScrollProgress(payload) {
    try {
        await chrome.runtime.sendMessage({
            type: 'UCV_SCROLL_CAPTURE_PROGRESS',
            ...payload
        });
    } catch (_) { /* popup/worker may be reloading */ }
}

const UCV_PERIOD_MONTHS = Object.freeze({
    last_month: 1,
    last_3_months: 3,
    last_year: 12
});

function ucvNormalizeCapturePeriod(value) {
    if (value === 'first_10') return 'first_10';
    return Object.prototype.hasOwnProperty.call(UCV_PERIOD_MONTHS, value)
        ? value
        : 'unlimited';
}

function ucvSubtractUtcCalendarMonths(timestamp, months) {
    const source = new Date(Number(timestamp));
    if (!Number.isFinite(source.getTime())) return null;
    const day = source.getUTCDate();
    const target = new Date(source.getTime());
    target.setUTCDate(1);
    target.setUTCMonth(target.getUTCMonth() - months);
    const lastDay = new Date(Date.UTC(
        target.getUTCFullYear(),
        target.getUTCMonth() + 1,
        0,
        source.getUTCHours(),
        source.getUTCMinutes(),
        source.getUTCSeconds(),
        source.getUTCMilliseconds()
    )).getUTCDate();
    target.setUTCDate(Math.min(day, lastDay));
    target.setUTCHours(
        source.getUTCHours(),
        source.getUTCMinutes(),
        source.getUTCSeconds(),
        source.getUTCMilliseconds()
    );
    return target.getTime();
}

function ucvUtcDayStart(timestamp) {
    if (timestamp === null || timestamp === undefined || timestamp === '') return null;
    const date = new Date(Number(timestamp));
    if (!Number.isFinite(date.getTime())) return null;
    return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
}

async function ucvRunProfileScrollCapture(options = {}) {
    const state = __ucvProfileScrollState;
    if (!state) return;

    const batchSize = Math.max(10, Number(options.batchSize) || 50);
    const batchPauseMs = Math.max(1000, Number(options.batchPauseMs) || 4000);
    const scrollDelayMs = Math.max(700, Number(options.scrollDelayMs) || 1400);
    const stagnantProbeLimit = Math.max(8, Number(options.stagnantProbeLimit) || 12);
    const endConfirmationLimit = Math.max(2, Number(options.endConfirmationLimit) || 3);
    const recoveryPauseMs = Math.max(3500, Number(options.recoveryPauseMs) || 6000);
    const endStableMs = Math.max(20000, Number(options.endStableMs) || 30000);
    const hardEndIdleMs = Math.max(endStableMs, Number(options.hardEndIdleMs) || 55000);
    const quantityLimit = Math.max(0, Number(options.quantityLimit) || 0);
    const capturePeriod = ucvNormalizeCapturePeriod(options.capturePeriod);
    const capturePeriodMonths = UCV_PERIOD_MONTHS[capturePeriod] || 0;
    const stepRatio = Math.min(0.95, Math.max(0.55, Number(options.stepRatio) || 0.82));
    const startFromTop = options.startFromTop !== false;

    let lastTotal = 0;
    let stagnantCycles = 0;
    let endConfirmations = 0;
    let lastPausedBucket = 0;
    let cycles = 0;
    let finishReason = 'END_REACHED';
    let previousProbeHeight = 0;
    let previousProbeScrollTop = -1;
    let previousProbeFingerprint = '';
    let lastNewPostAt = Date.now();
    let bottomCandidateStartedAt = 0;
    let periodReferenceDateMs = Number(options.periodReferenceDateMs || 0) || null;
    let periodCutoffDateMs = Number(options.periodCutoffDateMs || 0) || null;
    let periodFrontierDateMs = Number(options.periodFrontierDateMs || 0) || null;
    let periodReached = false;

    try {
        // Fresh exports start at the top. Resume keeps the exact current page
        // position and the IndexedDB contents so it continues where it stopped.
        if (startFromTop) {
            __ucvFeedOrderById = new Map();
            __ucvNextFeedOrder = 1;
            window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
            await ucvSleep(900);
        } else {
            await ucvSleep(350);
        }

        const initialCapture = await ucvCaptureVisiblePosts();
        lastTotal = Number(initialCapture.total || 0);
        lastPausedBucket = Math.floor(lastTotal / batchSize);
        if (capturePeriodMonths > 0) {
            const initialNewest = Number(initialCapture.visibleNewestChronologicalMs || 0) || null;
            const initialOldest = Number(initialCapture.visibleOldestChronologicalMs || 0) || null;
            if (initialNewest && (!periodReferenceDateMs || initialNewest > periodReferenceDateMs)) {
                periodReferenceDateMs = initialNewest;
                periodCutoffDateMs = ucvUtcDayStart(ucvSubtractUtcCalendarMonths(periodReferenceDateMs, capturePeriodMonths));
            }
            if (initialOldest && (!periodFrontierDateMs || initialOldest < periodFrontierDateMs)) {
                periodFrontierDateMs = initialOldest;
            }
        }
        await ucvSendScrollProgress({
            total: lastTotal,
            cycles,
            stagnantCycles,
            endConfirmations,
            autoWaiting: false,
            capturePeriod,
            periodReferenceDateMs,
            periodCutoffDateMs,
            periodFrontierDateMs,
            ...ucvProfileTimelineSnapshot()
        });

        while (state.running && cycles < 25000) {
            cycles += 1;
            const retryClicked = ucvClickVisibleRetryButton();

            const captured = await ucvCaptureVisiblePosts();
            const total = Number(captured.total || 0);
            if (capturePeriodMonths > 0) {
                const visibleNewest = Number(captured.visibleNewestChronologicalMs || 0) || null;
                const visibleOldest = Number(captured.visibleOldestChronologicalMs || 0) || null;
                if (visibleNewest && (!periodReferenceDateMs || visibleNewest > periodReferenceDateMs)) {
                    periodReferenceDateMs = visibleNewest;
                    periodCutoffDateMs = ucvUtcDayStart(ucvSubtractUtcCalendarMonths(periodReferenceDateMs, capturePeriodMonths));
                }
                if (visibleOldest && (!periodFrontierDateMs || visibleOldest < periodFrontierDateMs)) {
                    periodFrontierDateMs = visibleOldest;
                }
                const cutoffDayStart = ucvUtcDayStart(periodCutoffDateMs);
                const frontierDayStart = ucvUtcDayStart(periodFrontierDateMs);
                // El día límite se incluye completo. La captura se detiene al
                // confirmar una publicación de un día anterior.
                periodReached = Boolean(
                    cutoffDayStart !== null
                    && frontierDayStart !== null
                    && frontierDayStart < cutoffDayStart
                );
            }
            if (total > lastTotal) {
                stagnantCycles = 0;
                endConfirmations = 0;
                previousProbeHeight = 0;
                previousProbeScrollTop = -1;
                previousProbeFingerprint = '';
                bottomCandidateStartedAt = 0;
                lastNewPostAt = Date.now();
                lastTotal = total;
            } else {
                stagnantCycles += 1;
            }

            const snapshot = ucvProfileTimelineSnapshot();
            await ucvSendScrollProgress({
                total,
                cycles,
                stagnantCycles,
                endConfirmations,
                autoWaiting: false,
                retryClicked,
                capturePeriod,
                periodReferenceDateMs,
                periodCutoffDateMs,
                periodFrontierDateMs,
                ...snapshot
            });

            if (periodReached) {
                finishReason = 'DATE_WINDOW_REACHED';
                break;
            }

            if (quantityLimit > 0 && total >= quantityLimit) {
                finishReason = capturePeriod === 'first_10'
                    ? 'FIRST_10_REACHED'
                    : 'QUANTITY_LIMIT';
                break;
            }

            // Normal pacing pause. This is automatic: the user never needs to
            // press Resume after each batch.
            const completedBucket = Math.floor(total / batchSize);
            if (completedBucket > lastPausedBucket && total > 0) {
                lastPausedBucket = completedBucket;
                const pauseUntil = Date.now() + batchPauseMs;
                await ucvSendScrollProgress({
                    total,
                    cycles,
                    stagnantCycles,
                    endConfirmations,
                    autoWaiting: true,
                    pauseReason: 'BATCH_PAUSE',
                    pauseUntil,
                    capturePeriod,
                    periodReferenceDateMs,
                    periodCutoffDateMs,
                    periodFrontierDateMs,
                    ...ucvProfileTimelineSnapshot()
                });
                await ucvSleep(batchPauseMs);
                if (!state.running) break;
            }

            // A temporary X loading gap must not terminate the export. After a
            // short stagnant window, verify the bottom repeatedly. Completion is
            // automatic when the same bottom remains visible, no new unique IDs
            // arrive and X is no longer actively loading.
            if (stagnantCycles >= stagnantProbeLimit) {
                const probe = ucvProfileTimelineSnapshot();
                const fingerprint = ucvVisibleTimelineFingerprint();
                const bottomTolerance = Math.max(160, Math.round(probe.viewportHeight * 0.24));
                const geometryTolerance = Math.max(24, Math.round(probe.viewportHeight * 0.035));
                const atBottom = probe.distanceToBottom <= bottomTolerance;
                const heightStable = previousProbeHeight > 0
                    && Math.abs(probe.pageHeight - previousProbeHeight) <= geometryTolerance;
                const positionStable = previousProbeScrollTop >= 0
                    && Math.abs(probe.scrollTop - previousProbeScrollTop) <= geometryTolerance;
                const fingerprintStable = Boolean(
                    fingerprint
                    && previousProbeFingerprint
                    && fingerprint === previousProbeFingerprint
                );
                const loading = ucvProfileTimelineIsLoading();
                const explicitEnd = ucvProfileTimelineHasExplicitEnd();
                const now = Date.now();
                const idleMs = now - lastNewPostAt;
                const bottomCandidate = explicitEnd || (atBottom && !retryClicked);

                if (bottomCandidate) {
                    if (!bottomCandidateStartedAt) bottomCandidateStartedAt = now;
                } else {
                    bottomCandidateStartedAt = 0;
                    endConfirmations = 0;
                }

                const bottomStableMs = bottomCandidateStartedAt ? now - bottomCandidateStartedAt : 0;
                const verifiedStableBottom = bottomCandidate
                    && !loading
                    && idleMs >= endStableMs
                    && bottomStableMs >= endStableMs
                    && (positionStable || fingerprintStable || heightStable);

                if (explicitEnd) {
                    endConfirmations = endConfirmationLimit;
                } else if (verifiedStableBottom) {
                    endConfirmations += 1;
                } else if (!bottomCandidate || loading) {
                    endConfirmations = 0;
                }

                previousProbeHeight = probe.pageHeight;
                previousProbeScrollTop = probe.scrollTop;
                previousProbeFingerprint = fingerprint;

                const hardStableEnd = bottomCandidate
                    && !loading
                    && idleMs >= hardEndIdleMs
                    && bottomStableMs >= hardEndIdleMs
                    && (positionStable || fingerprintStable);

                if (explicitEnd || endConfirmations >= endConfirmationLimit || hardStableEnd) {
                    finishReason = 'END_REACHED';
                    break;
                }

                const pauseUntil = Date.now() + recoveryPauseMs;
                await ucvSendScrollProgress({
                    total,
                    cycles,
                    stagnantCycles,
                    endConfirmations,
                    endConfirmationLimit,
                    autoWaiting: true,
                    pauseReason: 'VERIFYING_END',
                    pauseUntil,
                    loading,
                    explicitEnd,
                    atBottom,
                    idleMs,
                    bottomStableMs,
                    fingerprintStable,
                    capturePeriod,
                    periodReferenceDateMs,
                    periodCutoffDateMs,
                    periodFrontierDateMs,
                    ...probe
                });
                await ucvSleep(recoveryPauseMs);
                if (!state.running) break;

                // Recovery nudge: move slightly upward and return to the real
                // bottom. This re-triggers X's timeline sentinel without losing
                // the current position or restarting at the profile header.
                ucvClickVisibleRetryButton();
                const nudge = Math.max(320, Math.round(window.innerHeight * 0.38));
                window.scrollBy({ top: -nudge, left: 0, behavior: 'auto' });
                await ucvSleep(650);
                const bottom = Math.max(
                    document.body?.scrollHeight || 0,
                    document.documentElement?.scrollHeight || 0
                );
                window.scrollTo({ top: bottom, left: 0, behavior: 'auto' });
                await ucvSleep(Math.max(1800, scrollDelayMs));

                const recoveryCapture = await ucvCaptureVisiblePosts();
                const recoveredTotal = Number(recoveryCapture.total || 0);
                if (recoveredTotal > lastTotal) {
                    lastTotal = recoveredTotal;
                    lastNewPostAt = Date.now();
                    endConfirmations = 0;
                    previousProbeHeight = 0;
                    previousProbeScrollTop = -1;
                    previousProbeFingerprint = '';
                    bottomCandidateStartedAt = 0;
                    stagnantCycles = 0;
                } else if (bottomCandidate) {
                    // Stay in end-verification mode. The next check happens
                    // quickly instead of waiting through another full scroll
                    // window, while still allowing X time to append more rows.
                    stagnantCycles = stagnantProbeLimit;
                } else {
                    stagnantCycles = 0;
                }
                continue;
            }

            const before = ucvProfileTimelineSnapshot();
            const step = Math.max(500, Math.floor(window.innerHeight * stepRatio));
            window.scrollBy({ top: step, left: 0, behavior: 'auto' });
            await ucvSleep(scrollDelayMs);

            // At a temporarily fixed bottom, a final nudge helps trigger the
            // next server-loaded group while preserving the current depth.
            const after = ucvProfileTimelineSnapshot();
            if (after.scrollTop === before.scrollTop) {
                window.scrollTo({
                    top: Math.max(document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0),
                    left: 0,
                    behavior: 'auto'
                });
                await ucvSleep(Math.max(900, Math.floor(scrollDelayMs * 0.8)));
            }
        }

        if (!state.running) {
            finishReason = 'STOPPED_BY_USER';
        } else if (cycles >= 25000 && finishReason === 'END_REACHED' && endConfirmations < endConfirmationLimit) {
            finishReason = 'MAX_SCROLL_CYCLES';
        }
        const finalCapture = await ucvCaptureVisiblePosts();
        try {
            await chrome.runtime.sendMessage({
                type: 'UCV_SCROLL_CAPTURE_DONE',
                reason: finishReason,
                total: finalCapture.total,
                cycles,
                stagnantCycles,
                endConfirmations,
                periodReached,
                capturePeriod,
                periodReferenceDateMs,
                periodCutoffDateMs,
                periodFrontierDateMs,
                finalPosition: ucvProfileTimelineSnapshot()
            });
        } catch (_) { /* best effort */ }
    } catch (error) {
        try {
            await chrome.runtime.sendMessage({
                type: 'UCV_SCROLL_CAPTURE_DONE',
                reason: 'ERROR',
                error: error?.message || 'SCROLL_CAPTURE_FAILED',
                total: lastTotal,
                cycles,
                stagnantCycles,
                endConfirmations,
                periodReached,
                capturePeriod,
                periodReferenceDateMs,
                periodCutoffDateMs,
                periodFrontierDateMs
            });
        } catch (_) { /* best effort */ }
    } finally {
        __ucvProfileScrollState = null;
    }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'UCV_READ_X_PROFILE') {
        try {
            sendResponse({ success: true, profile: ucvReadProfileInfo(), path: window.location.pathname });
        } catch (error) {
            sendResponse({ error: error?.message || 'PROFILE_READ_FAILED' });
        }
        return true;
    }

    if (message?.type === 'UCV_START_PROFILE_SCROLL') {
        const expectedUsername = String(message.username || '').replace(/^@/, '').toLowerCase();
        const activeUsername = String(extractUsername() || '').toLowerCase();
        const isRepliesPage = /^\/[a-zA-Z0-9_]{1,15}\/with_replies\/?$/.test(window.location.pathname);

        if (!isRepliesPage) {
            sendResponse({ error: 'OPEN_REPLIES_PAGE' });
            return true;
        }
        if (expectedUsername && activeUsername !== expectedUsername) {
            sendResponse({ error: 'WRONG_PROFILE_OPEN' });
            return true;
        }
        if (__ucvProfileScrollState?.running) {
            sendResponse({ error: 'ALREADY_RUNNING' });
            return true;
        }

        __ucvProfileScrollState = { running: true, startedAt: Date.now() };
        ucvRunProfileScrollCapture(message.options || {});
        sendResponse({ success: true, profile: ucvReadProfileInfo() });
        return true;
    }

    if (message?.type === 'UCV_STOP_PROFILE_SCROLL') {
        if (__ucvProfileScrollState) __ucvProfileScrollState.running = false;
        sendResponse({ success: true });
        return true;
    }

    return false;
});
