# Prueba Facebook 1.5.15

1. Carga la extensión sin empaquetar.
2. Recarga el perfil de Facebook con `Ctrl + Shift + R`.
3. Selecciona `Último mes`.
4. Inicia la exportación sin desplazar manualmente la página.
5. Verifica que se detenga cerca del límite temporal.
6. Descarga el JSON.

## Validaciones esperadas

- `fecha_origen_deteccion` debe mostrar principalmente `AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT`.
- No debe aparecer `AUTHOR_DATE_VISUAL_LINE`.
- Las publicaciones con fechas visibles como `18 de julio`, `18 de junio` o valores relativos deben conservarlas.
- `captura_llego_al_periodo_solicitado` debe ser `true` al superar el límite.
