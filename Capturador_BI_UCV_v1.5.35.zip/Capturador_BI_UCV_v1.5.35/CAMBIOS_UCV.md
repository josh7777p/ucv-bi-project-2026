# Capturador BI UCV 1.5.35

## Protección de navegación en Facebook histórico

- Impide que `Ver más` o `See more` abra notas, publicaciones, multimedia o enlaces externos durante el barrido.
- Mantiene la captura en el perfil original y detiene con un error explícito si Facebook cambia la ruta de forma inesperada.
- Evita clics duplicados sobre el mismo control de expansión.
- Conserva sin cambios los módulos funcionales de X e Instagram.

# Cambios 1.5.34

- Corregido el error `nullableCount is not defined` al leer el perfil de Facebook.
- El normalizador de contadores ahora es compartido por Facebook e Instagram.
- Sin cambios en los recorridos de captura ni en el formato de exportación.


## 1.5.33

- Se habilitó **Capturar las 10 primeras publicaciones** para X y Facebook, además de Instagram.
- X conserva el orden de aparición mediante `feed_order`, detiene el recorrido con `FIRST_10_REACHED` y exporta exactamente diez registros únicos.
- Facebook detiene su recorrido de una sola pasada después de diez tarjetas procesadas y conserva el orden real del feed.
- Los resúmenes JSON de X y Facebook reconocen la captura rápida como completa sin confundirla con el final del perfil ni con una ventana temporal.
- No se modificaron los módulos de captura, almacenamiento ni exportación específicos de Instagram.

# Cambios de Capturador BI UCV 1.5.32

## Cobertura ordenada del grid de Instagram

- Convierte la cola del grid en la fuente principal del orden de captura.
- Usa `Next` como acelerador, pero valida que el shortcode abierto sea el siguiente pendiente de la cola.
- Si el modal salta una tarjeta, abre el permalink esperado antes de procesar otro registro.
- Amplía la cola al desplazarse por el perfil cuando se agotan los enlaces ya cargados.
- Una tarjeta esperada que no pueda abrirse detiene la ejecución como `NAVIGATION_INTERRUPTED`; no se omite silenciosamente.
- Conserva fechas, descripciones, métricas, hashtags, colaboraciones, fijadas y deduplicación multimedia.
- No modifica los componentes funcionales de Facebook ni X.

# Historial anterior — 1.5.31


## Corrección final de publicaciones fijadas en Instagram

- Aísla la detección de `Pinned post icon` a la tarjeta de una sola publicación.
- Antes de ampliar el ámbito del selector, comprueba que el contenedor solo incluya un `shortcode` de publicación.
- Evita que el icono de una tarjeta se propague a publicaciones vecinas de la misma fila o de la fila siguiente.
- Mantiene `Next` como mecanismo principal sin cerrar el modal.
- Conserva clasificación de colaboraciones, menciones, hashtags, métricas y deduplicación multimedia.
- No modifica los componentes funcionales de Facebook ni X.

# Historial anterior — 1.5.30

## Corrección del recorrido de Instagram

- Restaura `Next` como mecanismo principal y mantiene abierto el modal entre publicaciones.
- Conserva la cola del grid únicamente como respaldo cuando `Next` no responde.
- Evita cerrar el modal después de cada registro durante el recorrido normal.
- La opción de diez publicaciones solo se declara completa con `FIRST_10_REACHED` y al menos diez registros exportados.
- Una interrupción antes de alcanzar el período se registra como `NAVIGATION_INTERRUPTED` e `INCOMPLETA`.
- La referencia temporal se obtiene mediante la fecha cronológicamente máxima atribuible a la cuenta; una fijada antigua no domina por su posición.
- Mantiene las correcciones de clasificación de colaboraciones, menciones y deduplicación multimedia de la versión 1.5.29.
- No modifica los módulos funcionales de Facebook ni X.

# Historial anterior — 1.5.29


## Correcciones de calidad del módulo de Instagram

- Registra publicaciones fijadas y usa la fecha máxima de publicaciones no fijadas como referencia inicial del período.
- Recorre primero una cola construida con el grid principal, incluidos los enlaces de colaboraciones, para evitar saltos entre publicaciones fijadas o recientes.
- Distingue publicación propia exclusiva, propia colaborativa y colaboración publicada por otra cuenta.
- Conserva autor original, colaboradores y atribución de métricas como campos separados.
- Evita interpretar dominios de correo, como `gmail.com`, como menciones de Instagram.
- Deduplica variantes de una misma URL multimedia mediante `ig_cache_key` o identificador estable.
- Mantiene intacta la lógica funcional de Facebook y X respecto de la versión 1.5.28.

# Historial anterior — 1.5.28

## Módulo inicial de Instagram 1.5.28

- Se habilita Instagram como tercera plataforma.
- Se agrega la opción **Capturar las 10 primeras publicaciones** para la prueba controlada.
- La captura abre la primera publicación del perfil y navega una por una mediante el control exterior `Next`.
- Se guardan `shortcode`, permalink, fecha exacta, descripción, tipo de contenido, Me gusta y las demás métricas explícitas disponibles.
- Se observan pasivamente las respuestas estructuradas que Instagram ya carga, sin generar solicitudes adicionales.
- Las observaciones repetidas se fusionan por máximo visible y nunca se suman.
- Los períodos de un mes, tres meses, un año y completo quedan disponibles para pruebas posteriores.
- Los archivos funcionales principales de Facebook y X permanecen idénticos a la versión 1.5.27.

## Corrección final de diagnóstico y evidencia métrica

- Se corrige el traslado de `privacyDateLinksFound`, `privacyTooltipAttempts` y `privacyTooltipResolved` desde el content script hasta el JSON.
- Los valores numéricos de `metricas` mantienen la regla de máximo visible y no cambian.
- La evidencia de `metricas_raw` se toma de la misma observación que produjo el máximo.
- Se agregan `metricas_raw_primera_observacion` y `metricas_raw_ultima_observacion` para auditoría.
- Se agregan campos raw dentro de `metricas_observacion` para relacionar primera, máxima y última lectura.
- La captura de Facebook conserva fechas, límite del período, descripciones, IDs y métricas de la v1.5.24.
- Los archivos principales del módulo X permanecen sin cambios.

# Historial anterior de Capturador BI UCV 1.5.24

## Fecha exacta desde el icono de privacidad

- Mantiene el recorrido secuencial y el zoom temporal de 40 %.
- Usa el menú de acciones únicamente para ordenar y delimitar la tarjeta.
- Localiza el icono `Compartido con: ...` y el enlace temporal inmediatamente anterior.
- Reconstruye el texto visible aunque Facebook lo divida en caracteres ofuscados.
- Provoca el tooltip y extrae la fecha completa mediante una expresión estricta.
- Exporta `fecha_visible_raw`, `fecha_tooltip_raw` y `fecha_icono_privacidad` como evidencia.
- Las fechas relativas sin tooltip exacto quedan pendientes y no se cargan al DW.
- Conserva la detención `DATE_CAPTURE_QUALITY_LOW` y el límite automático del período.
- Mantiene sin cambios los archivos principales de X/Twitter.

## Rendimiento incremental de Facebook 1.5.18

- Conserva la estrategia de fechas validada mediante `aria-labelledby`.
- Omite publicaciones sin cambios para evitar fusiones repetidas.
- Reintenta fechas pendientes mediante observación de mutaciones del DOM.
- Revisa al final solo las posiciones con fechas pendientes.
- Aumenta el paso de scroll y reduce pausas de Facebook de forma conservadora.
- No modifica la lógica de X/Twitter.

## Recuperación final y espera de fechas de Facebook 1.5.17

- Se ejecuta un barrido global de los botones `Acciones en esta publicación` antes de extraer cada grupo.
- La fecha se fija en una caché DOM por menú y por tarjeta antes de que Facebook virtualice el contenido.
- Se espera de forma limitada cuando el menú ya existe pero el nodo de `aria-labelledby` aún no ha sido hidratado.
- Los controles duplicados con la misma fecha se consolidan como una sola evidencia; dos fechas diferentes siguen considerándose ambiguas.
- Antes de exportar se realiza una revisión solapada desde el límite temporal hasta el inicio para completar fechas pendientes.
- El paso de scroll de Facebook se reduce para mantener cada encabezado visible durante más ciclos.
- El módulo de X/Twitter permanece sin cambios.


## Corrección modular de fechas de Facebook 1.5.16

- La fecha se obtiene desde el botón `Acciones en esta publicación` y el nodo señalado por `aria-labelledby`.
- La búsqueda asciende hasta el primer contenedor mínimo con una sola publicación.
- Se elimina la dependencia de distancias geométricas para la ruta principal.
- Se conserva `fecha_raw` y se generan los formatos ISO, `YYYY-MM-DD` y `DD/MM/YYYY`.
- X/Twitter no fue modificado.


## Facebook

- La fecha se obtiene primero desde el `aria-labelledby` del control temporal perteneciente a la tarjeta.
- Los IDs de `aria-labelledby` se resuelven contra todo el `document` mediante `document.getElementById`, tal como se comprobó en DevTools con el valor accesible `15 min`.
- La pertenencia a la publicación se valida sobre el control dentro de la tarjeta, aunque el nodo con el texto legible esté fuera de ella.
- Se desactivó la reconstrucción visual por coordenadas como fuente de fecha.
- La fecha queda bloqueada cuando se captura y la revisión final puede completar registros que se guardaron antes de la hidratación del encabezado.
- El período se detiene con dos publicaciones confirmadas anteriores al límite o con una publicación al menos siete días más antigua que el límite.
- Al detener manualmente, la extensión conserva ciclos y posición final cuando la pestaña responde.

## Corrección de integración 1.5.15

- La fuente `AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT` se agregó a la base local, al procesamiento analítico y al exportador JSON.
- En 1.5.14 el content script encontraba textos como `1 h` o `20 h`, pero las capas posteriores los descartaban por no reconocer el nombre de la fuente.
- La nueva fuente se considera directa, confiable y bloqueable, con prioridad superior a `AUTHOR_DATE_ARIA_LABELLEDBY`.
- La base local de Facebook ya se limpia al comenzar una captura nueva; solo se conserva cuando se reanuda explícitamente.

## Conservado

- Identificadores únicos, deduplicación, URLs de referencia y fusión progresiva de métricas.
- El módulo estable de X no fue modificado.
## Corrección de X y período de Facebook 1.5.26

- Se corrige el error `databaseSummary is not defined` en el cierre de X.
- Se corrige la lectura de elementos guardados en etiquetas combinadas de X.
- X incluye completo el día límite del período.
- Facebook calcula el período desde la publicación propia más reciente recuperada, sin cambiar su lógica de extracción aprobada.


## Corrección final 1.5.25

- Se normalizan y exportan las fechas obtenidas por tooltip o por lectura visual del enlace temporal.
- La hora dejó de ser requisito: una publicación con fecha y sin hora permanece apta para el DW.
- El día límite se incluye completo y la captura se detiene únicamente al confirmar publicaciones de días anteriores.
- Se corrigieron los contadores de diagnóstico del icono de privacidad.


## Normalización de fechas de X 1.5.27

- Convierte las fechas válidas de X a ISO 8601 al guardarlas en la base local.
- Conserva el mismo instante en `created_at_ms`.
- No modifica métricas, identificadores, período ni clasificación de publicaciones.
- Mantiene sin cambios los archivos funcionales de Facebook.
