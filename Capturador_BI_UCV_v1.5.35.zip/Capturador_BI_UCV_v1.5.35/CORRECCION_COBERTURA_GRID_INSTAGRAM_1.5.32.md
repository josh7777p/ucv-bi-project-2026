# Corrección de cobertura del grid de Instagram 1.5.32

## Problema corregido

El recorrido nativo del modal podía saltar tarjetas presentes en la cuadrícula del perfil. La captura obtenía diez publicaciones distintas, pero no siempre correspondían a las diez primeras tarjetas del grid.

## Solución

1. Se construye una cola ordenada de shortcodes desde la cuadrícula.
2. El control `Next` intenta abrir el siguiente detalle.
3. El shortcode abierto se compara con el siguiente shortcode pendiente de la cola.
4. Si no coincide, se abre directamente la tarjeta esperada y el elemento saltado no se procesa antes de tiempo.
5. Cuando la cola cargada se agota, el modal se cierra temporalmente, se desplaza el perfil y se anexan únicamente enlaces nuevos.
6. Si una tarjeta pendiente no puede abrirse después de los reintentos, la captura finaliza como `NAVIGATION_INTERRUPTED`.

La lógica de Facebook y X permanece sin cambios.
