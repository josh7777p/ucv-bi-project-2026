# Validación HTML 1.5.15

Los extractos aportados confirman que el control de fecha contiene `aria-labelledby`, mientras el texto accesible se encuentra en otro nodo del documento. La prueba manual devolvió `15 min` mediante `document.getElementById`. La versión 1.5.15 implementa esa ruta como mecanismo principal.
