# Capturador BI UCV v1.5.22 — recorrido desde el menú de acciones

## Corrección principal

Facebook ya no selecciona primero un contenedor supuesto de tarjeta. La captura comienza globalmente en cada control accesible **Acciones en esta publicación**, igual que la prueba realizada en DevTools:

1. localizar el siguiente menú no procesado;
2. alinearlo debajo del encabezado fijo;
3. ascender al contenedor mínimo que contiene un solo menú;
4. resolver `aria-labelledby` mediante `document.getElementById`;
5. fijar la fecha antes de expandir el contenido;
6. obtener la tarjeta asociada, descripción, ID, URL y métricas;
7. persistir una sola vez y avanzar al siguiente menú.

## Seguridad

- `Último mes` se calcula desde la fecha de inicio de la captura.
- Se mantiene `DATE_CAPTURE_QUALITY_LOW` para detener una ejecución con baja cobertura inicial.
- No se realiza un segundo recorrido global ni se regresa al inicio.
- El módulo de X no fue modificado.
