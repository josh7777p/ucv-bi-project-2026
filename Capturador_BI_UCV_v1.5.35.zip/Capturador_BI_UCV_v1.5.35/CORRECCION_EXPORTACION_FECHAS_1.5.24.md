# Capturador BI UCV v1.5.24 — corrección final de fechas

- Acepta `AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT` y `AUTHOR_DATE_PRIVACY_VISUAL_EXACT` en la exportación JSON.
- Una fecha de calendario sin hora es válida y apta para el DW; `hora_publicacion` queda en `null`.
- El día límite se incluye completo. La captura solo confirma la salida del período al detectar publicaciones de un día anterior.
- Los contadores de enlaces y tooltips de privacidad se transmiten al resumen final.
- El módulo de X permanece sin cambios.
