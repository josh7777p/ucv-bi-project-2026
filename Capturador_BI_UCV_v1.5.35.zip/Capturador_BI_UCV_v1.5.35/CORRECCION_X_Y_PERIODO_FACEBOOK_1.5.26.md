# Capturador BI UCV 1.5.26

## X

- Corrige `databaseSummary is not defined`.
- Mantiene **Último mes** calculado desde la publicación propia más reciente recuperada.
- Incluye completo el día límite y se detiene al confirmar un día anterior.
- Corrige `bookmark_count` extrayendo el número asociado específicamente a `elemento(s) guardado(s)` o `bookmark(s)`.
- Conserva separadas las métricas de reposts externos.

## Facebook

- La ventana temporal se calcula desde la publicación propia, no fijada y con fecha confiable más reciente recuperada.
- Se conserva sin cambios la lógica aprobada de fechas, métricas, identificadores, expansión, recorrido, zoom y exportación.
- El día límite continúa incluyéndose completo.
