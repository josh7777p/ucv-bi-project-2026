# Validación sobre HTML guardado — v1.5.17

Se reprodujo la estrategia de la extensión sobre `77777.html`:

- Menús `Acciones en esta publicación` detectados: 37.
- Menús con una única fecha autónoma resuelta mediante `aria-labelledby`: 37.
- Sin fecha: 0.
- Ambiguos: 0.
- Nivel de contenedor observado: 3 en los 37 casos.

La validación estática confirma la lógica de asociación. La ejecución real en Facebook debe comprobarse con el JSON exportado, porque la plataforma puede re-renderizar y virtualizar las tarjetas durante el scroll.
