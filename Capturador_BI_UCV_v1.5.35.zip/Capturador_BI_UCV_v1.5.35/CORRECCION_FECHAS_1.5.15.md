# Corrección de fechas 1.5.15

La fuente canónica `AUTHOR_DATE_ARIA_LABELLEDBY_DOCUMENT` se reconoce en las cuatro capas del flujo:

1. `content/facebook-content.js`: detecta y calcula la fecha.
2. `utils/facebook-database.js`: persiste, bloquea y prioriza la fecha.
3. `background/service-worker.js`: la acepta como fecha analítica para el período.
4. `background/downloads.js`: conserva la fecha en el JSON exportado.

La fuente antigua `AUTHOR_DATE_VISUAL_LINE` no se considera confiable en las capas de persistencia y exportación.

La base local de Facebook se limpia al iniciar una captura nueva, salvo que se reanude expresamente una captura existente.
