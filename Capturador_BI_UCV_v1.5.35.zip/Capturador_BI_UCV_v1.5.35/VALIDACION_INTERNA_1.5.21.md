# Validación interna — Capturador BI UCV v1.5.21

Criterios mínimos antes de declarar la captura definitiva:

- `metadata_captura.version_extension = 1.5.21`.
- `modo_recorrido = ONE_PASS_CARD_TOP_V21`.
- Cobertura de fechas mínima de 98 %.
- Detención automática de Último mes al cruzar el límite.
- Identificadores únicos iguales al total de registros.
- Zona de métricas observada en todas las tarjetas procesadas.
- Sin segundo recorrido global.
- Zoom original restaurado al finalizar, detener o producirse un error.
