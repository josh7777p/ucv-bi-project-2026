# Verificación recomendada — Capturador BI UCV v1.5.27

- `metadata_captura.version_extension` debe ser `1.5.27`.
- `metadata_captura.modo_recorrido` debe ser `ONE_PASS_PRIVACY_TOOLTIP_V26`.
- `resumen_captura.zoom_captura` debe aproximarse a `0.4`.
- `resumen_captura.zoom_restaurado` debe ser `true`.
- `tarjetas_procesadas_una_pasada` debe coincidir con los registros detectados, salvo fusiones justificadas.
- `tarjetas_con_fecha_en_recorrido` debe ser igual o muy cercana a las tarjetas procesadas.
- `fechas_exactas_resueltas_por_tooltip_privacidad` debe ser alta para las fechas relativas.
- En las publicaciones recientes debe predominar `AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT`.
- `fecha_tooltip_raw` debe contener la fecha completa cuando `fecha_visible_raw` sea relativa.
- `identificador_publicacion_origen` debe permanecer único.
- Las métricas deben coincidir con los contadores visibles de Facebook.
- Las descripciones no deben terminar en `Ver más` ni `Ver menos`.
- La pestaña no debe regresar al inicio durante la captura.


## Comprobaciones adicionales 1.5.25

- `enlaces_fecha_por_icono_privacidad` debe ser mayor que cero cuando se utilice la ruta del icono.
- `fechas_exactas_resueltas_por_tooltip_privacidad` debe coincidir con los registros cuyo origen sea `AUTHOR_DATE_PRIVACY_TOOLTIP_EXACT`.
- `metricas_raw.<métrica>` debe corresponder al `valor_maximo` de esa métrica.
- `metricas_raw_ultima_observacion` puede diferir del máximo cuando el contador visible cambie entre observaciones; esto no modifica la métrica operativa.

## Comprobaciones de X 1.5.27

- La captura no debe mostrar `databaseSummary is not defined`.
- En **Último mes**, `periodo_calculado_desde` debe ser `PUBLICACION_MAS_RECIENTE_RECUPERADA`.
- `fecha_limite_periodo` debe corresponder al día de la publicación más reciente menos un mes.
- El día límite debe incluirse completo.
- `bookmark_count` debe coincidir con el número que precede a `elemento(s) guardado(s)` o `bookmark(s)` en la evidencia raw.
- Todo `created_at` de X interpretable debe exportarse en ISO 8601 (`YYYY-MM-DDTHH:mm:ss.sssZ`).
