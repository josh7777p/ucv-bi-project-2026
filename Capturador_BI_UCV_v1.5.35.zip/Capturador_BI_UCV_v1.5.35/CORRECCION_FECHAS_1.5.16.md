# Corrección de fechas de Facebook — v1.5.16

## Alcance

Esta versión modifica únicamente la captura de Facebook. Los archivos del módulo de X/Twitter permanecen idénticos a la v1.5.15.

## Estrategia incorporada

1. Usa como ancla el botón accesible `Acciones en esta publicación`.
2. Asciende progresivamente por el DOM hasta el primer contenedor mínimo con un solo botón de acciones.
3. Busca controles con `aria-labelledby` dentro de ese contenedor.
4. Resuelve cada identificador mediante `document.getElementById(id)`.
5. Acepta únicamente una fecha autónoma y válida. No utiliza fechas del cuerpo, comentarios ni la posición del feed.
6. Conserva el texto original en `fecha_raw` y convierte el valor a ISO, `YYYY-MM-DD` y `DD/MM/YYYY` mediante el procesamiento existente.
7. Las fechas relativas (`4 h`, `1 día`, etc.) se calculan respecto a la fecha y hora real de observación y conservan esa referencia.

## Validación previa

El script ejecutado en DevTools detectó 37 publicaciones, 37 fechas únicas, 0 ausencias y 0 ambigüedades. Todas se localizaron en el contenedor mínimo alcanzado desde el botón de acciones.

## Diagnóstico exportado

- `fecha_origen_deteccion`
- `fecha_id_aria`
- `fecha_nivel_contenedor_acciones`
- `fecha_etiqueta_menu_acciones`

La fuente principal esperada es `AUTHOR_DATE_ACTION_ARIA_LABELLEDBY_DOCUMENT`.
