# Resultado de validación — v1.5.22

## Validaciones de archivos

- Todos los archivos JavaScript superaron `node --check`.
- Todos los archivos JSON son válidos.
- Los tres archivos principales de X conservaron exactamente sus hashes de la v1.5.21.

## Prueba estructural independiente sobre `9999.html`

- Menús `Acciones en esta publicación`: 34.
- Fechas asociadas por `aria-labelledby`: 34.
- Fechas faltantes: 0.
- Asociaciones ambiguas: 0.
- Nivel estructural: 3 en todos los casos.

## Prueba operativa del content script completo sobre el HTML guardado

- Modo: `ONE_PASS_ACTION_MENU_V22`.
- Publicaciones procesadas: 34.
- Menús procesados: 34.
- Publicaciones con fecha: 34.
- Publicaciones sin fecha: 0.
- Zonas de métricas observadas: 34.
- Identificadores únicos: 34.
- Fuente de extracción: `FACEBOOK_DOM_ACTION_MENU_V22`.

## Prueba de `Último mes` sobre el HTML guardado

- Finalización: `DATE_WINDOW_REACHED`.
- Publicaciones procesadas antes del límite: 28.
- Publicaciones con fecha: 28.
- Publicaciones sin fecha: 0.
- Menús procesados: 28.
- Zonas de métricas observadas: 28.
- La captura se detuvo antes de llegar al fondo del documento.

Estas pruebas utilizan un HTML guardado y no sustituyen una ejecución dinámica en Facebook. La aprobación definitiva depende del JSON generado por la prueba real del usuario.
