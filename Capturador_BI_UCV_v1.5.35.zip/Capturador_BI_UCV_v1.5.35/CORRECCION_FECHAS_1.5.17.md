# Corrección de fechas de Facebook — v1.5.17

Esta versión mantiene la estrategia validada en DevTools y corrige el momento de ejecución durante el scroll.

## Ruta principal

1. Detecta el botón accesible `Acciones en esta publicación`.
2. Asciende al primer contenedor mínimo que contiene un único menú de publicación.
3. Busca los controles `aria-labelledby` dentro de ese contenedor.
4. Resuelve el texto con `document.getElementById(id)`.
5. Acepta únicamente una fecha autónoma del encabezado.
6. Conserva `fecha_raw` y genera los formatos ISO, `YYYY-MM-DD` y `DD/MM/YYYY`.

## Recuperación de hidratación

- Se realiza un barrido global antes de extraer las tarjetas.
- Cuando un menú cercano al viewport todavía no tiene fecha, se espera y se reintenta de forma limitada.
- Las fechas resueltas se fijan en una caché DOM por menú y por tarjeta.
- Antes de finalizar se recorre el feed hacia el inicio con solapamiento y se actualizan los registros pendientes por su ID o firma de contenido.
- Dos controles con el mismo texto de fecha se consolidan como una sola evidencia.
- Dos fechas distintas en el mismo contenedor se mantienen como ambigüedad y no se infieren.

## Alcance

Los cambios se limitan al archivo modular `content/facebook-content.js` y a la identificación de versión/documentación de Facebook. Los archivos propios de X/Twitter permanecen intactos.
