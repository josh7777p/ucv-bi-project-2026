# Validación interna — v1.5.22

- Unidad de recorrido Facebook: menú accesible de acciones.
- Dirección de asociación: menú → fecha → tarjeta.
- Zoom temporal: 40 %.
- Límite de período: fecha de inicio de captura.
- Protección de calidad: activa.
- La validación dinámica definitiva depende de una ejecución real en Facebook.
