# Capturador BI UCV v1.5.21 — corrección de fechas y recorrido

- Zoom temporal de Facebook reducido a 40 % y restauración del zoom original.
- Cada tarjeta se alinea bajo el menú superior y se valida la visibilidad de su encabezado.
- La fecha se obtiene antes de expandir el cuerpo o desplazar hacia las métricas.
- Se acepta `AUTHOR_DATE_HOVER_TOOLTIP` como fuente analítica confiable.
- Se añade respaldo aria-labelledby estrictamente local a la tarjeta.
- Una fecha obtenida se conserva aunque una re-renderización posterior oculte el encabezado.
- El recorrido se detiene automáticamente si la cobertura inicial de fechas es insuficiente.
- No se realiza una segunda pasada ni se regresa al inicio.
