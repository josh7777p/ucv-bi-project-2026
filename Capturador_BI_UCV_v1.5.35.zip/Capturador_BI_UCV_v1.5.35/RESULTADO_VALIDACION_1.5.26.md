# Resultado de validación — v1.5.26

## X

- Se declaró y consultó `databaseSummary` antes de construir el resultado final.
- La ventana temporal se calcula desde la publicación propia, no fijada, más reciente recuperada.
- El día límite se normaliza al inicio del día y se incluye completo.
- La captura se detiene al confirmar una publicación de un día anterior al límite.
- El parser de guardados fue comprobado contra los 294 registros del archivo de referencia:
  - 286 evidencias raw interpretables.
  - 0 evidencias raw sin interpretar.
  - 40 valores que la versión anterior habría asociado al número equivocado.
  - 30 correcciones en publicaciones propias y 10 en reposts externos.
- Visualizaciones, Me gusta, reposts, respuestas y citas no fueron modificados.

## Facebook

- Solo se cambió el origen de la referencia temporal: ahora usa la publicación propia, no fijada y con fecha confiable más reciente recuperada.
- Se conserva completo el día límite.
- No se modificaron los parsers de fechas, métricas, identificadores, cuerpos, enlaces ni multimedia.
- Prueba estática controlada: 5 publicaciones, 5 fechas, 5 zonas de métricas y 5 identificadores únicos.
- El zoom temporal se mantiene en 0,4 y el recorrido continúa siendo de una sola pasada.

## Integridad

- Todos los archivos JavaScript superaron `node --check`.
- Todos los archivos JSON internos son válidos.
- `content/feed-parser.js` e `content/interceptor.js` permanecen idénticos a la v1.5.25.
- La confirmación definitiva requiere una nueva ejecución dinámica en X y Facebook.
